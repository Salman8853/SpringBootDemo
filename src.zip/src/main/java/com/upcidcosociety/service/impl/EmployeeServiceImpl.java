/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.EmployeeDao;
import com.upcidcosociety.dtob.Employee;
import com.upcidcosociety.model.EmployeeModel;
import com.upcidcosociety.service.EmployeeService;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService{
    
 @Autowired
 private EmployeeDao employeeDao;
   
 
 @Override
 public int addEmployee(EmployeeModel employee) {
     Employee emp =new Employee();
              emp.setEmpId(employee.getId());
              emp.setEmpName(employee.getName());
              emp.setEmpAddress(employee.getAddress());
              emp.setEmpAge(employee.getAge());
              emp.setSalary(employee.getSalary());
             return employeeDao.addEmployee(emp);
 }
}
