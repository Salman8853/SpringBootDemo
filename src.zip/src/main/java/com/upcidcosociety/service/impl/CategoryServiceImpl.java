/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.CategoryDao;
import com.upcidcosociety.dao.EmployeeDao;
import com.upcidcosociety.dtob.Category;
import com.upcidcosociety.service.CategoryService;
import com.upcidcosociety.util.UpcidConstants;
import com.upcidcosociety.util.UpcidResponse;
import com.upcidcosociety.util.UtilDate;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class CategoryServiceImpl implements CategoryService {
    
 @Autowired
 private CategoryDao categoryDao; 
 
 @Override
  public UpcidResponse addCategory(String remoteaddress,Category category){
      UpcidResponse response=new UpcidResponse();
      
      try {
          if(category!=null && category.getCategoryName()!=null && category.getCategoryName().trim().length()>0){
              List<Category>catlst = categoryDao.checkCategoryByidAndName(category.getCatId(), category.getCategoryName());
                if(catlst!=null && catlst.size()>0){
                 response.setResponsecode(UpcidConstants.REAPONSECODE_NOTFOUND);
                 response.setMessage("Category already exist");
                 response.setData(category);
                  return response;
                }
                Category  ct= new Category();
                 ct.setCategoryName(category.getCategoryName());
            
                 ct.setCreatedDate(UtilDate.convertDatetoTimestamp(new Date()));
                 ct.setIpAddress(remoteaddress);
          
                Integer catId=categoryDao.addCategory(ct);
                if(catId>0){
                    response.setResponsecode(UpcidConstants.REAPONSECODE_SUCCESS);
                    response.setMessage("Record saved");
                    response.setData(catId);
                }else{
                    response.setResponsecode(UpcidConstants.REAPONSECODE_FAILED);
                    response.setMessage("Record not saved");
                    response.setData(catId);
                }
                
          }else{
            response.setResponsecode(UpcidConstants.REAPONSECODE_NOTFOUND);
            response.setMessage("Plaese enter mandatory fields");
            response.setData(null);
          }
      } catch (Exception e) {
          
         response= new UpcidResponse(UpcidConstants.REAPONSECODE_UNAUTHORIZED, "Exception occured");
          e.printStackTrace();
      }
      
     return response;
  }
 
}
