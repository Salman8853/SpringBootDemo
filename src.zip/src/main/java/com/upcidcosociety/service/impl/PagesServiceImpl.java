/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.PagesDao;
import com.upcidcosociety.dtob.Pages;
import com.upcidcosociety.service.PagesService;
import com.upcidcosociety.util.UpcidConstants;
import com.upcidcosociety.util.UpcidResponse;
import com.upcidcosociety.util.UtilDate;
import java.util.Date;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class PagesServiceImpl  implements PagesService {
    
   @Autowired
   private PagesDao pagesDao;
   
     @Override
     public UpcidResponse addPages(String remoteaddress,Pages pages){
          UpcidResponse response=new UpcidResponse();
         try {
             if(pages!=null && pages.getPageTitle()!=null && pages.getPageTitle().trim().length()>0 && pages.getPageContent()!=null &&pages.getPageContent().trim().length()>0){
                 
                    // check duplicate pages first
                    
                    Pages page=new Pages();
                    page.setPageTitle(pages.getPageTitle());
                    page.setPageContent(pages.getPageContent());
                    page.setCreatedBy(pages.getPageTitle());
                    page.setCreatedDate(UtilDate.convertDatetoTimestamp(new Date()));
                    page.setIpAddress(remoteaddress);
                   Integer pageId=  pagesDao.addPages(page);
                   if(pageId!=null && pageId>0){
                    response.setResponsecode(UpcidConstants.REAPONSECODE_SUCCESS);
                    response.setMessage("Record saved");
                    response.setData(pageId); 
                   }else{
                    response.setResponsecode(UpcidConstants.REAPONSECODE_FAILED);
                    response.setMessage("Failed");
                    response.setData(pageId);
                   }
                  
             }else{
                 response.setResponsecode(UpcidConstants.REAPONSECODE_NOTFOUND);
                 response.setMessage("Please mandatory fields");
                 response.setData(null);
             }
         } catch (Exception e) {
              response= new UpcidResponse(UpcidConstants.REAPONSECODE_UNAUTHORIZED, "Exception occured");
              e.printStackTrace();
         }
      return response;
     }
}
