/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao;

import com.upcidcosociety.dtob.Employee;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository("EmployeeDao")
public class EmployeeDaoImpl implements EmployeeDao {
 
  @Autowired
  private SessionFactory sessionFactory; 

  @Override
  public int addEmployee(Employee employee) {
       this.sessionFactory.openSession().save(employee);
		
		return employee.getEmpId();
      
        
 }  
}
