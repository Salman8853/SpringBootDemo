/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.PagesDao;
import com.upcidcosociety.dtob.Pages;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class PagesDaoImpl  implements PagesDao {
  
  @Autowired
  private SessionFactory sessionFactory;
    
     @Override
     public Integer addPages(Pages pages){
         Session session = sessionFactory.openSession();
         Integer pageId = (Integer) session.save(pages);
         return pageId;
     }
}
