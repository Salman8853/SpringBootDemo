/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.controller;

import com.upcidcosociety.dtob.Pages;
import com.upcidcosociety.service.PagesService;
import com.upcidcosociety.util.UpcidResponse;
import java.security.Principal;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *
 * @author m.salman
 */
@Controller
public class PagesController {
    @Autowired
     private PagesService pagesService;
    
    @RequestMapping(value = "/pages", method = RequestMethod.GET)
    public String savepages(Pages pages) {
        return "pages";
    }
     @RequestMapping(value = "/addpages", method = RequestMethod.POST)
    public String savepages(Pages pages, HttpServletRequest request) {
        pagesService.addPages(request.getRemoteAddr(), pages);
        return "pages";
    }
    
}
