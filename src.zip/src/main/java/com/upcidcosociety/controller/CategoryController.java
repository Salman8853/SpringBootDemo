/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.controller;

import com.upcidcosociety.dtob.Category;
import com.upcidcosociety.service.CategoryService;
import com.upcidcosociety.util.UpcidResponse;
import java.security.Principal;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *
 * @author m.salman
 */
@Controller
public class CategoryController {
    @Autowired
     private CategoryService categoryService;
    
    
     @RequestMapping(value = "/category", method = RequestMethod.GET)
    public String savecategory(ModelMap map, HttpServletRequest request, Principal principal){
          map.addAttribute("category_form", new Category());
          return "category";
    }
    
   @RequestMapping(value = "/addcategory", method = RequestMethod.POST)
   public  String saveCategory( @ModelAttribute("category_form")Category category,ModelMap map, BindingResult result,HttpServletRequest request, Principal principal) {
       UpcidResponse upcidResponse=null;
       if(result.hasErrors()){
       
       }else{
        upcidResponse= categoryService.addCategory(request.getRemoteAddr(), category);
       
          map.addAttribute("catRes", upcidResponse);
       
        }
       
        return "hello";
 } 
    
}
