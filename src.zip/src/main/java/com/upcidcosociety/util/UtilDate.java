/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.util;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.slf4j.Logger;


/**
 *
 * @author m.salman
 */
public class UtilDate {
//    private static final  Logger = LoggerFactory.getLogger(UtilDate.class);
    public static final SimpleDateFormat dd_MM_yyyy = new SimpleDateFormat("dd-MM-yyyy");
    public static final SimpleDateFormat MM_dd_yyyy = new SimpleDateFormat("MM-dd-yyyy");
    public static final SimpleDateFormat MMsddsyyyy = new SimpleDateFormat("MM/dd/yyyy");
//    public static SimpleDateFormat CLIENT_SDF = new SimpleDateFormat("MMM dd, yyyy hh:mm:ss");
    public static final SimpleDateFormat MM_dd_yyyy_hh_mm_ss = new SimpleDateFormat("MM-dd-yyyy hh:mm:ss");
    public static final SimpleDateFormat MM_dd_yyyy_HH_mm_ss = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
    public static final SimpleDateFormat YYYY_MM_dd_HH_mm_ss = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    public static final SimpleDateFormat MM_dd_yyyy_hh_mm = new SimpleDateFormat("MM-dd-yyyy hh:mm");
    public static SimpleDateFormat dbDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    public static SimpleDateFormat dbDateTimeFormat = new SimpleDateFormat("yyyy-MM-dd  hh:mm:ss");
    public static SimpleDateFormat D_MMM_YYYY_H_MM_A = new SimpleDateFormat("d MMM yyyy (h:mm a)");
    
     public static String formateDateToString_YYYY_MM_dd_HH_mm_ss(Date date) {
       try {
            if (date != null) {
                return YYYY_MM_dd_HH_mm_ss.format(date);
            }
        } catch (Exception e) {
//            LOGGER.error("Error", e);
        }
        return YYYY_MM_dd_HH_mm_ss.format(new Date());

    }
     public static String formatetdateToStringMM_dd_yyyy(Date date) {
        try {
            if (date != null) {
                return MM_dd_yyyy.format(date);
            }
        } catch (Exception e) {
//            LOGGER.error("Error", e);
        }
        return MM_dd_yyyy.format(new Date());
    }
      public static String formatedateTostring_MM_dd_yyyy_HH_mm_ss(Date date) {
        try {
            if (date != null) {
                return MM_dd_yyyy_HH_mm_ss.format(date);
            }
        } catch (Exception e) {
//            LOGGER.error("Error", e);
        }
        return MM_dd_yyyy_HH_mm_ss.format(new Date());
    }
      
       public static Timestamp convertDatetoTimestamp(Date dateStr) {
        Timestamp timestamp = new Timestamp(dateStr.getTime());
        return timestamp;
    }
     
       
 
}   
 
