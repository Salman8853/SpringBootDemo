/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.util;

/**
 *
 * @author m.salman
 */
public class UpcidConstants {
    
    public static final int REAPONSECODE_SUCCESS=200; 
    public static final int REAPONSECODE_FAILED=400;
    public static final int REAPONSECODE_NOTVALID=400;
    public static final int REAPONSECODE_NOTFOUND=404;
    public static final int REAPONSECODE_UNAUTHORIZED=401;
    public static final int REAPONSECODE_ALREADYEXIST=409;
}
