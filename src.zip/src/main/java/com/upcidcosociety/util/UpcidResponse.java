/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.util;

import java.util.Date;

/**
 *
 * @author m.salman
 */
public class UpcidResponse {
    private int responsecode;
    private String message;
    private Object data ;

    public UpcidResponse() {
    }

  
   public UpcidResponse(int responsecode, String message) {
        this.responsecode = responsecode;
        this.message = message;
    }
    public int getResponsecode() {
        return responsecode;
    }

    public void setResponsecode(int responsecode) {
        this.responsecode = responsecode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

   
    
}
