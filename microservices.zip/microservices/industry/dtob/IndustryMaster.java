package com.gigflex.prototype.microservices.industry.dtob;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.util.CommonAttributes;


@Entity
@Table(name = "industry_master")
public class IndustryMaster extends CommonAttributes implements Serializable {
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "id")
	    private Integer id;

	    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	    @GenericGenerator(name = "uuid", strategy = "uuid2")
	    @Column(name = "industry_code", unique = true)
	    private String industryCode;
	     
	    @Column(name = "industry_name", nullable = false)
	    private String industryName;
	    
	    @PrePersist
	    private void assignUUID() {
	    	if (this.getIndustryCode() == null || this.getIndustryCode().length() == 0) {
	    		 this.setIndustryCode(UUID.randomUUID().toString());	 
	    		 }
         }


		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}

		public String getIndustryCode() {
			return industryCode;
		}

		public void setIndustryCode(String industryCode) {
			this.industryCode = industryCode;
		}

		public String getIndustryName() {
			return industryName;
		}

		public void setIndustryName(String industryName) {
			this.industryName = industryName;
		}
	    
	    

}
