/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.organizationbaseprocedure.api;

import com.gigflex.prototype.microservices.organizationbaseprocedure.dtob.OrganizationBaseProcedureRequest;
import com.gigflex.prototype.microservices.organizationbaseprocedure.service.OrganizationBaseProcedureService;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author amit.kumar
 */
@CrossOrigin(origins="*")
@RestController
@RequestMapping("/healthcareservice/")
public class OrganizationBaseProcedureController {
    
    
    @Autowired
    public OrganizationBaseProcedureService orgBasedProcedureService;
     
    @GetMapping("/getAllProcedureByOrganizationCode/{organizationCode}")
    public String getAllProcedureByOrganizationCode(@PathVariable String organizationCode){
            return orgBasedProcedureService.findAllProcedureByOrganizationCode(organizationCode);
    }     
     
    @GetMapping("/getProcedureByOrganizationCodeAndProcedureCode/{organizationCode}/{procedureCode}")
    public String getProcedureByOrganizationCodeAndProcedureCode(@PathVariable String organizationCode,@PathVariable String procedureCode) {
            return orgBasedProcedureService.findProcedureByOrganizationCodeAndProcedureCode(organizationCode,procedureCode);
    }
    
    @PutMapping("/updateProcedureByOrganizationBasedProcedureCode/{organizationBaseProcedureCode}")
    public String updateProcedureByOrganizationBasedProcedureCode(@PathVariable String organizationBaseProcedureCode,@RequestBody OrganizationBaseProcedureRequest orgBaseProcedureReq,HttpServletRequest request) {

            if (organizationBaseProcedureCode == null) {
                    return  "Organization Base Procedure Code with organizationBaseProcedureCode : (" + organizationBaseProcedureCode + ") Not found.";
            }            
            else {
                    String ip = request.getRemoteAddr();

                    return orgBasedProcedureService.updateProcedureByOrganizationBasedProcedureCode(organizationBaseProcedureCode,orgBaseProcedureReq,ip);
            }
    }
    
    
    @PostMapping("/saveOrganizationBasedProcedure")
    public String saveOrganizationBasedProcedure( @RequestBody OrganizationBaseProcedureRequest orgBaseProcedureReq,HttpServletRequest request){
                String ip = request.getRemoteAddr();

          return orgBasedProcedureService.saveOrganizationBaseProcedure(orgBaseProcedureReq,ip);

    }
    
}
