/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.organizationbaseprocedure.repository;

import com.gigflex.prototype.microservices.organizationbaseprocedure.dtob.OrganizationBaseProcedure;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author amit.kumar
 */
@Repository
public interface OrganizationBaseProcedureDao extends JpaRepository<OrganizationBaseProcedure,Integer>,JpaSpecificationExecutor<OrganizationBaseProcedure>{

    @Query("SELECT obp FROM OrganizationBaseProcedure obp WHERE obp.isDeleted != TRUE AND obp.organizationCode = :organizationCode")
    public List<OrganizationBaseProcedure> getAllByOrganizationCode(@Param("organizationCode") String organizationCode);

    @Query("SELECT obp FROM OrganizationBaseProcedure obp WHERE obp.isDeleted != TRUE AND obp.organizationCode = :organizationCode AND obp.procedureCode = :procedureCode")
    public OrganizationBaseProcedure getByOrganizationCodeAndProcedureCode(@Param("organizationCode") String organizationCode, @Param("procedureCode") String procedureCode);

    @Query("SELECT obp FROM OrganizationBaseProcedure obp WHERE obp.isDeleted != TRUE AND obp.organizationCode = :organizationCode AND obp.procedureCode = :procedureCode AND obp.organizationBaseProcedureCode != :organizationBaseProcedureCode")
    public OrganizationBaseProcedure getForCheckByOrganizationBaseProcedureCodeOrgCodeAndProcedureCode(@Param("organizationBaseProcedureCode") String organizationBaseProcedureCode,@Param("organizationCode") String organizationCode,@Param("procedureCode") String procedureCode);

    @Query("SELECT obp FROM OrganizationBaseProcedure obp WHERE obp.isDeleted != TRUE AND obp.organizationBaseProcedureCode = :organizationBaseProcedureCode")
    public OrganizationBaseProcedure getByOrganizationBaseProcedureCode(@Param("organizationBaseProcedureCode") String organizationBaseProcedureCode);

    
    
    
    
}
