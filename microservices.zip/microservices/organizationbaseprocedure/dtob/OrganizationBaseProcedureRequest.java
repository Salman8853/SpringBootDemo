/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.organizationbaseprocedure.dtob;

/**
 *
 * @author amit.kumar
 */
public class OrganizationBaseProcedureRequest {
    
    private Integer id;
    private String organizationBaseProcedureCode;
    private String procedureCode;
    private String organizationCode;
    private String procedureName;
    private String procedureDescription;
    private String procedureIcon;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOrganizationBaseProcedureCode() {
        return organizationBaseProcedureCode;
    }

    public void setOrganizationBaseProcedureCode(String organizationBaseProcedureCode) {
        this.organizationBaseProcedureCode = organizationBaseProcedureCode;
    }

    public String getProcedureCode() {
        return procedureCode;
    }

    public void setProcedureCode(String procedureCode) {
        this.procedureCode = procedureCode;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public String getProcedureName() {
        return procedureName;
    }

    public void setProcedureName(String procedureName) {
        this.procedureName = procedureName;
    }

    public String getProcedureDescription() {
        return procedureDescription;
    }

    public void setProcedureDescription(String procedureDescription) {
        this.procedureDescription = procedureDescription;
    }

    public String getProcedureIcon() {
        return procedureIcon;
    }

    public void setProcedureIcon(String procedureIcon) {
        this.procedureIcon = procedureIcon;
    }
    
    
    
}
