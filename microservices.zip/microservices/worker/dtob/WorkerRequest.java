package com.gigflex.prototype.microservices.worker.dtob;


public class WorkerRequest {
	
	   private String name;
	   
	    private String email;
	    
	    private String departmentCode;
	    
	    private String phone;
	    
	    private Integer expYear;
	    
	    private Integer expMonth;  
	    
	    private Integer expDays; 
	    
	    private String qualification; 
	    
	    private String externalEmpCode; 
	    
	    private String preWorkingHours; 
	   
	    private Boolean isActive; 

	    private String workerStatusCode;
	    
	    private String workerLogo;

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getDepartmentCode() {
			return departmentCode;
		}

		public void setDepartmentCode(String departmentCode) {
			this.departmentCode = departmentCode;
		}

		public String getPhone() {
			return phone;
		}

		public void setPhone(String phone) {
			this.phone = phone;
		}

		public Integer getExpYear() {
			return expYear;
		}

		public void setExpYear(Integer expYear) {
			this.expYear = expYear;
		}

		public Integer getExpMonth() {
			return expMonth;
		}

		public void setExpMonth(Integer expMonth) {
			this.expMonth = expMonth;
		}

		public Integer getExpDays() {
			return expDays;
		}

		public void setExpDays(Integer expDays) {
			this.expDays = expDays;
		}

		public String getQualification() {
			return qualification;
		}

		public void setQualification(String qualification) {
			this.qualification = qualification;
		}

		public String getExternalEmpCode() {
			return externalEmpCode;
		}

		public void setExternalEmpCode(String externalEmpCode) {
			this.externalEmpCode = externalEmpCode;
		}

		public String getPreWorkingHours() {
			return preWorkingHours;
		}

		public void setPreWorkingHours(String preWorkingHours) {
			this.preWorkingHours = preWorkingHours;
		}

		public Boolean getIsActive() {
			return isActive;
		}

		public void setIsActive(Boolean isActive) {
			this.isActive = isActive;
		}

		public String getWorkerStatusCode() {
			return workerStatusCode;
		}

		public void setWorkerStatusCode(String workerStatusCode) {
			this.workerStatusCode = workerStatusCode;
		}

		public String getWorkerLogo() {
			return workerLogo;
		}

		public void setWorkerLogo(String workerLogo) {
			this.workerLogo = workerLogo;
		}
	    
	    

}
