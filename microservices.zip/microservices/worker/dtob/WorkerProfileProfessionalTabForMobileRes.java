/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.worker.dtob;

import java.util.List;

/**
 *
 * @author m.salman
 */
public class WorkerProfileProfessionalTabForMobileRes {
    private String name;
    private String email;
    private String password;
    private String cpassword;
    private String workerLogo;
    private String language;
    private String dob;
    private String mobileNo;
    private String emergencyNo;
    private String address;
    private String city;
    private String postCode;
    private String country;
    private String latitude;
    private String longitude;
    private String designation;
    private String homeCountryCode;
    private String workerCountryCode;
    private String employmentTypeCode;
    private String employmentTypeName;
    private String qualification;
    private Integer expYear; 
    private Integer expMonth; 
    private Integer expDays; 
    
    private List <OrganizationWiseApproval> organizationWiseApprovalList;

    public List<OrganizationWiseApproval> getOrganizationWiseApprovalList() {
        return organizationWiseApprovalList;
    }

    public void setOrganizationWiseApprovalList(List<OrganizationWiseApproval> organizationWiseApprovalList) {
        this.organizationWiseApprovalList = organizationWiseApprovalList;
    }
    
    
    public String getEmploymentTypeCode() {
        return employmentTypeCode;
    }

    public void setEmploymentTypeCode(String employmentTypeCode) {
        this.employmentTypeCode = employmentTypeCode;
    }

    public String getEmploymentTypeName() {
        return employmentTypeName;
    }

    public void setEmploymentTypeName(String employmentTypeName) {
        this.employmentTypeName = employmentTypeName;
    }
    
    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getHomeCountryCode() {
        return homeCountryCode;
    }

    public void setHomeCountryCode(String homeCountryCode) {
        this.homeCountryCode = homeCountryCode;
    }

    public String getWorkerCountryCode() {
        return workerCountryCode;
    }

    public void setWorkerCountryCode(String workerCountryCode) {
        this.workerCountryCode = workerCountryCode;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    

    public String getCpassword() {
        return cpassword;
    }

    public void setCpassword(String cpassword) {
        this.cpassword = cpassword;
    }

    public String getWorkerLogo() {
        return workerLogo;
    }

    public void setWorkerLogo(String workerLogo) {
        this.workerLogo = workerLogo;
    }

    
    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getEmergencyNo() {
        return emergencyNo;
    }

    public void setEmergencyNo(String emergencyNo) {
        this.emergencyNo = emergencyNo;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPostCode() {
        return postCode;
    }

    public void setPostCode(String postCode) {
        this.postCode = postCode;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public Integer getExpYear() {
        return expYear;
    }

    public void setExpYear(Integer expYear) {
        this.expYear = expYear;
    }

    public Integer getExpMonth() {
        return expMonth;
    }

    public void setExpMonth(Integer expMonth) {
        this.expMonth = expMonth;
    }

    public Integer getExpDays() {
        return expDays;
    }

    public void setExpDays(Integer expDays) {
        this.expDays = expDays;
    }
    
}
