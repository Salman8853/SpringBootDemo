package com.gigflex.prototype.microservices.worker.dtob;

import java.util.List;

public class WorkerResponse {
	private Worker worker;
	
private List<WorkerApprovalStatusResponse> workerApprovalStatusResponseList;

	

	public Worker getWorker() {
		return worker;
	}

	public void setWorker(Worker worker) {
		this.worker = worker;
	}

	public List<WorkerApprovalStatusResponse> getWorkerApprovalStatusResponseList() {
		return workerApprovalStatusResponseList;
	}

	public void setWorkerApprovalStatusResponseList(
			List<WorkerApprovalStatusResponse> workerApprovalStatusResponseList) {
		this.workerApprovalStatusResponseList = workerApprovalStatusResponseList;
	}

    
    


}
