package com.gigflex.prototype.microservices.worker.repository;

import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkerApprovalStatus;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.gigflex.prototype.microservices.worker.dtob.Worker;

/**
 * 
 * @author ajit.p
 *
 */
@Repository
public interface WorkerRepository extends JpaRepository<Worker, Long> ,JpaSpecificationExecutor<Worker>{

	@Query("SELECT w FROM Worker w WHERE w.isDeleted != TRUE AND w.workerCode = :workerCode")
	public Worker findByWorkerCode(@Param("workerCode") String workerCode);

	@Transactional
	public Integer deleteByWorkerCode(String workerCode);

	@Query("SELECT org.organizationCode, org.organizationName,was.color FROM Organization org, WorkerApprovalStatus was  WHERE was.isDeleted != TRUE AND was.organization_Code=org.organizationCode AND  was.workerCode = :workerCode")
	public List<Object> getOrganizationByWorkerCode(
			@Param("workerCode") String workerCode);
	
	@Query("SELECT org.organizationCode, org.organizationName,was.color FROM Organization org, WorkerApprovalStatus was  WHERE was.isDeleted != TRUE AND was.organization_Code=org.organizationCode AND  was.workerCode = :workerCode")
	public List<Object> getOrganizationByWorkerCode(
			@Param("workerCode") String workerCode,Pageable pageableRequest);

	@Query("SELECT w FROM Worker w WHERE w.isDeleted != TRUE")
	public List<Worker> getAllWorkers();
	
//	@Query("SELECT was FROM WorkerApprovalStatus was WHERE was.isDeleted != TRUE AND was.workerCode=:workerCode")
//	public List<WorkerApprovalStatus> findWorkerApprovalStatusByWorkerCode(@Param("workerCode") String workerCode);
	
	@Query("SELECT was,org.organizationName FROM WorkerApprovalStatus was,Organization org WHERE was.isDeleted != TRUE AND was.workerCode=:workerCode AND was.organization_Code=org.organizationCode")
	public List<Object> findWorkerApprovalStatusByWorkerCode(@Param("workerCode") String workerCode);
	
        @Query("SELECT was FROM WorkerApprovalStatus was,Organization org WHERE was.isDeleted != TRUE AND org.isDeleted != TRUE AND was.workerCode=:workerCode AND was.organization_Code=org.organizationCode")
	public List<WorkerApprovalStatus> getAllWorkerApprovalStatusByWorkerCode(@Param("workerCode") String workerCode);
	
	
//	@Query("SELECT w, was.isApproved FROM Worker w, WorkerApprovalStatus was WHERE w.isDeleted != TRUE AND w.workerCode = was.workerCode ")
//	public List<Object> getAllWorkers();
	
    @Query("SELECT b,a.id,a.isApproved FROM WorkerApprovalStatus a , Worker b WHERE b.isDeleted != TRUE AND a.workerCode=b.workerCode")
    public List<Object> getAllWorkersWithApprovedAndId();

	@Query("SELECT w FROM Worker w WHERE w.isDeleted != TRUE")
	public List<Worker> getAllWorkers(Pageable pageableRequest);

	@Query("SELECT w FROM Worker w WHERE w.isDeleted != TRUE AND w.id = :id")
	public Worker getWorkerById(@Param("id") Long id);
        
        @Query("SELECT w FROM Worker w WHERE w.isDeleted != TRUE AND w.workerCode=:workercode")
	public Worker getWorkerProfileTabsByworkerCode(@Param("workercode") String workercode);
        
        @Query("SELECT w FROM Worker w WHERE w.isDeleted != TRUE AND w.workerCode=:workercode")
	public Worker getWorkerdetailByworkerCode(@Param("workercode") String workercode);
        
        @Query("SELECT w FROM Worker w WHERE w.isDeleted != TRUE AND w.workerCode!=:workerCode AND w.email=:email")
        public Worker getUniqueWorkerByWorkerCodeAndemail(@Param("workerCode")String workerCode,@Param("email")String email);
}
