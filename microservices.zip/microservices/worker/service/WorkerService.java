package com.gigflex.prototype.microservices.worker.service;


import com.gigflex.prototype.microservices.worker.dtob.UpdateWrkrProfileforMobileByworkerCode;
import com.gigflex.prototype.microservices.worker.dtob.WorkerDetailsReq;
import com.gigflex.prototype.microservices.worker.dtob.WorkerDetailsRes;

import com.gigflex.prototype.microservices.worker.dtob.WorkerHomelocationReq;
import java.util.List;

import com.gigflex.prototype.microservices.worker.dtob.WorkerLogoRequest;
import com.gigflex.prototype.microservices.worker.dtob.WorkerProfileForMobileReq;
import com.gigflex.prototype.microservices.worker.dtob.WorkerProfileForMobileRes;
import com.gigflex.prototype.microservices.worker.dtob.WorkerProfileProfessionalTabForMobileRes;
import com.gigflex.prototype.microservices.worker.dtob.WorkerProfileReq;
import com.gigflex.prototype.microservices.worker.dtob.WorkerRequest;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * @author ajit.p
 *
 */
public interface WorkerService {

	public String search(String search);

	public String getAllWorkers();

	public String getAllWorkersByPage(int page, int limit);

	public String getWorkerById(Long id);

	public String saveWorker(WorkerRequest workerReq, String ip);

	public String deleteWorkerById(Long id);

	public String updateWorker(Long id, WorkerRequest workerReq, String ip);

	public String findWorkerByWorkerCode(String workerCode);

	public String deleteByWorkerCode(String workerCode);

	public String getOrganizationByWorkerCode(String workerCode);

	public String getOrganizationByWorkerCode(String workerCode, int page,
			int limit);

	public String updateWorkerLogoByWorkerCode(WorkerLogoRequest workerLogoReq,
			String workerCode, String ip);

	public String softDeleteByWorkerCode(String workerCode);

	public String softMultipleDeleteByWorkerCode(List<String> workerCodeList);
        
        public String getworkerprofileByworkerCode(String workerCode );
        
        public String putworkerprofileByworkerCode(WorkerProfileReq req,String workerCode);
        
        public String updateworkerhomelocationByworkerCode(WorkerHomelocationReq req,String workerCode);
        
        public String getworkerHomelocationByworkerCode(String workerCode);
        
        public String getworkerdetailsByworkerCode( String workerCode);
        
        public String getworkerdetailsByworkerCode( String workerCode,String orgCode);
        
        public String UpdateworkerdetailsByworkerCode(WorkerDetailsReq workerdetailreq, String workerCode);
        
        public String getSkillsByOrgCodeAndworkerCode( String workerCode, String orgCode);
        
        public String getWorkerProfilePersonalTabforMobileByworkerCode( String workerCode);
        
        public String getWorkerProfileProfessionalTabforMobileByworkerCode(String workerCode);
        
        public String updateWorkerProfileProfessionalTabforMobileByworkerCode(WorkerProfileProfessionalTabForMobileRes req, String workerCode);
        
        public String UpdateworkerProfilePersonelTabByworkerCode(WorkerProfileForMobileReq req, String workerCode);

    public String getWorkerProfileforMobileByworkerCode(String workerCode);
    
//     public String updateworkerProfileForMobileByworkerCode(UpdateWrkrProfileforMobileByworkerCode req,String workerCode);
}