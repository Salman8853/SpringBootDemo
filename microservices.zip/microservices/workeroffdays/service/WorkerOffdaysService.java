package com.gigflex.prototype.microservices.workeroffdays.service;

import java.util.List;

import com.gigflex.prototype.microservices.workeroffdays.dtob.WorkerOffdays;
import com.gigflex.prototype.microservices.workeroffdays.dtob.WorkerOffdaysRequest;

public interface WorkerOffdaysService {

	public String search(String search);
	public String getAllWorkerOffDays();
	public String getAllWorkerOffDaysByPage(int page, int limit);
	public String getWorkerOffdaysById(Long id);
	public WorkerOffdays saveWorkerOffdays(WorkerOffdays workerOffdays);
	public String saveWorkerOffdays(WorkerOffdaysRequest workerOffdaysrqst,String ip);
	public void updateWorkerOffdays(WorkerOffdays workerOffdays); 
    public String updateWorkerOffdays(Long id, WorkerOffdaysRequest workerOffdaysrqst,String ip);
    public String getByOffDaysCode(String offDaysCode);
    public String deleteWorkerOffdaysById(Long id);
    public String deleteByOffDaysCode(String offDaysCode);
    public String softDeleteByOffDaysCode(String offDaysCode);
    public String softMultipleDeleteByOffDaysCode(List<String> offDaysCodeList);
    
}
