/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.workerhoursofoperation.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name = "worker_hoursofoperation")
public class WorkerHoursOfOperation extends CommonAttributes implements Serializable{
    
     
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;
  
    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "workerhoursofoperation_code", unique = true)
    private String workerhoursOfOperationCode;

    public WorkerHoursOfOperation() {
    }

    public WorkerHoursOfOperation(Long id, String workerhoursOfOperationCode, String vehicleCode, String workerCode, String toTime, Integer dayCode) {
        this.id = id;
        this.workerhoursOfOperationCode = workerhoursOfOperationCode;
      
        this.workerCode = workerCode;
        this.toTime = toTime;
        this.dayCode = dayCode;
    }
    
    
    @PrePersist
    private void assignUUID() {
        if (this.getWorkerhoursOfOperationCode() == null || this.getWorkerhoursOfOperationCode().length() == 0) {
           this.setWorkerhoursOfOperationCode(UUID.randomUUID().toString());
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    
    
    public String getWorkerhoursOfOperationCode() {
        return workerhoursOfOperationCode;
    }

    public void setWorkerhoursOfOperationCode(String workerhoursOfOperationCode) {
        this.workerhoursOfOperationCode = workerhoursOfOperationCode;
    }
    
  
     
    @Column(name = "worker_code", nullable = false)
    private String workerCode;
    
    @Column(name = "fromtime")
    private String fromTime;
            
    @Column(name = "totime")
    private String toTime; 
    
    @Column(name = "day_code")
    private Integer dayCode;

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getFromTime() {
        return fromTime;
    }

    public void setFromTime(String fromTime) {
        this.fromTime = fromTime;
    }

    public String getToTime() {
        return toTime;
    }

    public void setToTime(String toTime) {
        this.toTime = toTime;
    }

    public Integer getDayCode() {
        return dayCode;
    }

    public void setDayCode(Integer dayCode) {
        this.dayCode = dayCode;
    }

    @Override
    public String toString() {
        return "WorkerHoursOfOperation{" + "id=" + id + ", workerhoursOfOperationCode=" + workerhoursOfOperationCode + ", vehicleCode=" + ", workerCode=" + workerCode + ", fromTime=" + fromTime + ", toTime=" + toTime + ", dayCode=" + dayCode + '}';
    }
    
    
}
