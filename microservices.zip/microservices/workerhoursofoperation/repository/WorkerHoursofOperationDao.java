/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.workerhoursofoperation.repository;

import com.gigflex.prototype.microservices.workerhoursofoperation.dtob.WorkerHoursOfOperation;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public interface WorkerHoursofOperationDao extends JpaRepository<WorkerHoursOfOperation,Long>,JpaSpecificationExecutor<WorkerHoursOfOperation> {
    
    @Query("SELECT who FROM WorkerHoursOfOperation who WHERE who.isDeleted != TRUE AND who.workerCode = :workerCode AND who.dayCode=:dayCode")
    public WorkerHoursOfOperation getHoursByWorkerCodeAndDayCode(@Param("workerCode") String workerCode,@Param("dayCode") Integer dayCode);
    
    @Query("SELECT who FROM WorkerHoursOfOperation who WHERE who.isDeleted != TRUE AND who.workerCode = :workerCode")
    public List<WorkerHoursOfOperation> getHoursByWorkerCode(@Param("workerCode") String workerCode);
    
    @Query("SELECT who FROM WorkerHoursOfOperation who WHERE who.isDeleted != TRUE AND who.workerhoursOfOperationCode = :workerHoursofOperationCode")
    public WorkerHoursOfOperation  getworkerHoursofOperationByHoursOfOperationCode(@Param("workerHoursofOperationCode") String workerHoursofOperationCode);
    
    
}
