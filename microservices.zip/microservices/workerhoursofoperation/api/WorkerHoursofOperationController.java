/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.workerhoursofoperation.api;

import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.workerhoursofoperation.dtob.WorkerHoursOfOperationRequest;
import com.gigflex.prototype.microservices.workerhoursofoperation.service.WorkerHoursofOperationService;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author m.salman
 */
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/healthcareservice/")
public class WorkerHoursofOperationController {
    
     @Autowired
     WorkerHoursofOperationService workerHoursofOperationService;
    @PostMapping("/saveWorkerHoursofOperation")
    public String saveWorkerHoursofOperation(@RequestBody WorkerHoursOfOperationRequest req,HttpServletRequest request)
    {    if(
            req.getWorkerCode()!=null && req.getWorkerCode().trim().length()>0
           && req.getDayCode()!=null 
           && req.getFromTime()!=null && req.getFromTime().trim().length()>0
           && req.getToTime()!=null && req.getToTime().trim().length()>0)
           {
             if(req.getDayCode()>0 && req.getDayCode()<8)
             {
                 return  workerHoursofOperationService.saveWorkerHoursofOperation(req, request.getRemoteAddr());
             
             }else
             {
              GigflexResponse derr = new GigflexResponse(400, new Date(), "dayCode should be in range 1 to 7");
               return derr.toString();
             }
             
          }else
         {
           GigflexResponse derr = new GigflexResponse(400, new Date(), "WorkerCode , From Time , To Time,Vehicle Code & Day Code should not be blank");
               return derr.toString();
         }
       
    }
    @GetMapping("/getworkerHoursofOperationByworkerCodeAnddayCode/{workerCode}/{dayCode}")
    public String getworkerHoursofOperationByworkerCodeAnddayCode(@PathVariable  String workerCode,@PathVariable Integer dayCode)
    {
        if(workerCode!=null && workerCode.trim().length()>0 && dayCode!=null && dayCode>0)
        {
           if(dayCode>0 && dayCode<8)
           {
                return   workerHoursofOperationService.getworkerHoursofOperationByworkerCodeAnddayCode(workerCode,dayCode);
          
           }else
           {
             GigflexResponse derr = new GigflexResponse(400, new Date(), "dayCode must be in Range 1 to 7");
               return derr.toString();
           }
        
        }else
        {
         GigflexResponse derr = new GigflexResponse(400, new Date(), " workerCode ,dayCode should not be blank");
               return derr.toString();
        }
    }
     @GetMapping("/getworkerHoursOfOperationByworkerCode/{workerCode}")
    public String getworkerHoursOfOperationByworkerCode(@PathVariable("workerCode") String workerCode){
        if(workerCode!=null && workerCode.trim().length()>0)
        {
            return workerHoursofOperationService.getworkerHoursOfOperationByworkerCode(workerCode);
        }else
        {
         GigflexResponse derr = new GigflexResponse(400, new Date(), "workerCode should not be blank");
               return derr.toString();
        }
    }
      @GetMapping("/getAllworkerHoursofOperation/")
      public String getAllworkerHoursofOperation()
     {
       return  workerHoursofOperationService.getAllworkerHoursofOperation();
     }
      @PutMapping("/updateworkerHoursOfOperationByhourofOperationCode/{hoursOfOperationCode}")
       public String updateworkerHoursOfOperationByhourofOperationCode(@PathVariable("hoursOfOperationCode") String hoursOfOperationCode, @RequestBody WorkerHoursOfOperationRequest workerhoursOfOperationReq,HttpServletRequest request) {

           if(hoursOfOperationCode!=null && hoursOfOperationCode.trim().length()>0)
           {
                 if( workerhoursOfOperationReq.getDayCode() != null && workerhoursOfOperationReq.getDayCode()>0 &&  workerhoursOfOperationReq.getDayCode() < 8)
                 {
                     return  workerHoursofOperationService.updateworkerHoursOfOperationByhourofOperationCode(hoursOfOperationCode,workerhoursOfOperationReq,request.getRemoteAddr()); 
                 }else
                 {
                 GigflexResponse derr = new GigflexResponse(400, new Date(), "dayCode must be in Range 1 to 7");
                 return derr.toString();
                 }
            
           }else
           {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "hoursOfOperationCode not found");
               return derr.toString();
           }
    }
    
    @DeleteMapping("/cancelWorkerHoursOfOperationByHoursOfOperationCode/{hoursOfOperationCode}")
    public String cancelWorkerHoursOfOperationByHoursOfOperationCode(@PathVariable String hoursOfOperationCode){
        
        if(hoursOfOperationCode != null && hoursOfOperationCode.trim().length() >0)
        {
            return workerHoursofOperationService.cancelWorkerHoursOfOperationByHoursOfOperationCode(hoursOfOperationCode.trim());
        }
        else
        {
               GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
               return derr.toString(); 
         }
        
        
    }
    
    
    @DeleteMapping("/cancelMultipleWorkerHoursOfOperationByHoursOfOperationCode/{hoursOfOperationCodeList}")
         public String cancelMultipleWorkerHoursOfOperationByHoursOfOperationCode(@PathVariable List<String> hoursOfOperationCodeList) {
            if(hoursOfOperationCodeList != null && hoursOfOperationCodeList.size()>0 ){
                    return workerHoursofOperationService.cancelMultipleWorkerHoursOfOperationByHoursOfOperationCode(hoursOfOperationCodeList);
            }else{
                     GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
               return derr.toString();
            }

    }
}
