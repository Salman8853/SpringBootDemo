/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.uploadworkerschedule.service;

import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.gigflex.prototype.microservices.patient.dtob.PatientDetails;
import com.gigflex.prototype.microservices.patient.repository.PatientDao;
import com.gigflex.prototype.microservices.patient.service.PatientService;
import com.gigflex.prototype.microservices.schedule.repository.WorkerScheduleRequestRepository;
import com.gigflex.prototype.microservices.setting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.setting.repository.LocalSettingRepository;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.uploadqueue.dtob.UploadQueue;
import com.gigflex.prototype.microservices.uploadqueue.repository.UploadQueueDao;
import com.gigflex.prototype.microservices.uploadworkerschedule.dtob.WorkerScheduleUploadResponse;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.stream.StreamSupport;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;


/**
 *
 * @author amit.kumar
 */
@Service
public class WorkerScheduleFileStorageService {
    
        @Autowired
	private UploadQueueDao uploadQueueDao;

	@Autowired
	private PatientDao patientDao;
        
        
        @Autowired
	WorkerScheduleRequestRepository workerScheduleRequestRepository;
        
        
        @Autowired
        GlobalSettingRepository globalSettingRepository;
        @Autowired
        LocalSettingRepository localSettingRepository;
        @Autowired
        UserTypeRepository utr;
        
        @Autowired
        TimeZoneRepository timeZoneDao;
        
//        @Autowired
//	private UserRepository userRepository;

//	@Value("${xlsfile.upload-dir}")
//	String uploadDir;

	String uploadDir = "E:\\filedata";
	private Path fileStorageLocation;

        @Autowired
        private PatientService patientService;

	public String storeFile(MultipartFile file, String organizationCode) {
		// Normalize file name
		String res1 = "";
		this.fileStorageLocation = Paths.get(uploadDir).toAbsolutePath()
				.normalize();
		String fileName = StringUtils.cleanPath(file.getOriginalFilename());
		try {
			String filenameStart = "";
			String filenameEnd = "";
			Date date = new Date();
			long time = date.getTime();
			int inx = fileName.lastIndexOf(".");
			filenameStart = fileName.substring(0, inx);
			filenameEnd = fileName.substring(inx);
			fileName = filenameStart + "-" + time + filenameEnd;

			if (filenameEnd != null
					&& filenameEnd.trim().length() > 0
					&& (filenameEnd.equalsIgnoreCase(".xls") || filenameEnd
							.equalsIgnoreCase(".xlsx"))) {

				JSONObject jsonobj = new JSONObject();
				// Check if the file's name contains invalid characters
				if (fileName.contains("..") || fileName.contains("/") || fileName.contains("\\") || fileName.contains("<") || fileName.contains(">") || fileName.contains("'")) {
                //  throw new FileStorageException("Sorry! Filename contains invalid path sequence " + fileName);
                jsonobj.put("responsecode", 500);
                jsonobj.put("message", "Sorry! Filename contains invalid path sequence or characters like(.. ' / \\ < >)");
                res1 = jsonobj.toString();
            } else {
					// Copy file to the target location (Replacing existing file
					// with the same name)
					Path targetLocation = this.fileStorageLocation
							.resolve(fileName);
					Files.copy(file.getInputStream(), targetLocation,
							StandardCopyOption.REPLACE_EXISTING);

					File myFile = new File(targetLocation.toUri());
					FileInputStream fis = new FileInputStream(myFile);

					Workbook myWorkBook;
					Sheet mySheet = null;

					if (filenameEnd.equalsIgnoreCase(".xls")) {
						myWorkBook = new HSSFWorkbook(fis);
						mySheet = myWorkBook.getSheetAt(0);
					} else if (filenameEnd.equalsIgnoreCase(".xlsx")) {
						myWorkBook = new XSSFWorkbook(fis);
						mySheet = myWorkBook.getSheetAt(0);
					}
					Iterator<Row> rowIterator = mySheet.iterator();
					Iterator<Row> rowIterator1 = mySheet.iterator();

					Iterable<Row> newIterable = () -> rowIterator1;
					long size = StreamSupport.stream(newIterable.spliterator(),
							false).count();
					Boolean status = true;
					int rowCount = 0;
					String phoneList = "";
                                        String scheduleJobList = "";
                                        String startDateShuludBeBeforeEndDateList = "";
                                        String scheduleValidationList = "";

					while (rowIterator.hasNext()) {
						Row row = rowIterator.next();

						if (row != null) {
							if (rowCount == 0) {

								String cell1 = "";
								String cell2 = "";
								String cell3 = "";                                                                
								String cell4 = "";
								String cell5 = "";
								String cell6 = "";
								String cell7 = "";
								String cell8 = "";
								String cell9 = "";
                                                                String cell10 = "";
                                                                String cell11 = "";
                                                                String cell12 = "";
                                                                String cell13 = "";
                                                                String cell14 = "";
                                                                String cell15 = "";

								PatientDetails pDetails = new PatientDetails();
   
                                                                
                                                               if(row.getCell(0) != null)
                                                               {
                                                                   cell1 =  row.getCell(0).getStringCellValue();
                                                               }
                                                               else
                                                               {
                                                                   cell1 = "";
                                                               }
                                                               
                                                               if(row.getCell(1) != null)
                                                               {
                                                                   cell2 =  row.getCell(1).getStringCellValue();
                                                               }
                                                               else
                                                               {
                                                                   cell2 = "";
                                                               }
                                                               
                                                               if(row.getCell(2) != null)
                                                               {
                                                                   cell3 =  row.getCell(2).getStringCellValue();
                                                               }
                                                               else
                                                               {
                                                                   cell3 = "";
                                                               }
                                                               
                                                               if(row.getCell(3) != null)
                                                               {
                                                                   cell4 =  row.getCell(3).getStringCellValue();
                                                               }
                                                               else
                                                               {
                                                                   cell4 = "";
                                                               }
                                                               
                                                               if(row.getCell(4) != null)
                                                               {
                                                                   cell5 =  row.getCell(4).getStringCellValue();
                                                               }
                                                               else
                                                               {
                                                                   cell5 = "";
                                                               }
                                                               
                                                               if(row.getCell(5) != null)
                                                               {
                                                                   cell6 =  row.getCell(5).getStringCellValue();
                                                               }
                                                               else
                                                               {
                                                                   cell6 = "";
                                                               }
                                                               
                                                               if(row.getCell(6) != null)
                                                               {
                                                                   cell7 =  row.getCell(6).getStringCellValue();
                                                               }
                                                               else
                                                               {
                                                                   cell7 = "";
                                                               }
                                                                
                                                               if(row.getCell(7) != null)
                                                               {
                                                                   cell8 =  row.getCell(7).getStringCellValue();
                                                               }
                                                               else
                                                               {
                                                                   cell8 = "";
                                                               } 
                                                               
                                                               if(row.getCell(8) != null)
                                                               {
                                                                   cell9 =  row.getCell(8).getStringCellValue();
                                                               }
                                                               else
                                                               {
                                                                   cell9 = "";
                                                               } 
                                                               
                                                               if(row.getCell(9) != null)
                                                               {
                                                                   cell10 =  row.getCell(9).getStringCellValue();
                                                               }
                                                               else
                                                               {
                                                                   cell10 = "";
                                                               } 
                                                               
                                                               if(row.getCell(10) != null)
                                                               {
                                                                   cell11 =  row.getCell(10).getStringCellValue();
                                                               }
                                                               else
                                                               {
                                                                   cell11 = "";
                                                               } 
                                                               
                                                               if(row.getCell(11) != null)
                                                               {
                                                                   cell12 =  row.getCell(11).getStringCellValue();
                                                               }
                                                               else
                                                               {
                                                                   cell12 = "";
                                                               } 
                                                               
                                                               if(row.getCell(12) != null)
                                                               {
                                                                   cell13 =  row.getCell(12).getStringCellValue();
                                                               }
                                                               else
                                                               {
                                                                   cell13 = "";
                                                               } 
                                                               
                                                               if(row.getCell(13) != null)
                                                               {
                                                                   cell14 =  row.getCell(13).getStringCellValue();
                                                               }
                                                               else
                                                               {
                                                                   cell14 = "";
                                                               } 
                                                               
                                                               if(row.getCell(14) != null)
                                                               {
                                                                   cell15 =  row.getCell(14).getStringCellValue();
                                                               }
                                                               else
                                                               {
                                                                   cell15 = "";
                                                               } 
                                                               
                                                               
								if (cell1.trim().equalsIgnoreCase("Patient Name")
										&& cell2.trim().equalsIgnoreCase(
												"Email Address")
										&& cell3.trim().equalsIgnoreCase(
												"Address")
										&& cell4.trim().equalsIgnoreCase(
												"City")
                                                                                && cell5.trim().equalsIgnoreCase(
												"State")
                                                                                && cell6.trim().equalsIgnoreCase(
                                                                                                        "Country")
                                                                                && cell7.trim().equalsIgnoreCase(
                                                                                                        "Zipcode")
                                                                                && cell8.trim().equalsIgnoreCase(
                                                                                                        "Phone Number")
                                                                                && cell9.trim().equalsIgnoreCase(
                                                                                                        "Mobile Number")
                                                                                && cell10.trim().equalsIgnoreCase(
                                                                                                        "Phone Country Code")
                                                                                && cell11.trim().equalsIgnoreCase(
                                                                                                        "Schedule Start Date")
                                                                                && cell12.trim().equalsIgnoreCase(
                                                                                                        "Schedule Start Time")
                                                                                && cell13.trim().equalsIgnoreCase(
                                                                                                        "Schedule End Date")
                                                                                && cell14.trim().equalsIgnoreCase(
                                                                                                        "Schedule End Time")
                                                                                && cell15.trim().equalsIgnoreCase(
                                                                                                        "Job Name")) {
									status = true;
								} else {
									status = false;

									break;
								}

							} else {
	
								int cellCount = 0;
								PatientDetails pDetails = new PatientDetails();
                                                                WorkerScheduleUploadResponse schedule = new WorkerScheduleUploadResponse(); 

                                                                    
                                                                 for(int i = 0 ; i < 15 ; i++)
                                                                 {
                                                                        cellCount++;

                                                                        Cell cell = row.getCell(i);

									if (cell != null) {
										String res = "";
										switch (cell.getCellType()) {
										case Cell.CELL_TYPE_STRING:
                                                                                    if(cell.getStringCellValue()!=null)
                                                                                    {
											res = cell.getStringCellValue().trim();
                                                                                    }
											break;
										case Cell.CELL_TYPE_NUMERIC:
											double var = cell
													.getNumericCellValue();
                                                                                        
                                                                                        if (HSSFDateUtil.isCellDateFormatted(cell))
                                                                                        {
                                                                                           Date d = (Date)getDateValue(var);
                                                                                           SimpleDateFormat dateFormat;
                                                                                           if(cellCount == 11 || cellCount == 13 )
                                                                                           {
                                                                                               dateFormat = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD);
                                                                                           }
                                                                                           else
                                                                                           {
                                                                                               dateFormat = new SimpleDateFormat(GigflexConstants.HH_MM_SS);
                                                                                           }
                                                                                            
                                                                                           res = dateFormat.format(d);
                                                                                        }
                                                                                        else
                                                                                        {
                                                                                            Long l = (long) var;
                                                                                            res = l.toString();
                                                                                        }
                                                                                            break;     
										case Cell.CELL_TYPE_BOOLEAN:
											if (cell.getBooleanCellValue()) {
												res = "true";
											} else {
												res = "false";
											}

											break;
										default:

										}
//										
                                                                                if (cellCount == 15) {
											
                                                                                     schedule.setJobName(res);    
										}
                                                                                else if (cellCount == 14) {

											schedule.setEndTime(res);

										}
                                                                                else if (cellCount == 13) {

											schedule.setEndDate(res);

										}
                                                                                else if (cellCount == 12) {

											schedule.setStartTime(res);

										}
                                                                                else if (cellCount == 11) {

											schedule.setStartDate(res);

										}
                                                                                else if (cellCount == 10) {
											pDetails.setpCountryCode(res);                                                                                       

										} 
                                                                                else if (cellCount == 9) {

											pDetails.setMobileNumber(res);

										}
                                                                                else if (cellCount == 8) {

											pDetails.setPhoneNumber(res);

										}
                                                                                else if (cellCount == 7) {
											pDetails.setZipCode(res);

										}                                                                                
                                                                                else if (cellCount == 6) {
											pDetails.setPatientCountry(res);

										}
                                                                                else if (cellCount == 5) {
											pDetails.setPatientState(res);

										}
                                                                                else if (cellCount == 4) {
											pDetails.setPatientCity(res);

										}
                                                                                else if (cellCount == 3) {
											pDetails.setPatientAddress(res);

										}
                                                                                else if (cellCount == 2) {
											pDetails.setPatientEmail(res);

										}
                                                                                else if (cellCount == 1) {
											pDetails.setPatientName(res);

										}
                                                                                
                                                                                
                                                                                
									}

								}
                                                                 
                                                                 schedule.setPatientDetails(pDetails); 
                                                                 
                                                                 
                                                                 
								if (pDetails != null && pDetails.getPatientName() != null && pDetails.getPhoneNumber() != null) {
                                                                    
									PatientDetails pDetails1 = patientDao.findByPhoneNumber(pDetails.getPhoneNumber());                                                                       
									if ((pDetails1 != null && pDetails1.getId() > 0) ) {
                                                                            
                                                                              if(!pDetails1.getPatientName().equalsIgnoreCase(pDetails.getPatientName())) 
                                                                              {
                                                                                  if (phoneList.length() > 0) {
											phoneList += ","
													+ pDetails.getPhoneNumber();
										} else {
											phoneList = pDetails.getPhoneNumber();

										}
                                                                              }
										
									}

								}
                                                                
                                                                if(schedule != null)
                                                                {
                                                                    
                                                                    if(schedule.getStartDate()!=null && schedule.getStartTime() != null && schedule.getEndDate() !=null && schedule.getEndTime() != null && schedule.getJobName() != null)
                                                                    {
                                                                        
                                                                        String startDateTime = schedule.getStartDate()+" "+schedule.getStartTime();
                                                                        String endDateTime = schedule.getEndDate()+" "+schedule.getEndTime();                                                                      
                                         
//                          
                                                                        
                                                                        Date sdt = new SimpleDateFormat(GigflexConstants.DD_MM_YYYY_HH_MM_SS).parse(startDateTime);
                                                                        Date edt = new SimpleDateFormat(GigflexConstants.DD_MM_YYYY_HH_MM_SS).parse(endDateTime);
                                                                        
                                                                        if(sdt==null || edt==null)
                                                                        {                                                                           
                                                                            
                                                                            if (scheduleJobList.length() > 0) {
											scheduleJobList += ","
													+ schedule.getJobName();
										} else {
											scheduleJobList = schedule.getJobName();

										}
                                                                            
                                                                        }
                                                                        else
                                                                        {
                                                                            if(sdt.after(edt))
                                                                            {
                                                                                 if (startDateShuludBeBeforeEndDateList.length() > 0) {
											startDateShuludBeBeforeEndDateList += ","
													+ schedule.getJobName();
										} else {
											startDateShuludBeBeforeEndDateList = schedule.getJobName();

										}
                                                                            }
                                                                            else
                                                                            {
                                                                                
                                                                            }
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        if (scheduleValidationList.length() > 0) {
											scheduleValidationList += ","
													+ pDetails.getPatientName();
										} else {
											scheduleValidationList = pDetails.getPatientName();

										}
                                                                        
                                                                    }
                                                                    
                                                                }
                                                                
                                                                
							}
							rowCount++;
						}
					}
					if (status) {
						if (size > 1) {
							if (phoneList.length() > 0) {
								jsonobj.put("responsecode", 400);
								jsonobj.put("message",
										"Phones are already Exist!("
												+ phoneList + ")");
							} 
                                                        else if(scheduleJobList.length() > 0)
                                                        {
                                                            jsonobj.put("responsecode", 400);
								jsonobj.put("message",
										"Plz send date in correct format(yyyy-MM-dd HH:mm:ss) for following jobs !("
												+ scheduleJobList + ")");
                                                            
                                                        }
                                                        else if(scheduleValidationList.length() > 0)
                                                        {
                                                            jsonobj.put("responsecode", 400);
								jsonobj.put("message",
										"Input data is not valid for following patients !("
												+ scheduleValidationList + ")");
                                                            
                                                        }
                                                        else if(startDateShuludBeBeforeEndDateList.length() > 0)
                                                        {
                                                            jsonobj.put("responsecode", 400);
								jsonobj.put("message",
										"Start Date should be before the End date for the  following jobs !("
												+ startDateShuludBeBeforeEndDateList + ")");
                                                            
                                                        }
                                                        else {

								UploadQueue uq = new UploadQueue();

								uq.setFileName(fileName);
								uq.setTotalRecords((size - 1));
								uq.setProcessedRecords(0L);
								uq.setFaliedRecords(0L);

								UploadQueue uploadRes = uploadQueueDao.save(uq);

				startWorkerScheduleUploadThread(uploadDir + "/"	+ fileName, uploadRes.getUploadCode(),organizationCode);

								jsonobj.put("responsecode", 200);
								jsonobj.put("message", "success");
								jsonobj.put("filename", fileName);
								jsonobj.put("uploadFileCode",
										uploadRes.getUploadCode());
							}
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message",
									"Sorry! File have no data for Worker Schedule");
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message",
								"Sorry! File Should be in proper format.");
					}
					res1 = jsonobj.toString();

				}
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"File type should be xls or xlsx.");
				res1 = derr.toString();
			}

		} catch (IOException ex) {
			// throw new FileStorageException("Could not store file " + fileName
			// + ". Please try again!", ex);
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Could not store file " + fileName + ". Please try again!");
			res1 = derr.toString();
			ex.printStackTrace();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res1 = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res1 = derr.toString();
			ex.printStackTrace();
		}

		return res1;
	}

	// public static boolean passwordPattern(String pwd) {
	// if (pwd != null) {
	// try {
	// String pattern = "(?=.*[0-7])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{7,}";
	// isPwdValid = pwd.matches(pattern);
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// }
	// return isPwdValid;
	// }
	//
	// public static boolean emailPatternValidation(String email) {
	// if (email != null && !email.equals("")) {
	// try {
	// String regex = "^(.+)@(.+)$";
	// Pattern pattern = Pattern.compile(regex);
	// Matcher matcher = pattern.matcher(email);
	// if (matcher.matches()) {
	// isEmailValid = true;
	// }
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	//
	// }
	// return isEmailValid;
	// }

	public Resource loadFileAsResource(String fileName) {
		Resource resource = null;
		try {
			Path filePath = this.fileStorageLocation.resolve(fileName)
					.normalize();
			resource = new UrlResource(filePath.toUri());

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return resource;
	}

	public void startWorkerScheduleUploadThread(String fileName, String uploadCode,
			String organizationCode) {
		Thread t = new Thread(new WorkerScheduleUploadThread(/*kafkaService,*/fileName, uploadCode,organizationCode, uploadQueueDao, patientDao,patientService,
                        workerScheduleRequestRepository,globalSettingRepository,localSettingRepository,utr,timeZoneDao));
		t.start();
	}
        
        
        protected static Object getDateValue(double numericDateValue) 
       {
//         double numericDateValue = cellDate.getNumericCellValue();
         Date date = HSSFDateUtil.getJavaDate(numericDateValue);
         return date;
       }
    
}
