/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.patient.service.impl;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.jobs.repository.JobsAssignToWorkerRepository;
import com.gigflex.prototype.microservices.jobs.service.AssignJobToWorkerDynamicDistancePatientAddressThread;
import com.gigflex.prototype.microservices.patient.dtob.PatientDetails;
import com.gigflex.prototype.microservices.patient.dtob.PatientDocumentMapping;
import com.gigflex.prototype.microservices.patient.dtob.PatientDocumentMappingReq;
import com.gigflex.prototype.microservices.patient.dtob.PatientRequest;
import com.gigflex.prototype.microservices.patient.dtob.PatientResponse;
import com.gigflex.prototype.microservices.patient.repository.PatientDao;
import com.gigflex.prototype.microservices.patient.repository.PatientDocumentMappingDao;
import com.gigflex.prototype.microservices.patient.service.PatientService;
import com.gigflex.prototype.microservices.setting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.setting.repository.LocalSettingRepository;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author amit.kumar
 */
@Service
public class PatientServiceImpl implements PatientService{
    
    @Autowired
    PatientDao patientDao;
    
    @Autowired
    PatientDocumentMappingDao patientDocumentMappingDao;
    
    @Autowired
    TimeZoneRepository timeZoneDao;

    @Autowired
    GlobalSettingRepository globalSettingRepository;
    @Autowired
    LocalSettingRepository localSettingRepository;
    @Autowired
    UserTypeRepository utr;
    
      @Autowired
    JobsAssignToWorkerRepository jobsAssignToWorkerRepository;
         
         @Value("${google.api.key}")
    private String googleKey; 
    
    @Value("${file.upload-dir}")
    String uploadDir ;//="D:\\gigflexfiles";
    private Path fileStorageLocation;

    @Override
    public String getPatientDetailByOrganizationCode(String organizationCode) {
            
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<PatientDetails> patientDetailList = new ArrayList<PatientDetails>();

			List<PatientResponse> patientResList = new ArrayList<PatientResponse>();

			patientDetailList  = patientDao.getPatientDetailsByOrgCode(organizationCode);
			
                        if(patientDetailList != null && patientDetailList.size() > 0)
                        {
                            for (PatientDetails pDetail : patientDetailList) {

				PatientResponse pResponse = new PatientResponse();
                                pResponse.setPatientCode(pDetail.getPatientCode());
                                pResponse.setPatientName(pDetail.getPatientName());
                                pResponse.setPatientAddress(pDetail.getPatientAddress());
                                pResponse.setPatientCountry(pDetail.getPatientCountry());
                                pResponse.setPatientState(pDetail.getPatientState());
                                pResponse.setPatientCity(pDetail.getPatientCity());
                                pResponse.setMobileNumber(pDetail.getMobileNumber());
                                pResponse.setPhoneNumber(pDetail.getPhoneNumber());
                                pResponse.setPatientLatitude(pDetail.getPatientLatitude());
                                pResponse.setPatientLongitude(pDetail.getPatientLongitude());                                
				pResponse.setZipCode(pDetail.getZipCode()); 
                                pResponse.setIsActive(pDetail.isIsActive()); 
                                pResponse.setOrganizationCode(pDetail.getOrganizationCode());
                                pResponse.setPhoneCountryCode(pDetail.getpCountryCode());
                                pResponse.setMobileCountryCode(pDetail.getmCountryCode());
                                pResponse.setPatientEmail(pDetail.getPatientEmail());
                                pResponse.setPatientHistoryDescription(pDetail.getPatientHistoryDescription()); 
				
                                
                                List<PatientDocumentMapping> pDocumentMapplingList  = patientDocumentMappingDao.getPatientDocumentMappingByPatientCode(pDetail.getPatientCode());
                                List<PatientDocumentMappingReq> pDocumentMapplingReqList  = new ArrayList<PatientDocumentMappingReq>();
                                if(pDocumentMapplingList != null && pDocumentMapplingList.size() > 0)
                                {                                    
                                    for(PatientDocumentMapping patientDocumentMapping :pDocumentMapplingList)
                                    {
                                        PatientDocumentMappingReq pDocumentMappingResponse = new PatientDocumentMappingReq();
                                        pDocumentMappingResponse.setPatientCode(patientDocumentMapping.getPatientCode());
                                        pDocumentMappingResponse.setDocumentName(patientDocumentMapping.getDocumentName());
                                        pDocumentMappingResponse.setDocumentDescription(patientDocumentMapping.getDocumentDescription());
                                        pDocumentMappingResponse.setDocumentFilePath(patientDocumentMapping.getDocumentFilePath());
                                        pDocumentMappingResponse.setPatientDocumentMappingCode(patientDocumentMapping.getPatientDocumentMappingCode()); 
                                        pDocumentMapplingReqList.add(pDocumentMappingResponse);
                                    }                                    
                                }
                                
                                pResponse.setPatientDocumentMappingReqList(pDocumentMapplingReqList); 
                                
                                patientResList.add(pResponse);
				
			   }
                            
                            if (patientResList != null && patientResList.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(patientResList);
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Success");
					jsonobj.put("data", new JSONArray(Detail));

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");
				}
                            
                            
                        }
                        else
                        {
                            jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");
                        }

                        
			res = jsonobj.toString();
		} 
                catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
        
        
    }

    @Override
    public String getPatientDetailByPatientCode(String patientCode) {
       
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        
                        if(patientCode != null && patientCode.trim().length() > 0)
                        {
                            PatientDetails pDetails = new PatientDetails();

                            pDetails  = patientDao.getPatientDetailsBypatientCode(patientCode);

                            if(pDetails != null )
                            {
                                    PatientResponse pResponse = new PatientResponse();
                                    pResponse.setPatientCode(pDetails.getPatientCode());
                                    pResponse.setPatientName(pDetails.getPatientName());
                                    pResponse.setPatientAddress(pDetails.getPatientAddress());
                                    pResponse.setPatientCountry(pDetails.getPatientCountry());
                                    pResponse.setPatientState(pDetails.getPatientState());
                                    pResponse.setPatientCity(pDetails.getPatientCity());
                                    pResponse.setMobileNumber(pDetails.getMobileNumber());
                                    pResponse.setPhoneNumber(pDetails.getPhoneNumber());
                                    pResponse.setPatientLatitude(pDetails.getPatientLatitude());
                                    pResponse.setPatientLongitude(pDetails.getPatientLongitude());                                
                                    pResponse.setZipCode(pDetails.getZipCode()); 
                                    pResponse.setIsActive(pDetails.isIsActive());				   
                                    pResponse.setOrganizationCode(pDetails.getOrganizationCode());
                                    pResponse.setPhoneCountryCode(pDetails.getpCountryCode());
                                    pResponse.setMobileCountryCode(pDetails.getmCountryCode());
                                    pResponse.setPatientEmail(pDetails.getPatientEmail());
                                    pResponse.setPatientHistoryDescription(pDetails.getPatientHistoryDescription());
                                    
                                    List<PatientDocumentMapping> pDocumentMapplingList  = patientDocumentMappingDao.getPatientDocumentMappingByPatientCode(pDetails.getPatientCode());
                                    List<PatientDocumentMappingReq> pDocumentMapplingReqList  = new ArrayList<PatientDocumentMappingReq>();
                                    if(pDocumentMapplingList != null && pDocumentMapplingList.size() > 0)
                                    {                                    
                                        for(PatientDocumentMapping patientDocumentMapping :pDocumentMapplingList)
                                        {
                                            PatientDocumentMappingReq pDocumentMappingResponse = new PatientDocumentMappingReq();
                                            pDocumentMappingResponse.setPatientCode(patientDocumentMapping.getPatientCode());
                                            pDocumentMappingResponse.setDocumentName(patientDocumentMapping.getDocumentName());
                                            pDocumentMappingResponse.setDocumentDescription(patientDocumentMapping.getDocumentDescription());
                                            pDocumentMappingResponse.setDocumentFilePath(patientDocumentMapping.getDocumentFilePath());
                                            pDocumentMappingResponse.setPatientDocumentMappingCode(patientDocumentMapping.getPatientDocumentMappingCode()); 
                                            pDocumentMapplingReqList.add(pDocumentMappingResponse);
                                        }                                    
                                    }

                                    pResponse.setPatientDocumentMappingReqList(pDocumentMapplingReqList); 
                                    
                                    
                                if (pResponse != null ) {
                                            ObjectMapper mapperObj = new ObjectMapper();
                                            String Detail = mapperObj.writeValueAsString(pResponse);
                                            jsonobj.put("responsecode", 200);
                                            jsonobj.put("timestamp", new Date());
                                            jsonobj.put("message", "Success");
                                            jsonobj.put("data", new JSONObject(Detail));

                                    } else {
                                            jsonobj.put("responsecode", 404);
                                            jsonobj.put("timestamp", new Date());
                                            jsonobj.put("message", "Record Not Found");
                                    }


                            }
                            else
                            {
                                jsonobj.put("responsecode", 404);
                                jsonobj.put("timestamp", new Date());
                                jsonobj.put("message", "Record Not Found");
                            }

                        }
                        else
                        {
                            jsonobj.put("responsecode", 404);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Patirnt Code should not be blank");
                        }
                        
                        
			res = jsonobj.toString();
		} 
                catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
    }

    @Override
    public String getPatientDetailWithoutHavingLatLong() {
        
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

                        List<PatientDetails> pDetailsList = new ArrayList<PatientDetails>();
                        List<PatientResponse> pResponseList = new ArrayList<PatientResponse>();
                        String patientLatitude = "0.0";
                        String patientLongitude = "0.0";
                        pDetailsList  = patientDao.getPatientDetailWithoutHavingLatLong(patientLatitude,patientLongitude);

                        if(pDetailsList != null && pDetailsList.size() > 0)
                        {
                            for(int i = 0; i<pDetailsList.size() ; i++ )
                            {                                
                                PatientDetails pDetails = pDetailsList.get(i);
                                PatientResponse pResponse = new PatientResponse();
                                pResponse.setPatientCode(pDetails.getPatientCode());
                                pResponse.setPatientName(pDetails.getPatientName());
                                pResponse.setPatientAddress(pDetails.getPatientAddress());
                                pResponse.setPatientCountry(pDetails.getPatientCountry());
                                pResponse.setPatientState(pDetails.getPatientState());
                                pResponse.setPatientCity(pDetails.getPatientCity());
                                pResponse.setMobileNumber(pDetails.getMobileNumber());
                                pResponse.setPhoneNumber(pDetails.getPhoneNumber());
                                pResponse.setPatientLatitude(pDetails.getPatientLatitude());
                                pResponse.setPatientLongitude(pDetails.getPatientLongitude());                                
                                pResponse.setZipCode(pDetails.getZipCode()); 
                                pResponse.setIsActive(pDetails.isIsActive());				   
                                pResponse.setOrganizationCode(pDetails.getOrganizationCode());
                                pResponse.setPhoneCountryCode(pDetails.getpCountryCode());
                                pResponse.setPatientHistoryDescription(pDetails.getPatientHistoryDescription());
                                                                
                                List<PatientDocumentMapping> pDocumentMapplingList  = patientDocumentMappingDao.getPatientDocumentMappingByPatientCode(pDetails.getPatientCode());
                                List<PatientDocumentMappingReq> pDocumentMapplingReqList  = new ArrayList<PatientDocumentMappingReq>();
                                if(pDocumentMapplingList != null && pDocumentMapplingList.size() > 0)
                                {                                    
                                    for(PatientDocumentMapping patientDocumentMapping :pDocumentMapplingList)
                                    {
                                        PatientDocumentMappingReq pDocumentMappingResponse = new PatientDocumentMappingReq();
                                        pDocumentMappingResponse.setPatientCode(patientDocumentMapping.getPatientCode());
                                        pDocumentMappingResponse.setDocumentName(patientDocumentMapping.getDocumentName());
                                        pDocumentMappingResponse.setDocumentDescription(patientDocumentMapping.getDocumentDescription());
                                        pDocumentMappingResponse.setDocumentFilePath(patientDocumentMapping.getDocumentFilePath());
                                        pDocumentMappingResponse.setPatientDocumentMappingCode(patientDocumentMapping.getPatientDocumentMappingCode()); 
                                        pDocumentMapplingReqList.add(pDocumentMappingResponse);
                                    }                                    
                                }
                                
                                pResponse.setPatientDocumentMappingReqList(pDocumentMapplingReqList); 
                                
                                pResponseList.add(pResponse);
                                
                            } 
                               
                            if (pResponseList != null && pResponseList.size() > 0 ) {
                                        ObjectMapper mapperObj = new ObjectMapper();
                                        String Detail = mapperObj.writeValueAsString(pResponseList);
                                        jsonobj.put("responsecode", 200);
                                        jsonobj.put("timestamp", new Date());
                                        jsonobj.put("message", "Success");
                                        jsonobj.put("data", new JSONArray(Detail)); 

                                } else {
                                        jsonobj.put("responsecode", 404);
                                        jsonobj.put("timestamp", new Date());
                                        jsonobj.put("message", "Record Not Found");
                                }

                             
                        }
                        else
                        {
                            jsonobj.put("responsecode", 404);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Record Not Found");
                        }                        
                        
			res = jsonobj.toString();
		} 
                catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
    }

    @Override
    public String savePatientDetail(PatientRequest pRequest, String ip) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (pRequest != null) {        
                            
			if ( (pRequest.getOrganizationCode()!= null && pRequest.getOrganizationCode().trim().length() >0 
                                && pRequest.getPatientName()!=null &&  pRequest.getPatientName().length() > 0                                                                     
                                && pRequest.getPatientLatitude() != null && pRequest.getPatientLatitude().trim().length() >0
                                && pRequest.getPatientLongitude() != null && pRequest.getPatientLongitude().trim().length() > 0                               
                                && pRequest.getPhoneNumber() != null && pRequest.getPhoneNumber().trim().length() > 0                          
                                && pRequest.getPhoneCountryCode()!= null &&  pRequest.getPhoneCountryCode().trim().length() > 0                                
                                && pRequest.getPatientAddress() != null && pRequest.getPatientAddress().trim().length() > 0)) {                                       
                                                       
                                PatientDetails pDetail = new PatientDetails();

                                pDetail.setPatientName(pRequest.getPatientName());
                                pDetail.setIpAddress(ip);
                                pDetail.setOrganizationCode(pRequest.getOrganizationCode());
                                pDetail.setPatientAddress(pRequest.getPatientAddress());
                                pDetail.setPatientCountry(pRequest.getPatientCountry());
                                pDetail.setPatientState(pRequest.getPatientState());
                                pDetail.setPatientCity(pRequest.getPatientCity());
                                pDetail.setZipCode(pRequest.getZipCode());
                                pDetail.setPatientLatitude(pRequest.getPatientLatitude());
                                pDetail.setPatientLongitude(pRequest.getPatientLongitude());
                                pDetail.setMobileNumber(pRequest.getMobileNumber());
                                pDetail.setPhoneNumber(pRequest.getPhoneNumber());
                                pDetail.setPatientEmail(pRequest.getPatientEmail());
                                pDetail.setmCountryCode(pRequest.getMobileCountryCode());
                                pDetail.setpCountryCode(pRequest.getPhoneCountryCode());
                                pDetail.setPatientHistoryDescription(pRequest.getPatientHistoryDescription()); 
                                if (pRequest.isIsActive() != null) {
                                    pDetail.setIsActive(pRequest.isIsActive());
                                } else {
                                    pDetail.setIsActive(true);
                                }

                                PatientDetails pDetailResponse = patientDao.save(pDetail);

                                if (pDetailResponse != null && pDetailResponse.getId() > 0) {
                                    
                                    String message = "";

                                    if(pRequest.getPatientDocumentMappingReqList() !=null && pRequest.getPatientDocumentMappingReqList().size() > 0)
                                    {
                                        StringBuilder builder = new StringBuilder();
                                        for(PatientDocumentMappingReq pdMapping : pRequest.getPatientDocumentMappingReqList())
                                        {
                                            PatientDocumentMapping pDocumentMappingResponse = new PatientDocumentMapping();
                                            pDocumentMappingResponse.setPatientCode(pDetailResponse.getPatientCode());
                                            pDocumentMappingResponse.setDocumentName(pdMapping.getDocumentName());
                                            pDocumentMappingResponse.setDocumentDescription(pdMapping.getDocumentDescription());
                                            pDocumentMappingResponse.setDocumentFilePath(pdMapping.getDocumentFilePath());
                                            
                                            PatientDocumentMapping patientDocumentMappingRes = patientDocumentMappingDao.save(pDocumentMappingResponse);
                                            
                                            if(patientDocumentMappingRes == null)
                                            {
                                                builder.append(pdMapping.getDocumentName()+",");
                                            }                                            
                                        }
                                        
                                        if(builder.length() > 0)
                                        {
                                            int index = builder.lastIndexOf(",");
                                            String documentNames = builder.substring(0, index);                                            
                                            message =  "Patient Details has been added successfully.Following documents has been failed to save - "+documentNames;
                                        }       
                                    }
                                    else
                                    {
                                        message = "Patient Details has been added successfully.";
                                    }
                                    
                                    jsonobj.put("responsecode", 200);
                                    jsonobj.put("timestamp", new Date());
                                    jsonobj.put("message",message);
                                    ObjectMapper mapperObj = new ObjectMapper();
                                    String Detail = mapperObj.writeValueAsString(pDetailResponse);
                                    jsonobj.put("data", new JSONObject(Detail));
                                } else {

                                    jsonobj.put("responsecode", 400);
                                    jsonobj.put("timestamp", new Date());                                
                                    jsonobj.put("message", "Failed");
                                }
                            } else {
                                    jsonobj.put("responsecode", 404);
                                    jsonobj.put("timestamp", new Date());
                                    jsonobj.put("message", "Organization Code, Patient Name, Patient Latitude, Patient Longitude, Phone Number, Phone Country Code and Patient Address should not be blank");
                            }
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
        
    }

    @Override
    public String updatePatientDetail(String patientCode, PatientRequest pRequest, String ip) {
       
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (pRequest != null && patientCode!=null && patientCode.trim().length()>0) {        
                            
			if ( (pRequest.getOrganizationCode()!= null && pRequest.getOrganizationCode().trim().length() >0 
                                && pRequest.getPatientName()!=null &&  pRequest.getPatientName().length() > 0                                                                     
                                && pRequest.getPatientLatitude() != null && pRequest.getPatientLatitude().trim().length() >0
                                && pRequest.getPatientLongitude() != null && pRequest.getPatientLongitude().trim().length() > 0                               
                                && pRequest.getPhoneNumber() != null && pRequest.getPhoneNumber().trim().length() > 0                          
                                && pRequest.getPhoneCountryCode()!= null &&  pRequest.getPhoneCountryCode().trim().length() > 0                                
                                && pRequest.getPatientAddress() != null && pRequest.getPatientAddress().trim().length() > 0)) {                                       
                                                       
                                PatientDetails pDetail = patientDao.getPatientDetailBypatientCode(patientCode);
                                if(pDetail!=null && pDetail.getId()>0)
                                {
                                String oldlat=pDetail.getPatientLatitude();
                                String oldlong=pDetail.getPatientLongitude();
                                pDetail.setPatientName(pRequest.getPatientName());
                                pDetail.setIpAddress(ip);
                                pDetail.setOrganizationCode(pRequest.getOrganizationCode());
                                pDetail.setPatientAddress(pRequest.getPatientAddress());
                                pDetail.setPatientCountry(pRequest.getPatientCountry());
                                pDetail.setPatientState(pRequest.getPatientState());
                                pDetail.setPatientCity(pRequest.getPatientCity());
                                pDetail.setZipCode(pRequest.getZipCode());
                                pDetail.setPatientLatitude(pRequest.getPatientLatitude());
                                pDetail.setPatientLongitude(pRequest.getPatientLongitude());
                                pDetail.setMobileNumber(pRequest.getMobileNumber());
                                pDetail.setPhoneNumber(pRequest.getPhoneNumber());
                                pDetail.setPatientEmail(pRequest.getPatientEmail());
                                pDetail.setmCountryCode(pRequest.getMobileCountryCode());
                                pDetail.setpCountryCode(pRequest.getPhoneCountryCode());
                                pDetail.setPatientHistoryDescription(pRequest.getPatientHistoryDescription()); 
                                if (pRequest.isIsActive() != null) {
                                    pDetail.setIsActive(pRequest.isIsActive());
                                } 

                                PatientDetails pDetailResponse = patientDao.save(pDetail);


                                if (pDetailResponse != null && pDetailResponse.getId() > 0) {
                                    
                                    
                                    if(oldlat==null || oldlong==null || !oldlat.equalsIgnoreCase(pRequest.getPatientLatitude()) || !oldlong.equalsIgnoreCase(pRequest.getPatientLongitude()))
                    {
                        String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider,pDetailResponse.getOrganizationCode() , GigflexConstants.TimeZone);
                            String timezone = null;
                            TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            if (tzd != null && tzd.getId() > 0) {
                                timezone = tzd.getTimeZoneName();
                            }
                            startAssignJobToWorkerDynamicDistancePatientAddressThread( pDetailResponse,new Date(), timezone);
                  
                    }
                                    
                                    String message = "";
                                    if(pRequest.getPatientDocumentMappingReqList() !=null && pRequest.getPatientDocumentMappingReqList().size() > 0)
                                    {
                                        StringBuilder builder = new StringBuilder();
                                        for(PatientDocumentMappingReq pdMapping : pRequest.getPatientDocumentMappingReqList())
                                        {                                            
                                            PatientDocumentMapping pDocumentMappingResponse = patientDocumentMappingDao.getPatientDocumentMappingByPatientDocumentMappingCode(pdMapping.getPatientDocumentMappingCode());
                                            PatientDocumentMapping patientDocumentMappingRes =null;
                                            if(pDocumentMappingResponse != null )
                                            {
                                                pDocumentMappingResponse.setDocumentName(pdMapping.getDocumentName());
                                                pDocumentMappingResponse.setDocumentDescription(pdMapping.getDocumentDescription());
                                                pDocumentMappingResponse.setDocumentFilePath(pdMapping.getDocumentFilePath());
                                                patientDocumentMappingRes = patientDocumentMappingDao.save(pDocumentMappingResponse);
                                            }
                                            else
                                            {
                                                PatientDocumentMapping pdmResponse = new PatientDocumentMapping();
                                                pdmResponse.setPatientCode(pdMapping.getPatientCode());
                                                pdmResponse.setDocumentName(pdMapping.getDocumentName());
                                                pdmResponse.setDocumentDescription(pdMapping.getDocumentDescription());
                                                pdmResponse.setDocumentFilePath(pdMapping.getDocumentFilePath());
                                                patientDocumentMappingRes = patientDocumentMappingDao.save(pdmResponse);
                                            }   
                                                                                        
                                            if(patientDocumentMappingRes == null)
                                            {
                                                builder.append(pdMapping.getDocumentName()+",");
                                            }                                            
                                        }
                                        
                                        if(builder.length() > 0)
                                        {
                                            int index = builder.lastIndexOf(",");
                                            String documentNames = builder.substring(0, index);                                            
                                            message =  "Patient Details has been updated successfully.Following documents has been failed to update - "+documentNames;
                                        }       
                                    }
                                    else
                                    {
                                        message =  "Patient Details has been updated successfully.";
                                    }
                                    
                                    jsonobj.put("responsecode", 200);
                                    jsonobj.put("timestamp", new Date());
                                    jsonobj.put("message",message);
                                    ObjectMapper mapperObj = new ObjectMapper();
                                    String Detail = mapperObj.writeValueAsString(pDetailResponse);
                                    jsonobj.put("data", new JSONObject(Detail));
                                } else {

                                    jsonobj.put("responsecode", 400);
                                    jsonobj.put("timestamp", new Date());                                
                                    jsonobj.put("message", "Failed");
                                }
                                }
                                 else {

                                    jsonobj.put("responsecode", 404);
                                    jsonobj.put("timestamp", new Date());                                
                                    jsonobj.put("message", "Patient not found.");
                                }
                            } else {
                                    jsonobj.put("responsecode", 404);
                                    jsonobj.put("timestamp", new Date());
                                    jsonobj.put("message", "Organization Code, Patient Name, Patient Latitude, Patient Longitude, Phone Number, Phone Country Code and Patient Address should not be blank");
                            }
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
    }

    @Override
    public String storePatientDocumentFile(MultipartFile file,String patientCode) {
        
             // Normalize file name
            String res = "";
            String fileName = "";
            try {
            uploadDir =uploadDir+File.separator+patientCode;
            JSONObject jsonobj = new JSONObject();

            File uploadFile = new File(uploadDir);
            if (!uploadFile.exists()) {
                if (uploadFile.mkdir()) {

                } else {
                    jsonobj.put("responsecode", 500);
                    jsonobj.put("message", "Failed to create directory!");
                    res = jsonobj.toString();
                }
            }
        
            this.fileStorageLocation = Paths.get(uploadDir).toAbsolutePath().normalize();
            fileName = StringUtils.cleanPath(file.getOriginalFilename());
        
            String filenameStart = "";
            String filenameEnd = "";
            Date date = new Date();
            long time = date.getTime();
            int inx = fileName.lastIndexOf(".");
            filenameStart = fileName.substring(0, inx);
            filenameEnd = fileName.substring(inx);
            fileName = filenameStart + "-" + time + filenameEnd;

            
            // Check if the file's name contains invalid characters
            if (fileName.contains("..") || fileName.contains("/") || fileName.contains("\\") || fileName.contains("<") || fileName.contains(">") || fileName.contains("'")) {
                //  throw new FileStorageException("Sorry! Filename contains invalid path sequence " + fileName);
                jsonobj.put("responsecode", 500);
                jsonobj.put("message", "Sorry! Filename contains invalid path sequence or characters like(.. ' / \\ < >)");
                res = jsonobj.toString();
            } else {
                if (filenameEnd.equalsIgnoreCase(".jpeg") || filenameEnd.equalsIgnoreCase(".jpg") || filenameEnd.equalsIgnoreCase(".png") || filenameEnd.equalsIgnoreCase(".gif") 
                        || filenameEnd.equalsIgnoreCase(".pdf") || filenameEnd.equalsIgnoreCase(".doc") || filenameEnd.equalsIgnoreCase(".txt") || filenameEnd.equalsIgnoreCase(".docx")) {
                   // Copy file to the target location (Replacing existing file with the same name)
                    Path targetLocation = this.fileStorageLocation.resolve(fileName);
                    Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
                    jsonobj.put("responsecode", 200);
                    jsonobj.put("message", "success");
                    jsonobj.put("filename", fileName);
                    jsonobj.put("filepath", targetLocation.toString());
                    res = jsonobj.toString();
                } else {
                    jsonobj.put("responsecode", 500);
                    jsonobj.put("message", "Sorry! File should be in JPEG, JPG, PNG, GIF,PDF ,DOC ,DOCX & TXT format only");
                    res = jsonobj.toString();
                }

            }
        } catch (IOException ex) {
            //throw new FileStorageException("Could not store file " + fileName + ". Please try again!", ex);
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "Could not store file " + fileName + ". Please try again!");
            res = derr.toString();
            ex.printStackTrace();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "JSON parsing exception occurred.");
            res = derr.toString();
            ex.printStackTrace();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
        return res;
    }    
    
    
    @Override
    public String getPatientDocumentMappingByPatientDocumentMappingCode(String patientDocumentMappingCode) {
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        
                        if(patientDocumentMappingCode != null && patientDocumentMappingCode.trim().length() > 0)
                        {
                            PatientDocumentMapping pDocumentMappling = null;

                            pDocumentMappling  = patientDocumentMappingDao.getPatientDocumentMappingByPatientDocumentMappingCode(patientDocumentMappingCode);

                            if(pDocumentMappling != null )
                            {
                                    PatientDocumentMappingReq pDocumentMappingResponse = new PatientDocumentMappingReq();
                                    pDocumentMappingResponse.setPatientCode(pDocumentMappling.getPatientCode());
                                    pDocumentMappingResponse.setDocumentName(pDocumentMappling.getDocumentName());
                                    pDocumentMappingResponse.setDocumentDescription(pDocumentMappling.getDocumentDescription());
                                    pDocumentMappingResponse.setDocumentFilePath(pDocumentMappling.getDocumentFilePath());
                                    pDocumentMappingResponse.setPatientDocumentMappingCode(pDocumentMappling.getPatientDocumentMappingCode()); 
                                    
                                if (pDocumentMappingResponse != null ) {
                                            ObjectMapper mapperObj = new ObjectMapper();
                                            String Detail = mapperObj.writeValueAsString(pDocumentMappingResponse);
                                            jsonobj.put("responsecode", 200);
                                            jsonobj.put("timestamp", new Date());
                                            jsonobj.put("message", "Success");
                                            jsonobj.put("data", new JSONObject(Detail));

                                } else {
                                        jsonobj.put("responsecode", 404);
                                        jsonobj.put("timestamp", new Date());
                                        jsonobj.put("message", "Record Not Found");
                                }


                            }
                            else
                            {
                                jsonobj.put("responsecode", 404);
                                jsonobj.put("timestamp", new Date());
                                jsonobj.put("message", "Record Not Found");
                            }

                        }
                        else
                        {
                            jsonobj.put("responsecode", 404);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Patirnt Document Mapping Code should not be blank");
                        }
                        
                        
			res = jsonobj.toString();
		} 
                catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
    }

    

    @Override
    public String softDeletePatientDocumentByPatientDocumentMappingCode(String patientDocumentMappingCode) {
        
        String res = "";
        try 
        {
            JSONObject jsonobj = new JSONObject();
            PatientDocumentMapping patientDocumentMappinginDb = patientDocumentMappingDao.getPatientDocumentMappingByPatientDocumentMappingCode(patientDocumentMappingCode);

            if (patientDocumentMappinginDb != null && patientDocumentMappinginDb.getId() > 0) {
                    patientDocumentMappinginDb.setIsDeleted(true);
                    PatientDocumentMapping patientDocumentMappingRes = patientDocumentMappingDao.save(patientDocumentMappinginDb);
                if (patientDocumentMappingRes != null && patientDocumentMappingRes.getId()>0)
                {
                    jsonobj.put("responsecode", 200);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Patient Document deleted successfully.");

                } else {
                    jsonobj.put("responsecode", 400);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Failed");
                }

            } else {
                jsonobj.put("responsecode", 404);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "Record Not Found");
            }
            res = jsonobj.toString();
        } catch (Exception ex) {
        GigflexResponse derr = new GigflexResponse(500, new Date(),
        "JSON parsing exception occurred.");
        res = derr.toString();
        }
        return res;
    }
    
    
    @Override
    public String softMultipleDeletePatientDocumentByPatientDocumentMappingCode(List<String> patientDocumentMappingCodeList) {
        
        String res = "";
        try {
                JSONArray jarr = new JSONArray();
                for (String patientDocumentMappingCode : patientDocumentMappingCodeList)
                {
                    if(patientDocumentMappingCode != null && patientDocumentMappingCode.trim().length() > 0)
                    {
                        JSONObject jsonobj = new JSONObject();

                        PatientDocumentMapping patientDocumentMappinginDb = patientDocumentMappingDao.getPatientDocumentMappingByPatientDocumentMappingCode(patientDocumentMappingCode);

                        if (patientDocumentMappinginDb != null && patientDocumentMappinginDb.getId() > 0) {

                            patientDocumentMappinginDb.setIsDeleted(true);
                            PatientDocumentMapping patientDocumentMappingRes = patientDocumentMappingDao.save(patientDocumentMappinginDb);
                            if (patientDocumentMappingRes != null && patientDocumentMappingRes.getId() > 0) {
                                    jsonobj.put("responsecode", 200);
                                    jsonobj.put("timestamp", new Date());
                                    jsonobj.put("patientDocumentMappingCode", patientDocumentMappingCode);
                                    jsonobj.put("message", "Patient Document deleted successfully.");
                            } else {
                                    jsonobj.put("responsecode", 400);
                                    jsonobj.put("timestamp", new Date());
                                    jsonobj.put("patientDocumentMappingCode", patientDocumentMappingCode);
                                    jsonobj.put("message", "Failed");
                            }

                        } else {
                                jsonobj.put("responsecode", 404);
                                jsonobj.put("timestamp", new Date());
                                jsonobj.put("patientDocumentMappingCode", patientDocumentMappingCode);
                                jsonobj.put("message", "Record Not Found");
                        }

                    jarr.add(jsonobj);
                  }
                }
                if (jarr.size() > 0) {
                        res = jarr.toString();
                } else {
                        GigflexResponse derr = new GigflexResponse(400, new Date(),
                                        "Multiple delete failed.");
                        res = derr.toString();
                }

        } catch (Exception ex) {
                GigflexResponse derr = new GigflexResponse(500, new Date(),
                                "JSON parsing exception occurred.");
                res = derr.toString();
        }
        return res;
    }

   
    public  void startAssignJobToWorkerDynamicDistancePatientAddressThread(PatientDetails pDetail,Date startDate,String timezone){
        Thread t = new Thread(new AssignJobToWorkerDynamicDistancePatientAddressThread(pDetail,jobsAssignToWorkerRepository,startDate,timezone, googleKey));
        t.start();
    }
    
}
