/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.patient.dtob;

/**
 *
 * @author amit.kumar
 */
public class PatientDocumentMappingReq {
    
    private String patientCode;
    private String documentName;
    private String documentDescription;
    private String documentFilePath;
    private String patientDocumentMappingCode;

    public String getPatientCode() {
        return patientCode;
    }

    public void setPatientCode(String patientCode) {
        this.patientCode = patientCode;
    }

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public String getDocumentDescription() {
        return documentDescription;
    }

    public void setDocumentDescription(String documentDescription) {
        this.documentDescription = documentDescription;
    }

    public String getDocumentFilePath() {
        return documentFilePath;
    }

    public void setDocumentFilePath(String documentFilePath) {
        this.documentFilePath = documentFilePath;
    }

    public String getPatientDocumentMappingCode() {
        return patientDocumentMappingCode;
    }

    public void setPatientDocumentMappingCode(String patientDocumentMappingCode) {
        this.patientDocumentMappingCode = patientDocumentMappingCode;
    }
    
    
}
