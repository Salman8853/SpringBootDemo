/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.util;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONObject;
import java.util.Arrays;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

/**
 *
 * @author nirbhay.p
 */

public class GoogleDistanceDuration {

    public final static String API_KEY = "AIzaSyD3XOTNblH5XCPxOGqqBDlzOyY33pOPvAo";

    public static void main(String a[]) {

        GoogleDistanceDurationResponse res = getGoogleDistanceDuration(API_KEY, "40.7497152", "-73.98692599999998", "40.7543627", "-73.98766719999998");
        System.out.println(">>>st=" + res.getStatus());
    }

    public static GoogleDistanceDurationResponse getGoogleDistanceDuration(String key, String source_Lat, String source_Long, String desti_Lat, String desti_Long) {
        GoogleDistanceDurationResponse res = new GoogleDistanceDurationResponse();
        res.setStatus(Boolean.FALSE);
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
            HttpEntity<String> entity = new HttpEntity<String>(headers);
            RestTemplate restTemplate = new RestTemplate();
            String response = restTemplate.exchange("https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins=" + source_Lat + "," + source_Long + "&destinations=" + desti_Lat + "," + desti_Long + "&key=" + key, HttpMethod.GET, entity, String.class).getBody();

            JSONObject jsonObj = new JSONObject(response);

            if (jsonObj.has("status") && !jsonObj.isNull("status") && jsonObj.getString("status").equalsIgnoreCase("OK")) {
                res.setStatus(Boolean.TRUE);
                if (jsonObj.has("rows") && !jsonObj.isNull("rows")) {
                    JSONArray arr = jsonObj.getJSONArray("rows");
                    if (arr.length() > 0) {
                        JSONObject jsonObj1 = arr.getJSONObject(0);
                        if (jsonObj1 != null && jsonObj1.has("elements")) {
                            JSONArray arr1 = jsonObj1.getJSONArray("elements");
                            if (arr1.length() > 0) {
                                JSONObject jsonObj2 = arr1.getJSONObject(0);
                                if (jsonObj2 != null) {
                                    if (jsonObj2.has("distance") && !jsonObj2.isNull("distance")) {
                                        JSONObject jdis = jsonObj2.getJSONObject("distance");
                                        if (jdis.has("text") && !jdis.isNull("text")) {
                                            String str = (String) jdis.get("text");
                                            res.setDistanceText(str);
                                        }
                                        if (jdis.has("value") && !jdis.isNull("value")) {
                                            Integer val = (Integer) jdis.get("value");
                                            res.setDistanceValue(val);
                                        }
                                    }
                                    if (jsonObj2.has("duration") && !jsonObj2.isNull("duration")) {
                                        JSONObject jdur = jsonObj2.getJSONObject("duration");
                                        if (jdur.has("text") && !jdur.isNull("text")) {
                                            String str = (String) jdur.get("text");
                                            res.setDurationText(str);
                                        }
                                        if (jdur.has("value") && !jdur.isNull("value")) {
                                            Integer val = (Integer) jdur.get("value");
                                            res.setDurationValue(val);
                                        }
                                    }

                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }
}
