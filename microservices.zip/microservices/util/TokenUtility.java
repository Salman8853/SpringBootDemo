/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.util;

import atg.taglib.json.util.JSONObject;
import com.gigflex.prototype.microservices.users.dtob.Users;
import com.gigflex.prototype.microservices.users.repository.UserRepository;
import com.gigflex.prototype.microservices.verifyemployee.repository.WorkerApprovalStatusRepository;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

/**
 *
 * @author m.salman
 */
@Service
public class TokenUtility {
     @Autowired
	 private JwtConfig jwtConfig;
	  @Autowired
	UserRepository userRepository; 
          @Autowired
          WorkerApprovalStatusRepository workerapprovalstatusRepository;
	@Bean
    public JwtConfig jwtConfig() {
        return new JwtConfig();
    }
     
    public String getTokenFromHeader(HttpHeaders headers)
    {
        String res=null;
        try{
            List<String> lst=headers.get("Authorization");
            if(lst!=null && lst.size()>0)
            {
                res=lst.get(0);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return res;
    }
     
    public String getUserNameFromToken(String tokenold)
    {
        String userName=null;
        try{
            String token = tokenold.replace(jwtConfig.getPrefix(), "");
		 
		          Claims claims = Jwts.parser()
                 .setSigningKey(jwtConfig.getSecret().getBytes())
                 .parseClaimsJws(token)
                 .getBody();

         userName = claims.getSubject();
        }
        catch(Exception e)
        {
            e.printStackTrace();
            userName=null;
        }
        return userName;
    }
    public String userValidation(HttpHeaders headers,String workerCode)
    {
        
     
        String res="Failed";
        JSONObject jsonobj=new JSONObject();
        try{
            List<String> lst=headers.get("Authorization");
            if(lst!=null && lst.size()>0)
            {
              String tok=lst.get(0);
              if(tok!=null && tok.length()>0)
              {
                  String newtoken = tok.replace(jwtConfig.getPrefix(), "");
                  Claims claims = Jwts.parser()
                 .setSigningKey(jwtConfig.getSecret().getBytes())
                 .parseClaimsJws(newtoken)
                 .getBody();
             String userName=claims.getSubject();
                  if(userName != null && userName.length() > 0)
                  {
                    Users u=  userRepository.findByUsername(userName);
                      if(u!=null && u.getId()>0 && u.getUserCode()!=null)
                      {       if(u.getIsAdmin()|| u.getIsOwner())
                              {
                                 List<String> orgCodeByworkerCode= workerapprovalstatusRepository.getAllOrganizationCodeByWorkerCode(workerCode);
                                    String  orgcodeByuserCode= workerapprovalstatusRepository.getOrganizationCodeByuserCode(u.getUserCode());
                                   if(orgCodeByworkerCode.contains(orgcodeByuserCode))
                                   {
                                     res="true";
                                   }else
                                   {
                                     jsonobj.put("responsecode", 401);
				     jsonobj.put("timestamp", new Date());
				     jsonobj.put("message", "Unauthorised Access ");
                                    res=jsonobj.toString();
                                   }
                                   
                                           
                              }
                            else if(u.getUserCode().equals(workerCode))
                              {
                                  res="true";
                              }else
                              {
                                   jsonobj.put("responsecode", 401);
				  jsonobj.put("timestamp", new Date());
				  jsonobj.put("message", "Unauthorised Access ");
                                res=jsonobj.toString();
                              }
                      
                      
                      }else
                      {
                                jsonobj.put("responsecode", 401);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Unauthorised Access ");
                                 res=jsonobj.toString();
                      }
                      
                      
                  }else
                  {
                      GigflexResponse derr = new GigflexResponse(401, new Date(),
					"Access Token is not valid.");
			res = derr.toString();
                  }
              }else
              {
                GigflexResponse gres=new GigflexResponse(404, new Date(), "Access Token is not found.");
                    res=gres.toString();
              }
               
            }
            else
            {
               GigflexResponse gres=new GigflexResponse(404, new Date(), "Access Token is not found.");
                    res=gres.toString(); 
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return res;
    }
    
}

