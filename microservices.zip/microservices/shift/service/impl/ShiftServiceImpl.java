/**
 *
 */
package com.gigflex.prototype.microservices.shift.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.daysmaster.dtob.DaysMaster;
import com.gigflex.prototype.microservices.daysmaster.repository.DaysMasterDao;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.shift.dtob.DaysCodeRes;
import com.gigflex.prototype.microservices.shift.dtob.DaysCodeResquest;
import com.gigflex.prototype.microservices.shift.dtob.MultiOrganizationWorkerShiftResponse;
import com.gigflex.prototype.microservices.shift.dtob.MultiShiftRequest;
import com.gigflex.prototype.microservices.shift.dtob.SaveMultiShiftRes;
import com.gigflex.prototype.microservices.shift.dtob.Shift;
import com.gigflex.prototype.microservices.shift.dtob.ShiftWithDays;
import com.gigflex.prototype.microservices.shift.repository.ShiftRepository;
import com.gigflex.prototype.microservices.shift.repository.ShiftWithDaysRepository;
import com.gigflex.prototype.microservices.shift.search.ShiftSpecificationsBuilder;
import com.gigflex.prototype.microservices.shift.service.ShiftService;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.util.GigUtil;
import com.gigflex.prototype.microservices.util.GigflexDateUtil;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.workinglocation.dtob.WorkingLocation;
import com.gigflex.prototype.microservices.workinglocation.repository.WorkingLocationRepository;
//import com.gigflex.prototype.microservices.utility.GigflexDateUtil;
//import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkingLocation;
//import com.gigflex.prototype.microservices.verifyemployee.repository.WorkingLocationRepository;

/**
 * @author ajit.p
 *
 */
@Service
public class ShiftServiceImpl implements ShiftService {

	private static final Logger LOG = LoggerFactory
			.getLogger(ShiftServiceImpl.class);

	@Autowired
	ShiftRepository shiftRep;

	@Autowired
	OrganizationRepository orgRep;
	@Autowired
	ShiftWithDaysRepository shiftDaysrepo;

	@Autowired
	WorkingLocationRepository workLocRep;

	@Autowired
	DaysMasterDao daysDao;


        @Autowired
        TimeZoneRepository timeZoneDao;

	@Override
	public String createShift(MultiShiftRequest shiftRequest, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (shiftRequest != null) {
				if (shiftRequest.getOrganizationCode() != null
						&& shiftRequest.getOrganizationCode().trim().length() > 0
						&& shiftRequest.getDaysCodeList() != null
						&& shiftRequest.getDaysCodeList().size() > 0
						&& shiftRequest.getWorkingLocationCode() != null
						&& shiftRequest.getWorkingLocationCode().trim()
								.length() > 0
						&& shiftRequest.getShiftName() != null
						&& shiftRequest.getShiftName().trim().length() > 0
						&& shiftRequest.getEndTime() != null
						&& shiftRequest.getEndTime().trim().length() > 0
						&& shiftRequest.getStartTime() != null
						&& shiftRequest.getStartTime().trim().length() > 0) {

					Date startTime = null;
					Date endTime = null;

					try {
						startTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
								.parse(shiftRequest.getStartTime().trim());
						endTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
								.parse(shiftRequest.getEndTime().trim());
						if (startTime == null || endTime == null) {
							GigflexResponse derr = new GigflexResponse(400,
									new Date(),
									"Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
							return derr.toString();
						}
					} catch (Exception ex) {
						ex.printStackTrace();
						GigflexResponse derr = new GigflexResponse(400,
								new Date(),
								"Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
						return derr.toString();
					}

					Organization org = orgRep
							.findByOrganizationCode(shiftRequest
									.getOrganizationCode().trim());

					if (org != null && org.getId() > 0) {

						WorkingLocation wl = workLocRep
								.findByWorkingLocationCode(shiftRequest
										.getWorkingLocationCode().trim());

						if (wl != null && wl.getId() > 0) {

							if (startTime.before(endTime)) {
								List<DaysCodeRes> dcreslst = new ArrayList<DaysCodeRes>();
                                                                TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());	
                                                            String timezone = tzd.getTimeZoneName();
                                                            if(timezone!=null && timezone.length()>0 )
                                                            {
			startTime = GigflexDateUtil.convertStringDateToGMT(shiftRequest.getStartTime().trim(), timezone,"yyyy-MM-dd HH:mm:ss");
			endTime = GigflexDateUtil.convertStringDateToGMT(shiftRequest.getEndTime().trim(), timezone,"yyyy-MM-dd HH:mm:ss");
                                                            }
					  Shift shiftToBeSaved = new Shift();

			Shift shiftInDb = shiftRep.findShiftByOrganizationCode(shiftRequest.getShiftName(),shiftRequest.getOrganizationCode().trim(),shiftRequest.getWorkingLocationCode().trim());
			if (shiftInDb == null && startTime != null && endTime != null) {
									shiftToBeSaved.setOrganizationCode(shiftRequest.getOrganizationCode().trim());
									shiftToBeSaved.setShiftName(shiftRequest.getShiftName());
									shiftToBeSaved.setWorkingLocationCode(shiftRequest.getWorkingLocationCode().trim());
									// shiftToBeSaved.setStartTime(startTime);
									shiftToBeSaved.setStartTime(startTime);
									// shiftToBeSaved.setEndTime(endTime);
									shiftToBeSaved.setEndTime(endTime);
									shiftToBeSaved.setIpAddress(ip);
									shiftToBeSaved.setIsActive(shiftRequest
											.getIsActive());

									Shift shift = shiftRep.save(shiftToBeSaved);
									if (shift != null && shift.getId() > 0) {
//										kafkaService.sendShift(shift);
										for (DaysCodeResquest dcreq : shiftRequest
												.getDaysCodeList()) {
											if (dcreq.getDaysCode() != null
													&& dcreq.getDaysCode()
															.trim().length() > 0) {
												DaysCodeRes dcres = new DaysCodeRes();
												dcres.setDaysCode(dcreq
														.getDaysCode().trim());
												DaysMaster days = daysDao
														.getDaysMasterByDaysCode(dcreq
																.getDaysCode()
																.trim());

												if (days != null
														&& days.getId() > 0) {
													ShiftWithDays swd = shiftDaysrepo
															.getShiftWithDaysByShiftCodeDayscode(
																	shift.getShiftCode(),
																	dcreq.getDaysCode()
																			.trim());
													if (swd != null
															&& swd.getId() > 0) {
														dcres.setMessage("Mapping of Shift with Days is already exist.");
													} else {
														ShiftWithDays sd = new ShiftWithDays();
														sd.setDaysCode(dcreq
																.getDaysCode()
																.trim());
														sd.setShiftCode(shift
																.getShiftCode());
														ShiftWithDays sdRes = shiftDaysrepo
																.save(sd);
														if (sdRes != null
																&& sdRes.getId() > 0) {
															dcres.setMessage("Mapping of Shift with Days has been added successfully.");
															dcres.setDaysName(days
																	.getDaysName());
															dcres.setId(sdRes
																	.getId());
//                                                                                                                        kafkaService.sendShiftWithDays(sdRes);
														} else {
															dcres.setMessage("Mapping of Shift with Days has been failed.");
														}

													}

													// jsonobj.put("responsecode",
													// 200);
													// jsonobj.put("timestamp",
													// new Date());
													// jsonobj.put("message",
													// "New Shift added successfully.");
													// ObjectMapper mapperObj =
													// new ObjectMapper();
													// String Detail =
													// mapperObj.writeValueAsString(shift);
													// jsonobj.put("data", new
													// JSONObject(Detail));
												} else {
													dcres.setMessage("Days Code Not Found.");
													// jsonobj.put("message",
													// "Days Code Not Found.");
													// jsonobj.put("responsecode",
													// 400);
													// jsonobj.put("timestamp",
													// new Date());
												}
												dcreslst.add(dcres);
											}
										}

										SaveMultiShiftRes msres = new SaveMultiShiftRes();
										msres.setDaysCodeList(dcreslst);
										msres.setShift(shift);

										jsonobj.put("responsecode", 200);
										jsonobj.put("timestamp", new Date());
										jsonobj.put("message", "Success.");
										ObjectMapper mapperObj = new ObjectMapper();
										String Detail = mapperObj
												.writeValueAsString(msres);
										jsonobj.put("data", new JSONObject(
												Detail));
									} else {

										jsonobj.put("message", "Failed");
										jsonobj.put("responsecode", 400);
										jsonobj.put("timestamp", new Date());
									}

								} else {

									jsonobj.put("message",
											"Record is already exists!");

									jsonobj.put("responsecode", 409);
									jsonobj.put("timestamp", new Date());

									
                                                                            }                                       

                                

                               

                            } else {
                                jsonobj.put("message", "Start time must be before endtime.");
                                jsonobj.put("responsecode", 400);
                                jsonobj.put("timestamp", new Date());

                            }
                        } else {
                            jsonobj.put("message", "Working Location Code Not Found.");
                            jsonobj.put("responsecode", 400);
                            jsonobj.put("timestamp", new Date());
                        }
                    } else {
                        jsonobj.put("message", "Organization Code Not Found.");
                        jsonobj.put("responsecode", 400);
                        jsonobj.put("timestamp", new Date());
                    }

                } else {

                    jsonobj.put("responsecode", 400);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message",
                            "Data Should not be blank.");

                }

            }
            res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
        return res;

    }

   

//    @Override
//    public String getAllOrgWorkerShift(String organizationCode) {
//        String res = "";
//        try {
//            JSONObject jsonobj = new JSONObject();
//
//            List<Object> objlst = shiftRep.getAllOrgWorkerShiftWithNames(organizationCode);
//            List<OrganizationWorkerShiftResponse> maplst = new ArrayList<OrganizationWorkerShiftResponse>();
//            if (objlst != null && objlst.size() > 0) {
//                for (int i = 0; i < objlst.size(); i++) {
//                    Object[] arr = (Object[]) objlst.get(i);
//                    if (arr.length >= 4) {
//                        OrganizationWorkerShiftResponse ows = new OrganizationWorkerShiftResponse();
//
//                        Shift data = (Shift) arr[0];
//
//                        ows.setId(data.getId());
//                        ows.setShiftCode(data.getShiftCode());
//                        ows.setShiftName(data.getShiftName());
//                        ows.setOrganizationCode(data.getOrganizationCode());
//                        ows.setDaysCode(data.getDaysCode());
//                        ows.setWorkingLocationCode(data.getWorkingLocationCode());
//                        ows.setIsActive(data.getIsActive());
//                        ows.setStartTime(data.getStartTime());
//                        ows.setEndTime(data.getEndTime());
//
//                        ows.setOrganizationName((String) arr[1]);
//                        ows.setDaysName((String) arr[2]);
//                        ows.setLocation((String) arr[3]);
//
//                        maplst.add(ows);
//
//                    }
//                }
//                if (maplst.size() > 0) {
//                    ObjectMapper mapperObj = new ObjectMapper();
//                    String Detail = mapperObj.writeValueAsString(maplst);
//                    jsonobj.put("responsecode", 200);
//                    jsonobj.put("message", "Success");
//                    jsonobj.put("timestamp", new Date());
//                    jsonobj.put("data", new JSONArray(Detail));
//                } else {
//                    jsonobj.put("responsecode", 404);
//                    jsonobj.put("message", "Record Not Found");
//                    jsonobj.put("timestamp", new Date());
//                }
//            } else {
//                jsonobj.put("responsecode", 404);
//                jsonobj.put("message", "Record Not Found");
//                jsonobj.put("timestamp", new Date());
//            }
//
//            res = jsonobj.toString();
//        } catch (JSONException ex) {
//            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
//            res = derr.toString();
//            ex.printStackTrace();
//        } catch (Exception ex) {
//            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
//            res = derr.toString();
//            ex.printStackTrace();
//        }
//        return res;
//    }

  

    

//    @Override
//    public String getAllShiftWithOrgCodeByPage(String organizationCode, int page, int limit) {
//        String res = "";
//        try {
//            JSONObject jsonobj = new JSONObject();
//            Pageable pageableRequest = PageRequest.of(page, limit);
//            List<Object> objlst = shiftRep.getAllOrgWorkerShiftWithNames(organizationCode, pageableRequest);
//            List<OrganizationWorkerShiftResponse> maplst = new ArrayList<OrganizationWorkerShiftResponse>();
//            if (objlst != null && objlst.size() > 0) {
//                for (int i = 0; i < objlst.size(); i++) {
//                    Object[] arr = (Object[]) objlst.get(i);
//                    if (arr.length >= 4) {
//                        OrganizationWorkerShiftResponse ows = new OrganizationWorkerShiftResponse();
//
//                        Shift data = (Shift) arr[0];
//
//                        ows.setId(data.getId());
//                        ows.setShiftCode(data.getShiftCode());
//                        ows.setShiftName(data.getShiftName());
//                        ows.setOrganizationCode(data.getOrganizationCode());
//                        ows.setDaysCode(data.getDaysCode());
//                        ows.setWorkingLocationCode(data.getWorkingLocationCode());
//                        ows.setIsActive(data.getIsActive());
//                        ows.setStartTime(data.getStartTime());
//                        ows.setEndTime(data.getEndTime());
//
//                        ows.setOrganizationName((String) arr[1]);
//                        ows.setDaysName((String) arr[2]);
//                        ows.setLocation((String) arr[3]);
//
//                        maplst.add(ows);
//
//                    }
//                }
//                if (maplst.size() > 0) {
//                    ObjectMapper mapperObj = new ObjectMapper();
//                    String Detail = mapperObj.writeValueAsString(maplst);
//                    jsonobj.put("responsecode", 200);
//                    jsonobj.put("message", "Success");
//                    jsonobj.put("timestamp", new Date());
//                    jsonobj.put("data", new JSONArray(Detail));
//                } else {
//                    jsonobj.put("responsecode", 404);
//                    jsonobj.put("message", "Record Not Found");
//                    jsonobj.put("timestamp", new Date());
//                }
//            } else {
//                jsonobj.put("responsecode", 404);
//                jsonobj.put("message", "Record Not Found");
//                jsonobj.put("timestamp", new Date());
//            }
//
//            res = jsonobj.toString();
//        } catch (JSONException ex) {
//            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
//            res = derr.toString();
//            ex.printStackTrace();
//        } catch (Exception ex) {
//            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
//            res = derr.toString();
//            ex.printStackTrace();
//        }
//        return res;
//    }

    @Override
    public String search(String search) {
        String res = "";
        try {
            JSONArray jarr = new JSONArray();
            if (search != null && search.trim().length() > 0) {
                JSONObject jsonobj = new JSONObject();

                ShiftSpecificationsBuilder builder = new ShiftSpecificationsBuilder();
                Pattern pattern = Pattern.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
                java.util.regex.Matcher matcher = pattern.matcher(search + ",");
                while (matcher.find()) {
                    builder.with(matcher.group(1), matcher.group(2), matcher.group(3));
                }

                Specification<Shift> spec = builder.build();
                
                if(spec!=null){
                List<Shift> objlst = shiftRep.findAll(spec);
                if (objlst != null && objlst.size() > 0) {
                    for (Shift shift : objlst) {
                      Date locationShiftStartTime=null;
                      Date locationShiftEndTime=null; 
                      WorkingLocation wl=null;
                      if(shift!=null){
                      if(shift.getWorkingLocationCode()!=null && shift.getWorkingLocationCode().trim().length()>0){
                      wl = workLocRep.findByWorkingLocationCode(shift.getWorkingLocationCode());
                      }
                        if (wl != null && wl.getId() > 0 && wl.getTimeZone()!=null && wl.getTimeZone().trim().length()>0) {
                            try{
                                TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());
                                String timezone = tzd.getTimeZoneName();
                                if (timezone != null && timezone.length() > 0) {
                                    Date shiftStart = shift.getStartTime();
                                    locationShiftStartTime = GigflexDateUtil.getGMTtoLocationDate(shiftStart, timezone, "yyyy-MM-dd HH:mm:ss");
                                    Date shiftEnd = shift.getEndTime();
                                    locationShiftEndTime = GigflexDateUtil.getGMTtoLocationDate(shiftEnd, timezone, "yyyy-MM-dd HH:mm:ss");
                                }
                                shift.setStartTime(locationShiftStartTime);
                                shift.setEndTime(locationShiftEndTime);
                            }
                            catch(Exception e){
                                e.printStackTrace();
                            }
                        }
                        if (shift.getIsDeleted() != null && shift.getIsDeleted() != true) {
                            ObjectMapper mapperObj = new ObjectMapper();
                            String Detail = mapperObj.writeValueAsString(shift);
                            JSONObject jsonobjNew = new JSONObject();
                            jsonobjNew.put("shift", new JSONObject(Detail));
                            jarr.add(jsonobjNew);
                        }
                    }
                    }
                    if (jarr.size() > 0) {
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("message", "Success");
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("data", jarr);
                    } else {
                        jsonobj.put("responsecode", 400);
                        jsonobj.put("message", "Record Not Found!");
                        jsonobj.put("timestamp", new Date());
                    }

                } else {
                    jsonobj.put("responsecode", 400);
                    jsonobj.put("message", "Record Not Found!");
                    jsonobj.put("timestamp", new Date());
                }
                }
                else{
                   jsonobj.put("responsecode", 400);
                    jsonobj.put("message", "Record Not Found!");
                    jsonobj.put("timestamp", new Date());  
                }
                res = jsonobj.toString();

            } else {
                GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid.");
                res = derr.toString();

            }

        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
        }
        return res;
    }

    // @Override
    // public String getShiftByOrgCode(String organizationCode) {
    // String res = "";
    // try {
    // JSONObject jsonobj = new JSONObject();
    // List<Shift> shiftlst =
    // shiftRep.getShiftByOrganizationCode(organizationCode);
    // if (shiftlst != null && shiftlst.size() > 0) {
    // ObjectMapper mapperObj = new ObjectMapper();
    // String Detail = mapperObj.writeValueAsString(shiftlst);
    // jsonobj.put("responsecode", 200);
    // jsonobj.put("timestamp", new Date());
    // jsonobj.put("message", "Success");
    // jsonobj.put("data", new JSONArray(Detail));
    // } else {
    // jsonobj.put("responsecode", 404);
    // jsonobj.put("timestamp", new Date());
    // jsonobj.put("message", "Record Not Found");
    // }
    // res = jsonobj.toString();
    // } catch (JSONException | JsonProcessingException ex) {
    // GigflexResponse derr = new GigflexResponse(500, new Date(),
    // "JSON parsing exception is occurred.");
    // res = derr.toString();
    // }
    // catch (Exception ex) {
    // GigflexResponse derr = new GigflexResponse(500, new Date(),
    // "Exception is occurred.");
    // res = derr.toString();
    // }
    // return res;
    // }
//    @Override
//    public String updateShiftByWorkingLocation(String locationCode, MultiShiftRequest shiftRequest, String ip) {
//        String res = "";
//        try {
//            JSONObject jsonobj = new JSONObject();
//            if (shiftRequest.getOrganizationCode() != null && shiftRequest.getOrganizationCode().trim().length() > 0
//                    && shiftRequest.getDaysCodeList() != null && shiftRequest.getDaysCodeList().size() > 0
//                    && shiftRequest.getWorkingLocationCode() != null && shiftRequest.getWorkingLocationCode().trim().length() > 0
//                    && shiftRequest.getShiftName() != null && shiftRequest.getShiftName().trim().length() > 0
//                    && shiftRequest.getEndTime() != null && shiftRequest.getEndTime().trim().length() > 0 && shiftRequest.getStartTime() != null && shiftRequest.getStartTime().trim().length() > 0) {
//
//                Date startTime = null;
//                Date endTime = null;
//
//                try {
//                    startTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
//                            .parse(shiftRequest.getStartTime().trim());
//                    endTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
//                            .parse(shiftRequest.getEndTime().trim());
//                    if (startTime == null || endTime == null) {
//                        GigflexResponse derr = new GigflexResponse(400, new Date(),
//                                "Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
//                        return derr.toString();
//                    }
//                } catch (Exception ex) {
//                    ex.printStackTrace();
//                    GigflexResponse derr = new GigflexResponse(400, new Date(),
//                            "Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
//                    return derr.toString();
//                }
//
//                Organization org = orgRep.findByOrganizationCode(shiftRequest.getOrganizationCode());
//
//                if (org != null && org.getId() > 0) {
//
//                    WorkingLocation wl = workLocRep
//                            .findByWorkingLocationCode(shiftRequest.getWorkingLocationCode());
//
//                    if (wl != null && wl.getId() > 0) {
//
//                        if (startTime.before(endTime)) {
//                            List<DaysCodeRes> dcreslst = new ArrayList<DaysCodeRes>();
//                            for (DaysCodeResquest dcreq : shiftRequest.getDaysCodeList()) {
//                                if (dcreq.getDaysCode() != null && dcreq.getDaysCode().trim().length() > 0 && dcreq.getId() != null && dcreq.getId() > 0) {
//                                    DaysCodeRes dcres = new DaysCodeRes();
//                                    dcres.setDaysCode(dcreq.getDaysCode().trim());
//                                    dcres.setId(dcreq.getId());
//                                    DaysMaster days = daysDao.getDaysMasterByDaysCode(dcreq.getDaysCode().trim());
//
//                                    if (days != null && days.getId() > 0) {
//
//                                        dcres.setDaysName(days.getDaysName());
//
//                                        Shift shiftlst = shiftRep.getShiftById(dcreq.getId());
//
//                                        if (shiftlst != null && shiftlst.getId() > 0) {
//
////								Date startTime = null;
////								Date endTime = null;
////								try {
////									startTime = GigflexDateUtil.convertStringToDate(shiftRequest.getStartTime());
////									endTime = GigflexDateUtil.convertStringToDate(shiftRequest.getEndTime());
////								} catch (Exception ex) {
////									ex.printStackTrace();
////									GigflexResponse derr = new GigflexResponse(400, new Date(),
////											"Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
////									return derr.toString();
////								}
//                                            Shift shiftInDb = shiftRep.findShiftByOrganizationCodeWithId(
//                                                    shiftRequest.getShiftName(), shiftRequest.getOrganizationCode(),
//                                                    dcreq.getDaysCode().trim(), shiftRequest.getWorkingLocationCode(), dcreq.getId());
//
//                                            Shift shift = null;
//                                            if (shiftInDb == null) {
//
//                                                shiftlst.setOrganizationCode(shiftRequest.getOrganizationCode().trim());
//                                                shiftlst.setShiftName(shiftRequest.getShiftName());
//                                               // shiftlst.setDaysCode(dcreq.getDaysCode().trim());
//                                                shiftlst.setWorkingLocationCode(shiftRequest.getWorkingLocationCode().trim());
//                                                shiftlst.setStartTime(startTime);
//                                                shiftlst.setEndTime(endTime);
//
//                                                shiftlst.setIpAddress(ip);
//                                                shiftlst.setIsActive(shiftRequest.getIsActive());
//
//                                                jsonobj.put("responsecode", 200);
//                                                jsonobj.put("timestamp", new Date());
//
//                                                shift = shiftRep.save(shiftlst);
//
//                                                if (shift != null && shift.getId() > 0) {
//                                                    dcres.setMessage("Shift updated successfully.");
////											jsonobj.put("responsecode", 200);
////											jsonobj.put("message", "Shift updated successfully.");
////											jsonobj.put("timestamp", new Date());
////											ObjectMapper mapperObj = new ObjectMapper();
////											String Detail = mapperObj.writeValueAsString(shift);
////											jsonobj.put("data", new JSONObject(Detail));
//
//                                                    kafkaService.sendUpdateShift(shift);
//                                                } else {
////											jsonobj.put("responsecode", 400);
////											jsonobj.put("message", "Shift updation has been failed.");
////											jsonobj.put("timestamp", new Date());
//                                                    dcres.setMessage("Shift updation has been failed.");
//                                                }
//
//                                            } else {
//                                                dcres.setMessage("Record is already exists!");
//
////jsonobj.put("message", "Record is already exists!");
////									ObjectMapper mapperObj = new ObjectMapper();
////									String Detail = mapperObj.writeValueAsString(shift);
////									jsonobj.put("data", new JSONObject(Detail));
//                                            }
//                                        } else {
////								jsonobj.put("responsecode", 400);
////								jsonobj.put("message", "Input data is not valid.");
////								jsonobj.put("timestamp", new Date());
//                                            dcres.setMessage("shift id is not valid.");
//                                        }
//
//                                    } else {
////						jsonobj.put("message", "Days Code Not Found.");
////						jsonobj.put("responsecode", 400);
////						jsonobj.put("timestamp", new Date());
//                                        dcres.setMessage("Days Code Not Found.");
//                                    }
//                                    dcreslst.add(dcres);
//                                }
//                            }
//                            if (dcreslst != null && dcreslst.size() > 0) {
//                                MultiShiftRes msres = new MultiShiftRes();
//                                msres.setDaysCodeList(dcreslst);
//                                msres.setEndTime(shiftRequest.getEndTime().trim());
//                                msres.setIsActive(shiftRequest.getIsActive());
//                                msres.setOrganizationCode(shiftRequest.getOrganizationCode());
//                                msres.setShiftName(shiftRequest.getShiftName());
//                                msres.setStartTime(shiftRequest.getStartTime().trim());
//                                msres.setWorkingLocationCode(shiftRequest.getOrganizationCode());
//                                jsonobj.put("responsecode", 200);
//                                jsonobj.put("timestamp", new Date());
//                                jsonobj.put("message", "Success");
//                                ObjectMapper mapperObj = new ObjectMapper();
//                                String Detail = mapperObj.writeValueAsString(msres);
//                                jsonobj.put("data", new JSONObject(Detail));
//
//                            } else {
//                                jsonobj.put("message", "Failed");
//                                jsonobj.put("responsecode", 400);
//                                jsonobj.put("timestamp", new Date());
//                            }
//                        } else {
//                            jsonobj.put("responsecode", 400);
//                            jsonobj.put("message", "Start time must be before endtime.");
//                            jsonobj.put("timestamp", new Date());
//
//                        }
//                    } else {
//                        jsonobj.put("message", "Working Location Code Not Found.");
//                        jsonobj.put("responsecode", 400);
//                        jsonobj.put("timestamp", new Date());
//                    }
//                } else {
//                    jsonobj.put("message", "Organization Code Not Found.");
//                    jsonobj.put("responsecode", 400);
//                    jsonobj.put("timestamp", new Date());
//                }
//
//            } else {
//                jsonobj.put("responsecode", 400);
//                jsonobj.put("message", "Data Should not be blank.");
//                jsonobj.put("timestamp", new Date());
//            }
//
//            res = jsonobj.toString();
//
//        } catch (JSONException ex) {
//            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
//            res = derr.toString();
//            ex.printStackTrace();
//        } catch (Exception ex) {
//            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
//            res = derr.toString();
//            ex.printStackTrace();
//        }
//        return res;
//    }
//
//    
    @Override
    public String getAllOrganizationWorkerShiftByLocationCode(String locationCode) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();

            List<Object> objlst = shiftRep.getAllOrgWorkerShiftWithNamesByLocationcode(locationCode);
            List<MultiOrganizationWorkerShiftResponse> maplst = new ArrayList<MultiOrganizationWorkerShiftResponse>();
            if (objlst != null && objlst.size() > 0) {
                for (int i = 0; i < objlst.size(); i++) {
                    Object[] arr = (Object[]) objlst.get(i);
                    if (arr.length >= 3) {
                        Date locationShiftStartTime=null;
                        Date locationShiftEndTime=null;
                        MultiOrganizationWorkerShiftResponse ows = new MultiOrganizationWorkerShiftResponse();
                        Shift data = (Shift) arr[0];
                           WorkingLocation wl = workLocRep.findByWorkingLocationCode(locationCode.trim());

                        if (wl != null && wl.getId() > 0 && wl.getTimeZone()!=null && wl.getTimeZone().trim().length()>0) {
                         TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());
                                String timezone = tzd.getTimeZoneName();
                                if (timezone != null && timezone.length() > 0) {
                        Date shiftStart=data.getStartTime();
                        locationShiftStartTime=GigflexDateUtil.getGMTtoLocationDate(shiftStart, timezone, "yyyy-MM-dd HH:mm:ss");
                        Date shiftEnd=data.getEndTime();
                        locationShiftEndTime=GigflexDateUtil.getGMTtoLocationDate(shiftEnd, timezone, "yyyy-MM-dd HH:mm:ss");
                                }
                        }
                        data.setStartTime(locationShiftStartTime);
                        data.setEndTime(locationShiftEndTime);
                        ows.setOrganizationName((String) arr[1]);
                        ows.setLocation((String) arr[2]);
                        ows.setShift(data);
                        List<DaysCodeRes> dcreslst = new ArrayList<DaysCodeRes>();
                        List<Object> objdaylst = shiftRep.getAllDaysByShiftCode(data.getShiftCode());
                        if (objdaylst != null && objdaylst.size() > 0) {
                            for (int j = 0; j < objdaylst.size(); j++) {
                                Object[] arrday = (Object[]) objdaylst.get(j);
                                if (arrday.length >= 2) {
                                    DaysCodeRes objday = new DaysCodeRes();
                                    ShiftWithDays swd = (ShiftWithDays) arrday[0];
                                    objday.setDaysCode(swd.getDaysCode());
                                    objday.setId(swd.getId());
                                    objday.setDaysName((String) arrday[1]);
                                    dcreslst.add(objday);
                                }
                            }
                        }
                        ows.setDaysCodeList(dcreslst);
                        maplst.add(ows);

                    }
                }
                if (maplst.size() > 0) {
                    ObjectMapper mapperObj = new ObjectMapper();
                    String Detail = mapperObj.writeValueAsString(maplst);
                    jsonobj.put("responsecode", 200);
                    jsonobj.put("message", "Success");
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("data", new JSONArray(Detail));
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "Record Not Found");
                    jsonobj.put("timestamp", new Date());
                }
            } else {
                jsonobj.put("responsecode", 404);
                jsonobj.put("message", "Record Not Found");
                jsonobj.put("timestamp", new Date());
            }

            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
        return res;

    }

    @Override
    public String getAllOrganizationWorkerShiftByLocationCodeByPage(String locationCode, int page, int limit) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            Pageable pageableRequest = PageRequest.of(page, limit);
            List<Object> objlst = shiftRep.getAllOrgWorkerShiftWithNamesByLocationcode(locationCode, pageableRequest);
            List<MultiOrganizationWorkerShiftResponse> maplst = new ArrayList<MultiOrganizationWorkerShiftResponse>();
            if (objlst != null && objlst.size() > 0) {
                for (int i = 0; i < objlst.size(); i++) {
                    Object[] arr = (Object[]) objlst.get(i);
                    if (arr.length >= 3) {
                        Date locationShiftStartTime=null;
                        Date locationShiftEndTime=null;
                        MultiOrganizationWorkerShiftResponse ows = new MultiOrganizationWorkerShiftResponse();

                        Shift data = (Shift) arr[0];
                        WorkingLocation wl = workLocRep.findByWorkingLocationCode(locationCode.trim());

                        if (wl != null && wl.getId() > 0 && wl.getTimeZone()!=null && wl.getTimeZone().trim().length()>0) {
                         TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());
                                String timezone = tzd.getTimeZoneName();
                                if (timezone != null && timezone.length() > 0) {
                        Date shiftStart=data.getStartTime();
                        locationShiftStartTime=GigflexDateUtil.getGMTtoLocationDate(shiftStart, timezone, "yyyy-MM-dd HH:mm:ss");
                        Date shiftEnd=data.getEndTime();
                        locationShiftEndTime=GigflexDateUtil.getGMTtoLocationDate(shiftEnd, timezone, "yyyy-MM-dd HH:mm:ss");
                                }
                        }
                        data.setStartTime(locationShiftStartTime);
                        data.setEndTime(locationShiftEndTime);
                        ows.setOrganizationName((String) arr[1]);
                        ows.setLocation((String) arr[2]);
                        ows.setShift(data);
                        List<DaysCodeRes> dcreslst = new ArrayList<DaysCodeRes>();
                        List<Object> objdaylst = shiftRep.getAllDaysByShiftCode(data.getShiftCode());
                        if (objdaylst != null && objdaylst.size() > 0) {
                            for (int j = 0; j < objdaylst.size(); j++) {
                                Object[] arrday = (Object[]) objdaylst.get(j);
                                if (arrday.length >= 2) {
                                    DaysCodeRes objday = new DaysCodeRes();
                                    ShiftWithDays swd = (ShiftWithDays) arrday[0];
                                    objday.setDaysCode(swd.getDaysCode());
                                    objday.setId(swd.getId());
                                    objday.setDaysName((String) arrday[1]);
                                    dcreslst.add(objday);
                                }
                            }
                        }
                        ows.setDaysCodeList(dcreslst);
                        maplst.add(ows);

                    }
                }
                if (maplst.size() > 0) {
                    ObjectMapper mapperObj = new ObjectMapper();
                    String Detail = mapperObj.writeValueAsString(maplst);
                    jsonobj.put("responsecode", 200);
                    jsonobj.put("message", "Success");
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("data", new JSONArray(Detail));
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "Record Not Found");
                    jsonobj.put("timestamp", new Date());
                }
            } else {
                jsonobj.put("responsecode", 404);
                jsonobj.put("message", "Record Not Found");
                jsonobj.put("timestamp", new Date());
            }

            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
        return res;
    }


	@Override
	public String updateShiftById(Long id, MultiShiftRequest shiftRequest,String ip) {

		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (shiftRequest.getOrganizationCode() != null
					&& shiftRequest.getOrganizationCode().trim().length() > 0
					&& shiftRequest.getDaysCodeList() != null
					&& shiftRequest.getDaysCodeList().size() > 0
					&& shiftRequest.getWorkingLocationCode() != null
					&& shiftRequest.getWorkingLocationCode().trim().length() > 0
					&& shiftRequest.getShiftName() != null
					&& shiftRequest.getShiftName().trim().length() > 0
					&& shiftRequest.getEndTime() != null
					&& shiftRequest.getEndTime().trim().length() > 0
					&& shiftRequest.getStartTime() != null
					&& shiftRequest.getStartTime().trim().length() > 0) {

				Date startTime = null;
				Date endTime = null;
				Date shiftStartTime = null;
				Date shiftEndTime = null;

				try {
					startTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
							.parse(shiftRequest.getStartTime());
					endTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
							.parse(shiftRequest.getEndTime());
					if (startTime == null || endTime == null) {
						GigflexResponse derr = new GigflexResponse(400,
								new Date(),
								"Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
						return derr.toString();
					}
				} catch (Exception ex) {
					ex.printStackTrace();
					GigflexResponse derr = new GigflexResponse(400, new Date(),
							"Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
					return derr.toString();
				}
				Shift shiftlst = shiftRep.getShiftById(id);
				if (shiftlst != null && shiftlst.getId() > 0) {
					Organization org = orgRep
							.findByOrganizationCode(shiftRequest
									.getOrganizationCode());

					if (org != null && org.getId() > 0) {
						WorkingLocation wl = workLocRep
								.findByWorkingLocationCode(shiftRequest
										.getWorkingLocationCode());
						if (wl != null && wl.getId() > 0) {
                                                     TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());
                                                    String timezone = tzd.getTimeZoneName();
                                                    if (timezone != null && timezone.length() > 0) {
                                                        shiftStartTime = GigflexDateUtil
                                                                .convertStringDateToGMT(shiftRequest
                                                                        .getStartTime().trim(), timezone,
                                                                        "yyyy-MM-dd HH:mm:ss");
                                                        shiftEndTime = GigflexDateUtil
                                                                .convertStringDateToGMT(shiftRequest
                                                                        .getEndTime().trim(), timezone,
                                                                        "yyyy-MM-dd HH:mm:ss");
                                                    }
							if (shiftStartTime != null && shiftEndTime != null) {
								if (shiftStartTime.before(shiftEndTime)) {
									List<DaysCodeRes> dcreslst = new ArrayList<DaysCodeRes>();

									// Date startTime = null;
									// Date endTime = null;
									// try {
									// startTime =
									// GigflexDateUtil.convertStringToDate(shiftRequest.getStartTime());
									// endTime =
									// GigflexDateUtil.convertStringToDate(shiftRequest.getEndTime());
									// } catch (Exception ex) {
									// ex.printStackTrace();
									// GigflexResponse derr = new
									// GigflexResponse(400, new Date(),
									// "Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
									// return derr.toString();
									// }
									Shift shiftInDb = shiftRep
											.findShiftByOrganizationCodeWithId(
													shiftRequest.getShiftName(),
													shiftRequest
															.getOrganizationCode(),
													shiftRequest
															.getWorkingLocationCode(),
													id);

									Shift shift = null;
									if (shiftInDb == null) {

										shiftlst.setOrganizationCode(shiftRequest
												.getOrganizationCode().trim());
										shiftlst.setShiftName(shiftRequest
												.getShiftName());
										shiftlst.setWorkingLocationCode(shiftRequest
												.getWorkingLocationCode()
												.trim());
										shiftlst.setStartTime(shiftStartTime);
										shiftlst.setEndTime(shiftEndTime);

										shiftlst.setIpAddress(ip);
										shiftlst.setIsActive(shiftRequest
												.getIsActive());

										jsonobj.put("responsecode", 200);
										jsonobj.put("timestamp", new Date());

										shift = shiftRep.save(shiftlst);

										if (shift != null && shift.getId() > 0) {
											// jsonobj.put("responsecode", 200);
											// jsonobj.put("message",
											// "Shift updated successfully.");
											// jsonobj.put("timestamp", new
											// Date());
											// ObjectMapper mapperObj = new
											// ObjectMapper();
											// String Detail =
											// mapperObj.writeValueAsString(shift);
											// jsonobj.put("data", new
											// JSONObject(Detail));
//											kafkaService.sendUpdateShift(shift);
											List<ShiftWithDays> sdlst= shiftDaysrepo.getShiftWithDaysByShiftCode(shift.getShiftCode());
                                                                                        for(ShiftWithDays swd:sdlst)
                                                                                        {
                                                                                            try{
                                                                                                shiftDaysrepo.deleteShiftWithDaysByShiftDaysCode(swd.getShiftDaysCode());
//                                                                                                kafkaService.sendDeleteShiftWithDays(swd);
                                                                                            }
                                                                                            catch(Exception e)
                                                                                            {
                                                                                                e.printStackTrace();
                                                                                            }
                                                                                        }
											for (DaysCodeResquest dcreq : shiftRequest
													.getDaysCodeList()) {
												if (dcreq.getDaysCode() != null
														&& dcreq.getDaysCode()
																.trim()
																.length() > 0) {
													DaysCodeRes dcres = new DaysCodeRes();
													dcres.setDaysCode(dcreq
															.getDaysCode()
															.trim());
													DaysMaster days = daysDao
															.getDaysMasterByDaysCode(dcreq
																	.getDaysCode()
																	.trim());

													if (days != null
															&& days.getId() > 0) {
														ShiftWithDays swd = shiftDaysrepo
																.getShiftWithDaysByShiftCodeDayscode(
																		shift.getShiftCode(),
																		dcreq.getDaysCode()
																				.trim());
														if (swd != null
																&& swd.getId() > 0) {
															dcres.setMessage("Mapping of Shift with Days is already exist.");
														} else {
															ShiftWithDays sd = new ShiftWithDays();
															sd.setDaysCode(dcreq
																	.getDaysCode()
																	.trim());
															sd.setShiftCode(shift
																	.getShiftCode());
															ShiftWithDays sdRes = shiftDaysrepo
																	.save(sd);
															if (sdRes != null
																	&& sdRes.getId() > 0) {
																dcres.setMessage("Mapping of Shift with Days has been added successfully.");
																dcres.setDaysName(days
																		.getDaysName());
																dcres.setId(sdRes
																		.getId());
//                                                                                                                                kafkaService.sendShiftWithDays(sdRes);
															} else {
																dcres.setMessage("Mapping of Shift with Days has been failed.");
															}

														}

														// jsonobj.put("responsecode",
														// 200);
														// jsonobj.put("timestamp",
														// new Date());
														// jsonobj.put("message",
														// "New Shift added successfully.");
														// ObjectMapper
														// mapperObj = new
														// ObjectMapper();
														// String Detail =
														// mapperObj.writeValueAsString(shift);
														// jsonobj.put("data",
														// new
														// JSONObject(Detail));
													} else {
														dcres.setMessage("Days Code Not Found.");
														// jsonobj.put("message",
														// "Days Code Not Found.");
														// jsonobj.put("responsecode",
														// 400);
														// jsonobj.put("timestamp",
														// new Date());
													}
													dcreslst.add(dcres);
												}
											}

											SaveMultiShiftRes msres = new SaveMultiShiftRes();
											msres.setDaysCodeList(dcreslst);
											msres.setShift(shift);
											jsonobj.put("responsecode", 200);
											jsonobj.put("timestamp", new Date());
											jsonobj.put("message",
													"Shift updated successfully.");
											ObjectMapper mapperObj = new ObjectMapper();
											String Detail = mapperObj
													.writeValueAsString(msres);
											jsonobj.put("data", new JSONObject(
													Detail));
										} else {
											jsonobj.put("responsecode", 400);
											jsonobj.put("message",
													"Shift updation has been failed.");
											jsonobj.put("timestamp", new Date());
										}
									} else {
										jsonobj.put("message",
												"Record is already exists!");
										jsonobj.put("responsecode", 409);
										jsonobj.put("timestamp", new Date());
									}
								} else {
									jsonobj.put("responsecode", 400);
									jsonobj.put("message",
											"Start time must be before endtime.");
									jsonobj.put("timestamp", new Date());

								}
							} else {
								jsonobj.put("message",
										"Exception Occured in ShiftStart and ShiftEnd");
								jsonobj.put("responsecode", 500);
								jsonobj.put("timestamp", new Date());

							}

						} else {
							jsonobj.put("message",
									"Working Location Code Not Found.");
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("message", "Organization Code Not Found.");
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Shift does not exist.");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Data Should not be blank.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();

		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;

	}

	// @Override
	// public String getAllOrgWorkerShift(String organizationCode) {
	// String res = "";
	// try {
	// JSONObject jsonobj = new JSONObject();
	//
	// List<Object> objlst =
	// shiftRep.getAllOrgWorkerShiftWithNames(organizationCode);
	// List<OrganizationWorkerShiftResponse> maplst = new
	// ArrayList<OrganizationWorkerShiftResponse>();
	// if (objlst != null && objlst.size() > 0) {
	// for (int i = 0; i < objlst.size(); i++) {
	// Object[] arr = (Object[]) objlst.get(i);
	// if (arr.length >= 4) {
	// OrganizationWorkerShiftResponse ows = new
	// OrganizationWorkerShiftResponse();
	//
	// Shift data = (Shift) arr[0];
	//
	// ows.setId(data.getId());
	// ows.setShiftCode(data.getShiftCode());
	// ows.setShiftName(data.getShiftName());
	// ows.setOrganizationCode(data.getOrganizationCode());
	// ows.setDaysCode(data.getDaysCode());
	// ows.setWorkingLocationCode(data.getWorkingLocationCode());
	// ows.setIsActive(data.getIsActive());
	// ows.setStartTime(data.getStartTime());
	// ows.setEndTime(data.getEndTime());
	//
	// ows.setOrganizationName((String) arr[1]);
	// ows.setDaysName((String) arr[2]);
	// ows.setLocation((String) arr[3]);
	//
	// maplst.add(ows);
	//
	// }
	// }
	// if (maplst.size() > 0) {
	// ObjectMapper mapperObj = new ObjectMapper();
	// String Detail = mapperObj.writeValueAsString(maplst);
	// jsonobj.put("responsecode", 200);
	// jsonobj.put("message", "Success");
	// jsonobj.put("timestamp", new Date());
	// jsonobj.put("data", new JSONArray(Detail));
	// } else {
	// jsonobj.put("responsecode", 404);
	// jsonobj.put("message", "Record Not Found");
	// jsonobj.put("timestamp", new Date());
	// }
	// } else {
	// jsonobj.put("responsecode", 404);
	// jsonobj.put("message", "Record Not Found");
	// jsonobj.put("timestamp", new Date());
	// }
	//
	// res = jsonobj.toString();
	// } catch (JSONException ex) {
	// GigflexResponse derr = new GigflexResponse(500, new Date(),
	// "JSON parsing exception is occurred.");
	// res = derr.toString();
	// ex.printStackTrace();
	// } catch (Exception ex) {
	// GigflexResponse derr = new GigflexResponse(500, new Date(),
	// "Exception is occurred.");
	// res = derr.toString();
	// ex.printStackTrace();
	// }
	// return res;
	// }

	@Override
	public String softDeleteOrgWorkerShiftById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Shift shiftlst = shiftRep.getShiftById(id);

			if (shiftlst != null && shiftlst.getId() > 0) {
				shiftlst.setIsDeleted(true);
				Shift shiftRes = shiftRep.save(shiftlst);
				if (shiftRes != null && shiftRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Shift deleted successfully.");

//					kafkaService.sendUpdateShift(shiftRes);
					List<ShiftWithDays> sdlst = shiftDaysrepo
							.getShiftWithDaysByShiftCode(shiftlst
									.getShiftCode());
					if (sdlst != null && sdlst.size() > 0) {
						for (ShiftWithDays sd : sdlst) {
							sd.setIsDeleted(Boolean.TRUE);
							ShiftWithDays sdres=shiftDaysrepo.save(sd);
 //                                                       kafkaService.sendUpdateShiftWithDays(sdres);
						}
					}

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
			LOG.error("Error in softDeleteById>>>>>>", ex);
		} catch (org.springframework.orm.jpa.JpaSystemException ex) {
			GigflexResponse derr = new GigflexResponse(401, new Date(),
					GigUtil.getRootException(ex));
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
			LOG.error("Error in softDeleteById>>>>>>", ex);
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;

	}

	@Override
	public String softMultipleDeleteById(List<Long> idList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (Long id : idList) {
				if (id != null && id > 0) {
					JSONObject jsonobj = new JSONObject();

					Shift shiftlst = shiftRep.getShiftById(id);

					if (shiftlst != null && shiftlst.getId() > 0) {
						try {
							shiftlst.setIsDeleted(true);
							Shift shiftRes = shiftRep.save(shiftlst);
							if (shiftRes != null && shiftRes.getId() > 0) {
								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("Id", id);
								jsonobj.put("message",
										"Multiple Shift deleted successfully.");

//								kafkaService.sendUpdateShift(shiftRes);
								List<ShiftWithDays> sdlst = shiftDaysrepo
										.getShiftWithDaysByShiftCode(shiftlst
												.getShiftCode());
								if (sdlst != null && sdlst.size() > 0) {
									for (ShiftWithDays sd : sdlst) {
										sd.setIsDeleted(Boolean.TRUE);
										ShiftWithDays sdres=shiftDaysrepo.save(sd);
 //                                                                                kafkaService.sendUpdateShiftWithDays(sdres);
									}
								}
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("Id", id);
								jsonobj.put("message", "Failed");
							}
						} catch (org.springframework.orm.jpa.JpaSystemException ex) {
							jsonobj.put("responsecode", 401);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("Id", id);
							jsonobj.put("message", GigUtil.getRootException(ex));
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("Id", id);
						jsonobj.put("message", "Record Not Found");
					}

					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	// @Override
	// public String getAllShiftWithOrgCodeByPage(String organizationCode, int
	// page, int limit) {
	// String res = "";
	// try {
	// JSONObject jsonobj = new JSONObject();
	// Pageable pageableRequest = PageRequest.of(page, limit);
	// List<Object> objlst =
	// shiftRep.getAllOrgWorkerShiftWithNames(organizationCode,
	// pageableRequest);
	// List<OrganizationWorkerShiftResponse> maplst = new
	// ArrayList<OrganizationWorkerShiftResponse>();
	// if (objlst != null && objlst.size() > 0) {
	// for (int i = 0; i < objlst.size(); i++) {
	// Object[] arr = (Object[]) objlst.get(i);
	// if (arr.length >= 4) {
	// OrganizationWorkerShiftResponse ows = new
	// OrganizationWorkerShiftResponse();
	//
	// Shift data = (Shift) arr[0];
	//
	// ows.setId(data.getId());
	// ows.setShiftCode(data.getShiftCode());
	// ows.setShiftName(data.getShiftName());
	// ows.setOrganizationCode(data.getOrganizationCode());
	// ows.setDaysCode(data.getDaysCode());
	// ows.setWorkingLocationCode(data.getWorkingLocationCode());
	// ows.setIsActive(data.getIsActive());
	// ows.setStartTime(data.getStartTime());
	// ows.setEndTime(data.getEndTime());
	//
	// ows.setOrganizationName((String) arr[1]);
	// ows.setDaysName((String) arr[2]);
	// ows.setLocation((String) arr[3]);
	//
	// maplst.add(ows);
	//
	// }
	// }
	// if (maplst.size() > 0) {
	// ObjectMapper mapperObj = new ObjectMapper();
	// String Detail = mapperObj.writeValueAsString(maplst);
	// jsonobj.put("responsecode", 200);
	// jsonobj.put("message", "Success");
	// jsonobj.put("timestamp", new Date());
	// jsonobj.put("data", new JSONArray(Detail));
	// } else {
	// jsonobj.put("responsecode", 404);
	// jsonobj.put("message", "Record Not Found");
	// jsonobj.put("timestamp", new Date());
	// }
	// } else {
	// jsonobj.put("responsecode", 404);
	// jsonobj.put("message", "Record Not Found");
	// jsonobj.put("timestamp", new Date());
	// }
	//
	// res = jsonobj.toString();
	// } catch (JSONException ex) {
	// GigflexResponse derr = new GigflexResponse(500, new Date(),
	// "JSON parsing exception is occurred.");
	// res = derr.toString();
	// ex.printStackTrace();
	// } catch (Exception ex) {
	// GigflexResponse derr = new GigflexResponse(500, new Date(),
	// "Exception is occurred.");
	// res = derr.toString();
	// ex.printStackTrace();
	// }
	// return res;
	// }


	// @Override
	// public String getShiftByOrgCode(String organizationCode) {
	// String res = "";
	// try {
	// JSONObject jsonobj = new JSONObject();
	// List<Shift> shiftlst =
	// shiftRep.getShiftByOrganizationCode(organizationCode);
	// if (shiftlst != null && shiftlst.size() > 0) {
	// ObjectMapper mapperObj = new ObjectMapper();
	// String Detail = mapperObj.writeValueAsString(shiftlst);
	// jsonobj.put("responsecode", 200);
	// jsonobj.put("timestamp", new Date());
	// jsonobj.put("message", "Success");
	// jsonobj.put("data", new JSONArray(Detail));
	// } else {
	// jsonobj.put("responsecode", 404);
	// jsonobj.put("timestamp", new Date());
	// jsonobj.put("message", "Record Not Found");
	// }
	// res = jsonobj.toString();
	// } catch (JSONException | JsonProcessingException ex) {
	// GigflexResponse derr = new GigflexResponse(500, new Date(),
	// "JSON parsing exception is occurred.");
	// res = derr.toString();
	// }
	// catch (Exception ex) {
	// GigflexResponse derr = new GigflexResponse(500, new Date(),
	// "Exception is occurred.");
	// res = derr.toString();
	// }
	// return res;
	// }
	// @Override
	// public String updateShiftByWorkingLocation(String locationCode,
	// MultiShiftRequest shiftRequest, String ip) {
	// String res = "";
	// try {
	// JSONObject jsonobj = new JSONObject();
	// if (shiftRequest.getOrganizationCode() != null &&
	// shiftRequest.getOrganizationCode().trim().length() > 0
	// && shiftRequest.getDaysCodeList() != null &&
	// shiftRequest.getDaysCodeList().size() > 0
	// && shiftRequest.getWorkingLocationCode() != null &&
	// shiftRequest.getWorkingLocationCode().trim().length() > 0
	// && shiftRequest.getShiftName() != null &&
	// shiftRequest.getShiftName().trim().length() > 0
	// && shiftRequest.getEndTime() != null &&
	// shiftRequest.getEndTime().trim().length() > 0 &&
	// shiftRequest.getStartTime() != null &&
	// shiftRequest.getStartTime().trim().length() > 0) {
	//
	// Date startTime = null;
	// Date endTime = null;
	//
	// try {
	// startTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
	// .parse(shiftRequest.getStartTime().trim());
	// endTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
	// .parse(shiftRequest.getEndTime().trim());
	// if (startTime == null || endTime == null) {
	// GigflexResponse derr = new GigflexResponse(400, new Date(),
	// "Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
	// return derr.toString();
	// }
	// } catch (Exception ex) {
	// ex.printStackTrace();
	// GigflexResponse derr = new GigflexResponse(400, new Date(),
	// "Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
	// return derr.toString();
	// }
	//
	// Organization org =
	// orgRep.findByOrganizationCode(shiftRequest.getOrganizationCode());
	//
	// if (org != null && org.getId() > 0) {
	//
	// WorkingLocation wl = workLocRep
	// .findByWorkingLocationCode(shiftRequest.getWorkingLocationCode());
	//
	// if (wl != null && wl.getId() > 0) {
	//
	// if (startTime.before(endTime)) {
	// List<DaysCodeRes> dcreslst = new ArrayList<DaysCodeRes>();
	// for (DaysCodeResquest dcreq : shiftRequest.getDaysCodeList()) {
	// if (dcreq.getDaysCode() != null && dcreq.getDaysCode().trim().length() >
	// 0 && dcreq.getId() != null && dcreq.getId() > 0) {
	// DaysCodeRes dcres = new DaysCodeRes();
	// dcres.setDaysCode(dcreq.getDaysCode().trim());
	// dcres.setId(dcreq.getId());
	// DaysMaster days =
	// daysDao.getDaysMasterByDaysCode(dcreq.getDaysCode().trim());
	//
	// if (days != null && days.getId() > 0) {
	//
	// dcres.setDaysName(days.getDaysName());
	//
	// Shift shiftlst = shiftRep.getShiftById(dcreq.getId());
	//
	// if (shiftlst != null && shiftlst.getId() > 0) {
	//
	// // Date startTime = null;
	// // Date endTime = null;
	// // try {
	// // startTime =
	// GigflexDateUtil.convertStringToDate(shiftRequest.getStartTime());
	// // endTime =
	// GigflexDateUtil.convertStringToDate(shiftRequest.getEndTime());
	// // } catch (Exception ex) {
	// // ex.printStackTrace();
	// // GigflexResponse derr = new GigflexResponse(400, new Date(),
	// // "Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
	// // return derr.toString();
	// // }
	// Shift shiftInDb = shiftRep.findShiftByOrganizationCodeWithId(
	// shiftRequest.getShiftName(), shiftRequest.getOrganizationCode(),
	// dcreq.getDaysCode().trim(), shiftRequest.getWorkingLocationCode(),
	// dcreq.getId());
	//
	// Shift shift = null;
	// if (shiftInDb == null) {
	//
	// shiftlst.setOrganizationCode(shiftRequest.getOrganizationCode().trim());
	// shiftlst.setShiftName(shiftRequest.getShiftName());
	// // shiftlst.setDaysCode(dcreq.getDaysCode().trim());
	// shiftlst.setWorkingLocationCode(shiftRequest.getWorkingLocationCode().trim());
	// shiftlst.setStartTime(startTime);
	// shiftlst.setEndTime(endTime);
	//
	// shiftlst.setIpAddress(ip);
	// shiftlst.setIsActive(shiftRequest.getIsActive());
	//
	// jsonobj.put("responsecode", 200);
	// jsonobj.put("timestamp", new Date());
	//
	// shift = shiftRep.save(shiftlst);
	//
	// if (shift != null && shift.getId() > 0) {
	// dcres.setMessage("Shift updated successfully.");
	// // jsonobj.put("responsecode", 200);
	// // jsonobj.put("message", "Shift updated successfully.");
	// // jsonobj.put("timestamp", new Date());
	// // ObjectMapper mapperObj = new ObjectMapper();
	// // String Detail = mapperObj.writeValueAsString(shift);
	// // jsonobj.put("data", new JSONObject(Detail));
	//
	// kafkaService.sendUpdateShift(shift);
	// } else {
	// // jsonobj.put("responsecode", 400);
	// // jsonobj.put("message", "Shift updation has been failed.");
	// // jsonobj.put("timestamp", new Date());
	// dcres.setMessage("Shift updation has been failed.");
	// }
	//
	// } else {
	// dcres.setMessage("Record is already exists!");
	//
	// //jsonobj.put("message", "Record is already exists!");
	// // ObjectMapper mapperObj = new ObjectMapper();
	// // String Detail = mapperObj.writeValueAsString(shift);
	// // jsonobj.put("data", new JSONObject(Detail));
	// }
	// } else {
	// // jsonobj.put("responsecode", 400);
	// // jsonobj.put("message", "Input data is not valid.");
	// // jsonobj.put("timestamp", new Date());
	// dcres.setMessage("shift id is not valid.");
	// }
	//
	// } else {
	// // jsonobj.put("message", "Days Code Not Found.");
	// // jsonobj.put("responsecode", 400);
	// // jsonobj.put("timestamp", new Date());
	// dcres.setMessage("Days Code Not Found.");
	// }
	// dcreslst.add(dcres);
	// }
	// }
	// if (dcreslst != null && dcreslst.size() > 0) {
	// MultiShiftRes msres = new MultiShiftRes();
	// msres.setDaysCodeList(dcreslst);
	// msres.setEndTime(shiftRequest.getEndTime().trim());
	// msres.setIsActive(shiftRequest.getIsActive());
	// msres.setOrganizationCode(shiftRequest.getOrganizationCode());
	// msres.setShiftName(shiftRequest.getShiftName());
	// msres.setStartTime(shiftRequest.getStartTime().trim());
	// msres.setWorkingLocationCode(shiftRequest.getOrganizationCode());
	// jsonobj.put("responsecode", 200);
	// jsonobj.put("timestamp", new Date());
	// jsonobj.put("message", "Success");
	// ObjectMapper mapperObj = new ObjectMapper();
	// String Detail = mapperObj.writeValueAsString(msres);
	// jsonobj.put("data", new JSONObject(Detail));
	//
	// } else {
	// jsonobj.put("message", "Failed");
	// jsonobj.put("responsecode", 400);
	// jsonobj.put("timestamp", new Date());
	// }
	// } else {
	// jsonobj.put("responsecode", 400);
	// jsonobj.put("message", "Start time must be before endtime.");
	// jsonobj.put("timestamp", new Date());
	//
	// }
	// } else {
	// jsonobj.put("message", "Working Location Code Not Found.");
	// jsonobj.put("responsecode", 400);
	// jsonobj.put("timestamp", new Date());
	// }
	// } else {
	// jsonobj.put("message", "Organization Code Not Found.");
	// jsonobj.put("responsecode", 400);
	// jsonobj.put("timestamp", new Date());
	// }
	//
	// } else {
	// jsonobj.put("responsecode", 400);
	// jsonobj.put("message", "Data Should not be blank.");
	// jsonobj.put("timestamp", new Date());
	// }
	//
	// res = jsonobj.toString();
	//
	// } catch (JSONException ex) {
	// GigflexResponse derr = new GigflexResponse(500, new Date(),
	// "JSON parsing exception is occurred.");
	// res = derr.toString();
	// ex.printStackTrace();
	// } catch (Exception ex) {
	// GigflexResponse derr = new GigflexResponse(500, new Date(),
	// "Exception is occurred.");
	// res = derr.toString();
	// ex.printStackTrace();
	// }
	// return res;
	// }
	//
	//

}
