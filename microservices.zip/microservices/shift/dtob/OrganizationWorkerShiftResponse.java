package com.gigflex.prototype.microservices.shift.dtob;

import java.util.Date;



public class OrganizationWorkerShiftResponse {

	private Long id;

	private String organizationCode;

	private String organizationName;

	private String daysCode;

	private String daysName;

	private String workingLocationCode;

	private String location;

	private String shiftName;

	private String shiftCode;

	private Date startTime;

	private Date endTime;
	
	private Boolean isActive;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	public String getDaysCode() {
		return daysCode;
	}

	public void setDaysCode(String daysCode) {
		this.daysCode = daysCode;
	}

	public String getDaysName() {
		return daysName;
	}

	public void setDaysName(String daysName) {
		this.daysName = daysName;
	}

	public String getWorkingLocationCode() {
		return workingLocationCode;
	}

	public void setWorkingLocationCode(String workingLocationCode) {
		this.workingLocationCode = workingLocationCode;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getShiftName() {
		return shiftName;
	}

	public void setShiftName(String shiftName) {
		this.shiftName = shiftName;
	}

	public String getShiftCode() {
		return shiftCode;
	}

	public void setShiftCode(String shiftCode) {
		this.shiftCode = shiftCode;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	
	
	

}
