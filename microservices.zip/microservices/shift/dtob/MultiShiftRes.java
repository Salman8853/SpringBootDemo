package com.gigflex.prototype.microservices.shift.dtob;

import java.util.List;



/**
 * 
 * @author ajit.p
 *
 */
public class MultiShiftRes {
	
	private String organizationCode;
	
	private List<DaysCodeRes> daysCodeList;
	
	private String workingLocationCode;

	private String shiftName;
	
	private String startTime;
	
	private String endTime;
	
    private Boolean isActive;

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}

    public List<DaysCodeRes> getDaysCodeList() {
        return daysCodeList;
    }

    public void setDaysCodeList(List<DaysCodeRes> daysCodeList) {
        this.daysCodeList = daysCodeList;
    }

    
	public String getWorkingLocationCode() {
		return workingLocationCode;
	}

	public void setWorkingLocationCode(String workingLocationCode) {
		this.workingLocationCode = workingLocationCode;
	}

	public String getShiftName() {
		return shiftName;
	}

	public void setShiftName(String shiftName) {
		this.shiftName = shiftName;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	
	

	
}
