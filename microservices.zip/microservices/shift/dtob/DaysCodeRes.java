/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.shift.dtob;

import javax.persistence.Column;

/**
 *
 * @author nirbhay.p
 */
public class DaysCodeRes {
    private Long id;

	private String message;
	private String daysCode;
        private String daysName;

    public String getDaysName() {
        return daysName;
    }

    public void setDaysName(String daysName) {
        this.daysName = daysName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDaysCode() {
        return daysCode;
    }

    public void setDaysCode(String daysCode) {
        this.daysCode = daysCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
        
        
}
