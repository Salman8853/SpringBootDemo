/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.shift.repository;

import com.gigflex.prototype.microservices.shift.dtob.ShiftWithDays;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author nirbhay.p
 */
public interface ShiftWithDaysRepository extends JpaRepository<ShiftWithDays, Long>,JpaSpecificationExecutor<ShiftWithDays>{
    @Query("SELECT a FROM ShiftWithDays a  WHERE a.isDeleted != TRUE AND  a.daysCode= :daysCode AND  a.shiftCode = :shiftCode")
    public ShiftWithDays getShiftWithDaysByShiftCodeDayscode(@Param("shiftCode") String shiftCode, @Param("daysCode") String daysCode);
    
    @Transactional
    @Modifying
    @Query("DELETE FROM ShiftWithDays a  WHERE a.isDeleted != TRUE AND  a.shiftDaysCode = :shiftDaysCode")
    public void deleteShiftWithDaysByShiftDaysCode(@Param("shiftDaysCode") String shiftDaysCode);
    
    
    
    
    
     @Query("SELECT a FROM ShiftWithDays a  WHERE a.isDeleted != TRUE AND  a.shiftCode = :shiftCode")
    public List<ShiftWithDays> getShiftWithDaysByShiftCode(@Param("shiftCode") String shiftCode);
    

}
