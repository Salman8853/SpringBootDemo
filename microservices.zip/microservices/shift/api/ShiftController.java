/**
 * 
 */
package com.gigflex.prototype.microservices.shift.api;

import com.gigflex.prototype.microservices.shift.dtob.MultiShiftRequest;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.shift.dtob.ShiftRequest;
import com.gigflex.prototype.microservices.shift.service.ShiftService;
import com.gigflex.prototype.microservices.util.GigflexResponse;

/**
 * @author ajit.p
 *
 */
@CrossOrigin(origins="*")
@RestController
@RequestMapping("/healthcareservice/")
public class ShiftController {
	
	@Autowired
	ShiftService shiftService;
	
	@GetMapping("/shift/{search}")
	public String search(@PathVariable("search") String search) {
		return shiftService.search(search);
	}
	
//	@GetMapping("/getAllOrganizationWorkerShiftWithNames/{organizationCode}")
//	public String getAllOrganizationWorkerShiftWithNames(@PathVariable String organizationCode){
//		return shiftService.getAllOrgWorkerShift(organizationCode);
//	}
        
        @GetMapping("/getAllOrganizationWorkerShiftByLocationCode/{locationCode}")
	public String getAllOrganizationWorkerShiftByLocationCode(@PathVariable String locationCode){
		return shiftService.getAllOrganizationWorkerShiftByLocationCode(locationCode);
	}
	
        
        @GetMapping(path="/getAllOrganizationWorkerShiftByLocationCodeByPage/{locationCode}")
    public String getAllOrganizationWorkerShiftByLocationCodeByPage(@PathVariable String locationCode,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String shift = shiftService.getAllOrganizationWorkerShiftByLocationCodeByPage(locationCode,page, limit);
      
        return shift;
       
    }
//	@GetMapping("/getAllOrganizationWorkerShiftByOrgCode/{organizationCode}")
//	public String getAllOrganizationWorkerShiftByOrgCode(@PathVariable String organizationCode){
//		return shiftService.getShiftByOrgCode(organizationCode);
//	}
	
	
//	@GetMapping(path="/getAllOrganizationWorkerShiftByPage/{organizationCode}")
//    public String getAllOrganizationWorkerShiftByPage(@PathVariable String organizationCode,@RequestParam(value = "page", defaultValue = "0") int page,
//            @RequestParam(value = "limit", defaultValue = "30") int limit) {
//
//        String shift = shiftService.getAllShiftWithOrgCodeByPage(organizationCode,page, limit);
//      
//        return shift;
//       
//    }
	
	@PostMapping("/createShift")
	public String createShift(
			 @RequestBody MultiShiftRequest shiftRequest,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return shiftService.createShift(shiftRequest, ip);
	}
        
//        @PutMapping("/updateShiftByWorkingLocation/{locationCode}")
//	public String updateShiftById(@PathVariable String locationCode,
//			 @RequestBody MultiShiftRequest shiftRequest,
//			HttpServletRequest request) {
//		if (locationCode != null && shiftRequest!=null && locationCode.trim().length() > 0) {
//		if(shiftRequest.getWorkingLocationCode()!=null && shiftRequest.getWorkingLocationCode().trim().length()>0
//                        && shiftRequest.getWorkingLocationCode().trim().equals(locationCode))
//                {
//                    String ip = request.getRemoteAddr();
//
//			return shiftService.updateShiftByWorkingLocation(locationCode, shiftRequest, ip);
//                }else
//                {
//                     GigflexResponse derr = new GigflexResponse(400, new Date(), "Working Location Code should be same.");
//                return derr.toString();
//                }
//		
//                } else {
//                GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
//                return derr.toString();
//            }
//	}
	
	@PutMapping("/updateShiftById/{id}")
	public String updateShiftById(@PathVariable Long id,
			 @RequestBody MultiShiftRequest shiftRequest,
			HttpServletRequest request) {
		if (id != null && shiftRequest!=null && id > 0) {
		String ip = request.getRemoteAddr();

			return shiftService.updateShiftById(id, shiftRequest, ip);
		
                } else {
                GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
                return derr.toString();
            }
	}
	
	@DeleteMapping("/softDeleteShiftById/{id}")
	public String softDeleteShiftById(@PathVariable Long id) {
		return shiftService.softDeleteOrgWorkerShiftById(id);
	}
	
	@DeleteMapping("/softMultipleDeleteById/{idList}")
	public String softMultipleDeleteById(@PathVariable List<Long> idList) {
		if(idList != null && idList.size()>0){
			return shiftService.softMultipleDeleteById(idList);
		}else{
			 GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
	           return derr.toString();
		}
	}
}