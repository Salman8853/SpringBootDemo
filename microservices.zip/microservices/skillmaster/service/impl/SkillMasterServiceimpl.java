package com.gigflex.prototype.microservices.skillmaster.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.industry.dtob.IndustryMaster;
import com.gigflex.prototype.microservices.industry.repository.IndustryMasterDao;
import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMaster;
import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMasterRequest;
import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMasterResponse;
import com.gigflex.prototype.microservices.skillmaster.repository.SkillMasterDao;
import com.gigflex.prototype.microservices.skillmaster.search.SkillMasterSpecificationsBuilder;
import com.gigflex.prototype.microservices.skillmaster.service.SkillMasterService;
import com.gigflex.prototype.microservices.util.GigUtil;
import com.gigflex.prototype.microservices.util.GigflexResponse;

@Service
public class SkillMasterServiceimpl implements SkillMasterService {

	private static final Logger LOG = LoggerFactory
			.getLogger(SkillMasterServiceimpl.class);

	@Autowired
	private SkillMasterDao skillMasterDao;

	@Autowired
	private IndustryMasterDao industryDao;

	

	@Override
	public String updateSkillMasterById(Long id,
			SkillMasterRequest skillMasterReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (id > 0 && skillMasterReq != null) {
				if (skillMasterReq.getSkillname() != null
						&& skillMasterReq.getSkillname().trim().length() > 0
						&& skillMasterReq.getIndustryCode() != null
						&& skillMasterReq.getIndustryCode().trim().length() > 0) {

					IndustryMaster im = industryDao
							.getIndustryMasterByIndustryCode(skillMasterReq
									.getIndustryCode().trim());
					if (im != null && im.getId() > 0) {

						SkillMaster skillMasterInDb = skillMasterDao
								.getSkillMasterById(id);

						if (skillMasterInDb != null
								&& skillMasterInDb.getId() > 0) {

							SkillMaster skills = skillMasterInDb;

							if (!(skillMasterReq.getSkillname().equals(skills
									.getSkillName()))) {

								SkillMaster skilllst = skillMasterDao
										.getSkillMasterCheckForUpdate(id,
												skillMasterReq
														.getIndustryCode(),
												skillMasterReq.getSkillname());

								if (skilllst != null && skilllst.getId() > 0) {
									jsonobj.put("responsecode", 409);
									jsonobj.put("timestamp", new Date());
									jsonobj.put("message",
											"Record already exists!");
								} else {
									skills.setSkillName(skillMasterReq
											.getSkillname());
									skills.setIpAddress(ip);
									SkillMaster skillRes = skillMasterDao
											.save(skills);
									if (skillRes != null
											&& skillRes.getId() > 0) {
										jsonobj.put("responsecode", 200);
										jsonobj.put("message",
												"Skill Master updation has been done");
										jsonobj.put("timestamp", new Date());
										ObjectMapper mapperObj = new ObjectMapper();
										String Detail = mapperObj
												.writeValueAsString(skillRes);
										jsonobj.put("data", new JSONObject(
												Detail));

//										kafkaService
//												.sendUpdateSkillMaster(skillRes);

									} else {
										jsonobj.put("responsecode", 400);
										jsonobj.put("message",
												"Skill Master updation has been failed.");
										jsonobj.put("timestamp", new Date());
									}
								}
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("message",
										"Old Skill name and New Skill name should be different.");
								jsonobj.put("timestamp", new Date());
							}

						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "Skill ID is not valid.");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("message", "Industry Code Not Found.");
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;

	}

	@Override
	public String findAllSkillMaster() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<SkillMaster> skilllst = skillMasterDao.getAllSkillMaster();

			if (skilllst != null && skilllst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(skilllst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "No data found.");
				jsonobj.put("timestamp", new Date());

			}

			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String findSkillMasterById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			SkillMaster skilllst = skillMasterDao.getSkillMasterById(id);
			if (skilllst != null) {

				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				if (skilllst.getId() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(skilllst);
					jsonobj.put("data", new JSONObject(Detail));
					jsonobj.put("message", "Success");
				} else {
					jsonobj.put("message", "Record Not Found");
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String saveSkillMaster(SkillMasterRequest skillMasterReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (skillMasterReq != null) {
				if (skillMasterReq.getSkillname() != null
						&& skillMasterReq.getSkillname().trim().length() > 0
						&& skillMasterReq.getIndustryCode() != null
						&& skillMasterReq.getIndustryCode().trim().length() > 0) {

					IndustryMaster im = industryDao
							.getIndustryMasterByIndustryCode(skillMasterReq
									.getIndustryCode().trim());
					if (im != null && im.getId() > 0) {

						SkillMaster skilllst = skillMasterDao
								.getSkillMasterCheckForSave(
										skillMasterReq.getIndustryCode(),
										skillMasterReq.getSkillname());

						if (skilllst != null && skilllst.getId() > 0) {

							jsonobj.put("responsecode", 409);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Record already exists!");
						} else {

							SkillMaster skill = new SkillMaster();
							skill.setSkillName(skillMasterReq.getSkillname());
							skill.setIndustryCode(skillMasterReq
									.getIndustryCode());
							skill.setIpAddress(ip);

							SkillMaster skillRes = skillMasterDao.save(skill);

							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());

							if (skillRes != null && skillRes.getId() > 0) {

//								kafkaService.sendSkillMaster(skillRes);

								jsonobj.put("message",
										"Skill Master has been added successfully.");
								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj
										.writeValueAsString(skillRes);
								jsonobj.put("data", new JSONObject(Detail));
							} else {
								jsonobj.put("message", "Failed");
							}
						}
					} else {
						jsonobj.put("message", "Industry Code Not Found.");
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
					}

				}

				else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String deleteSkillMasterById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Optional<SkillMaster> skilllst = skillMasterDao.findById(id);
			if (skilllst.isPresent() && skilllst.get() != null) {
				skillMasterDao.deleteById(id);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Skill master has been deleted.");
				SkillMaster skills = skilllst.get();

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
			}
			jsonobj.put("timestamp", new Date());
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getSkillMasterBySkillCode(String skillCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			SkillMaster skilllst = skillMasterDao
					.getSkillMasterBySkillCode(skillCode);
			if (skilllst != null && skilllst.getId() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(skilllst);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Success");
				jsonobj.put("data", new JSONObject(Detail));

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String deleteBySkillCode(String skillCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			SkillMaster skilllst = skillMasterDao
					.getSkillMasterBySkillCode(skillCode);
			Integer deleteBySkillCode = skillMasterDao
					.deleteBySkillCode(skillCode);
			if (deleteBySkillCode != 0 && skilllst != null
					&& skilllst.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Skill Master has been deleted.");
				jsonobj.put("timestamp", new Date());

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();

		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softDeleteBySkillCode(String skillCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			SkillMaster skilllst = skillMasterDao
					.getSkillMasterBySkillCode(skillCode);

			if (skilllst != null && skilllst.getId() > 0) {

				skilllst.setIsDeleted(true);
				SkillMaster skillRes = skillMasterDao.save(skilllst);
				if (skillRes != null && skillRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Role Master deleted successfully.");
//					kafkaService.sendUpdateSkillMaster(skillRes);
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
			LOG.error("Error in softDeleteBySkillCode>>>>>>", ex);
		} catch (org.springframework.orm.jpa.JpaSystemException ex) {
			GigflexResponse derr = new GigflexResponse(401, new Date(),
					GigUtil.getRootException(ex));
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
			LOG.error("Error in softDeleteBySkillCode>>>>>>", ex);
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteBySkillCode(List<String> skillCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String skillCode : skillCodeList) {
				if (skillCode != null && skillCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					skillCode = skillCode.trim();

					SkillMaster skilllst = skillMasterDao
							.getSkillMasterBySkillCode(skillCode);

					if (skilllst != null && skilllst.getId() > 0) {

						try {

							skilllst.setIsDeleted(true);
							SkillMaster skillRes = skillMasterDao
									.save(skilllst);
							if (skillRes != null && skillRes.getId() > 0) {
								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("code", skillCode);
								jsonobj.put("message",
										"Skill Master deleted successfully.");
//								kafkaService.sendUpdateSkillMaster(skillRes);
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("code", skillCode);
								jsonobj.put("message", "Failed");
							}
						} catch (org.springframework.orm.jpa.JpaSystemException ex) {
							jsonobj.put("responsecode", 401);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", skillCode);
							jsonobj.put("message", GigUtil.getRootException(ex));
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", skillCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getAllSkillMasterByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<SkillMaster> skilllst = skillMasterDao
					.getAllSkillMaster(pageableRequest);
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (skilllst != null && skilllst.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(skilllst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();

			if (search != null && search.trim().length() > 0) {
				JSONObject jsonobj = new JSONObject();

				SkillMasterSpecificationsBuilder builder = new SkillMasterSpecificationsBuilder();
				Pattern pattern = Pattern
						.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
				java.util.regex.Matcher matcher = pattern.matcher(search + ",");
				while (matcher.find()) {
					builder.with(matcher.group(1), matcher.group(2),
							matcher.group(3));
				}

				Specification<SkillMaster> spec = builder.build();
				if (spec != null) {
					List<SkillMaster> skilllst = skillMasterDao.findAll(spec);
					if (skilllst != null && skilllst.size() > 0) {
						for (SkillMaster skill : skilllst) {
							if (skill.getIsDeleted() != null
									&& skill.getIsDeleted() != true) {
								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj
										.writeValueAsString(skill);
								JSONObject jsonobjNew = new JSONObject();
								jsonobjNew
										.put("skills", new JSONObject(Detail));
								jarr.add(jsonobjNew);

							}

						}
						if (jarr.size() > 0) {

							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "Success");
							jsonobj.put("timestamp", new Date());
							jsonobj.put("data", jarr);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "Record Not Found!");
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Record Not Found!");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Record Not Found!");
					jsonobj.put("timestamp", new Date());
				}
				res = jsonobj.toString();

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Input data is not valid.");
				res = derr.toString();

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getSkillWithNames() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<Object> objlst = skillMasterDao.getAllSkillWithNames();
			List<SkillMasterResponse> maplst = new ArrayList<SkillMasterResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 2) {
						SkillMasterResponse ows = new SkillMasterResponse();

						SkillMaster data = (SkillMaster) arr[0];

						ows.setId(data.getId());
						ows.setSkillCode(data.getSkillCode());
						ows.setIndustryCode(data.getIndustryCode());
						ows.setSkillName(data.getSkillName());

						ows.setIndustryName((String) arr[1]);
						maplst.add(ows);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getSkillWithNames(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);

			List<Object> objlst = skillMasterDao
					.getAllSkillWithNames(pageableRequest);
			List<SkillMasterResponse> maplst = new ArrayList<SkillMasterResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 2) {
						SkillMasterResponse ows = new SkillMasterResponse();

						SkillMaster data = (SkillMaster) arr[0];

						ows.setId(data.getId());
						ows.setSkillCode(data.getSkillCode());
						ows.setIndustryCode(data.getIndustryCode());
						ows.setSkillName(data.getSkillName());

						ows.setIndustryName((String) arr[1]);
						maplst.add(ows);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	/*
	 * @Override public String getSkillByOrganizationCode(String
	 * organizationCode) { String res = ""; try { JSONObject jsonobj = new
	 * JSONObject();
	 * 
	 * if (organizationCode != null && organizationCode.length() > 0) {
	 * List<SkillMaster> skillsRes = new ArrayList<SkillMaster>();
	 * 
	 * List<SkillMaster> skills = new ArrayList<SkillMaster>(); String
	 * industryCodeFromOrg = skillMasterDao
	 * .getSkillByIndustryAndOrganizationCode(organizationCode); skills =
	 * skillMasterDao .getSkillsByIndustryCode(industryCodeFromOrg);
	 * 
	 * for (SkillMaster sm : skills) { OrganizationSkill so =
	 * osDao.getSkillByOrgCodeSkillCode( organizationCode, sm.getSkillCode());
	 * 
	 * if (so == null) { skillsRes.add(sm); }
	 * 
	 * if (industryCodeFromOrg != null) { jsonobj.put("responsecode", 200);
	 * jsonobj.put("message", "Success"); jsonobj.put("timestamp", new Date());
	 * 
	 * if (skillsRes != null && skillsRes.size() > 0) { ObjectMapper mapperObj =
	 * new ObjectMapper(); String Detail = mapperObj
	 * .writeValueAsString(skillsRes); jsonobj.put("data", new
	 * JSONArray(Detail));
	 * 
	 * } else { jsonobj.put("responsecode", 404); jsonobj.put("timestamp", new
	 * Date()); jsonobj.put("message", "Record Not Found");
	 * 
	 * } } else { jsonobj.put("responsecode", 404); jsonobj.put("timestamp", new
	 * Date()); jsonobj.put("message", "Record Not Found");
	 * 
	 * } } } else { jsonobj.put("responsecode", 400); jsonobj.put("timestamp",
	 * new Date()); <<<<<<< HEAD }} else{ jsonobj.put("responsecode", 400);
	 * jsonobj.put("message", "Record Not Found!"); jsonobj.put("timestamp", new
	 * Date()); } ======= jsonobj.put("message", "Invalid Input"); }
	 * 
	 * >>>>>>> origin/181029_nirbhay_pratap_singh res = jsonobj.toString(); }
	 * catch (JSONException ex) { GigflexResponse derr = new
	 * GigflexResponse(500, new Date(), "JSON parsing exception occurred."); res
	 * = derr.toString(); ex.printStackTrace(); } catch (Exception ex) {
	 * GigflexResponse derr = new GigflexResponse(500, new Date(),
	 * "Exception is occurred."); res = derr.toString(); ex.printStackTrace(); }
	 * return res; }
	 */

    @Override
    public String getSkillsWithNamesByIndustryCode(String industryCode) {
        
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<Object> objlst = skillMasterDao.getAllSkillWithNamesByIndustryCode(industryCode);
			List<SkillMasterResponse> maplst = new ArrayList<SkillMasterResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 2) {
						SkillMasterResponse ows = new SkillMasterResponse();

						SkillMaster data = (SkillMaster) arr[0];

						ows.setId(data.getId());
						ows.setSkillCode(data.getSkillCode());
						ows.setIndustryCode(data.getIndustryCode());
						ows.setSkillName(data.getSkillName());

						ows.setIndustryName((String) arr[1]);
						maplst.add(ows);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	
    }

}
