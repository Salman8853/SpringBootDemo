package com.gigflex.prototype.microservices.skillmaster.search;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMaster;
import com.gigflex.prototype.microservices.util.SearchCriteria;


public class SkillMasterSpecificationsBuilder {
	private final List<SearchCriteria> params;
	 
    public SkillMasterSpecificationsBuilder() {
        params = new ArrayList<SearchCriteria>();
    }
 
    public SkillMasterSpecificationsBuilder with(String key, String operation, Object value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }
 
    public Specification<SkillMaster> build() {
        if (params.size() == 0) {
            return null;
        }
 
        List<Specification<SkillMaster>> specs = new ArrayList<Specification<SkillMaster>>();
        for (SearchCriteria param : params) {
            specs.add(new SkillMasterSpecification(param));
        }
 
        Specification<SkillMaster> result = specs.get(0);
        for (int i = 1; i < specs.size(); i++) {
            result = Specification.where(result).and(specs.get(i));
        }
        return result;
    }
}
