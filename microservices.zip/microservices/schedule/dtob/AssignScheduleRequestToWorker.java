/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.schedule.dtob;

/**
 *
 * @author abhishek
 */
public class AssignScheduleRequestToWorker {
    
    private String scheduleRequestCode;
     
    private String scheduleRequestAssignmentCode;
    
    private String workerCode;

    public String getScheduleRequestCode() {
        return scheduleRequestCode;
    }

    public void setScheduleRequestCode(String scheduleRequestCode) {
        this.scheduleRequestCode = scheduleRequestCode;
    }

    public String getScheduleRequestAssignmentCode() {
        return scheduleRequestAssignmentCode;
    }

    public void setScheduleRequestAssignmentCode(String scheduleRequestAssignmentCode) {
        this.scheduleRequestAssignmentCode = scheduleRequestAssignmentCode;
    }

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }
    
}
