package com.gigflex.prototype.microservices.schedule.dtob;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.util.Date;

import java.util.UUID;

import javax.persistence.PrePersist;
import org.hibernate.annotations.GenericGenerator;

/**
 * 
 * @author nirbhay.p
 *
 */
@Entity
@Table(name = "worker_schedule_request_assignment")
public class WorkerScheduleRequestAssignment extends CommonAttributes implements Serializable {


    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;  
    
    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "schedule_request_assignment_code", unique = true)
    private String scheduleRequestAssignmentCode;
    
     @Column(name = "schedule_request_code")
    private String scheduleRequestCode;
    
    @Column(name = "skill_code" )
    private String skillCode;
    
    @Column(name = "requested_staff")
    private Integer requestedStaff;
    
    @Column(name = "required_hours")
    private Integer requiredHours;
    
    @Column(name = "location_code")
    private String locationCode;
  
    @Column(name = "exp_in_days")
    private Long expDays;
    
    @Column(name = "cost_per_hours")
    private Double costPerHours;
    
    @Column(name = "certification_code")
    private String certificationCode;
        	
   @PrePersist
    private void assignUUID() {
        if(this.getScheduleRequestAssignmentCode()==null || this.getScheduleRequestAssignmentCode().length()==0)
        {
            this.setScheduleRequestAssignmentCode(UUID.randomUUID().toString());
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getScheduleRequestAssignmentCode() {
        return scheduleRequestAssignmentCode;
    }

    public void setScheduleRequestAssignmentCode(String scheduleRequestAssignmentCode) {
        this.scheduleRequestAssignmentCode = scheduleRequestAssignmentCode;
    }

    public String getScheduleRequestCode() {
        return scheduleRequestCode;
    }

    public void setScheduleRequestCode(String scheduleRequestCode) {
        this.scheduleRequestCode = scheduleRequestCode;
    }

    public String getSkillCode() {
        return skillCode;
    }

    public void setSkillCode(String skillCode) {
        this.skillCode = skillCode;
    }

    public Integer getRequestedStaff() {
        return requestedStaff;
    }

    public void setRequestedStaff(Integer requestedStaff) {
        this.requestedStaff = requestedStaff;
    }

    public Integer getRequiredHours() {
        return requiredHours;
    }

    public void setRequiredHours(Integer requiredHours) {
        this.requiredHours = requiredHours;
    }

    public String getLocationCode() {
        return locationCode;
    }

    public void setLocationCode(String locationCode) {
        this.locationCode = locationCode;
    }

    public Long getExpDays() {
        return expDays;
    }

    public void setExpDays(Long expDays) {
        this.expDays = expDays;
    }

       

    public Double getCostPerHours() {
        return costPerHours;
    }

    public void setCostPerHours(Double costPerHours) {
        this.costPerHours = costPerHours;
    }

    public String getCertificationCode() {
        return certificationCode;
    }

    public void setCertificationCode(String certificationCode) {
        this.certificationCode = certificationCode;
    }

}