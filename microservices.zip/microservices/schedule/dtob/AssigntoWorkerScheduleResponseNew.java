/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.schedule.dtob;

/**
 *
 * @author nirbhay.p
 */
public class AssigntoWorkerScheduleResponseNew {
    private AssignScheduleToWorker assignScheduleToWorker;
    
    private WorkerScheduleRequestRes workerScheduleRequest;

    private WorkerScheduleRequestAssignment workerScheduleRequestAssignment;

	private String skillName;
        
        private String skillColor;

	private String location;

	private String certificationName;
	
	private String OrganizationName;
    
    public AssignScheduleToWorker getAssignScheduleToWorker() {
        return assignScheduleToWorker;
    }

    public void setAssignScheduleToWorker(AssignScheduleToWorker assignScheduleToWorker) {
        this.assignScheduleToWorker = assignScheduleToWorker;
    }

    public WorkerScheduleRequestRes getWorkerScheduleRequest() {
        return workerScheduleRequest;
    }

    public void setWorkerScheduleRequest(WorkerScheduleRequestRes workerScheduleRequest) {
        this.workerScheduleRequest = workerScheduleRequest;
    }

    public String getSkillColor() {
        return skillColor;
    }

    public void setSkillColor(String skillColor) {
        this.skillColor = skillColor;
    }

    

    public WorkerScheduleRequestAssignment getWorkerScheduleRequestAssignment() {
        return workerScheduleRequestAssignment;
    }

    public void setWorkerScheduleRequestAssignment(WorkerScheduleRequestAssignment workerScheduleRequestAssignment) {
        this.workerScheduleRequestAssignment = workerScheduleRequestAssignment;
    }

    public String getSkillName() {
        return skillName;
    }

    public void setSkillName(String skillName) {
        this.skillName = skillName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getCertificationName() {
        return certificationName;
    }

    public void setCertificationName(String certificationName) {
        this.certificationName = certificationName;
    }

    public String getOrganizationName() {
        return OrganizationName;
    }

    public void setOrganizationName(String OrganizationName) {
        this.OrganizationName = OrganizationName;
    }
    
    
}
