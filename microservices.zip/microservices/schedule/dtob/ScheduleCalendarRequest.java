package com.gigflex.prototype.microservices.schedule.dtob;

import java.util.Date;
import java.util.List;



/**
 * 
 * @author nirbhay.p
 *
 */

public class ScheduleCalendarRequest {

    private String organizationCode;
    
    private Date startDate ;
    
    private Date endDate ;

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

   
   

}