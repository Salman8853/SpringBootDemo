package com.gigflex.prototype.microservices.schedule.dtob;


import com.gigflex.prototype.microservices.patient.dtob.PatientDetails;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author nirbhay.p
 */
public class AvailableWorkerBasedOnScheduleFilterRes {
    private String scheduleRequestAssignmentCode;
    private List<WorkerScheduleStatus> workerListWithStatus;
    private Integer workerCount;
    private PatientDetails patientDetails;

    public PatientDetails getPatientDetails() {
        return patientDetails;
    }

    public void setPatientDetails(PatientDetails patientDetails) {
        this.patientDetails = patientDetails;
    }

    
    
    public String getScheduleRequestAssignmentCode() {
        return scheduleRequestAssignmentCode;
    }

    public void setScheduleRequestAssignmentCode(String scheduleRequestAssignmentCode) {
        this.scheduleRequestAssignmentCode = scheduleRequestAssignmentCode;
    }

    public List<WorkerScheduleStatus> getWorkerListWithStatus() {
        return workerListWithStatus;
    }

    public void setWorkerListWithStatus(List<WorkerScheduleStatus> workerListWithStatus) {
        this.workerListWithStatus = workerListWithStatus;
    }

   
    public Integer getWorkerCount() {
        return workerCount;
    }

    public void setWorkerCount(Integer workerCount) {
        this.workerCount = workerCount;
    }
    
}
