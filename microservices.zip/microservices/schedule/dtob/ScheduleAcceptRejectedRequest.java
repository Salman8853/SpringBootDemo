/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.schedule.dtob;

/**
 *
 * @author nirbhay.p
 */
public class ScheduleAcceptRejectedRequest {
    private String assignScheduletoWorkerCode;

    public String getAssignScheduletoWorkerCode() {
        return assignScheduletoWorkerCode;
    }

    public void setAssignScheduletoWorkerCode(String assignScheduletoWorkerCode) {
        this.assignScheduletoWorkerCode = assignScheduletoWorkerCode;
    }
    
    
}
