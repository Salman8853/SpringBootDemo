package com.gigflex.prototype.microservices.schedule.dtob;

import com.gigflex.prototype.microservices.patient.dtob.PatientDetails;
import java.util.List;

public class WorkerScheduleRequestAssignmentResponse {
	
	
	public WorkerScheduleRequestRes workerScheduleRequestRes;
        
        public PatientDetails patientDetails = new PatientDetails();
	
	public List<WorkerScheduleRequestAssignmentWithName> workerScheduleRequestAssignmentWithNameList;

        public WorkerScheduleRequestRes getWorkerScheduleRequestRes() {
            return workerScheduleRequestRes;
        }

        public void setWorkerScheduleRequestRes(WorkerScheduleRequestRes workerScheduleRequestRes) {
            this.workerScheduleRequestRes = workerScheduleRequestRes;
        }

	public List<WorkerScheduleRequestAssignmentWithName> getWorkerScheduleRequestAssignmentWithNameList() {
		return workerScheduleRequestAssignmentWithNameList;
	}

	public void setWorkerScheduleRequestAssignmentWithNameList(
			List<WorkerScheduleRequestAssignmentWithName> workerScheduleRequestAssignmentWithNameList) {
		this.workerScheduleRequestAssignmentWithNameList = workerScheduleRequestAssignmentWithNameList;
	}

	
	
	
//	public WorkerScheduleRequest workerScheduleRequest;
//	
//	public List<WorkerScheduleRequestAssignment> workerScheduleRequestAssignment;
//	
//	public WorkerScheduleRequest getWorkerScheduleRequest() {
//		return workerScheduleRequest;
//	}
//	public void setWorkerScheduleRequest(WorkerScheduleRequest workerScheduleRequest) {
//		this.workerScheduleRequest = workerScheduleRequest;
//	}
//	public List<WorkerScheduleRequestAssignment> getWorkerScheduleRequestAssignment() {
//		return workerScheduleRequestAssignment;
//	}
//	public void setWorkerScheduleRequestAssignment(
//			List<WorkerScheduleRequestAssignment> workerScheduleRequestAssignment) {
//		this.workerScheduleRequestAssignment = workerScheduleRequestAssignment;
//	}

        public PatientDetails getPatientDetails() {
            return patientDetails;
        }

        public void setPatientDetails(PatientDetails patientDetails) {
            this.patientDetails = patientDetails;
        }
	
	
	

}
