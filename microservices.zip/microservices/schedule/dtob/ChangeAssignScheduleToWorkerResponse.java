/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.schedule.dtob;

/**
 *
 * @author nirbhay.p
 */
public class ChangeAssignScheduleToWorkerResponse {
    private ChangeAssignScheduleToWorker changeAssignScheduleToWorker;
    private String changedByWorkerName;
    private String changeToWorkerName;

    public ChangeAssignScheduleToWorker getChangeAssignScheduleToWorker() {
        return changeAssignScheduleToWorker;
    }

    public void setChangeAssignScheduleToWorker(ChangeAssignScheduleToWorker changeAssignScheduleToWorker) {
        this.changeAssignScheduleToWorker = changeAssignScheduleToWorker;
    }

    public String getChangedByWorkerName() {
        return changedByWorkerName;
    }

    public void setChangedByWorkerName(String changedByWorkerName) {
        this.changedByWorkerName = changedByWorkerName;
    }

    public String getChangeToWorkerName() {
        return changeToWorkerName;
    }

    public void setChangeToWorkerName(String changeToWorkerName) {
        this.changeToWorkerName = changeToWorkerName;
    }
    
}
