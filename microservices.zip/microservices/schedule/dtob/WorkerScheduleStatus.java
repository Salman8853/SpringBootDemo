/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.schedule.dtob;

import com.gigflex.prototype.microservices.worker.dtob.Worker;

/**
 *
 * @author nirbhay.p
 */
public class WorkerScheduleStatus {
    private Worker worker;
    private String assignWorkerStatus;

    public Worker getWorker() {
        return worker;
    }

    public void setWorker(Worker worker) {
        this.worker = worker;
    }

    public String getAssignWorkerStatus() {
        return assignWorkerStatus;
    }

    public void setAssignWorkerStatus(String assignWorkerStatus) {
        this.assignWorkerStatus = assignWorkerStatus;
    }
    
}
