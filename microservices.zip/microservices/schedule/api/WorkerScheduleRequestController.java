/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.schedule.api;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.schedule.dtob.ScheduleCalendarRequest;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequestAssignmentInputList;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequestInput;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequestUpdate;
import com.gigflex.prototype.microservices.schedule.service.WorkerScheduleRequestService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.util.List;


/**
 *
 * @author nirbhay.p
 */
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/healthcareservice/")
public class WorkerScheduleRequestController {

    @Autowired
    WorkerScheduleRequestService workerScheduleRequestService;
    
	@GetMapping("/getWorkerScheduleRequest/{id}")
	public String getWorkerById(@PathVariable Long id) {
		return workerScheduleRequestService.getWorkerScheduleRequestById(id);
	}

	@GetMapping("/getAvailableWorkerBasedOnScheduleFilterByScheduleRequestCode/{scheduleRequestCode}")
	public String getAvailableWorkerBasedOnScheduleFilterByScheduleRequestCode(
			@PathVariable String scheduleRequestCode) {
		return workerScheduleRequestService
				.getAvailableWorkerBasedOnScheduleFilterByScheduleRequestCode(scheduleRequestCode);
	}

	@GetMapping("/getWorkerScheduleRequestByScheduleRequestCode/{scheduleRequestCode}")
	public String getWorkerScheduleRequestByScheduleRequestCode(@PathVariable String scheduleRequestCode) {
		return workerScheduleRequestService.getWorkerScheduleRequestByScheduleRequestCode(scheduleRequestCode);
	}

	@GetMapping("/getWorkerScheduleRequestByOrganizationCode/{organizationCode}")
	public String getWorkerScheduleRequestByOrganizationCode(@PathVariable String organizationCode) {
		return workerScheduleRequestService.getWorkerScheduleRequestByOrganizationCode(organizationCode);
	}

	@GetMapping("/getWorkerScheduleRequestByPage/{id}")
	public String getWorkerScheduleRequestByPage(@PathVariable Long id,
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {
		return workerScheduleRequestService.getWorkerScheduleRequestById(id, page, limit);
	}

	@GetMapping("/getWorkerScheduleRequestByScheduleRequestCodeByPage/{scheduleRequestCode}")
	public String getWorkerScheduleRequestByScheduleRequestCodeByPage(@PathVariable String scheduleRequestCode,
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {
		return workerScheduleRequestService.getWorkerScheduleRequestByScheduleRequestCode(scheduleRequestCode, page,
				limit);
	}

	@GetMapping("/getWorkerScheduleRequestByOrganizationCodeByPage/{organizationCode}")
	public String getWorkerScheduleRequestByOrganizationCodeByPage(@PathVariable String organizationCode,
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {
		return workerScheduleRequestService.getWorkerScheduleRequestByOrganizationCode(organizationCode, page, limit);
	}

	@PostMapping("/createWorkerScheduleRequest")

	public String createWorkerScheduleRequest(@RequestBody WorkerScheduleRequestInput wsr, HttpServletRequest req) {
		if (wsr != null) {
                    if(wsr.getStart()!=null && wsr.getStart().trim().length()>0 && wsr.getEnd()!=null && wsr.getEnd().trim().length()>0)
                    {
                        try {
				Date sdt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(wsr.getStart().trim());
				Date edt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse( wsr.getEnd().trim());
                                if(sdt==null || edt==null)
                                {
                                    GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
				return derr.toString();
                                }
			} catch (Exception ex) {
				ex.printStackTrace();
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
				return derr.toString();
			}
                    return workerScheduleRequestService.saveWorkerScheduleRequest(wsr, req.getRemoteHost());
                    } else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Start and End should not be blank.");
			return derr.toString();
		}
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
			return derr.toString();
		}

	}

	@PutMapping("/publishedWorkerScheduleRequest/{scheduleRequestCode}/{isPublished}")
	public String publishedWorkerScheduleRequest(@PathVariable String scheduleRequestCode,
			@PathVariable Boolean isPublished, HttpServletRequest req) {
		if (isPublished != null && scheduleRequestCode != null && scheduleRequestCode.trim().length() > 0) {
			return workerScheduleRequestService.publishedWorkerScheduleRequest(isPublished, scheduleRequestCode,
					req.getRemoteHost());
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
			return derr.toString();
		}

	}

	@GetMapping("/getScheduleCalendar/{organizationCode}/{startDate}/{endDate}")
	public String getScheduleCalendar(@PathVariable String organizationCode, @PathVariable String startDate,
			@PathVariable String endDate) {
		if (organizationCode != null && organizationCode.trim().length() > 0 && startDate != null
				&& startDate.trim().length() > 0 && endDate != null && endDate.trim().length() > 0) {
			Date sdt = null;
			Date edt = null;
			try {
				sdt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(startDate);
				edt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(endDate);
			} catch (Exception ex) {
				ex.printStackTrace();
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
				return derr.toString();
			}
			
			
			ScheduleCalendarRequest calReq = new ScheduleCalendarRequest();
			calReq.setEndDate(edt);
			calReq.setOrganizationCode(organizationCode.trim());
			calReq.setStartDate(sdt);
			return workerScheduleRequestService.getScheduleCalendar(calReq);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"OrganizationCode, StartDate, EndDate should not be blank.");
			return derr.toString();
		}

	}
        
        
        
        @GetMapping(path="/getScheduleCalendarForWorker/{workerCode}/{status}/{stratDT}/{endDT}")
    public String getScheduleCalendarForWorker(@PathVariable String workerCode,@PathVariable List<String> status,
            @PathVariable String stratDT,@PathVariable String endDT) {

        if(workerCode!=null && workerCode.trim().length()>0 && status!=null && status.size()>0  ) {

            if( stratDT != null && stratDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0)
            {
		Date sDT = null;
		Date eDT = null;
		try {
			sDT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(stratDT.trim());
			eDT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(endDT.trim());
			if(sDT == null || eDT == null) {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send stratDT and endDT in correct format(yyyy-MM-dd HH:mm:ss)");
				return derr.toString();

			}

//currentTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(new Date());
		} catch (Exception ex) {
			ex.printStackTrace();
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Plz send stratDT and endDT in correct format(yyyy-MM-dd HH:mm:ss)");
			return derr.toString();
		}
                
                if(sDT!=null && eDT!=null)
                {
                   if (!(sDT.equals(eDT) || (eDT.after(sDT)))) {
                       GigflexResponse derr = new GigflexResponse(400, new Date(),
					"End Date must be after Start Date.");
			return derr.toString();
                   }
                }
                
            }
            else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Start Date and End Date should not be blank.");
			return derr.toString();
		}
		
		
			return workerScheduleRequestService.getScheduleCalendarForWorker(workerCode.trim(),status,stratDT.trim(), endDT.trim());
		
		}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Worker Code and Status should not be blank.");
			return derr.toString();
		}
	
       
    }
        
        

	@PostMapping("/addWorkerScheduleRequestAssignment/{scheduleRequestCode}")
	public String addWorkerScheduleRequestAssignment(@PathVariable String scheduleRequestCode,
			@RequestBody WorkerScheduleRequestAssignmentInputList wsr, HttpServletRequest req) {
		if (wsr != null) {
			if (scheduleRequestCode != null && scheduleRequestCode.trim().length() > 0) {
				return workerScheduleRequestService.addWorkerScheduleRequestAssignment(scheduleRequestCode, wsr,
						req.getRemoteHost());
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Schedule Request Code should not be blank.");
				return derr.toString();
			}
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
			return derr.toString();
		}

	}

	@GetMapping("/getTargetAchieved/{scheduleRequestCode}")
	public String getTargetAchieved(@PathVariable String scheduleRequestCode) {

		if (scheduleRequestCode != null && scheduleRequestCode.trim().length() > 0) {
			return workerScheduleRequestService.getTargetAchieved(scheduleRequestCode);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Schedule Request Code should not be blank.");
			return derr.toString();
		}

	}

	@GetMapping("/getPercentageOfScheduleFulfilment/{scheduleRequestCode}")
	public String getPercentageOfScheduleFulfilment(@PathVariable String scheduleRequestCode) {

		if (scheduleRequestCode != null && scheduleRequestCode.trim().length() > 0) {
			return workerScheduleRequestService.getPercentageOfScheduleFulfilment(scheduleRequestCode);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Schedule Request Code should not be blank.");
			return derr.toString();
		}

	}

	@GetMapping("/getWeelkyTargetByDates/{scheduleRequestAssignmentCode}/{status}/{startDate}/{endDate}")
	public String getWeelkyTargetForDateRange(@PathVariable String scheduleRequestAssignmentCode,
			@PathVariable String status, @PathVariable String startDate, @PathVariable String endDate) {
		GigflexResponse derr = null;
		if (scheduleRequestAssignmentCode != null && scheduleRequestAssignmentCode.trim().length() > 0) {
			if (status != null && status.trim().length() > 0) {
				if (startDate != null && startDate.trim().length() > 0 && endDate != null
						&& endDate.trim().length() > 0) {

					return workerScheduleRequestService.getWeeklyReportByDates(scheduleRequestAssignmentCode, status,
							startDate, endDate);
				} else {
					derr = new GigflexResponse(400, new Date(), "Date Should not be blank.");
				}
			} else {
				derr = new GigflexResponse(400, new Date(), "Status Should not be blank.");
			}
		}
		derr = new GigflexResponse(400, new Date(), "Schedule Request Code should not be blank.");
		return derr.toString();
	}
        
        
        @PutMapping("/publishedWorkerScheduleRequestByOrganizationCode/{organizationCode}/{isPublished}")
	public String publishedWorkerScheduleRequestByOrganizationCode(@PathVariable String organizationCode,
			@PathVariable Boolean isPublished, HttpServletRequest req) {
		if (isPublished != null && organizationCode != null && organizationCode.trim().length() > 0) {
			return workerScheduleRequestService.publishedWorkerScheduleRequestByOrganizationCode(isPublished, organizationCode,
					req.getRemoteHost());
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
			return derr.toString();
		}

	}
        
        
        @PutMapping("/updateWorkerScheduleRequestByScheduleRequestCode/{scheduleRequestCode}")
	public String updateWorkerScheduleRequestByScheduleRequestCode( @PathVariable String scheduleRequestCode,
                @RequestBody WorkerScheduleRequestUpdate wsr, HttpServletRequest req) {
		if (wsr != null) {
                    if(scheduleRequestCode!=null && scheduleRequestCode.trim().length()>0)
                    {
                       if (wsr.getStart() != null && wsr.getStart().trim().length() > 0 && wsr.getEnd() != null && wsr.getEnd().trim().length() > 0) {
                        try {
				Date sdt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(wsr.getStart().trim());
				Date edt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse( wsr.getEnd().trim());
                                if(sdt==null || edt==null)
                                {
                                    GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
				return derr.toString();
                                }
			} catch (Exception ex) {
				ex.printStackTrace();
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
				return derr.toString();
			}
                       }
                    return workerScheduleRequestService.updateWorkerScheduleRequestByScheduleRequestCode(wsr,scheduleRequestCode.trim(), req.getRemoteHost());
                    } else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "schedule Request Code should not be blank.");
			return derr.toString();
		}
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
			return derr.toString();
		}

	
	}
        
}
