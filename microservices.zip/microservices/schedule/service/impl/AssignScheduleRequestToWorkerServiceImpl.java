/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.schedule.service.impl;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.certificationsmaster.dtob.CertificationsMaster;
import com.gigflex.prototype.microservices.certificationsmaster.repository.CertificationsMasterRepository;
import com.gigflex.prototype.microservices.healthcarenotification.dtob.HealthcareNotification;
import com.gigflex.prototype.microservices.healthcarenotification.service.HealthcareNotificationService;
import com.gigflex.prototype.microservices.jobs.service.impl.JobsServiceImpl;
import com.gigflex.prototype.microservices.schedule.dtob.AssignScheduleRequestToWorker;
import com.gigflex.prototype.microservices.schedule.dtob.AssignScheduleToWorker;
import com.gigflex.prototype.microservices.schedule.service.AssignScheduleRequestToWorkerService;

import org.springframework.beans.factory.annotation.Autowired;

import com.gigflex.prototype.microservices.schedule.repository.AssignScheduleRequestToWorkerRepository;
import com.gigflex.prototype.microservices.schedule.dtob.*;
import com.gigflex.prototype.microservices.schedule.repository.ChangeAssignScheduleRequestToWorkerRepository;
import com.gigflex.prototype.microservices.schedule.repository.WorkerScheduleRequestRepository;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.util.GigflexResponse;

import java.util.Date;

import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexDateUtil;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.setting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.setting.repository.LocalSettingRepository;
import com.gigflex.prototype.microservices.users.dtob.Users;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import com.gigflex.prototype.microservices.util.SendNotification;
import com.gigflex.prototype.microservices.worker.repository.WorkerRepository;
import com.gigflex.prototype.microservices.workeroffdays.repository.WorkerOffdaysRepository;
import com.gigflex.prototype.microservices.workertimeoff.repository.WorkerTimeOffDao;
import com.gigflex.prototype.microservices.workinglocation.dtob.WorkingLocation;
import com.gigflex.prototype.microservices.workinglocation.repository.WorkingLocationRepository;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

/**
 *
 * @author abhishek
 */
@Service
public class AssignScheduleRequestToWorkerServiceImpl implements AssignScheduleRequestToWorkerService {

    private static final Logger LOG = LoggerFactory.getLogger(AssignScheduleRequestToWorkerServiceImpl.class);
    
    @Autowired
    AssignScheduleRequestToWorkerRepository assignScheduleRequestToWorkerRepository;

    @Autowired
    WorkerScheduleRequestRepository workerScheduleRequestRepository;

    @Autowired
    ChangeAssignScheduleRequestToWorkerRepository changeAssignScheduleRequestToWorkerRepository;
    @Autowired
    TimeZoneRepository timeZoneDao;
    @Autowired
    WorkingLocationRepository workLocRep;
    @Autowired
    CertificationsMasterRepository certificationsMasterRepository;
    @Autowired
    OrganizationRepository organizationRepository;
    
    @Autowired
    WorkerRepository workerRepository;
    
    @Autowired
    WorkerTimeOffDao workerTimeOffDao;
    
    @Autowired
    GlobalSettingRepository globalSettingRepository;
    @Autowired
    LocalSettingRepository localSettingRepository;
    @Autowired
    UserTypeRepository utr;
   

    @Value("${email.assignschedule.subject}")
    private String subject;

    @Value("${email.service.url}")
    private String mailServiceURL;
    
    @Autowired
    private HealthcareNotificationService notificationService;

    @Override
    public String saveAssignScheduleRequestToWorker(AssignScheduleRequestToWorker schReq, String idAddress) {
        String res = "";
        JSONObject jsonobj = new JSONObject();
        try {
           AssignScheduleToWorker asw= assignScheduleRequestToWorkerRepository.getAssignedScheduledToWorkerByReqCodeAndAssignCodeWorkerCode(schReq.getScheduleRequestCode(), schReq.getScheduleRequestAssignmentCode(),schReq.getWorkerCode());
           if(asw!=null && asw.getId()>0)
           {
               jsonobj.put("responsecode", 409);
            jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "This schedule already assigned.");
           }
           else
           {
           AssignScheduleToWorker assignSchedule = new AssignScheduleToWorker();
            assignSchedule.setScheduleRequestCode(schReq.getScheduleRequestCode().trim());
            assignSchedule.setScheduleRequestAssignmentCode(schReq.getScheduleRequestAssignmentCode().trim());
            assignSchedule.setWorkerCode(schReq.getWorkerCode().trim());
            assignSchedule.setStatus(GigflexConstants.assignedScheduleStatus);
            assignSchedule.setIpAddress(idAddress);
            AssignScheduleToWorker assignScheduleToWorkerSave = assignScheduleRequestToWorkerRepository.save(assignSchedule);

            jsonobj.put("responsecode", 200);
            jsonobj.put("timestamp", new Date());
            if (assignScheduleToWorkerSave != null && assignScheduleToWorkerSave.getId() > 0) {
                String status = sendScheduleRequestLinkViaEmail(assignScheduleToWorkerSave);

                ObjectMapper mapperObj = new ObjectMapper();
                String Detail = mapperObj.writeValueAsString(assignScheduleToWorkerSave);
                jsonobj.put("message", "Schedule has been assigned to Worker and mail is sent successfully.");
                jsonobj.put("data", new JSONObject(Detail));
            } else {
               jsonobj.put("responsecode", 400);
            jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "Failed");
            }
           }
            res = jsonobj.toString();
            } catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
        }
        return res;

    }

    @Override
    public String sendScheduleRequestLinkViaEmail(AssignScheduleToWorker assignScheduleToWorkerSave) {
        String res = "";
        String mailRes = "false";
        try {
            if (assignScheduleToWorkerSave != null && assignScheduleToWorkerSave.getId() > 0) {
                Date startDate = null;
                Date endDate = null;
               // String location = null;
                String organizationName = null;
                List<Object> assignScheduleToWorkerList = assignScheduleRequestToWorkerRepository.getScheduleDetailToAssignWorker(assignScheduleToWorkerSave.getScheduleRequestCode());
                for (Object object : assignScheduleToWorkerList) {
                    Object[] obj = (Object[]) object;
                    startDate = (Date) obj[0];
                    endDate = (Date) obj[1];
                    organizationName = (String) obj[2];
                }
                Worker workerData = assignScheduleRequestToWorkerRepository.getWorkerEmail(assignScheduleToWorkerSave.getWorkerCode());
                byte[] encoded1 = Base64.getEncoder().encode(workerData.getWorkerCode().getBytes());
                String tok = new String(encoded1);
                String bodyContent = "Dear " + workerData.getName() + ",<br><br> ";
                bodyContent += "Your schedule is created from " + startDate + "to " + endDate +  "<br><br><br>";
                String encodeURL = URLEncoder.encode(bodyContent, "UTF-8");
                Map<String, String> map = new HashMap<>();
                map.put("to", workerData.getEmail());
                map.put("subject", subject);
                map.put("body", encodeURL);
                try {
                    RestTemplate restTemplate = new RestTemplate();
                    ResponseEntity<String> response = restTemplate.getForEntity(mailServiceURL, String.class, map);
                    mailRes = response.getBody();
                    GigflexResponse derr = new GigflexResponse(200, new Date(), "Mail sending status is " + mailRes);
                    res = derr.toString();
                } catch (Exception ex) {
                    ex.printStackTrace();
                    GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred at sending email");
                    res = derr.toString();
                }
            } else {
                GigflexResponse derr = new GigflexResponse(400, new Date(), "User does not exist.");
                return derr.toString();
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
            res = derr.toString();
        }
        return res;
    }

    @Override

    public String saveAcceptedScheduleRequest(String assignScheduletoWorkerCode, String ipAddress) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            jsonobj.put("responsecode", 200);
            jsonobj.put("timestamp", new Date());
            AssignScheduleToWorker assignScheduleToWorker = assignScheduleRequestToWorkerRepository.getAssignedScheduledToWorker(assignScheduletoWorkerCode);
            if (assignScheduleToWorker != null && assignScheduleToWorker.getId() > 0) {
                assignScheduleToWorker.setStatus(GigflexConstants.assignedScheduleAcceptedStatus);
                assignScheduleToWorker.setIpAddress(ipAddress);
                AssignScheduleToWorker assignScheduleToWorkerStatus = assignScheduleRequestToWorkerRepository.save(assignScheduleToWorker);
                if (assignScheduleToWorkerStatus != null && assignScheduleToWorkerStatus.getId() > 0) {
                    
                    HealthcareNotification notification = new HealthcareNotification();
                    String appointmentId ="";
                   
                    String workerCode = assignScheduleToWorkerStatus.getWorkerCode();
                    Worker worker = workerRepository.findByWorkerCode(workerCode);
                    WorkerScheduleRequest wsr = workerScheduleRequestRepository.getByScheduleRequestCode(assignScheduleToWorkerStatus.getScheduleRequestCode());
                   
                    Date startTime = null;
                    Date endTime = null;
                    Users user = null;
                    String organizationCode ="";
                    if (wsr != null) {
                        startTime = wsr.getStartDT();
                        endTime = wsr.getEndDT();
                        organizationCode = wsr.getOrganizationCode();
                        user = workerTimeOffDao.getAdminByOrganizationCode(organizationCode);
                    }
                    
                    Date stDate = null;
                    Date endDate = null;
                    if (startTime != null && endTime != null) {
                        String timezone = null;
                        String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                        String dtFormatView = dtFormat;
                        String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);
                        String dateformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.DATEFORMAT);
                        String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TIMEFORMAT);
                        if (dateformat != null && dateformat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                            dtFormatView = dateformat.trim() + " " + timeformat.trim();
                        }

                        if (timezoneCode != null && timezoneCode.length() > 0) {
                            TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                                timezone = tzd.getTimeZoneName();
                            }
                        }

                        if (timezone != null) {
                            stDate = GigflexDateUtil.getGMTtoLocationDate(startTime, timezone, dtFormatView);
                            endDate = GigflexDateUtil.getGMTtoLocationDate(endTime, timezone, dtFormatView);
                        }
                    }
                    
                    
                    Organization org = organizationRepository.findByOrganizationCode(wsr.getOrganizationCode());

                    String organizationName = "";
                    if (org != null) {
                        organizationName = org.getOrganizationName();
                    }
                                       
                    String workerName = "";
                    if (worker != null) {
                        workerName = worker.getName();
                    }
                    
                    String email = "";
                    String userCode = "";
                    if(user != null)
                    {
                        email =  user.getEmail();
                        userCode = user.getUserCode();
                    }

                    String message = "Schedule request has been accepted";
                    String bodyContentShortMessage = message + ". Details are given below-"
                            + "Worker Name : " + workerName
                             + " Organization Name : " + organizationName
                            + " Start Date : " + stDate
                            + " End Date : " + endDate;
                          
                    String shortMessage = "" + message + "";

                    notification.setUserCode(userCode);
                    notification.setMessage(bodyContentShortMessage);
                    notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_ADMIN);
                    notification.setShortMessage(shortMessage);
                    notification.setAppointmentCode(appointmentId);
                    notification.setIsRead(Boolean.FALSE);
                    notification.setIpAddress(ipAddress);

                    notificationService.saveHealthcareNotification(notification);


                    String bodyContent = message + ". Details are given below-<br>"
                            + " Worker Name : " + workerName+"<br>"
                             + " Organization Name : " + organizationName+"<br>"
                            + " Start Date : " + stDate+"<br>"
                            + " End Date : " + endDate;
                           
                    SendNotification sn = new SendNotification();

                    if (email != null && email.length() > 0) {
                        String response = sn.sendMail(email, subject, bodyContent, mailServiceURL);

                        LOG.info("Cron scheduler mail response in DriverTimeOffServiceImpl >>>>>>", response);
                    }

                    jsonobj.put("message", "Worker status updated successfully");
                    ObjectMapper mapperObj = new ObjectMapper();
                    String Detail = mapperObj.writeValueAsString(assignScheduleToWorkerStatus);
                    jsonobj.put("data", new JSONObject(Detail));

                } else {
                    jsonobj.put("message", "Failed");
                }

            } else {
                jsonobj.put("responsecode", 404);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "Record Not Found");
            }
            res = jsonobj.toString();
            } catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
            res = derr.toString();

        }
        return res;
    }

    @Override
    public String saveRejectedScheduleRequest(String assignScheduletoWorkerCode, String ipAddress) {

        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            jsonobj.put("responsecode", 200);
            jsonobj.put("timestamp", new Date());
            AssignScheduleToWorker assignScheduleToWorker = assignScheduleRequestToWorkerRepository.getAssignedScheduledToWorker(assignScheduletoWorkerCode);
            if (assignScheduleToWorker != null && assignScheduleToWorker.getId() > 0) {
                assignScheduleToWorker.setStatus(GigflexConstants.assignedScheduleRejectedStatus);
                assignScheduleToWorker.setIpAddress(ipAddress);
                AssignScheduleToWorker assignScheduleToWorkerStatus = assignScheduleRequestToWorkerRepository.save(assignScheduleToWorker);
                if (assignScheduleToWorkerStatus != null && assignScheduleToWorkerStatus.getId() > 0) {
                    
                     HealthcareNotification notification = new HealthcareNotification();
                    String appointmentId ="";
                   
                    String workerCode = assignScheduleToWorkerStatus.getWorkerCode();
                    Worker worker = workerRepository.findByWorkerCode(workerCode);
                    WorkerScheduleRequest wsr = workerScheduleRequestRepository.getByScheduleRequestCode(assignScheduleToWorkerStatus.getScheduleRequestCode());
                   
                    Date startTime = null;
                    Date endTime = null;
                    Users user = null;
                    String organizationCode ="";
                    if (wsr != null) {
                        startTime = wsr.getStartDT();
                        endTime = wsr.getEndDT();
                        organizationCode = wsr.getOrganizationCode();
                        user = workerTimeOffDao.getAdminByOrganizationCode(organizationCode);
                    }
                    
                    Date stDate = null;
                    Date endDate = null;
                    if (startTime != null && endTime != null) {
                        String timezone = null;
                        String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                        String dtFormatView = dtFormat;
                        String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);
                        String dateformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.DATEFORMAT);
                        String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TIMEFORMAT);
                        if (dateformat != null && dateformat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                            dtFormatView = dateformat.trim() + " " + timeformat.trim();
                        }

                        if (timezoneCode != null && timezoneCode.length() > 0) {
                            TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                                timezone = tzd.getTimeZoneName();
                            }
                        }

                        if (timezone != null) {
                            stDate = GigflexDateUtil.getGMTtoLocationDate(startTime, timezone, dtFormatView);
                            endDate = GigflexDateUtil.getGMTtoLocationDate(endTime, timezone, dtFormatView);
                        }
                    }                    
                    
                    Organization org = organizationRepository.findByOrganizationCode(wsr.getOrganizationCode());

                    String organizationName = "";
                    if (org != null) {
                        organizationName = org.getOrganizationName();
                    }
                                       
                    String workerName = "";      
                    String email = "";
                    if (worker != null) {
                        workerName = worker.getName();
//                        email = worker.getEmail();
                    }
                                        
                    String userCode = "";
                    if(user != null)
                    {
                        email =  user.getEmail();
                        userCode = user.getUserCode();
                    }

                    String message = "Schedule request has been rejected";
                    String bodyContentShortMessage = message + ". Details are given below-"
                            + "Worker Name : " + workerName
                             + " Organization Name : " + organizationName
                            + " Start Date : " + stDate
                            + " End Date : " + endDate;
                          
                    String shortMessage = "" + message + "";

                    notification.setUserCode(userCode);
                    notification.setMessage(bodyContentShortMessage);
                    notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_ADMIN);
                    notification.setShortMessage(shortMessage);
                    notification.setAppointmentCode(appointmentId);
                    notification.setIsRead(Boolean.FALSE);
                    notification.setIpAddress(ipAddress);

                    notificationService.saveHealthcareNotification(notification);


                    String bodyContent = message + ". Details are given below-<br>"
                            + " Worker Name : " + workerName+"<br>"
                             + " Organization Name : " + organizationName+"<br>"
                            + " Start Date : " + stDate+"<br>"
                            + " End Date : " + endDate;
                           
                    SendNotification sn = new SendNotification();

                    if (email != null && email.length() > 0) {
                        String response = sn.sendMail(email, subject, bodyContent, mailServiceURL);

                        LOG.info("Cron scheduler mail response in DriverTimeOffServiceImpl >>>>>>", response);
                    }                    
                    
                    jsonobj.put("message", "Worker status updated successfully");
                    ObjectMapper mapperObj = new ObjectMapper();
                    String Detail = mapperObj.writeValueAsString(assignScheduleToWorkerStatus);
                    jsonobj.put("data", new JSONObject(Detail));

                } else {
                    jsonobj.put("message", "Failed");
                }

            } else {
                jsonobj.put("responsecode", 404);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "Record Not Found");
            }
            res = jsonobj.toString();
            } catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
            res = derr.toString();

        }
        return res;

    }

    @Override
    public String getAvailableWorkerWithSameFilterByAssignScheduletoWorkerCode(String assignScheduletoWorkerCode) {

        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            WorkerScheduleRequest wsr = assignScheduleRequestToWorkerRepository.getWorkerScheduleRequestByAssignScheduletoWorkerCode(assignScheduletoWorkerCode);
            if (wsr != null && wsr.getId() > 0 && wsr.getStartDT() != null && wsr.getEndDT() != null) {
                List<String> busyWorkerLst = new ArrayList<String>();
                List<Object> busyObj = assignScheduleRequestToWorkerRepository.getBusyWorkerListInStartEnd(wsr.getStartDT(), wsr.getEndDT());
                if (busyObj != null && busyObj.size() > 0) {
                    for (Object objectWr : busyObj) {
                        if (objectWr != null && objectWr.toString().length() > 0) {
                            busyWorkerLst.add((String) objectWr);
                        }
                    }
                }
                boolean stNot = true;
                Long experienceInDays = 0L;
                String skillcode = null;
                String certificatecode = null;

                WorkerScheduleRequestAssignment wsra = assignScheduleRequestToWorkerRepository.getWorkerScheduleRequestAssignmentByAssignScheduletoWorkerCode(assignScheduletoWorkerCode);
                if (wsra != null && wsra.getId() > 0) {
                    List<String> newWorkerLst = new ArrayList<String>();
                    List<Worker> wrlstRes = null;
                    experienceInDays = wsra.getExpDays();
                    skillcode = wsra.getSkillCode();
                    certificatecode = wsra.getCertificationCode();
                    if (skillcode != null && skillcode.trim().length() > 0) {
                        if(busyWorkerLst!=null && busyWorkerLst.size()>0)
                        {
                        List<Worker> wrlst = assignScheduleRequestToWorkerRepository.getSameSkillAvailableWorkerList(experienceInDays,assignScheduletoWorkerCode, busyWorkerLst);
                        wrlstRes = wrlst;
                        for (Worker wr : wrlst) {
                            newWorkerLst.add(wr.getWorkerCode());
                        }
                        stNot = false;
                        }
                        else
                                {
                                   List<Worker> wrlst = assignScheduleRequestToWorkerRepository.getSameSkillAvailableWorkerList(experienceInDays,assignScheduletoWorkerCode, busyWorkerLst);
                        wrlstRes = wrlst;
                        for (Worker wr : wrlst) {
                            newWorkerLst.add(wr.getWorkerCode());
                        }
                        stNot = false; 
                                }
                    }
                    if (certificatecode != null && certificatecode.trim().length() > 0) {
                        if (stNot == false && wrlstRes != null && wrlstRes.size() > 0) {
                            List<Worker> wrlst = assignScheduleRequestToWorkerRepository.getSameCertificateAvailableWorkerListWithIN(certificatecode, wsr.getOrganizationCode(), newWorkerLst);
                            wrlstRes = wrlst;
                            newWorkerLst = new ArrayList<String>();
                            for (Worker wr : wrlst) {
                                newWorkerLst.add(wr.getWorkerCode());
                            }
                        } else {
                            if (stNot) {
                                List<Worker> wrlst = assignScheduleRequestToWorkerRepository.getSameCertificateAvailableWorkerListWithNotIN(certificatecode, wsr.getOrganizationCode(), busyWorkerLst);
                                wrlstRes = wrlst;
                                newWorkerLst = new ArrayList<String>();
                                for (Worker wr : wrlst) {
                                    newWorkerLst.add(wr.getWorkerCode());
                                }
                                stNot = false;
                            }
                        }

                    }

//                    if (exp_year != null && exp_month != null && exp_days != null && (exp_year > 0 || exp_month > 0 || exp_days > 0)) {
//                        if (stNot == false && wrlstRes != null && wrlstRes.size() > 0) {
//                                List<Worker> wrlst =assignScheduleRequestToWorkerRepository.getSameExperienceAvailableWorkerListWithIN(exp_year, exp_month, exp_days, wsr.getOrganizationCode(),newWorkerLst);
//                                wrlstRes = wrlst;
//                            newWorkerLst = new ArrayList<String>();
//                            for (Worker wr : wrlst) {
//                                newWorkerLst.add(wr.getWorkerCode());
//                            }
//                        } else {
//                            if (stNot) {
//                                List<Worker> wrlst =assignScheduleRequestToWorkerRepository.getSameExperienceAvailableWorkerListWithNotIN(exp_year, exp_month, exp_days, wsr.getOrganizationCode(),busyWorkerLst);
//                                wrlstRes = wrlst;
//                            newWorkerLst = new ArrayList<String>();
//                            for (Worker wr : wrlst) {
//                                newWorkerLst.add(wr.getWorkerCode());
//                            }
//                             stNot = false;
//                            }
//                        }
//
//                    }

                    //List<Worker> wrlst = assignScheduleRequestToWorkerRepository.getSmaeSkillAvailableWorkerList(assignScheduletoWorkerCode,busyWorkerLst);
                    if (wrlstRes != null && wrlstRes.size() > 0) {

                        jsonobj.put("responsecode", 200);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Same skill available worker list");
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(wrlstRes);
                        jsonobj.put("data", new JSONArray(Detail));

                    } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Record Not Found");
                    }
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Schedule not found.");
                }

            } else {
                jsonobj.put("responsecode", 404);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "Schedule not found.");
            }

            res = jsonobj.toString();
            } catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
            res = derr.toString();

        }
        return res;
    }

    @Override
    public String changeAssignToWorkerScheduleRequest(ChangeAssignScheduleToWorkerInputRequest casw, String ip) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();

            AssignScheduleToWorker assignScheduleToWorker = assignScheduleRequestToWorkerRepository.getAssignedScheduledToWorker(casw.getAssignScheduletoWorkerCode());
            if (assignScheduleToWorker != null && assignScheduleToWorker.getId() > 0) {
                ChangeAssignScheduleToWorker chg = new ChangeAssignScheduleToWorker();
                chg.setAssignScheduletoWorkerCode(casw.getAssignScheduletoWorkerCode());
                chg.setChangeToWorkerCode(casw.getChangeToWorkerCode());
                chg.setChangedByWorkerCode(casw.getChangedByWorkerCode());
                chg.setIpAddress(ip);
                ChangeAssignScheduleToWorker chgRes = changeAssignScheduleRequestToWorkerRepository.save(chg);
                if (chgRes != null && chgRes.getId() > 0) {
                    assignScheduleToWorker.setStatus(GigflexConstants.assignedScheduleChangedStatus);
                    AssignScheduleToWorker assignScheduleToWorkerres = assignScheduleRequestToWorkerRepository.save(assignScheduleToWorker);
                    if (assignScheduleToWorkerres != null && assignScheduleToWorkerres.getId() > 0) {
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Schedule change has been added with pending for appraval.");
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(chgRes);
                        jsonobj.put("data", new JSONObject(Detail));
                    } else {
                        jsonobj.put("responsecode", 400);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Schedule change has been failed.");
                        changeAssignScheduleRequestToWorkerRepository.deleteById(chgRes.getId());
                    }

                } else {
                    jsonobj.put("responsecode", 400);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Schedule change has been failed.");
                }

            } else {
                jsonobj.put("responsecode", 404);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "AssignScheduleToWorker does not exist.");
            }
            res = jsonobj.toString();
            } catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();

        }
        return res;
    }

    @Override
    public String approvalChangeAssignToWorkerScheduleRequest(ApprovalChangeAssignScheduleToWorkerInputRequest casw, String ip) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();

            ChangeAssignScheduleToWorker changeAssignScheduleToWorker = changeAssignScheduleRequestToWorkerRepository.getChangeAssignScheduleToWorker(casw.getChangeAssignScheduletoWorkerCode());
            if (changeAssignScheduleToWorker != null && changeAssignScheduleToWorker.getId() > 0) {
                AssignScheduleToWorker assignScheduleToWorker = assignScheduleRequestToWorkerRepository.getAssignedScheduledToWorker(changeAssignScheduleToWorker.getAssignScheduletoWorkerCode());
                if (assignScheduleToWorker != null && assignScheduleToWorker.getId() > 0) {

                    changeAssignScheduleToWorker.setIsApproved(casw.getIsApproved());
                    changeAssignScheduleToWorker.setIpAddress(ip);
                    ChangeAssignScheduleToWorker changeAssignScheduleToWorkerRes = changeAssignScheduleRequestToWorkerRepository.save(changeAssignScheduleToWorker);
                    if (changeAssignScheduleToWorkerRes != null && changeAssignScheduleToWorkerRes.getId() > 0) {
                        assignScheduleToWorker.setStatus(GigflexConstants.assignedScheduleStatus);
                        assignScheduleToWorker.setWorkerCode(changeAssignScheduleToWorkerRes.getChangeToWorkerCode());
                        assignScheduleToWorker.setIpAddress(ip);
                        AssignScheduleToWorker assignScheduleToWorkerres = assignScheduleRequestToWorkerRepository.save(assignScheduleToWorker);
                        if (assignScheduleToWorkerres != null && assignScheduleToWorkerres.getId() > 0) {
                            jsonobj.put("responsecode", 200);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Approval of Schedule change has been done.");
                            ObjectMapper mapperObj = new ObjectMapper();
                            String Detail = mapperObj.writeValueAsString(changeAssignScheduleToWorkerRes);
                            jsonobj.put("data", new JSONObject(Detail));
                        } else {
                            jsonobj.put("responsecode", 400);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Approval of Schedule change has been failed.");
                            Boolean bol = null;
                            changeAssignScheduleToWorkerRes.setIsApproved(bol);
                            changeAssignScheduleRequestToWorkerRepository.save(changeAssignScheduleToWorkerRes);
                        }

                    } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Approval of Schedule change has been failed.");
                    }
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "AssignScheduleToWorker does not exist.");
                }

            } else {
                jsonobj.put("responsecode", 404);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", " ChangeAssignScheduleToWorker does not exist.");
            }
            res = jsonobj.toString();
            } catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();

        }
        return res;
    }

    @Override
    public String getAssigntoWorkerScheduleRequestByWorkerCode(String workerCode) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            List<AssigntoWorkerScheduleResponse> awslst=new ArrayList<AssigntoWorkerScheduleResponse>();
           List<Object> asrwlst= assignScheduleRequestToWorkerRepository.getAssigntoWorkerScheduleRequestByWorkerCode(workerCode);
           if(asrwlst!=null && asrwlst.size()>0) 
           {
           for (Object object : asrwlst) {
               AssigntoWorkerScheduleResponse aws=new AssigntoWorkerScheduleResponse();     
               Object[] obj = (Object[]) object;
               if(obj.length>=3)
               {
               aws.setAssignScheduleToWorker((AssignScheduleToWorker) obj[0]);
               WorkerScheduleRequest wr=(WorkerScheduleRequest)obj[1];
               Date frmDt = null;
               Date toDt = null;

               WorkingLocation wl = workLocRep.findByWorkingLocationCode(wr.getWorkingLocationCode().trim());

               if (wl != null && wl.getId() > 0
                       && wl.getTimeZone() != null
                       && wl.getTimeZone().trim().length() > 0) {
                   TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());	
                   String timezone = tzd.getTimeZoneName();
                    if(timezone!=null && timezone.length()>0 )
                    {
                   Date fromDate = wr.getStartDT();
                   frmDt = GigflexDateUtil.getGMTtoLocationDate(
                           fromDate, timezone, "yyyy-MM-dd HH:mm:ss");
                   Date toDate = wr.getEndDT();
                   toDt = GigflexDateUtil.getGMTtoLocationDate(toDate,
                           timezone, "yyyy-MM-dd HH:mm:ss");
                    }
                   wr.setStartDT(frmDt);
                   wr.setEndDT(toDt);
                    aws.setLocation(wl.getLocation());
               }
               aws.setWorkerScheduleRequest(wr);
               WorkerScheduleRequestAssignment ws=(WorkerScheduleRequestAssignment)obj[2];
               aws.setWorkerScheduleRequestAssignment(ws);
               
                   if (ws.getSkillCode() != null && ws.getSkillCode().length() > 0) {
                       String skillName = workerScheduleRequestRepository.getSkillNameByCode(ws.getSkillCode());
                       aws.setSkillName(skillName);
                   }
                   
                   if (ws.getCertificationCode() != null && ws.getCertificationCode().length() > 0) {
                       
                       CertificationsMaster cm = certificationsMasterRepository.getCertificationsMasterByCertificationCode(ws.getCertificationCode());
                       if (cm != null && cm.getId() > 0) {
                           aws.setCertificationName(cm.getCertificationName());
                       }
                   }
                   if (wr.getOrganizationCode() != null && wr.getOrganizationCode().length() > 0) {
                       
                       Organization o = organizationRepository.findByOrganizationCode(wr.getOrganizationCode());
                       if (o != null && o.getId() > 0) {
                           aws.setOrganizationName(o.getOrganizationName());
                       }
                   }
                   
               awslst.add(aws);
           }
            }
           if(awslst!=null && awslst.size()>0)
           {
               jsonobj.put("responsecode", 200);
               jsonobj.put("timestamp", new Date());
               jsonobj.put("message", "Success");
               ObjectMapper mapperObj = new ObjectMapper();
               String Detail = mapperObj.writeValueAsString(awslst);
               jsonobj.put("data", new JSONArray(Detail));
           }
           else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Records not found.");
                }
           } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Records not found.");
                }
            res = jsonobj.toString();
            } catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();

        }
        return res;
            
    }

    @Override
    public String getAssigntoWorkerScheduleRequestByWorkerCodeByPage(String workerCode, int page, int limit) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            if(limit>0){
            Pageable pageableRequest = PageRequest.of(page, limit);
            List<AssigntoWorkerScheduleResponse> awslst=new ArrayList<AssigntoWorkerScheduleResponse>();
           List<Object> asrwlst= assignScheduleRequestToWorkerRepository.getAssigntoWorkerScheduleRequestByWorkerCode(workerCode,pageableRequest);
           if(asrwlst!=null && asrwlst.size()>0) 
           {
               int count=0;
               List<Object> asrwlstcnt= assignScheduleRequestToWorkerRepository.getAssigntoWorkerScheduleRequestByWorkerCode(workerCode);
               if(asrwlstcnt!=null && asrwlstcnt.size()>0)
               {
                   count=asrwlstcnt.size();
               }
           for (Object object : asrwlst) {
               AssigntoWorkerScheduleResponse aws=new AssigntoWorkerScheduleResponse();     
               Object[] obj = (Object[]) object;
               if(obj.length>=3)
               {
               aws.setAssignScheduleToWorker((AssignScheduleToWorker) obj[0]);
               WorkerScheduleRequest wr=(WorkerScheduleRequest)obj[1];
               Date frmDt = null;
               Date toDt = null;

               WorkingLocation wl = workLocRep.findByWorkingLocationCode(wr.getWorkingLocationCode().trim());

               if (wl != null && wl.getId() > 0
                       && wl.getTimeZone() != null
                       && wl.getTimeZone().trim().length() > 0) {
                   TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());	
                   String timezone = tzd.getTimeZoneName();
                    if(timezone!=null && timezone.length()>0 )
                    {
                   Date fromDate = wr.getStartDT();
                   frmDt = GigflexDateUtil.getGMTtoLocationDate(
                           fromDate, timezone, "yyyy-MM-dd HH:mm:ss");
                   Date toDate = wr.getEndDT();
                   toDt = GigflexDateUtil.getGMTtoLocationDate(toDate,
                           timezone, "yyyy-MM-dd HH:mm:ss");
                    }
                   wr.setStartDT(frmDt);
                   wr.setEndDT(toDt);
                    aws.setLocation(wl.getLocation());
               }
               aws.setWorkerScheduleRequest(wr);
               WorkerScheduleRequestAssignment ws=(WorkerScheduleRequestAssignment)obj[2];
               aws.setWorkerScheduleRequestAssignment(ws);
               
                   if (ws.getSkillCode() != null && ws.getSkillCode().length() > 0) {
                       String skillName = workerScheduleRequestRepository.getSkillNameByCode(ws.getSkillCode());
                       aws.setSkillName(skillName);
                   }
                   
                   if (ws.getCertificationCode() != null && ws.getCertificationCode().length() > 0) {
                       
                       CertificationsMaster cm = certificationsMasterRepository.getCertificationsMasterByCertificationCode(ws.getCertificationCode());
                       if (cm != null && cm.getId() > 0) {
                           aws.setCertificationName(cm.getCertificationName());
                       }
                   }
                   if (wr.getOrganizationCode() != null && wr.getOrganizationCode().length() > 0) {
                       
                       Organization o = organizationRepository.findByOrganizationCode(wr.getOrganizationCode());
                       if (o != null && o.getId() > 0) {
                           aws.setOrganizationName(o.getOrganizationName());
                       }
                   }
                   
               awslst.add(aws);
           }
            }
           if(awslst!=null && awslst.size()>0)
           {
               jsonobj.put("responsecode", 200);
               jsonobj.put("timestamp", new Date());
               jsonobj.put("message", "Success");
               jsonobj.put("count",count);
               ObjectMapper mapperObj = new ObjectMapper();
               String Detail = mapperObj.writeValueAsString(awslst);
               jsonobj.put("data", new JSONArray(Detail));
           }
           else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Records not found.");
                }
           } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Records not found.");
                }
           } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
            res = jsonobj.toString();
            } catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();

        }
        return res;
            
    
    }

    @Override
    public String getAllSceduleByWorkerCodeWithFilterByPage(String workerCode, List<String> status, String stratDT, String endDT, int page, int limit) {
       String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
             if (limit > 0) {
            Pageable pageableRequest = PageRequest.of(page, limit);
            Date sDT = null;
            Date eDT = null;
            if (stratDT != null && stratDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0) {
                                stratDT = stratDT + " 00:00:00";
                                endDT = endDT + " 00:00:00";

                                //Date sd = GigflexDateUtil.getGMTtoLocationDate(sDT,timezone, GigflexConstants.dateFormatterForView);
                                sDT = GigflexDateUtil.convertStringToDate(stratDT.trim(), "yyyy-MM-dd HH:mm:ss");
                                eDT = GigflexDateUtil.convertStringToDate(endDT.trim(), "yyyy-MM-dd HH:mm:ss");
                                if (sDT == null || eDT == null) {
                                    GigflexResponse derr = new GigflexResponse(400, new Date(),
                                            "Date conversion has been failed.");
                                    return derr.toString();
                                }
                                Calendar cal = Calendar.getInstance();
                                cal.setTime(eDT);
                                cal.add(Calendar.DATE, 1);
                                eDT = cal.getTime();
                            }
            List<Object> objlstCheck = null;

                    int count = 0;
                    if (status.size() == 1 && status.get(0).equalsIgnoreCase("all")) {
                        List<String> stlst = new ArrayList<String>();
                        stlst.add(GigflexConstants.assignedScheduleAcceptedStatus);
                        stlst.add(GigflexConstants.assignedScheduleChangedStatus);
                        stlst.add(GigflexConstants.assignedScheduleRejectedStatus);
                        stlst.add(GigflexConstants.assignedScheduleStatus);
                        status = stlst;
                    }

                    List<Object> objlst = null;
                    if (sDT != null && eDT != null) {
                        objlst = assignScheduleRequestToWorkerRepository.getAllSceduleByWorkerCodeWithFilterByPage(workerCode, status, sDT, eDT, pageableRequest);
                        objlstCheck = assignScheduleRequestToWorkerRepository.getAllSceduleByWorkerCodeWithFilterByPage(workerCode, status, sDT, eDT);
                        if (objlstCheck != null && objlstCheck.size() > 0) {
                            count = objlstCheck.size();
                        }
                    } else {
                        objlst = assignScheduleRequestToWorkerRepository.getAllSceduleByWorkerCodeWithFilterByPage(workerCode, status, pageableRequest);
                        objlstCheck = assignScheduleRequestToWorkerRepository.getAllSceduleByWorkerCodeWithFilterByPage(workerCode, status);
                        if (objlstCheck != null && objlstCheck.size() > 0) {
                            count = objlstCheck.size();
                        }
                    }
            
            List<AssigntoWorkerScheduleResponse> awslst=new ArrayList<AssigntoWorkerScheduleResponse>();
          //List<Object> asrwlst= assignScheduleRequestToWorkerRepository.getAssigntoWorkerScheduleRequestByWorkerCode(workerCode,pageableRequest);
           if(objlst!=null && objlst.size()>0) 
           {
           for (Object object : objlst) {
               AssigntoWorkerScheduleResponse aws=new AssigntoWorkerScheduleResponse();     
               Object[] obj = (Object[]) object;
               if(obj.length>=3)
               {
               aws.setAssignScheduleToWorker((AssignScheduleToWorker) obj[0]);
               WorkerScheduleRequest wr=(WorkerScheduleRequest)obj[1];
               Date frmDt = null;
               Date toDt = null;

               WorkingLocation wl = workLocRep.findByWorkingLocationCode(wr.getWorkingLocationCode().trim());

               if (wl != null && wl.getId() > 0
                       && wl.getTimeZone() != null
                       && wl.getTimeZone().trim().length() > 0) {
                   TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());	
                   String timezone = tzd.getTimeZoneName();
                    if(timezone!=null && timezone.length()>0 )
                    {
                   Date fromDate = wr.getStartDT();
                   frmDt = GigflexDateUtil.getGMTtoLocationDate(
                           fromDate, timezone, "yyyy-MM-dd HH:mm:ss");
                   Date toDate = wr.getEndDT();
                   toDt = GigflexDateUtil.getGMTtoLocationDate(toDate,
                           timezone, "yyyy-MM-dd HH:mm:ss");
                    }
                   wr.setStartDT(frmDt);
                   wr.setEndDT(toDt);
                    aws.setLocation(wl.getLocation());
               }
               aws.setWorkerScheduleRequest(wr);
               WorkerScheduleRequestAssignment ws=(WorkerScheduleRequestAssignment)obj[2];
               aws.setWorkerScheduleRequestAssignment(ws);
               
                   if (ws.getSkillCode() != null && ws.getSkillCode().length() > 0) {
                       String skillName = workerScheduleRequestRepository.getSkillNameByCode(ws.getSkillCode());
                       aws.setSkillName(skillName);
                   }
                   
                   if (ws.getCertificationCode() != null && ws.getCertificationCode().length() > 0) {
                       
                       CertificationsMaster cm = certificationsMasterRepository.getCertificationsMasterByCertificationCode(ws.getCertificationCode());
                       if (cm != null && cm.getId() > 0) {
                           aws.setCertificationName(cm.getCertificationName());
                       }
                   }
                   if (wr.getOrganizationCode() != null && wr.getOrganizationCode().length() > 0) {
                       
                       Organization o = organizationRepository.findByOrganizationCode(wr.getOrganizationCode());
                       if (o != null && o.getId() > 0) {
                           aws.setOrganizationName(o.getOrganizationName());
                       }
                   }
                   
               awslst.add(aws);
           }
            }
           if(awslst!=null && awslst.size()>0)
           {
               jsonobj.put("responsecode", 200);
               jsonobj.put("timestamp", new Date());
               jsonobj.put("message", "Success");
               jsonobj.put("count", count);
               ObjectMapper mapperObj = new ObjectMapper();
               String Detail = mapperObj.writeValueAsString(awslst);
               jsonobj.put("data", new JSONArray(Detail));
           }
           else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Records not found.");
                }
           } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Records not found.");
                }
           
           } else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("message", "Limit should not be Zero or Negative.");
                jsonobj.put("timestamp", new Date());
            }
            res = jsonobj.toString();
            } catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();

        }
        return res;
            
    
    
    }

	
}
