/**
 * 
 */
package com.gigflex.prototype.microservices.schedule.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.schedule.dtob.ChangeAssignScheduleToWorker;
import com.gigflex.prototype.microservices.schedule.repository.ChangeAssignScheduleRequestToWorkerRepository;
import com.gigflex.prototype.microservices.schedule.service.ChangeAssignScheduleRequestToWorkerService;
import com.gigflex.prototype.microservices.util.GigflexResponse;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.gigflex.prototype.microservices.schedule.dtob.AssignScheduleToWorker;
import com.gigflex.prototype.microservices.schedule.dtob.ChangeAssignScheduleToWorkerByScheduleRequestCodeRequest;
import com.gigflex.prototype.microservices.schedule.dtob.ChangeAssignScheduleToWorkerResponse;
import com.gigflex.prototype.microservices.schedule.repository.AssignScheduleRequestToWorkerRepository;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import java.util.ArrayList;

/**
 * @author ajit.p
 *
 */
@Service
public class ChangeAssignScheduleRequestToWorkerServiceImpl implements ChangeAssignScheduleRequestToWorkerService {

	@Autowired
	ChangeAssignScheduleRequestToWorkerRepository changeAssignScheduleRequestToWorkerRepository;

        
        @Autowired
        AssignScheduleRequestToWorkerRepository assignScheduleRequestToWorkerRepository;
        
	@Override
	public String getTradeWorkerListByOrganizationCode(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        List<ChangeAssignScheduleToWorkerResponse> caslst=new ArrayList<ChangeAssignScheduleToWorkerResponse>();
			if (organizationCode != null && organizationCode.trim().length() > 0) {
				List<Object> tradeWorkerListByWorkerCode  = changeAssignScheduleRequestToWorkerRepository
						.getTradeWorkerListByOrganizationCode(organizationCode);

				if (tradeWorkerListByWorkerCode != null && tradeWorkerListByWorkerCode.size() > 0) {
					for (int i = 0; i < tradeWorkerListByWorkerCode.size(); i++) {

						Object[] arr = (Object[]) tradeWorkerListByWorkerCode.get(i);
						if (arr.length >= 3) {
                                                    ChangeAssignScheduleToWorkerResponse cas=new ChangeAssignScheduleToWorkerResponse();
                                                    ChangeAssignScheduleToWorker cast = (ChangeAssignScheduleToWorker) arr[0];
                                                        if(cast!=null)
                                                        {
                                                            cas.setChangeAssignScheduleToWorker(cast);
                                                            cas.setChangedByWorkerName((String) arr[1]); 
                                                            cas.setChangeToWorkerName((String) arr[2]);
							caslst.add(cas);
                                                        }
						}
					}
					if (caslst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(caslst);	
                                            jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}

				}else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getTradeWorkerListByWorkerCode(String changeByWorkerCode) {

		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			//JSONArray jsonArray = new JSONArray();
                        List<ChangeAssignScheduleToWorkerResponse> caslst=new ArrayList<ChangeAssignScheduleToWorkerResponse>();
			
			if (changeByWorkerCode != null && changeByWorkerCode.trim().length() > 0) {
				List<Object> tradeWorkerListByWorkerCode = changeAssignScheduleRequestToWorkerRepository
						.getTradeWorkerListByWorkerCodeEmployee(changeByWorkerCode);

				if (tradeWorkerListByWorkerCode != null && tradeWorkerListByWorkerCode.size() > 0) {
					for (int i = 0; i < tradeWorkerListByWorkerCode.size(); i++) {

						Object[] arr = (Object[]) tradeWorkerListByWorkerCode.get(i);
						if (arr.length >= 3) {
                                                    ChangeAssignScheduleToWorkerResponse cas=new ChangeAssignScheduleToWorkerResponse();
                                                    ChangeAssignScheduleToWorker cast = (ChangeAssignScheduleToWorker) arr[0];
                                                        if(cast!=null)
                                                        {
                                                            cas.setChangeAssignScheduleToWorker(cast);
                                                            cas.setChangedByWorkerName((String) arr[1]); 
                                                            cas.setChangeToWorkerName((String) arr[2]);
							caslst.add(cas);
                                                        }
						}
					}
					if (caslst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(caslst);	
                                            jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}

				}else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}

			}else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

    @Override
    public String changeAssignScheduleRequestToWorker(ChangeAssignScheduleToWorkerByScheduleRequestCodeRequest casw, String ip) {
        
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();

            AssignScheduleToWorker assignScheduleToWorker = assignScheduleRequestToWorkerRepository.getAssignedScheduledToWorkerByScheduleRequestCode(casw.getScheduleRequestCode());
            if (assignScheduleToWorker != null && assignScheduleToWorker.getId() > 0) {
                ChangeAssignScheduleToWorker chg = new ChangeAssignScheduleToWorker();
                chg.setAssignScheduletoWorkerCode(assignScheduleToWorker.getAssignScheduletoWorkerCode());
                chg.setChangeToWorkerCode(casw.getChangeToWorkerCode());
                chg.setChangedByWorkerCode(casw.getChangedByWorkerCode());
                chg.setIpAddress(ip);
                ChangeAssignScheduleToWorker chgRes = changeAssignScheduleRequestToWorkerRepository.save(chg);
                if (chgRes != null && chgRes.getId() > 0) {
                    assignScheduleToWorker.setStatus(GigflexConstants.assignedScheduleChangedStatus);
                    AssignScheduleToWorker assignScheduleToWorkerres = assignScheduleRequestToWorkerRepository.save(assignScheduleToWorker);
                    if (assignScheduleToWorkerres != null && assignScheduleToWorkerres.getId() > 0) {
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Schedule change has been added with pending for appraval.");
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(chgRes);
                        jsonobj.put("data", new JSONObject(Detail));
                    } else {
                        jsonobj.put("responsecode", 400);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Schedule change has been failed.");
                        changeAssignScheduleRequestToWorkerRepository.deleteById(chgRes.getId());
                    }

                } else {
                    jsonobj.put("responsecode", 400);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Schedule change has been failed.");
                }

            } else {
                jsonobj.put("responsecode", 404);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "AssignScheduleToWorker does not exist.");
            }
            res = jsonobj.toString();
            } catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();

        }
        return res;
        
    }

    @Override
    public String updateAssignScheduleRequestToWorkerByID(Long id, ChangeAssignScheduleToWorkerByScheduleRequestCodeRequest caswRequest, String ip) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if ( id != null && id.toString().trim().length() > 0 && caswRequest != null) {
                            
				if (caswRequest.getChangeToWorkerCode() !=null && caswRequest.getChangeToWorkerCode().trim().length() > 0
                                && caswRequest.getChangedByWorkerCode() != null &&  caswRequest.getChangedByWorkerCode().trim().length() > 0 
                                     && caswRequest.isIsApproved() != null && caswRequest.isIsApproved().toString().trim().length() > 0 ) {
                               
					ChangeAssignScheduleToWorker chgReq = changeAssignScheduleRequestToWorkerRepository.getChangeAssignScheduleByID(id);  
					if (chgReq != null && chgReq.getId() > 0) {
						chgReq.setChangeToWorkerCode(caswRequest.getChangeToWorkerCode());
                                                chgReq.setChangedByWorkerCode(caswRequest.getChangedByWorkerCode()); 
                                                chgReq.setIpAddress(ip);
                                                chgReq.setIsApproved(caswRequest.isIsApproved());
                                                
						ChangeAssignScheduleToWorker changeAssignScheduleToWorkerRes = changeAssignScheduleRequestToWorkerRepository.save(chgReq);
						if (changeAssignScheduleToWorkerRes != null && changeAssignScheduleToWorkerRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("message",
									"ChangeAssignScheduleToWorker updation has been done");
							jsonobj.put("timestamp", new Date());
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj
									.writeValueAsString(changeAssignScheduleToWorkerRes); 
							jsonobj.put("data", new JSONObject(Detail));
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message",
									"ChangeAssignScheduleToWorker updation has been failed.");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", " ChangeAssignScheduleToWorker ID is not valid.");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "ChangeToWorkerCode,ChangedByWorkerCode & IsApproved should not be blank");

				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;

        
        
        
    }
    
}
