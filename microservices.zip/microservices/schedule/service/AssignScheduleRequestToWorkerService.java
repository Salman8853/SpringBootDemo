/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.schedule.service;

import com.gigflex.prototype.microservices.schedule.dtob.AssignScheduleRequestToWorker;
import com.gigflex.prototype.microservices.schedule.dtob.AssignScheduleToWorker;
import com.gigflex.prototype.microservices.schedule.dtob.ApprovalChangeAssignScheduleToWorkerInputRequest;
import com.gigflex.prototype.microservices.schedule.dtob.AssignScheduleRequestToWorker;
import com.gigflex.prototype.microservices.schedule.dtob.AssignScheduleToWorker;
import com.gigflex.prototype.microservices.schedule.dtob.ChangeAssignScheduleToWorkerInputRequest;
import java.util.List;


/**
 *
 * @author abhishek
 */
public interface AssignScheduleRequestToWorkerService {

      public String saveAssignScheduleRequestToWorker(AssignScheduleRequestToWorker schReq,String idAddress);
      public String  sendScheduleRequestLinkViaEmail(AssignScheduleToWorker assignScheduleToWorkerSave);
      public String saveAcceptedScheduleRequest(String assignScheduletoWorkerCode, String ipAddress);
      public String saveRejectedScheduleRequest(String assignScheduletoWorkerCode, String ipAddress);
      public String getAvailableWorkerWithSameFilterByAssignScheduletoWorkerCode(String assignScheduletoWorkerCode);
      public String changeAssignToWorkerScheduleRequest(ChangeAssignScheduleToWorkerInputRequest casw, String ip);
      public String approvalChangeAssignToWorkerScheduleRequest(ApprovalChangeAssignScheduleToWorkerInputRequest casw, String ip);
      public String getAssigntoWorkerScheduleRequestByWorkerCode(String workerCode);
      public String getAssigntoWorkerScheduleRequestByWorkerCodeByPage(String workerCode,int page, int limit);
      public String getAllSceduleByWorkerCodeWithFilterByPage(String workerCode,List <String> status,String stratDT, String endDT, int page, int limit);
      
}
