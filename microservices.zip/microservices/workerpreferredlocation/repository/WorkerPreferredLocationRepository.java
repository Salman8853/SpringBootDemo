package com.gigflex.prototype.microservices.workerpreferredlocation.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gigflex.prototype.microservices.workerworkinghours.dtob.WorkerWorkingHours;
import com.gigflex.prototype.microservices.workerpreferredlocation.dtob.WorkerPreferredLocation;

public interface WorkerPreferredLocationRepository extends JpaRepository<WorkerPreferredLocation,Long>,JpaSpecificationExecutor<WorkerPreferredLocation>{
	
	@Query("SELECT wpl FROM WorkerWorkingHours wpl WHERE wpl.isDeleted != TRUE AND wpl.workerPreferredLocationCode = :workerPreferredLocationCode")
	public List<WorkerWorkingHours> getWorkerWrkngHrsByWorkerPreferredLocationCode(@Param("workerPreferredLocationCode") String workerPreferredLocationCode);
	
	@Query("SELECT wpl FROM WorkerPreferredLocation wpl WHERE wpl.isDeleted != TRUE")
    public List<WorkerPreferredLocation> getAllWorkerPreferredLocation();
	

	@Query("SELECT wpl FROM WorkerPreferredLocation wpl WHERE wpl.isDeleted != TRUE")
    public List<WorkerPreferredLocation> getAllWorkerPreferredLocation(Pageable pageableRequest);
	

	@Query("SELECT wpl FROM WorkerPreferredLocation wpl WHERE wpl.isDeleted != TRUE AND wpl.id = :id")
	public WorkerPreferredLocation getWorkerPreferredLocationById(@Param("id") Long id);
	
	@Query("SELECT wpl FROM WorkerPreferredLocation wpl WHERE wpl.isDeleted != TRUE AND wpl.workerCode = :workerCode")
	public List<WorkerPreferredLocation> getWorkerPreferredLocationByWorkerCode(@Param("workerCode") String workerCode);
	
	@Query("SELECT wpl FROM WorkerPreferredLocation wpl WHERE wpl.isDeleted != TRUE AND wpl.workerCode = :workerCode")
	public List<WorkerPreferredLocation> getWorkerPreferredLocationByWorkerCode(@Param("workerCode") String workerCode,Pageable pageableRequest);
	
	@Query("SELECT wpl,w.name,o.organizationName FROM WorkerPreferredLocation wpl, Worker w, Organization o WHERE wpl.isDeleted != TRUE AND w.workerCode = wpl.workerCode AND o.organizationCode = wpl.workerOrganizationCode")
	public List<Object> getAllWorkerPreferredLocationWithName();
	

	@Query("SELECT wpl,w.name,o.organizationName FROM WorkerPreferredLocation wpl, Worker w, Organization o WHERE wpl.isDeleted != TRUE AND w.workerCode = wpl.workerCode AND o.organizationCode = wpl.workerOrganizationCode")
	public List<Object> getAllWorkerPreferredLocationWithName(Pageable pageableRequest);
	
//	@Query("SELECT wpl FROM WorkerPreferredLocation wpl WHERE wpl.isDeleted != TRUE AND wpl.workerPreferredLocationCode = :workerPreferredLocationCode")
//	public List<WorkerPreferredLocation> getWorkerPreferredLocationByWorkerPreferredLocationCode(@Param("workerPreferredLocationCode") String workerPreferredLocationCode);
	
	@Query("SELECT wpl FROM WorkerPreferredLocation wpl WHERE wpl.isDeleted != TRUE AND wpl.workerPreferredLocationCode = :workerPreferredLocationCode")
	public WorkerPreferredLocation getPreferredLocationByWorkerPreferredLocationCode(@Param("workerPreferredLocationCode") String workerPreferredLocationCode);

	@Query("SELECT wpl FROM WorkerPreferredLocation wpl WHERE wpl.isDeleted != TRUE AND wpl.workerPreferredLocationCode = :workerPreferredLocationCode")
	public List<WorkerPreferredLocation> getWorkerPreferredLocationByWorkerPreferredLocationCodeByPage(@Param("workerPreferredLocationCode") String workerPreferredLocationCode, Pageable pageableRequest);

	@Query("SELECT wpl FROM WorkerPreferredLocation wpl WHERE wpl.isDeleted != TRUE AND wpl.lat = :lat AND wpl.lang = :lang AND wpl.workerCode = :workerCode AND wpl.workerOrganizationCode = :workerOrganizationCode")
	public WorkerPreferredLocation getWorkerPreferredLocationByLatLangAndWorkerCodeOrgCode(@Param("lat") String lat, @Param("lang") String lang, @Param("workerCode") String workerCode,@Param("workerOrganizationCode") String workerOrganizationCode);
	
	
//	@Query("SELECT wpl FROM WorkerPreferredLocation wpl WHERE wpl.isDeleted != TRUE AND wpl.lat = :lat AND wpl.lang = :lang AND wpl.workerCode = :workerCode")
//	public WorkerPreferredLocation getWorkerPreferredLocationByLatLangAndWorkerCode(@Param("lat") String lat, @Param("lang") String lang, @Param("workerCode") String workerCode);
	
	@Query("SELECT wpl FROM WorkerPreferredLocation wpl WHERE wpl.isDeleted != TRUE AND wpl.id != :id AND wpl.lat = :lat AND wpl.lang = :lang AND wpl.workerCode = :workerCode")
	public WorkerPreferredLocation getWorkerPreferredLocationByIdLatLangAndWorkerCode(@Param("id") Long id,@Param("lat") String lat, @Param("lang") String lang, @Param("workerCode") String workerCode);

	@Query("SELECT wpl FROM WorkerPreferredLocation wpl WHERE wpl.isDeleted != TRUE AND wpl.id != :id AND wpl.lat = :lat AND wpl.lang = :lang AND wpl.workerCode = :workerCode AND wpl.workerOrganizationCode = :workerOrganizationCode")
	public WorkerPreferredLocation getWorkerPreferredLocationByIdLatLangAndWorkerCodeOrgCode(@Param("id") Long id,@Param("lat") String lat, @Param("lang") String lang, @Param("workerCode") String workerCode,@Param("workerOrganizationCode") String workerOrganizationCode);


}
