package com.gigflex.prototype.microservices.workerpreferredlocation.api;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.workerpreferredlocation.dtob.WorkerPreferredLocationRequest;
import com.gigflex.prototype.microservices.workerpreferredlocation.dtob.WorkerPreferredLocationUpdateRequest;
import com.gigflex.prototype.microservices.workerpreferredlocation.service.WorkerPreferredLocationService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/healthcareservice/")
public class WorkerPreferredLocationController {
	
	@Autowired
	private WorkerPreferredLocationService workerPreferredLocationService;
	
	@GetMapping("/workerPreferredLocation/{search}")
	public String search(@PathVariable("search") String search) {
		return workerPreferredLocationService.search(search);
	}
	
	@GetMapping("/getAllWorkerPreferredLocation")
	public String getAllWorkerPreferredLocation(){
		return workerPreferredLocationService.getAllWorkerPreferredLocation();
	}
	
	@GetMapping("/getAllWorkerPreferredLocationWithNames")
	public String getAllWorkerPreferredLocationWithName(){
		return workerPreferredLocationService.getAllWorkerPreferredLocationWithName();
	}
	

	@GetMapping(path="/getAllWorkerPreferredLocationByPage")
    public String getAllWorkerPreferredLocationByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String wpl = workerPreferredLocationService.getAllWorkerPreferredLocationByPage(page, limit);
      
        return wpl;
       
    }
	
	@GetMapping(path="/getAllWorkerPreferredLocationWithNamesByPage")
    public String getAllWorkerPreferredLocationWithNamesByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

		 String wpl = workerPreferredLocationService.getAllWorkerPreferredLocationWithNamesByPage(page, limit);
	      
	        return wpl;
       
    }
	
	

	@GetMapping("/getWorkerPreferredLocation/{id}")
    public String getWorkerPreferredLocationById(@PathVariable Long id){
  	    return workerPreferredLocationService.getWorkerPreferredLocationById(id);
    }
	
	@GetMapping("/getWorkerPreferredLocationByWorkerCode/{workerCode}")
	public String getWorkerPreferredLocationByWorkerCode(@PathVariable String workerCode) {
		return workerPreferredLocationService.getWorkerPreferredLocationByWorkerCode(workerCode);
	}
	
	@GetMapping("/getWorkerPreferredLocationByWorkerCodeByPage/{workerCode}")
	public String getWorkerPreferredLocationByWorkerCodeByPage(@PathVariable String workerCode,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {
		
		 String wpl = workerPreferredLocationService.getWorkerPreferredLocationByWorkerCode(workerCode,page, limit);
	      
		
		return wpl;
	}
	
	@GetMapping("/getWorkerPreferredLocationByWorkerPreferredLocationCode/{workerPreferredLocationCode}")
	public String getWorkerPreferredLocationByWorkerPreferredLocationCode(@PathVariable String workerPreferredLocationCode) {
		return workerPreferredLocationService.getWorkerPreferredLocationByWorkerPreferredLocationCode(workerPreferredLocationCode);
	}
	
	@GetMapping("/getWorkerPreferredLocationByWorkerPreferredLocationCodeByPage/{workerPreferredLocationCode}")
	public String getWorkerPreferredLocationByWorkerPreferredLocationCodeByPage(@PathVariable String workerPreferredLocationCode,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {
		
		 String wpl = workerPreferredLocationService.getWorkerPreferredLocationByWorkerPreferredLocationCode(workerPreferredLocationCode, page, limit);
	      
		
		return wpl;
	}
	
	@PostMapping("/saveWorkerPreferredLocation")
	public String saveWorkerPreferredLocation(
			@RequestBody WorkerPreferredLocationRequest workerPreLocReq,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return workerPreferredLocationService.saveWorkerPreferredLocation(workerPreLocReq, ip);

	}
	
	@PutMapping("/updateWorkerPreferredLocationById/{id}")
	public String updateCertificationsMaster(@PathVariable Long id,
			 @RequestBody WorkerPreferredLocationUpdateRequest workerPreLocReq,
			HttpServletRequest request) {

		if (id == null) {
			return "Role Master with Id : (" + id + ") Not found.";
		} else {
			String ip = request.getRemoteAddr();

			return workerPreferredLocationService.updateWorkerPreferredLocationById(id, workerPreLocReq, ip);

		}

	}
	
	@DeleteMapping("/softDeleteWorkerPreferredLocationByWorkerPreferredLocationCode/{workerPreferredLocationCode}")
	public String softDeleteWorkerPreferredLocationByWorkerPreferredLocationCode(@PathVariable String workerPreferredLocationCode) {
		return workerPreferredLocationService.softDeleteWorkerPreferredLocationByPreferredLocationCode(workerPreferredLocationCode);
	}
	
	@DeleteMapping("/softMultipleDeleteWorkerPreferredLocationByWorkerPreferredLocationCode/{workerPreferredLocationCodeList}")
	public String softMultipleDeleteWorkerPreferredLocationByWorkerPreferredLocationCode(@PathVariable List<String> workerPreferredLocationCodeList) {
		if(workerPreferredLocationCodeList != null && workerPreferredLocationCodeList.size()>0){
			return workerPreferredLocationService.softMultipleDeleteByWorkerPreferredLocationCode(workerPreferredLocationCodeList);
		}else{
			 GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
	           return derr.toString();
		}
		
	}

}
