package com.gigflex.prototype.microservices.workerpreferredlocation.service;

import java.util.List;

import com.gigflex.prototype.microservices.workerpreferredlocation.dtob.WorkerPreferredLocationRequest;
import com.gigflex.prototype.microservices.workerpreferredlocation.dtob.WorkerPreferredLocationUpdateRequest;

public interface WorkerPreferredLocationService {
	
	public String search(String search);
	
	public String getAllWorkerPreferredLocation();

	public String getAllWorkerPreferredLocationByPage(int page, int limit);

	public String getWorkerPreferredLocationById(Long id);
	public String getWorkerPreferredLocationByWorkerCode(String workerCode);
	public String getWorkerPreferredLocationByWorkerCode(String workerCode,int page, int limit);
	
	public String getWorkerPreferredLocationByWorkerPreferredLocationCode(String workerPreferredLocationCode);
	public String getWorkerPreferredLocationByWorkerPreferredLocationCode(String workerPreferredLocationCode,int page, int limit);

	public String saveWorkerPreferredLocation(WorkerPreferredLocationRequest workerPreLocReq, String ip);
	public String updateWorkerPreferredLocationById(Long id,WorkerPreferredLocationUpdateRequest workerPreLocReq, String ip);
	public String softDeleteWorkerPreferredLocationByPreferredLocationCode(String workerPreferredLocationCode);
	public String softMultipleDeleteByWorkerPreferredLocationCode(List<String> workerPreferredLocationCodeList);
	public String getAllWorkerPreferredLocationWithName();

	public String getAllWorkerPreferredLocationWithNamesByPage(int page, int limit);

}
