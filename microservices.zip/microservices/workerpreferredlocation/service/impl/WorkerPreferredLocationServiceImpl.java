package com.gigflex.prototype.microservices.workerpreferredlocation.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.util.GigUtil;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.worker.repository.WorkerRepository;
import com.gigflex.prototype.microservices.workerpreferredlocation.dtob.Location;
import com.gigflex.prototype.microservices.workerpreferredlocation.dtob.WorkerPreferredLocation;
import com.gigflex.prototype.microservices.workerpreferredlocation.dtob.WorkerPreferredLocationRequest;
import com.gigflex.prototype.microservices.workerpreferredlocation.dtob.WorkerPreferredLocationResponse;
import com.gigflex.prototype.microservices.workerpreferredlocation.dtob.WorkerPreferredLocationUpdateRequest;
import com.gigflex.prototype.microservices.workerpreferredlocation.repository.WorkerPreferredLocationRepository;
import com.gigflex.prototype.microservices.workerpreferredlocation.search.WorkerPreferredLocationSpecificationsBuilder;
import com.gigflex.prototype.microservices.workerpreferredlocation.service.WorkerPreferredLocationService;

@Service
public class WorkerPreferredLocationServiceImpl implements
		WorkerPreferredLocationService {

	private static final Logger LOG = LoggerFactory
			.getLogger(WorkerPreferredLocationServiceImpl.class);

	@Autowired
	private WorkerPreferredLocationRepository workerPreferredLocationRepository;
	
	@Autowired
	private WorkerRepository workerDao;
	
	@Autowired
	private OrganizationRepository orgDao;

	
	@Override
	public String getAllWorkerPreferredLocation() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<WorkerPreferredLocation> workerPreLocLst = workerPreferredLocationRepository
					.getAllWorkerPreferredLocation();
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (workerPreLocLst != null && workerPreLocLst.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(workerPreLocLst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getWorkerPreferredLocationById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			WorkerPreferredLocation workerPreLocLst = workerPreferredLocationRepository
					.getWorkerPreferredLocationById(id);
			if (workerPreLocLst != null && workerPreLocLst.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(workerPreLocLst);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getWorkerPreferredLocationByWorkerCode(String workerCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<WorkerPreferredLocation> workerPreLocLst = workerPreferredLocationRepository
					.getWorkerPreferredLocationByWorkerCode(workerCode);
			if (workerPreLocLst != null && workerPreLocLst.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(workerPreLocLst);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Success");
				jsonobj.put("data", new JSONArray(Detail));

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String saveWorkerPreferredLocation(
			WorkerPreferredLocationRequest workerPreLocReq, String ip) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();

			if (workerPreLocReq != null) {
				if ((workerPreLocReq.getWorkerCode() != null && workerPreLocReq
						.getWorkerCode().trim().length() > 0 && workerPreLocReq.getWorkerOrganizationCode() != null && workerPreLocReq
						.getWorkerOrganizationCode().trim().length() > 0)
						&& workerPreLocReq.getLocation() != null
						&& workerPreLocReq.getLocation().size() > 0) {

					for (Location location : workerPreLocReq.getLocation()) {
						if (location != null) {

							JSONObject jsonobj = new JSONObject();
							
							Worker worker = workerDao
									.findByWorkerCode(workerPreLocReq
											.getWorkerCode());
							if (worker != null && worker.getId() > 0) {
								
								Organization org = orgDao.findByOrganizationCode(workerPreLocReq.getWorkerOrganizationCode());
								if (org != null && org.getId() > 0) {
									
							WorkerPreferredLocation wpl = workerPreferredLocationRepository
									.getWorkerPreferredLocationByLatLangAndWorkerCodeOrgCode(
											location.getLat(),
											location.getLang(),
											workerPreLocReq.getWorkerCode(),
											workerPreLocReq.getWorkerOrganizationCode());
							if (wpl != null && wpl.getId() > 0) {
								jsonobj.put("responsecode", 409);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Record already exist.");
							} else {

								WorkerPreferredLocation workerPreLocLst = new WorkerPreferredLocation();

								workerPreLocLst.setWorkerCode(workerPreLocReq
										.getWorkerCode());
								workerPreLocLst.setWorkerOrganizationCode(workerPreLocReq.getWorkerOrganizationCode());
								workerPreLocLst.setLocation(location
										.getLocation());
								workerPreLocLst.setLat(location.getLat());
								workerPreLocLst.setLang(location.getLang());
								workerPreLocLst.setIsactive(workerPreLocReq
										.getIsactive());
								workerPreLocLst.setIpAddress(ip);

								WorkerPreferredLocation workerPreLocRes = workerPreferredLocationRepository
										.save(workerPreLocLst);

								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());

								if (workerPreLocRes != null
										&& workerPreLocRes.getId() > 0) {

//									kafkaService
//											.sendWorkerPreferredLocation(workerPreLocRes);

									jsonobj.put("message",
											"Worker Preferred Location has been added successfully.");
									ObjectMapper mapperObj = new ObjectMapper();
									String Detail = mapperObj
											.writeValueAsString(workerPreLocRes);
									jsonobj.put("data", new JSONObject(Detail));
								} else {
									jsonobj.put("message", "Failed");
								}

							}
							} else {
								jsonobj.put("message", "Organization Code Not Found.");
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
							}
							} else {
								jsonobj.put("message", "Worker Code Not Found.");
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
							}
							jarr.add(jsonobj);
						}
							
						if (jarr.size() > 0) {
							res = jarr.toString();
						} else {
							GigflexResponse derr = new GigflexResponse(400,
									new Date(), "Multiple add failed.");
							res = derr.toString();
						}

					}
				} else {
					GigflexResponse derr = new GigflexResponse(400, new Date(),
							"Worker Code, Organization Code and Location Details should not be blank");
					res = derr.toString();
				}
			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String updateWorkerPreferredLocationById(Long id,
			WorkerPreferredLocationUpdateRequest workerPreLocReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (id > 0 && workerPreLocReq != null) {
				if ((workerPreLocReq.getWorkerCode() != null && workerPreLocReq
						.getWorkerCode().trim().length() > 0)) {
					WorkerPreferredLocation workerPreLocLst = workerPreferredLocationRepository
							.getWorkerPreferredLocationById(id);
					if (workerPreLocLst != null && workerPreLocLst.getId() > 0) {
						Worker worker = workerDao
								.findByWorkerCode(workerPreLocReq
										.getWorkerCode());
						if (worker != null && worker.getId() > 0) {
							
							Organization org = orgDao.findByOrganizationCode(workerPreLocReq.getWorkerOrganizationCode());
							if (org != null && org.getId() > 0) {

						WorkerPreferredLocation wpl = workerPreferredLocationRepository
								.getWorkerPreferredLocationByIdLatLangAndWorkerCodeOrgCode(
										id, workerPreLocReq.getLat(),
										workerPreLocReq.getLang(),
										workerPreLocReq.getWorkerCode(),
										workerPreLocReq.getWorkerOrganizationCode());
						if (wpl != null && wpl.getId() > 0) {
							jsonobj.put("responsecode", 409);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Record already exist.");
						} else {

							WorkerPreferredLocation workerPreLoc = workerPreLocLst;

							workerPreLoc.setWorkerCode(workerPreLocReq
									.getWorkerCode());
							workerPreLocLst.setWorkerOrganizationCode(workerPreLocReq.getWorkerOrganizationCode());

							workerPreLoc.setLocation(workerPreLocReq
									.getLocation());
							workerPreLoc.setLat(workerPreLocReq.getLat());
							workerPreLoc.setLang(workerPreLocReq.getLang());
							workerPreLoc.setIsactive(workerPreLocReq
									.getIsactive());
							workerPreLoc.setIpAddress(ip);

							WorkerPreferredLocation workerPreLocRes = workerPreferredLocationRepository
									.save(workerPreLocLst);

							if (workerPreLocRes != null
									&& workerPreLocRes.getId() > 0) {
								jsonobj.put("responsecode", 200);
								jsonobj.put("message",
										"Worker Preferred Location updation has been done");
								jsonobj.put("timestamp", new Date());
								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj
										.writeValueAsString(workerPreLocRes);
								jsonobj.put("data", new JSONObject(Detail));

//								kafkaService
//										.sendWorkerPreferredLocationUpdate(workerPreLocRes);
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("message",
										"Worker Preferred Location updation has been failed.");
								jsonobj.put("timestamp", new Date());
							}
							
						}
						} else {
							jsonobj.put("message", "Organization Code Not Found.");
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
						}
						} else {
							jsonobj.put("message", "Worker Code Not Found.");
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message",
								"Worker Preferred Location ID is not valid.");
						jsonobj.put("timestamp", new Date());
					}

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Worker Code should not be blank");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String softDeleteWorkerPreferredLocationByPreferredLocationCode(
			String workerPreferredLocationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			WorkerPreferredLocation wpl = workerPreferredLocationRepository
					.getPreferredLocationByWorkerPreferredLocationCode(workerPreferredLocationCode);
			if (wpl != null && wpl.getId() > 0) {
			

					wpl.setIsDeleted(true);
					WorkerPreferredLocation workerPreLocRes = workerPreferredLocationRepository
							.save(wpl);
					if (workerPreLocRes != null && workerPreLocRes.getId() > 0) {
						jsonobj.put("responsecode", 200);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message",
								"Worker Preferred Location deleted successfully.");
//						kafkaService
//								.sendWorkerPreferredLocationUpdate(workerPreLocRes);
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Failed");
					}
				

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
			LOG.error("Error in softDeleteByWorkerPreferredLocationCode>>>>>>",
					ex);
		} catch (org.springframework.orm.jpa.JpaSystemException ex) {
			GigflexResponse derr = new GigflexResponse(401, new Date(),
					GigUtil.getRootException(ex));
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
			LOG.error("Error in softDeleteByWorkerPreferredLocationCode>>>>>>",
					ex);
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteByWorkerPreferredLocationCode(
			List<String> workerPreferredLocationCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String workerPreferredLocationCode : workerPreferredLocationCodeList) {
				if (workerPreferredLocationCode != null
						&& workerPreferredLocationCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					workerPreferredLocationCode = workerPreferredLocationCode
							.trim();

					WorkerPreferredLocation wpl = workerPreferredLocationRepository
							.getPreferredLocationByWorkerPreferredLocationCode(workerPreferredLocationCode);
					if (wpl != null && wpl.getId() > 0) {
						try {
								wpl.setIsDeleted(true);
								WorkerPreferredLocation workerPreLocRes = workerPreferredLocationRepository
										.save(wpl);
								if (workerPreLocRes != null
										&& workerPreLocRes.getId() > 0) {
									jsonobj.put("responsecode", 200);
									jsonobj.put("timestamp", new Date());
									jsonobj.put("code",
											workerPreferredLocationCode);
									jsonobj.put("message",
											"Worker Preferred Location deleted successfully.");
//									kafkaService
//											.sendWorkerPreferredLocationUpdate(workerPreLocRes);
								} else {
									jsonobj.put("responsecode", 400);
									jsonobj.put("timestamp", new Date());
									jsonobj.put("code",
											workerPreferredLocationCode);
									jsonobj.put("message", "Failed");
								}
							
						} catch (org.springframework.orm.jpa.JpaSystemException ex) {
							jsonobj.put("responsecode", 401);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", workerPreferredLocationCode);
							jsonobj.put("message", GigUtil.getRootException(ex));
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", workerPreferredLocationCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getAllWorkerPreferredLocationWithName() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<Object> objlst = workerPreferredLocationRepository
					.getAllWorkerPreferredLocationWithName();
			List<WorkerPreferredLocationResponse> maplst = new ArrayList<WorkerPreferredLocationResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);

					if (arr.length >= 3) {
						WorkerPreferredLocationResponse wplr = new WorkerPreferredLocationResponse();

						WorkerPreferredLocation wpl = (WorkerPreferredLocation) arr[0];

						wplr.setId(wpl.getId());
						wplr.setWorkerPreferredLocationCode(wpl
								.getWorkerPreferredLocationCode());
						wplr.setIsactive(wpl.getIsactive());
						wplr.setLang(wpl.getLang());
						wplr.setLat(wpl.getLat());
						wplr.setLocation(wpl.getLocation());
						wplr.setWorkerCode(wpl.getWorkerCode());
						wplr.setWorkerOrganizationCode(wpl.getWorkerOrganizationCode());
						wplr.setName((String) arr[1]);
						wplr.setOrganizationName((String) arr[2]);
//						wplr.setName((String) arr[1]);
						

						maplst.add(wplr);
					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllWorkerPreferredLocationByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<WorkerPreferredLocation> wpl = workerPreferredLocationRepository
					.getAllWorkerPreferredLocation(pageableRequest);
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (wpl != null && wpl.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(wpl);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllWorkerPreferredLocationWithNamesByPage(int page,
			int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<Object> objlst = workerPreferredLocationRepository
					.getAllWorkerPreferredLocationWithName(pageableRequest);
			List<WorkerPreferredLocationResponse> maplst = new ArrayList<WorkerPreferredLocationResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 3) {
						WorkerPreferredLocationResponse wplr = new WorkerPreferredLocationResponse();

						WorkerPreferredLocation wpl = (WorkerPreferredLocation) arr[0];

						wplr.setId(wpl.getId());
						wplr.setWorkerPreferredLocationCode(wpl
								.getWorkerPreferredLocationCode());
						wplr.setIsactive(wpl.getIsactive());
						wplr.setLang(wpl.getLang());
						wplr.setLat(wpl.getLat());
						wplr.setLocation(wpl.getLocation());
						wplr.setWorkerCode(wpl.getWorkerCode());
						wplr.setWorkerOrganizationCode(wpl.getWorkerOrganizationCode());
						wplr.setName((String) arr[1]);
						wplr.setOrganizationName((String) arr[2]);
//						wplr.setName((String) arr[1]);
						

						maplst.add(wplr);
					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getWorkerPreferredLocationByWorkerCode(String workerCode,
			int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<WorkerPreferredLocation> workerPreLocLst = workerPreferredLocationRepository
					.getWorkerPreferredLocationByWorkerCode(workerCode,
							pageableRequest);
			if (workerPreLocLst != null && workerPreLocLst.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(workerPreLocLst);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Success");
				jsonobj.put("data", new JSONArray(Detail));

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getWorkerPreferredLocationByWorkerPreferredLocationCode(
			String workerPreferredLocationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			WorkerPreferredLocation workerPreLocLst = workerPreferredLocationRepository
					.getPreferredLocationByWorkerPreferredLocationCode(workerPreferredLocationCode);
			if (workerPreLocLst != null) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(workerPreLocLst);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Success");
				jsonobj.put("data", new JSONObject(Detail));

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;

	}

	@Override
	public String getWorkerPreferredLocationByWorkerPreferredLocationCode(
			String workerPreferredLocationCode, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<WorkerPreferredLocation> workerPreLocLst = workerPreferredLocationRepository
					.getWorkerPreferredLocationByWorkerPreferredLocationCodeByPage(
							workerPreferredLocationCode, pageableRequest);
			if (workerPreLocLst != null && workerPreLocLst.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(workerPreLocLst);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Success");
				jsonobj.put("data", new JSONArray(Detail));

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			if (search != null && search.trim().length() > 0) {
				JSONObject jsonobj = new JSONObject();

				WorkerPreferredLocationSpecificationsBuilder builder = new WorkerPreferredLocationSpecificationsBuilder();
				Pattern pattern = Pattern
						.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
				java.util.regex.Matcher matcher = pattern.matcher(search + ",");
				while (matcher.find()) {
					builder.with(matcher.group(1), matcher.group(2),
							matcher.group(3));
				}

				Specification<WorkerPreferredLocation> spec = builder.build();
				if (spec != null) {
					List<WorkerPreferredLocation> workerPreLocLst = workerPreferredLocationRepository
							.findAll(spec);
					if (workerPreLocLst != null && workerPreLocLst.size() > 0) {
						for (WorkerPreferredLocation wpl : workerPreLocLst) {
							if (wpl.getIsDeleted() != null
									&& wpl.getIsDeleted() != true) {

								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj
										.writeValueAsString(wpl);
								JSONObject jsonobjNew = new JSONObject();
								jsonobjNew.put("WorkerPreferredLocation",
										new JSONObject(Detail));
								jarr.add(jsonobjNew);

							}

						}
						if (jarr.size() > 0) {

							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "Success");
							jsonobj.put("timestamp", new Date());
							jsonobj.put("data", jarr);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "Record Not Found!");
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Record Not Found!");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Record Not Found!");
					jsonobj.put("timestamp", new Date());
				}
				res = jsonobj.toString();

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Input data is not valid.");
				res = derr.toString();

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

}
