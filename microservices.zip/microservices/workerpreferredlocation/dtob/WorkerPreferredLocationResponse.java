package com.gigflex.prototype.microservices.workerpreferredlocation.dtob;

public class WorkerPreferredLocationResponse {
	
	    private Long id;
	    
	    private String workerCode;
	    
		private String location;
	    
		private String lat;

		private String lang;

		private Boolean isactive;
		
		private String workerPreferredLocationCode;
		
		private String name;
		
	    private String workerOrganizationCode;
	    
	    private String organizationName;



		public String getWorkerPreferredLocationCode() {
			return workerPreferredLocationCode;
		}

		public void setWorkerPreferredLocationCode(String workerPreferredLocationCode) {
			this.workerPreferredLocationCode = workerPreferredLocationCode;
		}

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getWorkerCode() {
			return workerCode;
		}

		public void setWorkerCode(String workerCode) {
			this.workerCode = workerCode;
		}

		public String getLocation() {
			return location;
		}

		public void setLocation(String location) {
			this.location = location;
		}

		public String getLat() {
			return lat;
		}

		public void setLat(String lat) {
			this.lat = lat;
		}

		public String getLang() {
			return lang;
		}

		public void setLang(String lang) {
			this.lang = lang;
		}

		public Boolean getIsactive() {
			return isactive;
		}

		public void setIsactive(Boolean isactive) {
			this.isactive = isactive;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getWorkerOrganizationCode() {
			return workerOrganizationCode;
		}

		public void setWorkerOrganizationCode(String workerOrganizationCode) {
			this.workerOrganizationCode = workerOrganizationCode;
		}

		public String getOrganizationName() {
			return organizationName;
		}

		public void setOrganizationName(String organizationName) {
			this.organizationName = organizationName;
		}
		
		
		
		

}
