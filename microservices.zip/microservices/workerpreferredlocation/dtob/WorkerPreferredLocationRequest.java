package com.gigflex.prototype.microservices.workerpreferredlocation.dtob;

import java.util.List;

import javax.persistence.Column;

public class WorkerPreferredLocationRequest {
	
	    private String workerCode;
	    
		private List<Location> location;
		
		private Boolean isactive;
		
	    private String workerOrganizationCode;


		public String getWorkerCode() {
			return workerCode;
		}

		public void setWorkerCode(String workerCode) {
			this.workerCode = workerCode;
		}

		public List<Location> getLocation() {
			return location;
		}

		public void setLocation(List<Location> location) {
			this.location = location;
		}

		public Boolean getIsactive() {
			return isactive;
		}

		public void setIsactive(Boolean isactive) {
			this.isactive = isactive;
		}

		public String getWorkerOrganizationCode() {
			return workerOrganizationCode;
		}

		public void setWorkerOrganizationCode(String workerOrganizationCode) {
			this.workerOrganizationCode = workerOrganizationCode;
		}

	    
		
		

}
