package com.gigflex.prototype.microservices.timezone.dtob;

public class TimeZoneDetailRequest {
	
	private String timeZoneName;

	public String getTimeZoneName() {
		return timeZoneName;
	}

	public void setTimeZoneName(String timeZoneName) {
		this.timeZoneName = timeZoneName;
	}

}
