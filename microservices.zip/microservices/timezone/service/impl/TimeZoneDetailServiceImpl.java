package com.gigflex.prototype.microservices.timezone.service.impl;

import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetailMultiRequest;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetailRequest;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.timezone.search.TimeZoneDetailSpecificationsBuilder;
import com.gigflex.prototype.microservices.timezone.service.TimeZoneDetailService;
import com.gigflex.prototype.microservices.util.GigflexResponse;

@Service
public class TimeZoneDetailServiceImpl implements TimeZoneDetailService {

	@Autowired
	private TimeZoneRepository timeZoneDao;

	@Override
	public String getAllTimeZoneDetail() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<TimeZoneDetail> timeZonelst = timeZoneDao
					.getAllTimeZoneDetail();

			if (timeZonelst != null && timeZonelst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(timeZonelst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "No data found.");
				jsonobj.put("timestamp", new Date());

			}

			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getAllTimeZoneDetail(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<TimeZoneDetail> timeZonelst = timeZoneDao
					.getAllTimeZoneDetail(pageableRequest);

			if (timeZonelst != null && timeZonelst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(timeZonelst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String createNewTimeZone(TimeZoneDetailMultiRequest timeZonereq,
			String ip) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			JSONObject jsonobj = new JSONObject();

			if (timeZonereq != null) {

				for (String timeZoneName : timeZonereq.getTimeZoneName()) {
					if (timeZoneName != null
							&& timeZoneName.trim().length() > 0) {

						TimeZoneDetail timeDetail = new TimeZoneDetail();
						timeDetail.setTimeZoneName(timeZoneName);

						timeDetail.setIpAddress(ip);

						TimeZoneDetail timeRes = timeZoneDao.save(timeDetail);

						if (timeRes != null && timeRes.getId() > 0) {

							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("Time Zone Name", timeZoneName);
							jsonobj.put("message",
									"Time Zone Detail has been added successfully.");
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj
									.writeValueAsString(timeRes);
							jsonobj.put("data", new JSONObject(Detail));
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Failed");
							jsonobj.put("Time Zone Name", timeZoneName);

						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message",
								"Time Zone Name Should Not be Blank.");
						jsonobj.put("Time Zone Name", timeZoneName);

					}
					jarr.add(jsonobj);

				}

				if (jarr.size() > 0) {
					res = jarr.toString();
				} else {
					GigflexResponse derr = new GigflexResponse(400, new Date(),
							"Multiple add failed.");
					res = derr.toString();
				}

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String updateTimeZoneDetailById(Long id,
			TimeZoneDetailRequest timeZonereq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (id > 0 && timeZonereq != null) {

				if (timeZonereq.getTimeZoneName() != null
						&& timeZonereq.getTimeZoneName().trim().length() > 0) {

					TimeZoneDetail timeZone = timeZoneDao
							.getTimeZoneDetailById(id);

					if (timeZone != null && timeZone.getId() > 0) {

						TimeZoneDetail td = timeZone;

						td.setTimeZoneName(timeZonereq.getTimeZoneName().trim());

						TimeZoneDetail tdRes = timeZoneDao.save(td);

						if (tdRes != null && tdRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("message",
									"TimeZoneDetail updation has been done");
							jsonobj.put("timestamp", new Date());
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj.writeValueAsString(tdRes);
							jsonobj.put("data", new JSONObject(Detail));

						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message",
									"TimeZoneDetail updation has been failed.");
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message",
								"TimeZoneDetail ID is not valid.");
						jsonobj.put("timestamp", new Date());
					}

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "TimeZone name should not be blank");
				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getTimeZoneDetailById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			TimeZoneDetail timeZone = timeZoneDao.getTimeZoneDetailById(id);

			if (timeZone != null && timeZone.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(timeZone);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getTimeZoneDetailByTimeZoneCode(String timeZoneCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			TimeZoneDetail timeZone = timeZoneDao
					.getTimeZoneDetailByTimeZoneCode(timeZoneCode);

			if (timeZone != null && timeZone.getId() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(timeZone);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Success");
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String softDeleteTimeZoneDetailByTimeZoneCode(String timeZoneCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			TimeZoneDetail timeZone = timeZoneDao
					.getTimeZoneDetailByTimeZoneCode(timeZoneCode);

			if (timeZone != null && timeZone.getId() > 0) {
				timeZone.setIsDeleted(true);
				TimeZoneDetail timeZoneRes = timeZoneDao.save(timeZone);

				if (timeZoneRes != null && timeZoneRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message",
							"TimeZoneDetail deleted successfully.");
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteByTimeZoneCode(List<String> timeZoneCode) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String tCode : timeZoneCode) {
				if (tCode != null && tCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					tCode = tCode.trim();

					TimeZoneDetail timeZone = timeZoneDao
							.getTimeZoneDetailByTimeZoneCode(tCode);

					if (timeZone != null && timeZone.getId() > 0) {
						timeZone.setIsDeleted(true);
						TimeZoneDetail timeZoneRes = timeZoneDao.save(timeZone);

						if (timeZoneRes != null && timeZoneRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message",
									"TimeZoneDetail deleted successfully.");
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Failed");
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", tCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			if (search != null && search.trim().length() > 0) {
				JSONObject jsonobj = new JSONObject();

				TimeZoneDetailSpecificationsBuilder builder = new TimeZoneDetailSpecificationsBuilder();
				Pattern pattern = Pattern
						.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
				java.util.regex.Matcher matcher = pattern.matcher(search + ",");
				while (matcher.find()) {
					builder.with(matcher.group(1), matcher.group(2),
							matcher.group(3));
				}

				Specification<TimeZoneDetail> spec = builder.build();
				if (spec != null) {
					List<TimeZoneDetail> timeZoneLst = timeZoneDao
							.findAll(spec);
					if (timeZoneLst != null && timeZoneLst.size() > 0) {
						for (TimeZoneDetail tzd : timeZoneLst) {
							if (tzd.getIsDeleted() != null
									&& tzd.getIsDeleted() != true) {

								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj
										.writeValueAsString(tzd);
								JSONObject jsonobjNew = new JSONObject();
								jsonobjNew.put("VehicleType", new JSONObject(
										Detail));
								jarr.add(jsonobjNew);

							}

						}
						if (jarr.size() > 0) {

							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "Success");
							jsonobj.put("timestamp", new Date());
							jsonobj.put("data", jarr);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "Record Not Found!");
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Record Not Found!");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Record Not Found!");
					jsonobj.put("timestamp", new Date());
				}
				res = jsonobj.toString();

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Input data is not valid.");
				res = derr.toString();

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;

	}

	// @Override
	// public String createNewTimeZone(TimeZoneDetailRequest timeZonereq,String
	// ip) {
	// String res = "";
	// try {
	// JSONObject jsonobj = new JSONObject();
	// if (timeZonereq != null) {
	// if (timeZonereq.getTimeZoneName() != null
	// && timeZonereq.getTimeZoneName().trim().length() > 0) {
	//
	// TimeZoneDetail timeZone = new TimeZoneDetail();
	// timeZone.setTimeZoneName(timeZonereq.getTimeZoneName());
	// timeZone.setIpAddress(ip);
	//
	// TimeZoneDetail timeRes = timeZoneDao.save(timeZone);
	//
	// jsonobj.put("responsecode", 200);
	// jsonobj.put("timestamp", new Date());
	//
	// if (timeRes != null && timeRes.getId() > 0) {
	// jsonobj.put("message",
	// "Time Zone Detail has been added successfully.");
	// ObjectMapper mapperObj = new ObjectMapper();
	// String Detail = mapperObj.writeValueAsString(timeRes);
	// jsonobj.put("data", new JSONObject(Detail));
	// } else {
	// jsonobj.put("message", "Failed");
	// }
	// } else {
	// jsonobj.put("responsecode", 400);
	// jsonobj.put("timestamp", new Date());
	// jsonobj.put("message", "Time Zone Name should not be blank");
	// }
	// } else {
	// jsonobj.put("responsecode", 400);
	// jsonobj.put("message", "Input data is not valid.");
	// jsonobj.put("timestamp", new Date());
	// }
	// res = jsonobj.toString();
	// } catch (JSONException | JsonProcessingException ex) {
	// GigflexResponse derr = new GigflexResponse(500, new Date(),
	// "JSON parsing exception occurred.");
	// res = derr.toString();
	// }
	// return res;
	// }

}
