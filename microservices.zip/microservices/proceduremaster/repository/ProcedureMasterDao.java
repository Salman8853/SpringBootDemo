/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.proceduremaster.repository;

import com.gigflex.prototype.microservices.proceduremaster.dtob.ProcedureMaster;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author amit.kumar
 */
@Repository
public interface ProcedureMasterDao extends JpaRepository<ProcedureMaster,Integer>,JpaSpecificationExecutor<ProcedureMaster>{

    @Query("SELECT pm FROM ProcedureMaster pm WHERE pm.isDeleted != TRUE")
    public List<ProcedureMaster> getAllProcedureMaster();

    @Query("SELECT pm FROM ProcedureMaster pm WHERE pm.isDeleted != TRUE")
    public List<ProcedureMaster> getAllProcedureMaster(Pageable pageableRequest);

    @Query("SELECT pm FROM ProcedureMaster pm WHERE pm.isDeleted != TRUE AND pm.id = :id")
    public ProcedureMaster getProcedureMasterById(@Param("id") Integer id);

    @Query("SELECT pm FROM ProcedureMaster pm WHERE pm.isDeleted != TRUE AND pm.procedureCode = :procedureCode")
    public ProcedureMaster getProcedureMasterByProcedureCode(@Param("procedureCode") String procedureCode);

    @Query("SELECT pm FROM ProcedureMaster pm WHERE pm.isDeleted != TRUE AND pm.procedureId = :procedureId")
    public ProcedureMaster getProcedureMasterByProcedureId(@Param("procedureId") String procedureId);

    @Query("SELECT pm FROM ProcedureMaster pm WHERE pm.isDeleted != TRUE AND pm.procedureCode != :procedureCode AND pm.procedureId = :procedureId")
    public ProcedureMaster getProcedureMasterByProcedureCodeAndProcedureId(@Param("procedureCode") String procedureCode, @Param("procedureId") String procedureId);
    
}
