/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.proceduremaster.dtob;

import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMaster;
import java.util.List;

/**
 *
 * @author amit.kumar
 */
public class ProcedureMasterResponse {
    
    private Integer id;
    private String procedureCode;
    private String procedureName;
    private String procedureDescription;
    private String procedureId;
    private String procedureIcon;
    private List<SkillMaster> skillMasterList;
    

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProcedureCode() {
        return procedureCode;
    }

    public void setProcedureCode(String procedureCode) {
        this.procedureCode = procedureCode;
    }

    public String getProcedureName() {
        return procedureName;
    }

    public void setProcedureName(String procedureName) {
        this.procedureName = procedureName;
    }

    public String getProcedureDescription() {
        return procedureDescription;
    }

    public void setProcedureDescription(String procedureDescription) {
        this.procedureDescription = procedureDescription;
    }

    public String getProcedureId() {
        return procedureId;
    }

    public void setProcedureId(String procedureId) {
        this.procedureId = procedureId;
    }

    public List<SkillMaster> getSkillMasterList() {
        return skillMasterList;
    }

    public void setSkillMasterList(List<SkillMaster> skillMasterList) {
        this.skillMasterList = skillMasterList;
    }

    public String getProcedureIcon() {
        return procedureIcon;
    }

    public void setProcedureIcon(String procedureIcon) {
        this.procedureIcon = procedureIcon;
    }

    
}
