/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.proceduremaster.service;

import com.gigflex.prototype.microservices.proceduremaster.dtob.ProcedureMasterRequest;
import java.util.List;

/**
 *
 * @author amit.kumar
 */
public interface ProcedureMasterService {

    public String findAllProcedureMaster();

    public String getAllProcedureMasterByPage(int page, int limit);

    public String findProcedureMasterById(Integer id);

    public String findByProcedureCode(String procedureCode);

    public String saveProcedureMaster(ProcedureMasterRequest procedureMasterReq, String ip);

    public String softDeleteProcedureMasterByProcedureCode(String procedureCode);

    public String softMultipleDeleteByProcedureCode(List<String> procedureCodeList);

    public String updateProcedureMasterByProcedureCode(String procedureCode, ProcedureMasterRequest procedureMasterReq, String ip);
    
}
