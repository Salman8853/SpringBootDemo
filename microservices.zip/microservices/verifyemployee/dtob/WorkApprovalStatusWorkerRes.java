package com.gigflex.prototype.microservices.verifyemployee.dtob;


import com.gigflex.prototype.microservices.worker.dtob.Worker;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author nirbhay.p
 */
public class WorkApprovalStatusWorkerRes {
    private Worker worker;
    private Long workApprovalStatusId;
private Boolean isApproved;
    public Worker getWorker() {
        return worker;
    }

    public void setWorker(Worker worker) {
        this.worker = worker;
    }

    public Long getWorkApprovalStatusId() {
        return workApprovalStatusId;
    }

    public void setWorkApprovalStatusId(Long workApprovalStatusId) {
        this.workApprovalStatusId = workApprovalStatusId;
    }

    public Boolean getIsApproved() {
        return isApproved;
    }

    public void setIsApproved(Boolean isApproved) {
        this.isApproved = isApproved;
    }

    
}
