/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.verifyemployee.dtob;

import com.gigflex.prototype.microservices.worker.dtob.Worker;
import java.util.List;

/**
 *
 * @author amit.kumar
 */
public class WorkApprovalStatusWorkerDetailResponse {
    
    
    
    private Worker worker;
    private Long workApprovalStatusId;
    private Boolean isApproved;
    private List<String> certificateCode;
    private List<String> certificateName;
    private List<String> skillCode;
    private List<String> skillName;

    public Worker getWorker() {
        return worker;
    }

    public void setWorker(Worker worker) {
        this.worker = worker;
    }

    public Long getWorkApprovalStatusId() {
        return workApprovalStatusId;
    }

    public void setWorkApprovalStatusId(Long workApprovalStatusId) {
        this.workApprovalStatusId = workApprovalStatusId;
    }

    public Boolean isIsApproved() {
        return isApproved;
    }

    public void setIsApproved(Boolean isApproved) {
        this.isApproved = isApproved;
    }

    public List<String> getCertificateCode() {
        return certificateCode;
    }

    public void setCertificateCode(List<String> certificateCode) {
        this.certificateCode = certificateCode;
    }

    public List<String> getCertificateName() {
        return certificateName;
    }

    public void setCertificateName(List<String> certificateName) {
        this.certificateName = certificateName;
    }

    public List<String> getSkillCode() {
        return skillCode;
    }

    public void setSkillCode(List<String> skillCode) {
        this.skillCode = skillCode;
    }

    public List<String> getSkillName() {
        return skillName;
    }

    public void setSkillName(List<String> skillName) {
        this.skillName = skillName;
    }
    
    
    
    
    
    
    
}
