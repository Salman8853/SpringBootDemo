/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.verifyemployee.dtob;

import java.util.List;

/**
 *
 * @author nirbhay.p
 */

public class MultipleWorkerApprovalStatusRequest{
   
    
   
    private List<WorkerApprovalStatusRequestList>  workerApprovalStatusRequestList;
   
    private String approvedByCode ;

    
    public String getApprovedByCode() {
        return approvedByCode;
    }

    public void setApprovedByCode(String approvedByCode) {
        this.approvedByCode = approvedByCode;
    }

    public List<WorkerApprovalStatusRequestList> getWorkerApprovalStatusRequestList() {
        return workerApprovalStatusRequestList;
    }

    public void setWorkerApprovalStatusRequestList(List<WorkerApprovalStatusRequestList> workerApprovalStatusRequestList) {
        this.workerApprovalStatusRequestList = workerApprovalStatusRequestList;
    }
     
    
    
}
