/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.verifyemployee.dtob;

import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.worker.dtob.WorkerRes;


/**
 *
 * @author nirbhay.p
 */
public class WorkerOrganizationResponse {
    private Organization organization;
    private WorkerRes workerRes;
    private WorkerApprovalStatus workerApprovalStatus;

    public Organization getOrganization() {
        return organization;
    }

    public void setOrganization(Organization organization) {
        this.organization = organization;
    }

    public WorkerRes getWorkerRes() {
        return workerRes;
    }

    public void setWorkerRes(WorkerRes workerRes) {
        this.workerRes = workerRes;
    }
    
    public WorkerApprovalStatus getWorkerApprovalStatus() {
        return workerApprovalStatus;
    }

    public void setWorkerApprovalStatus(WorkerApprovalStatus workerApprovalStatus) {
        this.workerApprovalStatus = workerApprovalStatus;
    }

    
    
}
