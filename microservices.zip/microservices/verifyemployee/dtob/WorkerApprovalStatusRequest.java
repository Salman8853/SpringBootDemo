/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.verifyemployee.dtob;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author nirbhay.p
 */

public class WorkerApprovalStatusRequest{
   
    @NotNull
    private Long id;
    @NotNull
    @Size(min=1, message="Worker Code should not empty.")
    private String workerCode ;
    @NotNull
    @Size(min=1, message="Organization Code should not empty.")
    private String organizationCode ;
    @NotNull
    private Boolean isApproved;
    @NotNull
    @Size(min=1, message="Approved By Code should not empty.")
    private String approvedByCode ;

    
    public String getApprovedByCode() {
        return approvedByCode;
    }

    public void setApprovedByCode(String approvedByCode) {
        this.approvedByCode = approvedByCode;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    
    
    
    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public Boolean getIsApproved() {
        return isApproved;
    }

    public void setIsApproved(Boolean isApproved) {
        this.isApproved = isApproved;
    }
     
    
}
