/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.verifyemployee.dtob;

/**
 *
 * @author nirbhay.p
 */

public class SingleWorkerApprovalStatusRequest{
   
    
   
    private String workerCode ;
    
    private String organizationCode ;
   
    private Boolean isApproved;
   
    private String approvedByCode ;

    
    public String getApprovedByCode() {
        return approvedByCode;
    }

    public void setApprovedByCode(String approvedByCode) {
        this.approvedByCode = approvedByCode;
    }
     
    
    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public Boolean getIsApproved() {
        return isApproved;
    }

    public void setIsApproved(Boolean isApproved) {
        this.isApproved = isApproved;
    }
     
    
}
