/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.verifyemployee.repository;

import com.gigflex.prototype.microservices.organization.dtob.Organization;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkerApprovalStatus;
import com.gigflex.prototype.microservices.worker.dtob.Worker;

/**
 *
 * @author nirbhay.p
 */
@Repository
public interface WorkerApprovalStatusRepository extends
		JpaRepository<WorkerApprovalStatus, Long> ,JpaSpecificationExecutor<WorkerApprovalStatus>{

	/**
	 *
	 * @param apprId
	 * @return
	 */
	// public WorkerApprovalStatus findById(Long id);
	
	
        @Query("SELECT w FROM WorkerApprovalStatus w  WHERE w.isDeleted != TRUE AND w.id != :id AND w.organization_Code=:organization_Code AND w.workerCode=:workerCode")
	public WorkerApprovalStatus getWASByWorkercodeAndOrgcodeNotID(@Param("id") Long id,@Param("organization_Code") String organization_Code,@Param("workerCode") String workerCode);
	
	@Query("SELECT was FROM WorkerApprovalStatus was WHERE was.isDeleted != TRUE AND was.organization_Code=:organizationCode")
	public List<WorkerApprovalStatus> findAllWorkerApprovalStatusByOrgCode(@Param("organizationCode") String organizationCode);
	
	@Query("SELECT was FROM WorkerApprovalStatus was WHERE was.isDeleted != TRUE AND was.workerCode=:workerCode AND was.organization_Code != :organizationCode")
	public List<WorkerApprovalStatus> findAllWASByWorkerAndOrgCode(@Param("workerCode") String workerCode , @Param("organizationCode") String organizationCode);
	
	@Query("SELECT was FROM WorkerApprovalStatus was, Worker w WHERE was.isDeleted != TRUE AND was.workerCode=w.workerCode AND w.workerCode=:workerCode")
	public WorkerApprovalStatus findWorkerApprovalStatusByWorkerCode(@Param("workerCode") String workerCode);
	
	@Query("SELECT a,b,c FROM WorkerApprovalStatus a , Organization c , Worker b, Users user WHERE a.isDeleted != TRUE AND user.isDeleted != TRUE AND user.userCode =a.workerCode AND user.isActive = TRUE AND user.isAdmin != TRUE AND user.isOwner != TRUE AND a.workerCode=b.workerCode AND a.organization_Code=c.organizationCode AND a.organization_Code=:organizationCode")
	public List<Object> getNameAndOrgName(
			@Param("organizationCode") String organizationCode);
	
	@Query("SELECT b,c FROM WorkerApprovalStatus a , Organization c , Worker b WHERE a.isDeleted != TRUE AND a.workerCode=b.workerCode AND a.organization_Code=c.organizationCode AND a.organization_Code=:organizationCode")
	public List<Object> getNameAndOrgName(
			@Param("organizationCode") String organizationCode,Pageable pageableRequest);

	@Query("SELECT a,b.name,c.organizationName FROM WorkerApprovalStatus a , Organization c , Worker b WHERE a.workerCode=b.workerCode AND a.isDeleted != TRUE AND a.organization_Code=c.organizationCode")
	public List<Object> getAllWorkerApprovalStatus();
	
	@Query("SELECT a,b.name,c.organizationName FROM WorkerApprovalStatus a , Organization c , Worker b WHERE a.workerCode=b.workerCode AND a.isDeleted != TRUE AND a.organization_Code=c.organizationCode")
	public List<Object> getAllWorkerApprovalStatus(Pageable pageableRequest);

	@Query("SELECT b,a.id,a.isApproved FROM WorkerApprovalStatus a , Organization c , Worker b WHERE a.isDeleted != TRUE AND a.workerCode=b.workerCode AND  a.organization_Code=:organizationCode AND a.organization_Code=c.organizationCode AND a.isApproved<>TRUE")
	public List<Object> getPendingWorkerForApproval(
			@Param("organizationCode") String organizationCode);
	
        @Query("SELECT b,a.id,a.isApproved FROM WorkerApprovalStatus a , Organization c , Worker b WHERE a.isDeleted != TRUE AND a.workerCode=b.workerCode  AND a.organization_Code=:organizationCode AND a.organization_Code=c.organizationCode")
	public List<Object> getWorkApprovalStatusByOrganizationCode(
			@Param("organizationCode") String organizationCode);
        
	@Query("SELECT b FROM WorkerApprovalStatus a , Organization c , Worker b WHERE a.isDeleted != TRUE AND a.workerCode=b.workerCode AND a.organization_Code=c.organizationCode AND a.organization_Code=:organizationCode AND a.isApproved<>TRUE")
	public List<Worker> getPendingWorkerForApproval(
			@Param("organizationCode") String organizationCode,Pageable pageableRequest);
	
	@Query("SELECT os FROM WorkerApprovalStatus os WHERE os.isDeleted != TRUE")
	public List<WorkerApprovalStatus> findAllWorkerApprovalStatus();
	
	@Query("SELECT os FROM WorkerApprovalStatus os WHERE os.isDeleted != TRUE")
	public List<WorkerApprovalStatus> findAllWorkerApprovalStatus(Pageable pageableRequest);

	@Query("SELECT os FROM WorkerApprovalStatus os WHERE os.isDeleted != TRUE AND os.id = :id")
	public WorkerApprovalStatus getWorkerApprovalStatusById(@Param("id") Long id);
        
    @Query("SELECT osa FROM WorkerApprovalStatus osa WHERE osa.isDeleted != TRUE AND osa.workerCode=:workerCode AND osa.organization_Code=:organizationCode")
	public WorkerApprovalStatus getWorkerApprovalStatusByWorkerCodeOrgCode(@Param("workerCode") String workerCode,@Param("organizationCode") String organizationCode);
        
         @Query("SELECT a,b.name,c.organizationName FROM WorkerApprovalStatus a , Organization c , Worker b WHERE a.isDeleted != TRUE AND a.workerCode=b.workerCode AND a.organization_Code=c.organizationCode AND a.workerCode = :workerCode")
    public List<Object> getWASByWorkerCode(@Param("workerCode") String workerCode);

    @Query("SELECT b,a.id,a.isApproved, a.workerCode FROM WorkerApprovalStatus a , Organization c , Worker b WHERE a.isDeleted != TRUE AND a.workerCode=b.workerCode  AND a.organization_Code=:organizationCode AND a.organization_Code=c.organizationCode")
    public List<Object> getWorkApprovalStatusDetailByOrganizationCode(@Param("organizationCode") String organizationCode);
  
    
    @Query("SELECT b FROM WorkerApprovalStatus a , Organization c , Worker b WHERE a.isDeleted != TRUE AND a.workerCode=b.workerCode AND a.organization_Code=c.organizationCode AND a.organization_Code=:organizationCode AND a.isApproved=TRUE")
    public List<Worker> getAllApprovedWorkerByOrgCode(@Param("organizationCode") String organizationCode);
    
    @Query("SELECT b FROM WorkerApprovalStatus a , Organization c , Worker b,Users u  WHERE a.isDeleted != TRUE AND a.workerCode=b.workerCode AND a.organization_Code=c.organizationCode AND a.organization_Code=:organizationCode AND a.isApproved=TRUE AND u.userCode=b.workerCode AND u.isAdmin!=TRUE AND u.isOwner!=TRUE ORDER BY b.name")
    public List<Worker> getAllApprovedWorkerOnlyByOrgCode(@Param("organizationCode") String organizationCode);
    
    @Query("SELECT b FROM WorkerApprovalStatus a , Organization c , Worker b,Users u  WHERE a.isDeleted != TRUE AND a.workerCode=b.workerCode AND a.organization_Code=c.organizationCode AND a.organization_Code=:organizationCode AND a.isApproved=TRUE AND u.userCode=b.workerCode AND u.isAdmin!=TRUE AND u.isOwner!=TRUE ORDER BY b.name")
    public List<Worker> getAllApprovedWorkerOnlyByOrgCode(@Param("organizationCode") String organizationCode,Pageable pageableRequest);
    
    @Query("SELECT c FROM WorkerApprovalStatus a , Organization c , Worker b WHERE a.isDeleted != TRUE AND a.workerCode=b.workerCode AND a.organization_Code=c.organizationCode AND a.workerCode=:workerCode AND a.isApproved=TRUE")
    public List<Organization> getAllOrganizationByWorkerCode(@Param("workerCode") String workerCode);
    
    @Query("SELECT c.organization_Code FROM  WorkerApprovalStatus c WHERE c.isDeleted != TRUE AND c.workerCode=:workerCode")
    public List<String> getAllOrganizationCodeByWorkerCode(@Param("workerCode") String workerCode);
    
     @Query("SELECT c.organization_Code FROM  WorkerApprovalStatus c WHERE c.isDeleted != TRUE AND c.workerCode=:userCode")
    public String getOrganizationCodeByuserCode(@Param("userCode") String userCode);
    
    
    //@Query("SELECT a.workerCode FROM WorkerApprovalStatus a  WHERE a.isDeleted != TRUE  AND a.organization_Code=:organizationCode AND a.isApproved=TRUE")
    @Query("SELECT b.workerCode FROM WorkerApprovalStatus a , Organization c , Worker b,Users u  WHERE a.isDeleted != TRUE AND a.workerCode=b.workerCode AND a.organization_Code=c.organizationCode AND a.organization_Code=:organizationCode AND a.isApproved=TRUE AND u.userCode=b.workerCode AND u.isAdmin!=TRUE AND u.isOwner!=TRUE")
    public List<String> getAllApprovedWorkerCodesByOrgCode(@Param("organizationCode") String organizationCode);
    
//    @Query("SELECT osa FROM WorkerApprovalStatus osa ,Worker worker WHERE osa.isDeleted != TRUE AND worker.isDeleted != TRUE AND osa.organization_Code=:organizationCode")
//    public List<WorkerApprovalStatus> getWorkerApprovalStatusByOrgCode(@Param("organizationCode") String organizationCode);
        
}
