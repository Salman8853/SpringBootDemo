/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.verifyemployee.service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.users.dtob.Users;
import com.gigflex.prototype.microservices.users.repository.UserRepository;
import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkerApprovalStatus;
import com.gigflex.prototype.microservices.verifyemployee.repository.WorkerApprovalStatusRepository;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.worker.repository.WorkerRepository;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

/**
 *
 * @author nirbhay.p
 */
@Service
public class KafkaWASUpdateFromRegistration {
    private Worker worker;

	@Autowired
	WorkerApprovalStatusRepository wasDao;
    
    private static final Logger LOG = LoggerFactory.getLogger(KafkaWASUpdateFromRegistration.class);

    @KafkaListener(topics = "UpdateWorkerApprovalStatusFromRegistration")
    public void listen(@Payload String message) {
		ObjectMapper objectMapper = new ObjectMapper();
		LOG.info("received message='{}'", message);
		try {
			WorkerApprovalStatus was = objectMapper.readValue(message, WorkerApprovalStatus.class);
			
			LOG.info("received message='{}'", was.getApprovedByCode());
			LOG.info("received message='{}'", was.getApprovedDate());
			LOG.info("received message='{}'", was.getOrganization_Code());

			
                        
			WorkerApprovalStatus wasRes = wasDao.getWorkerApprovalStatusByWorkerCodeOrgCode(was.getWorkerCode(),was.getOrganization_Code());
            

			if (wasRes != null && wasRes.getId() > 0) {
				wasRes.setApprovedByCode(was.getApprovedByCode());
                wasRes.setApprovedDate(was.getApprovedDate());
                wasRes.setIpAddress(was.getIpAddress());
                wasRes.setIsDeleted(was.getIsDeleted());
                wasRes.setIsApproved(was.getIsApproved());
                wasRes.setColor(was.getColor());
                wasDao.save(wasRes);
			}
		} catch (JsonParseException e) {
			LOG.error("In KafkaWASUpdateFromRegistration >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In KafkaWASUpdateFromRegistration >>>>", e);
		} catch (IOException e) {
			LOG.error("In KafkaWASUpdateFromRegistration >>>>", e);
		}catch (Exception e) {
			LOG.error("In KafkaWASUpdateFromRegistration >>>>", e);
		}
    }
}
