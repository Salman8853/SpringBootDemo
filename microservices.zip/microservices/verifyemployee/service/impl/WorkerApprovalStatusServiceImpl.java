/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.verifyemployee.service.impl;

import java.net.URLEncoder;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.certificationsmaster.dtob.CertificationsMaster;
import com.gigflex.prototype.microservices.employmenttype.dtob.EmploymentType;
import com.gigflex.prototype.microservices.employmenttype.repository.EmploymentTypeRepository;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.organizationworkerskill.repository.OrgWorkerSkillDao;
import com.gigflex.prototype.microservices.users.dtob.Users;
import com.gigflex.prototype.microservices.users.repository.UserRepository;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.verifyemployee.dtob.MultipleWorkerApprovalStatusRequest;
import com.gigflex.prototype.microservices.verifyemployee.dtob.SingleWorkerApprovalStatusRequest;
import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkApprovalStatusWorkerRes;
import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkerApprovalStatus;
import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkerApprovalStatusRequest;
import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkerApprovalStatusRequestList;
import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkerApprovalStatusRequestSave;
import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkerOrganizationNameResponse;
import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkerOrganizationResponse;
import com.gigflex.prototype.microservices.verifyemployee.repository.WorkerApprovalStatusRepository;
import com.gigflex.prototype.microservices.verifyemployee.search.WorkerApprovalStatusSpecificationsBuilder;
import com.gigflex.prototype.microservices.verifyemployee.service.WorkerApprovalStatusService;
import com.gigflex.prototype.microservices.verifyemployee.dtob.WASWorkerNameOrganizationNameResponse;
import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkApprovalStatusWorkerDetailResponse;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.worker.dtob.WorkerRes;
import com.gigflex.prototype.microservices.worker.repository.WorkerRepository;
import com.gigflex.prototype.microservices.workercertifications.dtob.WorkerCertifications;
import com.gigflex.prototype.microservices.workercertifications.repository.WorkerCertificationsRepository;

/**
 *
 * @author nirbhay.p
 */

@Service
public class WorkerApprovalStatusServiceImpl implements
		WorkerApprovalStatusService {
	@Autowired
	WorkerApprovalStatusRepository approvalStatusRepository;


	@Autowired
	UserRepository regDao;

	@Value("${email.verifyworkernotification.subject}")
	private String subject;

	@Value("${email.service.url}")
	private String mailServiceURL;

	@Autowired
	WorkerRepository workerDao;

	@Autowired
	OrganizationRepository orgDao;
        
        @Autowired
	private WorkerCertificationsRepository workerCertificationsRepository;
        
        @Autowired
        OrgWorkerSkillDao orgWorkerSkillDao;
        
        @Autowired
        EmploymentTypeRepository empTypeDao;

	@Override
	public WorkerApprovalStatus saveInWorkerApprovalStatus(
			WorkerApprovalStatus workerApprovalStatus) {
		WorkerApprovalStatus resp = approvalStatusRepository
				.save(workerApprovalStatus);
		return resp;
	}

	@Override
	public String verifyEmployeeStatus(
			WorkerApprovalStatusRequest approvalStatusRequest, String ip) {

		try {
			Optional<WorkerApprovalStatus> approvalStatuslst = approvalStatusRepository
					.findById(approvalStatusRequest.getId());
			if (approvalStatuslst.isPresent()
					&& approvalStatuslst.get() != null) {
				WorkerApprovalStatus approvalStatus = approvalStatuslst.get();
				if (approvalStatus.getWorkerCode().equalsIgnoreCase(
						approvalStatusRequest.getWorkerCode())
						&& approvalStatus.getOrganization_Code()
								.equalsIgnoreCase(
										approvalStatusRequest
												.getOrganizationCode())) {
					approvalStatus.setIsApproved(approvalStatusRequest
							.getIsApproved());
					approvalStatus.setApprovedByCode(approvalStatusRequest
							.getApprovedByCode());
					approvalStatus.setUpdatedAt(new Timestamp(new Date()
							.getTime()));

					approvalStatus.setApprovedDate(new Date());
					approvalStatus.setIpAddress(ip);
					WorkerApprovalStatus approvalStatusresp = approvalStatusRepository
							.save(approvalStatus);
					if (approvalStatusresp != null
							&& approvalStatusresp.getId().equals(
									approvalStatusRequest.getId())) {
//						kafkaService.sendUpdateWAS(approvalStatusresp);
						GigflexResponse derr = new GigflexResponse(200,
								new Date(), "Employee verification is done.");
						return derr.toString();
					} else {
						GigflexResponse derr = new GigflexResponse(400,
								new Date(), "Employee verification is failed.");
						return derr.toString();
					}
				} else {
					GigflexResponse derr = new GigflexResponse(400, new Date(),
							"Input data is mismatched.");
					return derr.toString();
				}
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"ID does not exist.");
				return derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			return derr.toString();
		}

	}

	@Override
	public String getAllWAS() {

		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<WorkerApprovalStatus> wklst = approvalStatusRepository
					.findAllWorkerApprovalStatus();

			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (wklst != null && wklst.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(wklst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("message", "No data found.");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getWASByID(Long id) {

		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			WorkerApprovalStatus wklst = approvalStatusRepository
					.getWorkerApprovalStatusById(id);
			if (wklst != null && wklst.getId() > 0) {
				WorkerApprovalStatus wk = wklst;
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				if (wk != null) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(wk);
					jsonobj.put("data", new JSONObject(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String deleteWASById(Long id) {

		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Optional<WorkerApprovalStatus> wklst = approvalStatusRepository
					.findById(id);
			if (wklst.isPresent() && wklst.get() != null) {
				approvalStatusRepository.deleteById(id);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "WorkApprovalStatus has been deleted.");
//				kafkaService.sendDeleteWAS(wklst.get());
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record not found.");
			}
			jsonobj.put("timestamp", new Date());
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;

	}

	@Override
	public String createWAS(WorkerApprovalStatus was) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			WorkerApprovalStatus wlres = approvalStatusRepository
					.getWorkerApprovalStatusByWorkerCodeOrgCode(
							was.getWorkerCode(), was.getOrganization_Code());
			if (wlres != null && wlres.getId() > 0) {
				jsonobj.put("responsecode", 409);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record is already exist.");
			} else {
				WorkerApprovalStatus wl = approvalStatusRepository.save(was);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				if (wl != null && wl.getId() > 0) {
					jsonobj.put("message",
							"WorkApprovalStatus has been added successfully.");
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(wl);
					jsonobj.put("data", new JSONObject(Detail));
//					kafkaService.sendAddWAS(wl);
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Failed");
				}
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String updateWAS(WorkerApprovalStatus was, Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (id > 0 && was != null) {
				WorkerApprovalStatus wlres = approvalStatusRepository
						.getWASByWorkercodeAndOrgcodeNotID(id,
								was.getOrganization_Code(), was.getWorkerCode());

				if (wlres != null && wlres.getId() > 0) {
					jsonobj.put("responsecode", 409);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message",
							"Mapping of worker with organization should be unique.");
				} else {
					WorkerApprovalStatus wklst = approvalStatusRepository
							.getWorkerApprovalStatusById(id);
					if (wklst != null && wklst.getId() > 0) {
						WorkerApprovalStatus wasdb = wklst;
						wasdb.setApprovedByCode(was.getApprovedByCode());
						wasdb.setApprovedDate(was.getApprovedDate());
						wasdb.setIpAddress(was.getIpAddress());
						wasdb.setIsApproved(was.getIsApproved());
						wasdb.setOrganization_Code(was.getOrganization_Code());
						wasdb.setWorkerCode(was.getWorkerCode());
                                                wasdb.setColor(was.getColor());
						WorkerApprovalStatus wl = approvalStatusRepository
								.save(wasdb);

						if (wl != null && wl.getId() > 0) {
							jsonobj.put("responsecode", 200);
                                                        if(was.getIsApproved())
                                                        {
							jsonobj.put("message","This worker has been approved.");
                                                        }
                                                        else
                                                        {
                                                         jsonobj.put("message","This worker has been disapproved.");   
                                                        }
							jsonobj.put("timestamp", new Date());
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj.writeValueAsString(wl);
							jsonobj.put("data", new JSONObject(Detail));
//							kafkaService.sendUpdateWAS(wl);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message",
									"WorkApprovalStatus updation has been failed.");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "ID is not valid.");
						jsonobj.put("timestamp", new Date());
					}
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;

	}

	@Override
	public String getAllWorkerApprovalStatus() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			// if(organizationCode!=null && organizationCode.length()>0)
			// {
			List<Object> objlst = approvalStatusRepository
					.getAllWorkerApprovalStatus();
			List<WorkerOrganizationNameResponse> wolst = new ArrayList<WorkerOrganizationNameResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 3) {
						WorkerOrganizationNameResponse wo = new WorkerOrganizationNameResponse();

						WorkerApprovalStatus was = (WorkerApprovalStatus) arr[0];
						wo.setId(was.getId());
						wo.setOrganization_Code(was.getOrganization_Code());
						wo.setWorkerCode(was.getWorkerCode());
						wo.setIsApproved(was.getIsApproved());
						wo.setApprovedByCode(was.getApprovedByCode());
						wo.setApprovedDate(was.getApprovedDate());
                                                wo.setColor(was.getColor());
						wo.setWorkerName((String) arr[1]);
						wo.setOrganizationName((String) arr[2]);

						wolst.add(wo);
					}

				}

				if (wolst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(wolst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			// }
			// else {
			// jsonobj.put("responsecode", 400);
			// jsonobj.put("message", "Input data is not valid.");
			// jsonobj.put("timestamp", new Date());
			// }
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getWorkerAndOrganization(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (organizationCode != null
					&& organizationCode.trim().length() > 0) {
				List<Object> objlst = approvalStatusRepository
						.getNameAndOrgName(organizationCode);
				List<WorkerOrganizationResponse> wolst = new ArrayList<WorkerOrganizationResponse>();
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 3) {
							WorkerOrganizationResponse wo = new WorkerOrganizationResponse();
							wo.setWorkerApprovalStatus((WorkerApprovalStatus) arr[0]);
                                                       
                                                        Worker worker = (Worker) arr[1];
                                                        WorkerRes wRes= new WorkerRes();
                                                        wRes.setAddress1(worker.getAddress1());
                                                        wRes.setAddress2(worker.getAddress2());
                                                        wRes.setCity(worker.getCity());
                                                        wRes.setCountry(worker.getCountry());
                                                        wRes.setDepartmentCode(worker.getDepartmentCode());
                                                        wRes.setDesignation(worker.getDesignation());
                                                        wRes.setDistance(worker.getDistance());
                                                        wRes.setDob(worker.getDob());
                                                        wRes.setEmail(worker.getEmail());
                                                        wRes.setEmploymentTypeCode(worker.getEmploymentTypeCode());
                                                        
                                                        String empTypeName = "";
                                                        if(worker.getEmploymentTypeCode() != null)
                                                        {
                                                           EmploymentType empType =  empTypeDao.getEmploymentTypeByCode(worker.getEmploymentTypeCode());
                                                           if(empType != null && empType.getId() > 0)
                                                           {
                                                               empTypeName = empType.getEmploymentTypeName();
                                                           }
                                                        }
                                                        
                                                        wRes.setEmploymentTypeName(empTypeName);
                                                        wRes.setExpDays(worker.getExpDays());
                                                        wRes.setExpMonth(worker.getExpMonth());
                                                        wRes.setExpYear(worker.getExpYear());
                                                        wRes.setExternalEmpCode(worker.getExternalEmpCode());
                                                        wRes.setHome_phone(worker.getHome_phone());
                                                        wRes.setHomecountryCode(worker.getHomecountryCode());
                                                        wRes.setId(worker.getId());
                                                        wRes.setIsActive(worker.getIsActive());
                                                        wRes.setLanguage(worker.getLanguage());
                                                        wRes.setLatitude(worker.getLatitude());
                                                        wRes.setLongitude(worker.getLongitude());
                                                        wRes.setName(worker.getName());
                                                        wRes.setPhone(worker.getPhone());
                                                        wRes.setPreWorkingHours(worker.getPreWorkingHours());
                                                        wRes.setQualification(worker.getQualification());
                                                        wRes.setState(worker.getState());
                                                        wRes.setWork_phone(worker.getWork_phone());
                                                        wRes.setWorkcountryCode(worker.getWorkcountryCode());
                                                        wRes.setWorkerCode(worker.getWorkerCode());
                                                        wRes.setWorkerLogo(worker.getWorkerLogo());
                                                        wRes.setWorkerStatusCode(worker.getWorkerStatusCode());
                                                        wRes.setZipcode(worker.getZipcode());
                                                        
                                                        wo.setWorkerRes(wRes);
							wo.setOrganization((Organization) arr[2]);
                                                         
							wolst.add(wo);
						}

					}

					if (wolst.size() > 0) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(wolst);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("workercount", wolst.size());
						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getPendingWorkerForApproval(String organizationCode) {
		String res = "";
		try {

			JSONObject jsonobj = new JSONObject();
			JSONArray jarr = new JSONArray();
			if (organizationCode != null
					&& organizationCode.trim().length() > 0) {
				List<WorkApprovalStatusWorkerRes> wasreslst = new ArrayList<WorkApprovalStatusWorkerRes>();
				List<Object> objlst = approvalStatusRepository
						.getPendingWorkerForApproval(organizationCode.trim());
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 3) {
							WorkApprovalStatusWorkerRes wres = new WorkApprovalStatusWorkerRes();
							wres.setWorkApprovalStatusId((Long) arr[1]);
							Boolean st = (Boolean) arr[2];
							if (st != null) {
								wres.setIsApproved(st);
							} else {
								wres.setIsApproved(Boolean.FALSE);
							}
							wres.setWorker((Worker) arr[0]);
							wasreslst.add(wres);

						}
					}
					if (wasreslst != null && wasreslst.size() > 0) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(wasreslst);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("workercount", wasreslst.size());
						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String softDeleteWASById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			WorkerApprovalStatus was = approvalStatusRepository
					.getWorkerApprovalStatusById(id);

			if (was != null && was.getId() > 0) {
				was.setIsDeleted(true);
				WorkerApprovalStatus wasRes = approvalStatusRepository
						.save(was);
				if (wasRes != null && wasRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());

					jsonobj.put("message",
							"Worker Approval Status deleted successfully.");

//					kafkaService.sendUpdateWAS(wasRes);
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteById(List<Long> idList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (Long id : idList) {
				if (id != null && id > 0) {
					JSONObject jsonobj = new JSONObject();

					WorkerApprovalStatus was = approvalStatusRepository
							.getWorkerApprovalStatusById(id);

					if (was != null && was.getId() > 0) {

						was.setIsDeleted(true);
						WorkerApprovalStatus wasRes = approvalStatusRepository
								.save(was);
						if (wasRes != null && wasRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("Id", id);
							jsonobj.put("message",
									"Worker Approval Status deleted successfully.");
//							kafkaService.sendUpdateWAS(wasRes);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("Id", id);
							jsonobj.put("message", "Failed");
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("Id", id);
						jsonobj.put("message", "Record Not Found");
					}

					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String verifySingleEmployee(
			SingleWorkerApprovalStatusRequest approvalStatusRequest, String ip) {
		String res = "";
		String mailRes = "false";
		try {
			if (approvalStatusRequest != null
					&& approvalStatusRequest.getApprovedByCode() != null
					&& approvalStatusRequest.getApprovedByCode().trim()
							.length() > 0
					&& approvalStatusRequest.getOrganizationCode() != null
					&& approvalStatusRequest.getOrganizationCode().trim()
							.length() > 0
					&& approvalStatusRequest.getWorkerCode() != null
					&& approvalStatusRequest.getWorkerCode().trim().length() > 0
					&& approvalStatusRequest.getIsApproved() != null) {
				WorkerApprovalStatus approvalStatus = approvalStatusRepository
						.getWorkerApprovalStatusByWorkerCodeOrgCode(
								approvalStatusRequest.getWorkerCode(),
								approvalStatusRequest.getOrganizationCode());
				if (approvalStatus != null && approvalStatus.getId() > 0) {
					approvalStatus.setIsApproved(approvalStatusRequest
							.getIsApproved());
					approvalStatus.setApprovedByCode(approvalStatusRequest
							.getApprovedByCode());
					approvalStatus.setApprovedDate(new Date());
					approvalStatus.setIpAddress(ip);
					WorkerApprovalStatus approvalStatusresp = approvalStatusRepository
							.save(approvalStatus);
					if (approvalStatusresp != null
							&& approvalStatusresp.getId() > 0) {
//						kafkaService.sendUpdateWAS(approvalStatusresp);
						try {
							Users user = regDao.findByUserCode(approvalStatus
									.getWorkerCode());
							if (user != null && user.getEmail() != null
									&& user.getEmail().length() > 0) {
								user.getEmail();
								String bodyContent = null;
								if (approvalStatus.getIsDeleted() == true) {
									bodyContent = "Dear worker, <br><br>You are approved.</br>";
								} else {
									bodyContent = "Dear worker, <br><b>You are Rejected.</br>";
								}
								String encodeURL = URLEncoder.encode(
										bodyContent, "UTF-8");
								Map<String, String> map = new HashMap<>();
								map.put("to", user.getEmail());
								map.put("subject", subject);
								map.put("body", encodeURL);
								try {
									RestTemplate restTemplate = new RestTemplate();
									ResponseEntity<String> response = restTemplate
											.getForEntity(mailServiceURL,
													String.class, map);
									mailRes = response.getBody();

								} catch (Exception ex) {
									ex.printStackTrace();

								}
							}
						} catch (Exception ex) {
							ex.printStackTrace();

						}
						GigflexResponse derr = new GigflexResponse(200,
								new Date(), "Employee verification is done.");
						res = derr.toString();
					} else {
						GigflexResponse derr = new GigflexResponse(400,
								new Date(), "Employee verification is failed.");
						res = derr.toString();
					}
				} else {
					GigflexResponse derr = new GigflexResponse(400, new Date(),
							"Record does not exist.");
					res = derr.toString();
				}
			} else {
				GigflexResponse derr = new GigflexResponse(
						400,
						new Date(),
						"ApprovedByCode, OrganizationCode, WorkerCode and Approval status should not be blank.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String verifyMultipleEmployee(
			MultipleWorkerApprovalStatusRequest approvalStatusRequest, String ip) {
		String res = "";
		String mailRes = "false";
		try {
			JSONArray jarr = new JSONArray();
			for (WorkerApprovalStatusRequestList wlst : approvalStatusRequest
					.getWorkerApprovalStatusRequestList()) {
				JSONObject jsonobj = new JSONObject();
				if (approvalStatusRequest != null
						&& approvalStatusRequest
								.getWorkerApprovalStatusRequestList().size() > 0
						&& approvalStatusRequest.getApprovedByCode().trim()
								.length() > 0
						&& wlst.getOrganizationCode() != null
						&& wlst.getOrganizationCode().trim().length() > 0
						&& wlst.getWorkerCode() != null
						&& wlst.getWorkerCode().trim().length() > 0
						&& wlst.getIsApproved() != null) {
					WorkerApprovalStatus approvalStatus = approvalStatusRepository
							.getWorkerApprovalStatusByWorkerCodeOrgCode(
									wlst.getWorkerCode(),
									wlst.getOrganizationCode());
					if (approvalStatus != null && approvalStatus.getId() > 0) {
						approvalStatus.setIsApproved(wlst.getIsApproved());
						approvalStatus.setApprovedByCode(approvalStatusRequest
								.getApprovedByCode());
						approvalStatus.setApprovedDate(new Date());
						approvalStatus.setIpAddress(ip);
						WorkerApprovalStatus approvalStatusresp = approvalStatusRepository
								.save(approvalStatus);
						if (approvalStatusresp != null
								&& approvalStatusresp.getId() > 0) {
//							kafkaService.sendUpdateWAS(approvalStatusresp);
							try {
								Users user = regDao
										.findByUserCode(approvalStatus
												.getWorkerCode());
								if (user != null && user.getEmail() != null
										&& user.getEmail().length() > 0) {
									user.getEmail();
									String bodyContent = null;
									if (approvalStatus.getIsDeleted() == true) {
										bodyContent = "Dear worker, <br><br>You are approved.</br>";
									} else {
										bodyContent = "Dear worker, <br><b>You are Rejected.</br>";
									}
									String encodeURL = URLEncoder.encode(
											bodyContent, "UTF-8");
									Map<String, String> map = new HashMap<>();
									map.put("to", user.getEmail());
									map.put("subject", subject);
									map.put("body", encodeURL);
									try {
										RestTemplate restTemplate = new RestTemplate();
										ResponseEntity<String> response = restTemplate
												.getForEntity(mailServiceURL,
														String.class, map);
										mailRes = response.getBody();

									} catch (Exception ex) {
										ex.printStackTrace();

									}
								}
							} catch (Exception ex) {
								ex.printStackTrace();

							}
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("workerCode", wlst.getWorkerCode());
							jsonobj.put("organizationCode",
									wlst.getOrganizationCode());
							jsonobj.put("message",
									"Employee verification is done.");
							jarr.add(jsonobj);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("workerCode", wlst.getWorkerCode());
							jsonobj.put("organizationCode",
									wlst.getOrganizationCode());
							jsonobj.put("message",
									"Employee verification is failed.");
							jarr.add(jsonobj);
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("workerCode", wlst.getWorkerCode());
						jsonobj.put("organizationCode",
								wlst.getOrganizationCode());
						jsonobj.put("message", "Record does not exist.");
						jarr.add(jsonobj);
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("workerCode", wlst.getWorkerCode());
					jsonobj.put("organizationCode", wlst.getOrganizationCode());
					jsonobj.put(
							"message",
							"ApprovedByCode, OrganizationCode, WorkerCode and Approval status should not be blank.");
					jarr.add(jsonobj);
				}
			}
			res = jarr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getWorkerAndOrganization(String organizationCode, int page,
			int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			if (organizationCode != null
					&& organizationCode.trim().length() > 0) {
				List<Object> objlst = approvalStatusRepository
						.getNameAndOrgName(organizationCode, pageableRequest);
				List<WorkerOrganizationResponse> wolst = new ArrayList<WorkerOrganizationResponse>();
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 2) {
							WorkerOrganizationResponse wo = new WorkerOrganizationResponse();
							
                                                        Worker worker = (Worker) arr[0];
                                                        WorkerRes wRes= new WorkerRes();
                                                        wRes.setAddress1(worker.getAddress1());
                                                        wRes.setAddress2(worker.getAddress2());
                                                        wRes.setCity(worker.getCity());
                                                        wRes.setCountry(worker.getCountry());
                                                        wRes.setDepartmentCode(worker.getDepartmentCode());
                                                        wRes.setDesignation(worker.getDesignation());
                                                        wRes.setDistance(worker.getDistance());
                                                        wRes.setDob(worker.getDob());
                                                        wRes.setEmail(worker.getEmail());
                                                        wRes.setEmploymentTypeCode(worker.getEmploymentTypeCode());
                                                        
                                                        String empTypeName = "";
                                                        if(worker.getEmploymentTypeCode() != null)
                                                        {
                                                           EmploymentType empType =  empTypeDao.getEmploymentTypeByCode(worker.getEmploymentTypeCode());
                                                           if(empType != null && empType.getId() > 0)
                                                           {
                                                               empTypeName = empType.getEmploymentTypeName();
                                                           }
                                                        }
                                                        
                                                        wRes.setEmploymentTypeName(empTypeName);
                                                        wRes.setExpDays(worker.getExpDays());
                                                        wRes.setExpMonth(worker.getExpMonth());
                                                        wRes.setExpYear(worker.getExpYear());
                                                        wRes.setExternalEmpCode(worker.getExternalEmpCode());
                                                        wRes.setHome_phone(worker.getHome_phone());
                                                        wRes.setHomecountryCode(worker.getHomecountryCode());
                                                        wRes.setId(worker.getId());
                                                        wRes.setIsActive(worker.getIsActive());
                                                        wRes.setLanguage(worker.getLanguage());
                                                        wRes.setLatitude(worker.getLatitude());
                                                        wRes.setLongitude(worker.getLongitude());
                                                        wRes.setName(worker.getName());
                                                        wRes.setPhone(worker.getPhone());
                                                        wRes.setPreWorkingHours(worker.getPreWorkingHours());
                                                        wRes.setQualification(worker.getQualification());
                                                        wRes.setState(worker.getState());
                                                        wRes.setWork_phone(worker.getWork_phone());
                                                        wRes.setWorkcountryCode(worker.getWorkcountryCode());
                                                        wRes.setWorkerCode(worker.getWorkerCode());
                                                        wRes.setWorkerLogo(worker.getWorkerLogo());
                                                        wRes.setWorkerStatusCode(worker.getWorkerStatusCode());
                                                        wRes.setZipcode(worker.getZipcode());
                                                        
                                                        wo.setWorkerRes(wRes);
							wo.setOrganization((Organization) arr[1]);
							wolst.add(wo);
						}

					}

					if (wolst.size() > 0) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(wolst);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("workercount", wolst.size());
						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getPendingWorkerForApproval(String organizationCode,
			int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			if (organizationCode != null
					&& organizationCode.trim().length() > 0) {
				List<Worker> objlst = approvalStatusRepository
						.getPendingWorkerForApproval(organizationCode,
								pageableRequest);
				if (objlst != null && objlst.size() > 0) {

					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(objlst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("workercount", objlst.size());
					jsonobj.put("data", new JSONArray(Detail));

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String verifyWorker(String organization_Code, String workerCode,
			String approvedByCode, Boolean isApproved) {
		String res = "";
		String mailRes = "false";
		try {
			if (organization_Code != null && workerCode != null
					&& approvedByCode != null && isApproved != null) {
				WorkerApprovalStatus approvalStatus = approvalStatusRepository
						.getWorkerApprovalStatusByWorkerCodeOrgCode(workerCode,
								organization_Code);
				if (approvalStatus != null && approvalStatus.getId() > 0) {
					approvalStatus.setOrganization_Code(organization_Code);
					approvalStatus.setWorkerCode(workerCode);
					approvalStatus.setApprovedByCode(approvedByCode);
					approvalStatus.setApprovedDate(new Date());

					approvalStatus.setIsApproved(isApproved);

					WorkerApprovalStatus approvalStatusresp = approvalStatusRepository
							.save(approvalStatus);
					if (approvalStatusresp != null
							&& approvalStatusresp.getId() > 0) {
//						kafkaService.sendUpdateWAS(approvalStatusresp);
						try {
							Users user = regDao.findByUserCode(workerCode);
							if (user != null && user.getEmail() != null
									&& user.getEmail().length() > 0) {
								user.getEmail();
								String bodyContent = null;
								if (isApproved == true) {
									bodyContent = "Dear worker, <br><br>You are approved.</br>";
								} else {
									bodyContent = "Dear worker, <br><b>You are Rejected.</br>";
								}

								String encodeURL = URLEncoder.encode(
										bodyContent, "UTF-8");
								Map<String, String> map = new HashMap<>();
								map.put("to", user.getEmail());
								map.put("subject", subject);
								map.put("body", encodeURL);
								try {
									RestTemplate restTemplate = new RestTemplate();
									ResponseEntity<String> response = restTemplate
											.getForEntity(mailServiceURL,
													String.class, map);
									mailRes = response.getBody();

								} catch (Exception ex) {
									ex.printStackTrace();

								}
							}
						} catch (Exception ex) {
							ex.printStackTrace();

						}
						if (isApproved == true) {
							res = "Worker verification is done. Worker has been approved";
						} else {
							res = "Worker verification is done. Worker has been disapproved.";
						}
					} else {
						res = "Worker verification is failed.";
					}
				} else {
					res = "Record does not exist.";
				}

			} else {
				res = "ApprovedByCode, OrganizationCode, WorkerCode and Approval status should not be blank.";
			}

		} catch (Exception ex) {
			res = "Exception is occurred.";
		}
		return res;
	}

	@Override
	public String getWorkerApprovalStatusByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<WorkerApprovalStatus> approvalStatus = approvalStatusRepository
					.findAllWorkerApprovalStatus(pageableRequest);
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (approvalStatus != null && approvalStatus.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(approvalStatus);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getWorkerApprovalStatusWithNamesByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			// if(organizationCode!=null && organizationCode.length()>0)
			// {
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<Object> objlst = approvalStatusRepository
					.getAllWorkerApprovalStatus(pageableRequest);
			List<WorkerOrganizationNameResponse> wolst = new ArrayList<WorkerOrganizationNameResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 3) {
						WorkerOrganizationNameResponse wo = new WorkerOrganizationNameResponse();

						WorkerApprovalStatus was = (WorkerApprovalStatus) arr[0];
						wo.setId(was.getId());
						wo.setOrganization_Code(was.getOrganization_Code());
						wo.setWorkerCode(was.getWorkerCode());
						wo.setIsApproved(was.getIsApproved());
						wo.setApprovedByCode(was.getApprovedByCode());
						wo.setApprovedDate(was.getApprovedDate());
                                                wo.setColor(was.getColor());
						wo.setWorkerName((String) arr[1]);
						wo.setOrganizationName((String) arr[2]);

						wolst.add(wo);
					}

				}

				if (wolst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(wolst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			// }
			// else {
			// jsonobj.put("responsecode", 400);
			// jsonobj.put("message", "Input data is not valid.");
			// jsonobj.put("timestamp", new Date());
			// }
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			if (search != null && search.trim().length() > 0) {
				JSONObject jsonobj = new JSONObject();

				WorkerApprovalStatusSpecificationsBuilder builder = new WorkerApprovalStatusSpecificationsBuilder();
				Pattern pattern = Pattern
						.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
				java.util.regex.Matcher matcher = pattern.matcher(search + ",");
				while (matcher.find()) {
					builder.with(matcher.group(1), matcher.group(2),
							matcher.group(3));
				}

				Specification<WorkerApprovalStatus> spec = builder.build();
				if (spec != null) {
					List<WorkerApprovalStatus> approvalStatus = approvalStatusRepository
							.findAll(spec);
					if (approvalStatus != null && approvalStatus.size() > 0) {
						for (WorkerApprovalStatus was : approvalStatus) {
							if (was.getIsDeleted() != null
									&& was.getIsDeleted() != true) {

								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj
										.writeValueAsString(was);
								JSONObject jsonobjNew = new JSONObject();
								jsonobjNew.put("WorkerApprovalStatus",
										new JSONObject(Detail));
								jarr.add(jsonobjNew);

							}

						}
						if (jarr.size() > 0) {

							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "Success");
							jsonobj.put("timestamp", new Date());
							jsonobj.put("data", jarr);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "Record Not Found!");
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Record Not Found!");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Record Not Found!");
					jsonobj.put("timestamp", new Date());
				}
				res = jsonobj.toString();

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Input data is not valid.");
				res = derr.toString();

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getWorkApprovalStatusByOrganizationCode(
			String organizationCode) {

		String res = "";
		try {

			JSONObject jsonobj = new JSONObject();
			JSONArray jarr = new JSONArray();
			if (organizationCode != null
					&& organizationCode.trim().length() > 0) {
				List<WorkApprovalStatusWorkerRes> wasreslst = new ArrayList<WorkApprovalStatusWorkerRes>();
				List<Object> objlst = approvalStatusRepository
						.getWorkApprovalStatusByOrganizationCode(organizationCode
								.trim());
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 3) {
							WorkApprovalStatusWorkerRes wres = new WorkApprovalStatusWorkerRes();
							wres.setWorkApprovalStatusId((Long) arr[1]);
							Boolean st = (Boolean) arr[2];
							if (st != null) {
								wres.setIsApproved(st);
							} else {
								wres.setIsApproved(Boolean.FALSE);
							}
							wres.setWorker((Worker) arr[0]);
							wasreslst.add(wres);

						}
					}
					if (wasreslst != null && wasreslst.size() > 0) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(wasreslst);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("workercount", wasreslst.size());
						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String saveWorkerApprovalStatus(
			WorkerApprovalStatusRequestSave wasReqSave, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (wasReqSave != null) {
				if ((wasReqSave.getOrganization_Code() != null && wasReqSave
						.getOrganization_Code().trim().length() > 0)
						&& (wasReqSave.getWorkerCode() != null && wasReqSave
								.getWorkerCode().trim().length() > 0)) {

					Organization org = orgDao.findByOrganizationCode(wasReqSave
							.getOrganization_Code());
					if (org != null && org.getId() > 0) {

						Worker worker = workerDao.findByWorkerCode(wasReqSave
								.getWorkerCode());
						if (worker != null && worker.getId() > 0) {

							WorkerApprovalStatus wlres = approvalStatusRepository
									.getWorkerApprovalStatusByWorkerCodeOrgCode(
											wasReqSave.getWorkerCode(),
											wasReqSave.getOrganization_Code());
							if (wlres != null && wlres.getId() > 0) {
								jsonobj.put("responsecode", 409);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Record already exist.");
							} else {
								WorkerApprovalStatus was = new WorkerApprovalStatus();

								was.setOrganization_Code(wasReqSave
										.getOrganization_Code());
								was.setWorkerCode(wasReqSave.getWorkerCode());
								was.setIsApproved(Boolean.FALSE);
                                                                was.setColor(wasReqSave.getColor());
								was.setIpAddress(ip);

								WorkerApprovalStatus wasRes = approvalStatusRepository
										.save(was);

								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());

								if (wasRes != null && wasRes.getId() > 0) {

									jsonobj.put("message",
											"Worker Approval Status has been added successfully.");
									ObjectMapper mapperObj = new ObjectMapper();
									String Detail = mapperObj
											.writeValueAsString(wasRes);
									jsonobj.put("data", new JSONObject(Detail));
									// kafkaService.sendWorkingLocation(wasRes);
//									kafkaService.sendAddWAS(wasRes);
								} else {
									jsonobj.put("responsecode", 400);
									jsonobj.put("message", "Failed");
								}

							}
						} else {
							jsonobj.put("responsecode", 404);
							jsonobj.put("message", "Worker Code Not Found");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Organization Code Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Data should not be blank.");
					jsonobj.put("timestamp", new Date());
				}
			}
			//
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String softDeleteByWorkerAndOrgCode(String workerCode,
			String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (organizationCode != null
					&& organizationCode.trim().length() > 0
					&& workerCode != null && workerCode.trim().length() > 0) {
				
				WorkerApprovalStatus was = approvalStatusRepository
						.getWorkerApprovalStatusByWorkerCodeOrgCode(workerCode,
								organizationCode);

				if (was != null && was.getId() > 0) {

					was.setIsDeleted(true);
					WorkerApprovalStatus wasRes = approvalStatusRepository
							.save(was);
					if (wasRes != null && wasRes.getId() > 0) {
						jsonobj.put("responsecode", 200);
						jsonobj.put("timestamp", new Date());

						jsonobj.put("message",
								"Worker Approval Status deleted successfully.");

//						kafkaService.sendUpdateWAS(wasRes);
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Failed");
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}
        
        	@Override
	public String getWorkerApprovalStatusByWorkerCode(String workerCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (workerCode != null && workerCode.trim().length() > 0) {
				List<Object> objlst = approvalStatusRepository
						.getWASByWorkerCode(workerCode);
				List<WASWorkerNameOrganizationNameResponse> maplst=new ArrayList<WASWorkerNameOrganizationNameResponse>();
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 3) {
							WASWorkerNameOrganizationNameResponse wwo = new WASWorkerNameOrganizationNameResponse();
							
							WorkerApprovalStatus was = (WorkerApprovalStatus) arr[0];

							if(was.getIsApproved())
							{
								wwo.setApprovedStatus("This worker is approved");
							}else{
								wwo.setApprovedStatus("This worker is not approved");
							}
                                                        wwo.setColor(was.getColor());
							wwo.setOrganization_Code(was.getOrganization_Code());
							wwo.setOrganizationName((String) arr[2]);
							wwo.setWorkerCode(was.getWorkerCode());
							wwo.setName((String) arr[1]);
							

							maplst.add(wwo);
						}
					}
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("data", new JSONArray(Detail));
			}else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			}else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Worker Code should not be blank");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

    @Override
    public String getWorkApprovalStatusWithCertificatesDetailsByOrganizationCode(String organizationCode) {
        
        
        String res = "";
		try {

			JSONObject jsonobj = new JSONObject();
			JSONArray jarr = new JSONArray();
                        
                         List<String> certificateCode = new ArrayList<String>();
                         List<String> certificateName = new ArrayList<String>();
                         List<String> skillCode = new ArrayList<String>();
                         List<String> skillName = new ArrayList<String>();
			if (organizationCode != null
					&& organizationCode.trim().length() > 0) {
				List<WorkApprovalStatusWorkerDetailResponse> wasreslst = new ArrayList<WorkApprovalStatusWorkerDetailResponse>();
                                
                                List<Object> objlst = approvalStatusRepository
						.getWorkApprovalStatusDetailByOrganizationCode(organizationCode.trim());
                                
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
                                            
                                             certificateCode = new ArrayList<String>();
                                             certificateName = new ArrayList<String>();
                                             skillCode = new ArrayList<String>();
                                             skillName = new ArrayList<String>();
                                            
                                            
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 3) {
							WorkApprovalStatusWorkerDetailResponse wres = new WorkApprovalStatusWorkerDetailResponse();
							wres.setWorkApprovalStatusId((Long) arr[1]);
							Boolean st = (Boolean) arr[2];
							if (st != null) {
								wres.setIsApproved(st);
							} else {
								wres.setIsApproved(Boolean.FALSE);
							}
							wres.setWorker((Worker) arr[0]);
                                                        
                                                        String workerCode = (String) arr[3];
                                                        int count=0;
                                                        List<Object> workerCertificationList= workerCertificationsRepository.getWorkerCertificationsByWorkerCode(workerCode);
                                                        if(workerCertificationList!=null && workerCertificationList.size()>0 )
                                                        {
                                                            count=workerCertificationList.size();
                                                        
                                                           for (int j = 0; j < workerCertificationList.size(); j++) {
                                                            
                                                            Object[] certificateArray = (Object[]) workerCertificationList.get(j);
                                                            
                                                            if (certificateArray.length >= 4) {
                                                                
                                                                WorkerCertifications wc = (WorkerCertifications) certificateArray[0];
		
                                                                certificateCode.add(wc.getCertificationCode());
                                                                CertificationsMaster cm=(CertificationsMaster) certificateArray[2];
                                                                if(cm!=null)
                                                                {
                                                                  certificateName.add(cm.getCertificationName());                                                                 
                                                                }
                                                                
                                                                
                                                                
                                                              }
                                                            
                                                            }
                                                        
                                                        }
                                                        wres.setCertificateCode(certificateCode);
                                                        wres.setCertificateName(certificateName); 
                                                                                                                
                                                        List<Object> workerSkillList= orgWorkerSkillDao.getOrgWorkSkillByOrganizationCodeAndWorkerCode(organizationCode,workerCode);
                                                        
                                                        if(workerSkillList != null && workerSkillList.size() > 0)
                                                        {
                                                            for (int k = 0; k < workerSkillList.size(); k++) {
                                                                
                                                                Object[] skillArray = (Object[]) workerSkillList.get(k);
                                                                
                                                                String  strSkillName =  (String) skillArray[0];
                                                                String  strSkillCode =  (String) skillArray[1];
                                                                
                                                                skillName.add(strSkillName);
                                                                skillCode.add(strSkillCode);
                                                                
                                                            }
                                                        }
                                                        wres.setSkillCode(skillCode);
                                                        wres.setSkillName(skillName); 
							wasreslst.add(wres);

						}
					}
					if (wasreslst != null && wasreslst.size() > 0) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(wasreslst);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("workercount", wasreslst.size());
						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
    }


}
