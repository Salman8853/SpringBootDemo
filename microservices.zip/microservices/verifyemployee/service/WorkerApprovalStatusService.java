/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.verifyemployee.service;

import java.util.List;

import com.gigflex.prototype.microservices.verifyemployee.dtob.MultipleWorkerApprovalStatusRequest;
import com.gigflex.prototype.microservices.verifyemployee.dtob.SingleWorkerApprovalStatusRequest;
import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkerApprovalStatus;
import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkerApprovalStatusRequest;
import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkerApprovalStatusRequestSave;

/**
 *
 * @author nirbhay.p
 */
public interface WorkerApprovalStatusService {
	public String search(String search);

	public String verifySingleEmployee(
			SingleWorkerApprovalStatusRequest approvalStatusRequest, String ip);

	public String verifyMultipleEmployee(
			MultipleWorkerApprovalStatusRequest approvalStatusRequest, String ip);

	public String getAllWAS();

	public WorkerApprovalStatus saveInWorkerApprovalStatus(
			WorkerApprovalStatus workerApprovalStatus);

	public String getWASByID(Long id);

	public String verifyEmployeeStatus(
			WorkerApprovalStatusRequest approvalStatusRequest, String ip);

	public String deleteWASById(Long id);

	public String softDeleteWASById(Long id);

	public String softMultipleDeleteById(List<Long> idList);

	public String createWAS(WorkerApprovalStatus was);

	public String updateWAS(WorkerApprovalStatus was, Long id);

	public String getAllWorkerApprovalStatus();

	public String getWorkerApprovalStatusByPage(int page, int limit);

	public String getWorkerApprovalStatusWithNamesByPage(int page, int limit);

	public String getWorkerAndOrganization(String organizationCode);

	public String getPendingWorkerForApproval(String organizationCode);
        
        public String getWorkApprovalStatusByOrganizationCode(String organizationCode);

	public String getWorkerAndOrganization(String organizationCode, int page,
			int limit);

	public String getPendingWorkerForApproval(String organizationCode,
			int page, int limit);

	public String verifyWorker(String organization_Code, String workerCode,
			String approvedByCode, Boolean isApproved);
	
	public String saveWorkerApprovalStatus(WorkerApprovalStatusRequestSave wasReqSave, String ip);
	
    public String softDeleteByWorkerAndOrgCode(String workerCode, String organizationCode);
    
     //public String getPendingWorkerForApproval(String organizationCode);
   //public String getWorkerAndOrganization(String organizationCode);
   public String getWorkerApprovalStatusByWorkerCode(String workerCode);
   //public String getAllWorkerApprovalStatus();

    public String getWorkApprovalStatusWithCertificatesDetailsByOrganizationCode(String organizationCode);

}
