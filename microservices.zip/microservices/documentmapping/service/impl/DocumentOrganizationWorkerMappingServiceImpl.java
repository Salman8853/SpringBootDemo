/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.documentmapping.service.impl;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.documentmapping.dtob.DocumentOrganizationMapping;
import com.gigflex.prototype.microservices.documentmapping.dtob.DocumentOrganizationWorkerMapping;
import com.gigflex.prototype.microservices.documentmapping.dtob.DocumentOrganizationWorkerMappingRequest;
import com.gigflex.prototype.microservices.documentmapping.dtob.WorkerDocuments;
import com.gigflex.prototype.microservices.documentmapping.repository.DocumentOrganizationWorkerMappingRepository;
import com.gigflex.prototype.microservices.documentmapping.service.DocumentOrganizationWorkerMappingService;
import com.gigflex.prototype.microservices.documentmapping.dtob.DocumentOrganizationWorkerMappingResponse;
import com.gigflex.prototype.microservices.documentmapping.dtob.DocumentOrganizationWorkerMappingWithAllFieldsResponse;
import com.gigflex.prototype.microservices.documentmapping.repository.DocumentOrganizationMappingRepository;
import com.gigflex.prototype.microservices.documentmapping.repository.WorkerDocumentsRepository;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.verifyemployee.repository.WorkerApprovalStatusRepository;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.worker.repository.WorkerRepository;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author nirbhay.p
 */
@Service
public class DocumentOrganizationWorkerMappingServiceImpl implements DocumentOrganizationWorkerMappingService{

    @Autowired
    DocumentOrganizationWorkerMappingRepository documentOrganizationWorkerMappingRepository;
    @Autowired
    WorkerRepository workerRepository;
    @Autowired
    WorkerApprovalStatusRepository workerApprovalStatusRepository;
    
    @Autowired
    DocumentOrganizationMappingRepository documentOrganizationMappingRepository;
    
    @Autowired
    WorkerDocumentsRepository workerDocumentsRepository;
    
    @Autowired
    OrganizationRepository organizationRepository;
    
    @Override
    public String getDocumentOrganizationWorkerMapping() {
        	 String res = "";
		 try {
		 JSONObject jsonobj = new JSONObject();
                 List<DocumentOrganizationWorkerMappingResponse> rsplst= new ArrayList<DocumentOrganizationWorkerMappingResponse>();
		 List<Object> objlst = documentOrganizationWorkerMappingRepository.getAllDocumentOrganizationWorkerMapping();
		        if (objlst != null && objlst.size() > 0) {
                         for (int i = 0; i < objlst.size(); i++) {
                             Object[] arr = (Object[]) objlst.get(i);
                             if (arr.length >= 4) {
                                 DocumentOrganizationWorkerMappingResponse resp=new DocumentOrganizationWorkerMappingResponse();
                                 DocumentOrganizationWorkerMapping d=(DocumentOrganizationWorkerMapping) arr[0];
                                 WorkerDocuments wd=(WorkerDocuments) arr[1];
                                 DocumentOrganizationMapping dom=(DocumentOrganizationMapping) arr[2];
                                 resp.setDocumentOrganizationWorkerCode(d.getDocumentOrganizationWorkerCode());
                                 resp.setId(d.getId());
                                 resp.setWorkerDocumentCode(d.getWorkerDocumentCode());
                                 resp.setOrganizationDocumentCode(dom.getOrganizationDocumentCode());
                                 if(wd!=null && wd.getId()>0 && wd.getWorkerCode()!=null)
                                 {
                                     resp.setWorkerCode(wd.getWorkerCode());
                                     resp.setDocumentCode(wd.getDocumentCode());
                                     resp.setDocumentName((String) arr[3]);
                                     Worker w=workerRepository.getWorkerProfileTabsByworkerCode(wd.getWorkerCode());
                                     if(w!=null && w.getId()>0)
                                     {
                                         resp.setWorkerName(w.getName());
                                     }
                                     
                                 }
                                 if(dom!=null && dom.getId()>0 && dom.getOrganizationCode()!=null)
                                 {
                                     resp.setOrganizationCode(dom.getOrganizationCode());
                                     Organization org=organizationRepository.findByOrganizationCode(dom.getOrganizationCode());
                                     if(org!=null && org.getId()>0)
                                     {
                                         resp.setOrganizationName(org.getOrganizationName());
                                     }
                                 }
                                 rsplst.add(resp);
                             }
                         }
                     }
		 if (rsplst != null && rsplst.size() > 0) {
		 jsonobj.put("responsecode", 200);
		 jsonobj.put("message", "Success");
		 jsonobj.put("timestamp", new Date());
		 ObjectMapper mapperObj = new ObjectMapper();
		 String Detail = mapperObj.writeValueAsString(rsplst);
		 jsonobj.put("data", new JSONArray(Detail));
		 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("message", "Record Not Found.");
		 jsonobj.put("timestamp", new Date());
		 }
		 res = jsonobj.toString();
		 } catch (JSONException | JsonProcessingException ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "JSON parsing exception occurred.");
		 res = derr.toString();
		 } catch (Exception ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "Exception occurred.");
		 res = derr.toString();
		 }
		 return res;

   
    }

    @Override
    public String getDocumentOrganizationWorkerMappingByCode(String documentOrganizationWorkerCode) {
       
        String res = "";
		 try {
		 JSONObject jsonobj = new JSONObject();
		DocumentOrganizationWorkerMapping objlst = documentOrganizationWorkerMappingRepository.getDocumentOrganizationWorkerMappingByCode(documentOrganizationWorkerCode);
		        
		 if (objlst != null && objlst.getId() > 0) {
		 jsonobj.put("responsecode", 200);
		 jsonobj.put("message", "Success");
		 jsonobj.put("timestamp", new Date());
		 ObjectMapper mapperObj = new ObjectMapper();
		 String Detail = mapperObj.writeValueAsString(objlst);
		 jsonobj.put("data", new JSONObject(Detail));
		 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("message", "Record Not Found.");
		 jsonobj.put("timestamp", new Date());
		 }
		 res = jsonobj.toString();
		 } catch (JSONException | JsonProcessingException ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "JSON parsing exception occurred.");
		 res = derr.toString();
		 } catch (Exception ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "Exception occurred.");
		 res = derr.toString();
		 }
		 return res;
    }
    
    @Override
    public String getDocumentOrganizationWorkerMappingWithNameByCode(String documentOrganizationWorkerCode) {
        
       
        
        	 String res = "";
		 try {
		 JSONObject jsonobj = new JSONObject();
                 DocumentOrganizationWorkerMappingResponse resp= null;
		 Object objlst = documentOrganizationWorkerMappingRepository.getDocumentOrganizationWorkerMappingWithNameByCode(documentOrganizationWorkerCode);
		        if (objlst != null) {
                        
                             Object[] arr = (Object[]) objlst;
                             if (arr.length >= 4) {
                                 resp=new DocumentOrganizationWorkerMappingResponse();
                                 DocumentOrganizationWorkerMapping d=(DocumentOrganizationWorkerMapping) arr[0];
                                 WorkerDocuments wd=(WorkerDocuments) arr[1];
                                 DocumentOrganizationMapping dom=(DocumentOrganizationMapping) arr[2];
                                 resp.setDocumentOrganizationWorkerCode(d.getDocumentOrganizationWorkerCode());
                                 resp.setId(d.getId());
                                 resp.setWorkerDocumentCode(d.getWorkerDocumentCode());
                                 resp.setOrganizationDocumentCode(dom.getOrganizationDocumentCode());
                                 if(wd!=null && wd.getId()>0 && wd.getWorkerCode()!=null)
                                 {
                                     resp.setWorkerCode(wd.getWorkerCode());
                                     resp.setDocumentCode(wd.getDocumentCode());
                                     resp.setDocumentName((String) arr[3]);
                                     Worker w=workerRepository.getWorkerProfileTabsByworkerCode(wd.getWorkerCode());
                                     if(w!=null && w.getId()>0)
                                     {
                                         resp.setWorkerName(w.getName());
                                     }
                                     
                                 }
                                 if(dom!=null && dom.getId()>0 && dom.getOrganizationCode()!=null)
                                 {
                                     resp.setOrganizationCode(dom.getOrganizationCode());
                                     Organization org=organizationRepository.findByOrganizationCode(dom.getOrganizationCode());
                                     if(org!=null && org.getId()>0)
                                     {
                                         resp.setOrganizationName(org.getOrganizationName());
                                     }
                                 }
                             }
                        
                     }
		 if (resp != null && resp.getId() > 0) {
		 jsonobj.put("responsecode", 200);
		 jsonobj.put("message", "Success");
		 jsonobj.put("timestamp", new Date());
		 ObjectMapper mapperObj = new ObjectMapper();
		 String Detail = mapperObj.writeValueAsString(resp);
		 jsonobj.put("data", new JSONObject(Detail));
		 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("message", "Record Not Found.");
		 jsonobj.put("timestamp", new Date());
		 }
		 res = jsonobj.toString();
		 } catch (JSONException | JsonProcessingException ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "JSON parsing exception occurred.");
		 res = derr.toString();
		 } catch (Exception ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "Exception occurred.");
		 res = derr.toString();
		 }
		 return res;
        	 
    
    }

    @Override
    public String saveDocumentOrganizationWorkerMapping(DocumentOrganizationWorkerMappingRequest driDetReq, String ip) {
        
        
        String res = "";
		 try {
		 JSONObject jsonobj = new JSONObject();
                 
                   DocumentOrganizationWorkerMapping dom=  documentOrganizationWorkerMappingRepository.getDocumentOrganizationWorkerMappingByWorkerDocumentCodeAndOrganizationDocumentCode(driDetReq.getWorkerDocumentCode(), driDetReq.getOrganizationDocumentCode());
                   if(dom!=null && dom.getId()>0)
                   {
                       jsonobj.put("responsecode", 409);
                       jsonobj.put("message", "Record is already exist.");
                       jsonobj.put("timestamp", new Date());
                   }
                   else
                     {
                        DocumentOrganizationMapping dorg= documentOrganizationMappingRepository.getDocumentOrganizationMappingByCode(driDetReq.getOrganizationDocumentCode());
                        if(dorg!=null && dorg.getId()>0)
                        {
                         WorkerDocuments wd=   workerDocumentsRepository.getWorkerDocumentsByWorkerDocumentCode(driDetReq.getWorkerDocumentCode());
                         if(wd!=null && wd.getId()>0)
                        {
                        if(dorg.getDocumentCode().equalsIgnoreCase(wd.getDocumentCode()))
                        {
                        DocumentOrganizationWorkerMapping dm = new DocumentOrganizationWorkerMapping();
                         dm.setWorkerDocumentCode(driDetReq.getWorkerDocumentCode());
                         dm.setOrganizationDocumentCode(driDetReq.getOrganizationDocumentCode());
                         dm.setIpAddress(ip);
                         DocumentOrganizationWorkerMapping dmres = documentOrganizationWorkerMappingRepository.save(dm);
                         if (dmres != null && dmres.getId() > 0) {
                             jsonobj.put("responsecode", 200);
                             jsonobj.put("timestamp", new Date());
                             jsonobj.put("message",
                                     "Document Organization Worker Mapping has been added successfully.");
                             ObjectMapper mapperObj = new ObjectMapper();
                             String Detail = mapperObj.writeValueAsString(dmres);
                             jsonobj.put("data", new JSONObject(Detail));
                         } else {
                             jsonobj.put("responsecode", 400);
                             jsonobj.put("timestamp", new Date());
                             jsonobj.put("message", "Failed");
                         }
                         }
                         else {
                             jsonobj.put("responsecode", 400);
                             jsonobj.put("timestamp", new Date());
                             jsonobj.put("message", "Worker's Documents Code and Organization's Documents Code should be matched.");
                         }
                         }
                         else {
                             jsonobj.put("responsecode", 404);
                             jsonobj.put("timestamp", new Date());
                             jsonobj.put("message", "Worker Documents does not exist.");
                         }
                        }
                         else {
                             jsonobj.put("responsecode", 404);
                             jsonobj.put("timestamp", new Date());
                             jsonobj.put("message", "Document Organization Mapping does not exist.");
                         }
                     }
                 
		 res = jsonobj.toString();
		 } catch (JSONException | JsonProcessingException ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "JSON parsing exception occurred.");
		 res = derr.toString();
		 } catch (Exception ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "Exception occurred.");
		 res = derr.toString();
		 }
		 return res;
    
    }

    @Override
    public String softDeleteDocumentOrganizationWorkerMappingByCode(String documentOrganizationWorkerCode) {
        
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        
			DocumentOrganizationWorkerMapping docTypeLst = documentOrganizationWorkerMappingRepository
					.getDocumentOrganizationWorkerMappingByCode(documentOrganizationWorkerCode);

			if (docTypeLst != null && docTypeLst.getId() > 0) {
				docTypeLst.setIsDeleted(true);
				DocumentOrganizationWorkerMapping docTypeRes = documentOrganizationWorkerMappingRepository.save(docTypeLst);
				if (docTypeRes != null && docTypeRes.getId() > 0) {
					
					
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message",
							"Document Organization Worker Mapping deleted successfully.");
					// kafkaService.sendRoleMasterUpdate(roleRes);
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
                        
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
		}
		return res;
	
    }

    @Override
    public String softMultipleDeleteDocumentOrganizationWorkerMappingByCode(List<String> documentOrganizationWorkerCodeList) {
        
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String documentCode : documentOrganizationWorkerCodeList) {
				if (documentCode != null && documentCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					documentCode = documentCode.trim();

					DocumentOrganizationWorkerMapping docTypeLst = documentOrganizationWorkerMappingRepository
					.getDocumentOrganizationWorkerMappingByCode(documentCode);

					if (docTypeLst != null && docTypeLst.getId() > 0) {

						docTypeLst.setIsDeleted(true);
						DocumentOrganizationWorkerMapping docTypeRes = documentOrganizationWorkerMappingRepository
								.save(docTypeLst);
						if (docTypeRes != null && docTypeRes.getId() > 0) {
							
							
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", documentCode);
							jsonobj.put("message",
									"Document Organization Worker Mapping deleted successfully.");
							// kafkaService.se
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", documentCode);
							jsonobj.put("message", "Failed");
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", documentCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
		}
		return res;
	
    }

    @Override
    public String checkDocumentOrganizationWorkerMappingByOrgCodeAndWorkerCode(String organizationCode, String workerCode) {
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        
                        Worker w=workerRepository.getWorkerProfileTabsByworkerCode(workerCode);
                        if(w!=null && w.getId()>0)
                        {
                        List<DocumentOrganizationWorkerMappingWithAllFieldsResponse> resLst=new ArrayList<DocumentOrganizationWorkerMappingWithAllFieldsResponse>();
                        List<Object> objlst = documentOrganizationMappingRepository.getAllDocumentOrganizationMappingByOrgCode(organizationCode);
		        if (objlst != null && objlst.size() > 0) {
                         for (int i = 0; i < objlst.size(); i++) {
                             Object[] arr = (Object[]) objlst.get(i);
                             if (arr.length >= 3) {
                                 DocumentOrganizationMapping dom=(DocumentOrganizationMapping) arr[0];
                                 if(dom!=null && dom.getId()>0)
                                 {
                                 DocumentOrganizationWorkerMappingWithAllFieldsResponse resp=new DocumentOrganizationWorkerMappingWithAllFieldsResponse();
                                 resp.setDocumentCode(dom.getDocumentCode());
                                 resp.setDocumentName((String) arr[1]);
                                 resp.setOrganizationDocumentId(dom.getId());
                                 resp.setOrganizationCode(dom.getOrganizationCode());
                                 resp.setOrganizationDocumentCode(dom.getOrganizationDocumentCode());
                                 resp.setOrganizationName((String) arr[2]);
                                 resp.setWorkerCode(workerCode);
                                 resp.setWorkerName(w.getName());
                                 WorkerDocuments wd=workerDocumentsRepository.getWorkerDocumentsByDocCodeAndWorkerCode(dom.getDocumentCode(), workerCode);
                                 if(wd!=null && wd.getId()>0)
                                 {
                                     resp.setWorkerDocumentId(wd.getId());
                                     resp.setWorkerDocumentCode(wd.getWorkerDocumentCode());
                                     resp.setDocumentValue(wd.getDocumentValue());
                                     resp.setIsUploaded(Boolean.TRUE);
                                     DocumentOrganizationWorkerMapping ddm=  documentOrganizationWorkerMappingRepository.getDocumentOrganizationWorkerMappingByWorkerDocumentCodeAndOrganizationDocumentCode(wd.getWorkerDocumentCode(), dom.getOrganizationDocumentCode());
                                     if(ddm!=null && ddm.getId()>0)
                                     {
                                         resp.setIsMapped(Boolean.TRUE);
                                         resp.setCanShare(Boolean.FALSE);
                                         resp.setDocumentOrganizationWorkerId(ddm.getId());
                                         resp.setDocumentOrganizationWorkerCode(ddm.getDocumentOrganizationWorkerCode());
                                     }
                                     else
                                     {
                                        resp.setIsMapped(Boolean.FALSE);
                                        resp.setCanShare(Boolean.TRUE);
                                     }
                                 }
                                 else
                                 {
                                     resp.setIsUploaded(Boolean.FALSE);
                                     resp.setIsMapped(Boolean.FALSE);
                                     resp.setCanShare(Boolean.FALSE);
                                 }
                                 
                                 
                                 resLst.add(resp);
                             }
                             }
                         }
                     }
                       
                        
                 if (resLst != null && resLst.size() > 0) {
		 jsonobj.put("responsecode", 200);
		 jsonobj.put("message", "Success");
		 jsonobj.put("timestamp", new Date());
		 ObjectMapper mapperObj = new ObjectMapper();
		 String Detail = mapperObj.writeValueAsString(resLst);
		 jsonobj.put("data", new JSONArray(Detail));
		 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("message", "Record Not Found.");
		 jsonobj.put("timestamp", new Date());
		 }
                    }
                         else {
                             jsonobj.put("responsecode", 404);
                             jsonobj.put("timestamp", new Date());
                             jsonobj.put("message", "Worker does not exist.");
                         }
                     
		 res = jsonobj.toString();
                 } catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
		}
		return res;  
    }

    @Override
    public String getAllDocumentOrganizationWorkerMappingByOrganizationCode(String organizationCode) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        
                        
                        List<DocumentOrganizationWorkerMappingWithAllFieldsResponse> resLst=new ArrayList<DocumentOrganizationWorkerMappingWithAllFieldsResponse>();
                        List<Worker> wkrlst=workerApprovalStatusRepository.getAllApprovedWorkerByOrgCode(organizationCode);
                        for(Worker wkr:wkrlst)
                        {
                        List<Object> objlst = documentOrganizationMappingRepository.getAllDocumentOrganizationMappingByOrgCode(organizationCode);
		        if (objlst != null && objlst.size() > 0) {
                         for (int i = 0; i < objlst.size(); i++) {
                             Object[] arr = (Object[]) objlst.get(i);
                             if (arr.length >= 3) {
                                 DocumentOrganizationMapping dom=(DocumentOrganizationMapping) arr[0];
                                 if(dom!=null && dom.getId()>0)
                                 {
                                     
                                 DocumentOrganizationWorkerMappingWithAllFieldsResponse resp=new DocumentOrganizationWorkerMappingWithAllFieldsResponse();
                                 resp.setDocumentCode(dom.getDocumentCode());
                                 resp.setDocumentName((String) arr[1]);
                                 resp.setOrganizationDocumentId(dom.getId());
                                 resp.setOrganizationCode(dom.getOrganizationCode());
                                 resp.setOrganizationDocumentCode(dom.getOrganizationDocumentCode());
                                 resp.setOrganizationName((String) arr[2]);
                                 resp.setWorkerCode(wkr.getWorkerCode());
                                 resp.setWorkerName(wkr.getName());
                                 WorkerDocuments wd=workerDocumentsRepository.getWorkerDocumentsByDocCodeAndWorkerCode(dom.getDocumentCode(), wkr.getWorkerCode());
                                 if(wd!=null && wd.getId()>0)
                                 {
                                     resp.setWorkerDocumentId(wd.getId());
                                     resp.setWorkerDocumentCode(wd.getWorkerDocumentCode());
                                     resp.setDocumentValue(wd.getDocumentValue());
                                     resp.setIsUploaded(Boolean.TRUE);
                                     DocumentOrganizationWorkerMapping ddm=  documentOrganizationWorkerMappingRepository.getDocumentOrganizationWorkerMappingByWorkerDocumentCodeAndOrganizationDocumentCode(wd.getWorkerDocumentCode(), dom.getOrganizationDocumentCode());
                                     if(ddm!=null && ddm.getId()>0)
                                     {
                                         resp.setIsMapped(Boolean.TRUE);
                                         resp.setCanShare(Boolean.FALSE);
                                         resp.setDocumentOrganizationWorkerId(ddm.getId());
                                         resp.setDocumentOrganizationWorkerCode(ddm.getDocumentOrganizationWorkerCode());
                                     }
                                     else
                                     {
                                        resp.setIsMapped(Boolean.FALSE);
                                        resp.setCanShare(Boolean.TRUE);
                                     }
                                 }
                                 else
                                 {
                                     resp.setIsUploaded(Boolean.FALSE);
                                     resp.setIsMapped(Boolean.FALSE);
                                     resp.setCanShare(Boolean.FALSE);
                                 }
                                 
                                 
                                 resLst.add(resp);
                             }
                             }
                         }
                     }
                       
                        }    
                 if (resLst != null && resLst.size() > 0) {
		 jsonobj.put("responsecode", 200);
		 jsonobj.put("message", "Success");
		 jsonobj.put("timestamp", new Date());
		 ObjectMapper mapperObj = new ObjectMapper();
		 String Detail = mapperObj.writeValueAsString(resLst);
		 jsonobj.put("data", new JSONArray(Detail));
		 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("message", "Record Not Found.");
		 jsonobj.put("timestamp", new Date());
		 }
                    
		 res = jsonobj.toString();
                 } catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
		}
		return res;  
    
    }

    @Override
    public String getAllDocumentOrganizationWorkerMappingByWorkerCode(String workerCode) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        
                        Worker wkr=workerRepository.getWorkerProfileTabsByworkerCode(workerCode);
                        if(wkr!=null && wkr.getId()>0)
                        {
                        List<DocumentOrganizationWorkerMappingWithAllFieldsResponse> resLst=new ArrayList<DocumentOrganizationWorkerMappingWithAllFieldsResponse>();
                        List<Organization> orglst=workerApprovalStatusRepository.getAllOrganizationByWorkerCode(workerCode);
                        for(Organization org:orglst)
                        {
                        List<Object> objlst = documentOrganizationMappingRepository.getAllDocumentOrganizationMappingByOrgCode(org.getOrganizationCode());
		        if (objlst != null && objlst.size() > 0) {
                         for (int i = 0; i < objlst.size(); i++) {
                             Object[] arr = (Object[]) objlst.get(i);
                             if (arr.length >= 3) {
                                 DocumentOrganizationMapping dom=(DocumentOrganizationMapping) arr[0];
                                 if(dom!=null && dom.getId()>0)
                                 {
                                     
                                 DocumentOrganizationWorkerMappingWithAllFieldsResponse resp=new DocumentOrganizationWorkerMappingWithAllFieldsResponse();
                                 resp.setDocumentCode(dom.getDocumentCode());
                                 resp.setDocumentName((String) arr[1]);
                                 resp.setOrganizationDocumentId(dom.getId());
                                 resp.setOrganizationCode(dom.getOrganizationCode());
                                 resp.setOrganizationDocumentCode(dom.getOrganizationDocumentCode());
                                 resp.setOrganizationName((String) arr[2]);
                                 resp.setWorkerCode(wkr.getWorkerCode());
                                 resp.setWorkerName(wkr.getName());
                                 WorkerDocuments wd=workerDocumentsRepository.getWorkerDocumentsByDocCodeAndWorkerCode(dom.getDocumentCode(), wkr.getWorkerCode());
                                 if(wd!=null && wd.getId()>0)
                                 {
                                     resp.setWorkerDocumentId(wd.getId());
                                     resp.setWorkerDocumentCode(wd.getWorkerDocumentCode());
                                     resp.setDocumentValue(wd.getDocumentValue());
                                     resp.setIsUploaded(Boolean.TRUE);
                                     DocumentOrganizationWorkerMapping ddm=  documentOrganizationWorkerMappingRepository.getDocumentOrganizationWorkerMappingByWorkerDocumentCodeAndOrganizationDocumentCode(wd.getWorkerDocumentCode(), dom.getOrganizationDocumentCode());
                                     if(ddm!=null && ddm.getId()>0)
                                     {
                                         resp.setIsMapped(Boolean.TRUE);
                                         resp.setCanShare(Boolean.FALSE);
                                         resp.setDocumentOrganizationWorkerId(ddm.getId());
                                         resp.setDocumentOrganizationWorkerCode(ddm.getDocumentOrganizationWorkerCode());
                                     }
                                     else
                                     {
                                        resp.setIsMapped(Boolean.FALSE);
                                        resp.setCanShare(Boolean.TRUE);
                                     }
                                 }
                                 else
                                 {
                                     resp.setIsUploaded(Boolean.FALSE);
                                     resp.setIsMapped(Boolean.FALSE);
                                     resp.setCanShare(Boolean.FALSE);
                                 }
                                 
                                 
                                 resLst.add(resp);
                             }
                             }
                         }
                     }
                       
                        }    
                 if (resLst != null && resLst.size() > 0) {
		 jsonobj.put("responsecode", 200);
		 jsonobj.put("message", "Success");
		 jsonobj.put("timestamp", new Date());
		 ObjectMapper mapperObj = new ObjectMapper();
		 String Detail = mapperObj.writeValueAsString(resLst);
		 jsonobj.put("data", new JSONArray(Detail));
		 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("message", "Record Not Found.");
		 jsonobj.put("timestamp", new Date());
		 }
                 }
                         else {
                             jsonobj.put("responsecode", 404);
                             jsonobj.put("timestamp", new Date());
                             jsonobj.put("message", "Worker does not exist.");
                         }
                        
		 res = jsonobj.toString();
                 } catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
		}
		return res;  
    }

    
    
}
