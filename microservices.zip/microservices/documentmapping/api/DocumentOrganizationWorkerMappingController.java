/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.documentmapping.api;

import com.gigflex.prototype.microservices.documentmapping.dtob.DocumentOrganizationWorkerMappingRequest;
import com.gigflex.prototype.microservices.documentmapping.service.DocumentOrganizationWorkerMappingService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author nirbhay.p
 */

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/healthcareservice/")
public class DocumentOrganizationWorkerMappingController {
    
    
    @Autowired
    DocumentOrganizationWorkerMappingService documentOrganizationWorkerMappingService;
    
    
        @GetMapping("/getAllDocumentOrganizationWorkerMapping")
	public String getAllDocumentOrganizationWorkerMapping() {
		return documentOrganizationWorkerMappingService.getDocumentOrganizationWorkerMapping();
	}
        
        
        @GetMapping("/checkDocumentOrganizationWorkerMappingByOrgCodeAndWorkerCode/{organizationCode}/{workerCode}")
	public String checkDocumentOrganizationWorkerMappingByOrgCodeAndWorkerCode(@PathVariable("organizationCode") String organizationCode,@PathVariable("workerCode") String workerCode) {
	if(organizationCode!=null && organizationCode.trim().length()>0 && workerCode!=null && workerCode.trim().length()>0)
        {
            return documentOrganizationWorkerMappingService.checkDocumentOrganizationWorkerMappingByOrgCodeAndWorkerCode(organizationCode.trim(),workerCode.trim());
        }
        else
        {
            GigflexResponse derr = new GigflexResponse(400, new Date(),"Organization Code, Worker Code should not be blank.");
            return derr.toString();
        }
	}
        
        
        @GetMapping("/getAllDocumentOrganizationWorkerMappingByOrganizationCode/{organizationCode}")
	public String getAllDocumentOrganizationWorkerMappingByOrganizationCode(@PathVariable("organizationCode") String organizationCode) {
	if(organizationCode!=null && organizationCode.trim().length()>0)
        {
            return documentOrganizationWorkerMappingService.getAllDocumentOrganizationWorkerMappingByOrganizationCode(organizationCode.trim());
        }
        else
        {
            GigflexResponse derr = new GigflexResponse(400, new Date(),"Organization Code should not be blank.");
            return derr.toString();
        }
	}
        
        
        @GetMapping("/getAllDocumentOrganizationWorkerMappingByWorkerCode/{workerCode}")
	public String getAllDocumentOrganizationWorkerMappingByWorkerCode(@PathVariable("workerCode") String workerCode) {
	if(workerCode!=null && workerCode.trim().length()>0)
        {
            return documentOrganizationWorkerMappingService.getAllDocumentOrganizationWorkerMappingByWorkerCode(workerCode.trim());
        }
        else
        {
            GigflexResponse derr = new GigflexResponse(400, new Date(),"Worker Code should not be blank.");
            return derr.toString();
        }
	}
        
        @GetMapping("/getDocumentOrganizationWorkerMappingByCode/{documentOrganizationWorkerCode}")
	public String getDocumentOrganizationWorkerMappingByCode(@PathVariable("documentOrganizationWorkerCode") String documentOrganizationWorkerCode) {
	if(documentOrganizationWorkerCode!=null && documentOrganizationWorkerCode.trim().length()>0)
        {
            return documentOrganizationWorkerMappingService.getDocumentOrganizationWorkerMappingByCode(documentOrganizationWorkerCode.trim());
        }
        else
        {
            GigflexResponse derr = new GigflexResponse(400, new Date(),"Document Organization Worker Code should not be blank.");
            return derr.toString();
        }
	}
        
        @GetMapping("/getDocumentOrganizationWorkerMappingWithNameByCode/{documentOrganizationWorkerCode}")
	public String getDocumentOrganizationWorkerMappingWithNameByCode(@PathVariable("documentOrganizationWorkerCode") String documentOrganizationWorkerCode) {
	if(documentOrganizationWorkerCode!=null && documentOrganizationWorkerCode.trim().length()>0)
        {
            return documentOrganizationWorkerMappingService.getDocumentOrganizationWorkerMappingWithNameByCode(documentOrganizationWorkerCode.trim());
        }
        else
        {
            GigflexResponse derr = new GigflexResponse(400, new Date(),"Document Organization Worker Code should not be blank.");
            return derr.toString();
        }
	}
        
        
        @PostMapping("/saveDocumentOrganizationWorkerMapping")
	public String saveDocumentOrganizationWorkerMapping(@RequestBody DocumentOrganizationWorkerMappingRequest driDetReq,
			HttpServletRequest request) {
            if(driDetReq!=null && driDetReq.getOrganizationDocumentCode()!=null && driDetReq.getOrganizationDocumentCode().trim().length()>0 &&
                    driDetReq.getWorkerDocumentCode()!=null &&  driDetReq.getWorkerDocumentCode().trim().length()>0 )
            {
                driDetReq.setOrganizationDocumentCode(driDetReq.getOrganizationDocumentCode().trim());
                driDetReq.setWorkerDocumentCode(driDetReq.getWorkerDocumentCode().trim());
                String ip = request.getRemoteAddr();
		return documentOrganizationWorkerMappingService.saveDocumentOrganizationWorkerMapping(driDetReq, ip);
            }
            else
            {
                GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Organization DocumentCode, Worker DocumentCode should not be blank.");
			return derr.toString();
            }

	}
        
        @DeleteMapping("/softDeleteDocumentOrganizationWorkerMappingByCode/{documentOrganizationWorkerCode}")
	public String softDeleteDocumentOrganizationWorkerMappingByCode(
			@PathVariable String documentOrganizationWorkerCode) {
	if(documentOrganizationWorkerCode!=null && documentOrganizationWorkerCode.trim().length()>0)
        {	
            return documentOrganizationWorkerMappingService.softDeleteDocumentOrganizationWorkerMappingByCode(documentOrganizationWorkerCode.trim());
        }else
        {
            GigflexResponse derr = new GigflexResponse(400, new Date(),"Document Organization Worker Code should not be blank.");
            return derr.toString();
        }
        }

	@DeleteMapping("/softMultipleDeleteDocumentOrganizationWorkerMappingByCode/{documentOrganizationWorkerCodeList}")
	public String softMultipleDeleteDocumentOrganizationWorkerMappingByCode(
			@PathVariable List<String> documentOrganizationWorkerCodeList) {
		if (documentOrganizationWorkerCodeList != null && documentOrganizationWorkerCodeList.size() > 0) {
			return documentOrganizationWorkerMappingService
					.softMultipleDeleteDocumentOrganizationWorkerMappingByCode(documentOrganizationWorkerCodeList);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

	}
        
}
