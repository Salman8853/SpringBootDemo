package com.gigflex.prototype.microservices.documentmapping.dtob;


public class WorkerDocumentsRequest {
	
    private String documentCode;
   
    private String workerCode;
 
    private String documentValue;

    public String getDocumentCode() {
        return documentCode;
    }

    public void setDocumentCode(String documentCode) {
        this.documentCode = documentCode;
    }

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getDocumentValue() {
        return documentValue;
    }

    public void setDocumentValue(String documentValue) {
        this.documentValue = documentValue;
    }
    

   
    
}
