package com.gigflex.prototype.microservices.documentmapping.repository;


import com.gigflex.prototype.microservices.documentmapping.dtob.WorkerDocuments;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


public interface WorkerDocumentsRepository extends JpaRepository<WorkerDocuments, Long>,JpaSpecificationExecutor<WorkerDocuments>{
	
	
	@Query("SELECT d,dd.documentName ,w.name FROM WorkerDocuments d, Worker w, DocumentTypeDetail dd  WHERE d.isDeleted != TRUE AND dd.isDeleted != TRUE AND w.isDeleted != TRUE AND d.workerCode=w.workerCode AND  d.documentCode = dd.documentCode")
	public List<Object> getAllWorkerDocuments();
        
        
    	@Query("SELECT d,dd.documentName ,w.name FROM WorkerDocuments d, Worker w, DocumentTypeDetail dd  WHERE d.isDeleted != TRUE AND dd.isDeleted != TRUE AND w.isDeleted != TRUE AND d.workerCode=w.workerCode AND  d.documentCode = dd.documentCode")
	public List<Object> getAllWorkerDocuments(Pageable pageableRequest);
        
       @Query("SELECT d,dd.documentName ,w.name FROM WorkerDocuments d, Worker w, DocumentTypeDetail dd  WHERE  d.isDeleted != TRUE AND dd.isDeleted != TRUE AND w.isDeleted != TRUE AND d.workerCode=w.workerCode AND  d.documentCode = dd.documentCode AND d.workerCode = :workerCode")
	public List<Object> getAllWorkerDocumentsByWorkerCode(@Param("workerCode") String workerCode);
        
        
        @Query("SELECT d,dd.documentName ,w.name FROM WorkerDocuments d, Worker w, DocumentTypeDetail dd  WHERE  d.isDeleted != TRUE AND dd.isDeleted != TRUE AND w.isDeleted != TRUE AND d.workerCode=w.workerCode AND  d.documentCode = dd.documentCode AND d.workerCode = :workerCode")
	public List<Object> getAllWorkerDocumentsByWorkerCode(@Param("workerCode") String workerCode,Pageable pageableRequest);
        
	@Query("SELECT d FROM WorkerDocuments d WHERE d.isDeleted != TRUE AND d.workerDocumentCode = :workerDocumentCode")
	public WorkerDocuments getWorkerDocumentsByWorkerDocumentCode(@Param("workerDocumentCode") String workerDocumentCode);
	
	@Query("SELECT d FROM WorkerDocuments d WHERE d.isDeleted != TRUE AND d.id = :id")
	public WorkerDocuments getWorkerDocumentsByID(@Param("id") Long id);
	
        @Query("SELECT d FROM WorkerDocuments d WHERE d.isDeleted != TRUE AND d.documentCode = :documentCode  AND d.workerCode = :workerCode")
	public WorkerDocuments getWorkerDocumentsByDocCodeAndWorkerCode(@Param("documentCode") String documentCode,@Param("workerCode") String workerCode);
	
        @Query("SELECT d FROM WorkerDocuments d WHERE d.isDeleted != TRUE AND d.id != :id AND  d.documentCode = :documentCode  AND d.workerCode = :workerCode")
	public WorkerDocuments getWorkerDocumentsByNotIDDocCodeAndWorkerCode(@Param("id") Long id,@Param("documentCode") String documentCode,@Param("workerCode") String workerCode);
	

}
