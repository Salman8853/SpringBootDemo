/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.employmenttype.service;

import com.gigflex.prototype.microservices.employmenttype.dtob.EmploymentTypeRequest;

/**
 *
 * @author nirbhay.p
 */
public interface EmploymentTypeService {

    public String getAllEmploymentType();

    public String saveEmploymentType(EmploymentTypeRequest empreq, String ip);

    public String getEmploymentTypeByCode(String employmentTypeCode);

    public String softDeleteEmploymentTypeByCode(String employmentTypeCode);

    public String updateEmploymentTypeByCode(EmploymentTypeRequest empreq, String employmentTypeCode, String ip);
    
}
