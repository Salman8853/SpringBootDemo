package com.gigflex.prototype.microservices.organizationworkinglocationhours.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gigflex.prototype.microservices.organizationworkinglocationhours.dtob.OrganizationWorkingLocationHours;
import com.gigflex.prototype.microservices.workinglocation.dtob.WorkingLocation;


public interface OrganizationWorkingLocationHoursRepository extends JpaRepository<OrganizationWorkingLocationHours,Long>,JpaSpecificationExecutor<OrganizationWorkingLocationHours>{
	
	@Query("SELECT orgWrLocHrs FROM OrganizationWorkingLocationHours orgWrLocHrs, WorkingLocation wl WHERE orgWrLocHrs.isDeleted != TRUE AND wl.workingLocationCode = orgWrLocHrs.workingLocationCode AND orgWrLocHrs.workingLocationCode = :workingLocationCode")
	public List<OrganizationWorkingLocationHours> getOrgWorkingLocHrsByWorkingLocationCode(@Param("workingLocationCode") String workingLocationCode);
	
	@Query("SELECT orgWrLocHrs, wl.location, dm.daysName FROM OrganizationWorkingLocationHours orgWrLocHrs, Organization o, WorkingLocation wl, DaysMaster dm WHERE orgWrLocHrs.isDeleted != TRUE AND orgWrLocHrs.dayCode =dm.daysCode AND o.organizationCode = orgWrLocHrs.organizationCode AND wl.organizationCode = orgWrLocHrs.organizationCode AND orgWrLocHrs.workingLocationCode = wl.workingLocationCode AND orgWrLocHrs.organizationCode = :organizationCode ORDER BY wl.location")
	public List<Object> getOrgWorkingLocHrsByOrganizationCode(@Param("organizationCode") String organizationCode);
	
	@Query("SELECT orgWrLocHrs, dm.daysName FROM OrganizationWorkingLocationHours orgWrLocHrs, Organization o, DaysMaster dm WHERE orgWrLocHrs.isDeleted != TRUE AND orgWrLocHrs.dayCode =dm.daysCode AND o.organizationCode = orgWrLocHrs.organizationCode AND orgWrLocHrs.workingLocationCode = :workingLocationCode AND orgWrLocHrs.organizationCode = :organizationCode")
	public List<Object> getOrgWorkingLocHrsByOrganizationCodeWithLocation(@Param("organizationCode") String organizationCode,@Param("workingLocationCode") String workingLocationCode);
	
	@Query("SELECT orgWrLocHrs, wl.location, dm.daysName, o.organizationName FROM OrganizationWorkingLocationHours orgWrLocHrs, WorkingLocation wl, DaysMaster dm, Organization o WHERE orgWrLocHrs.isDeleted != TRUE AND orgWrLocHrs.workingLocationCode = wl.workingLocationCode AND orgWrLocHrs.organizationCode = o.organizationCode AND orgWrLocHrs.dayCode = dm.daysCode")
	public List<Object> getAllOrganizationWorkingLocationHoursWithNames();
	
	@Query("SELECT orgWrLocHrs, wl.location, dm.daysName, o.organizationName FROM OrganizationWorkingLocationHours orgWrLocHrs, WorkingLocation wl, DaysMaster dm, Organization o WHERE orgWrLocHrs.isDeleted != TRUE AND orgWrLocHrs.workingLocationCode = wl.workingLocationCode AND orgWrLocHrs.organizationCode = o.organizationCode AND orgWrLocHrs.dayCode = dm.daysCode")
	public List<Object> getAllOrganizationWorkingLocationHoursWithNames(Pageable pageableRequest);
	
	@Query("SELECT orgWrLocHrs FROM OrganizationWorkingLocationHours orgWrLocHrs WHERE orgWrLocHrs.isDeleted != TRUE AND orgWrLocHrs.dayCode = :dayCode AND orgWrLocHrs.organizationCode = :organizationCode AND orgWrLocHrs.workingLocationCode = :workingLocationCode")
	public OrganizationWorkingLocationHours getOrgWorkingLovHrsByDayCodeOrgCodeAndWorkLocCode(@Param("dayCode") String dayCode, @Param("organizationCode") String organizationCode, @Param("workingLocationCode") String workingLocationCode);
	
	@Query("SELECT orgWrLocHrs FROM OrganizationWorkingLocationHours orgWrLocHrs WHERE orgWrLocHrs.isDeleted != TRUE AND orgWrLocHrs.id != :id AND orgWrLocHrs.dayCode = :dayCode AND orgWrLocHrs.organizationCode = :organizationCode AND orgWrLocHrs.workingLocationCode = :workingLocationCode")
	public OrganizationWorkingLocationHours getOrgWorkingLovHrsByIdDayCodeOrgCodeAndWorkLocCode(@Param("id") Long id,@Param("dayCode") String dayCode, @Param("organizationCode") String organizationCode, @Param("workingLocationCode") String workingLocationCode);
	
	@Query("SELECT wl FROM WorkingLocation wl WHERE wl.isDeleted != TRUE AND wl.organizationCode = :organizationCode ORDER BY wl.location")
    public List<WorkingLocation> getWorkingLocationByOrganizationCode(@Param("organizationCode") String organizationCode,Pageable pageableRequest);

    @Query("SELECT wl FROM WorkingLocation wl WHERE wl.isDeleted != TRUE AND wl.organizationCode = :organizationCode ORDER BY wl.location")
    public List<WorkingLocation> getWorkingLocationByOrganizationCode(@Param("organizationCode") String organizationCode);

}
