package com.gigflex.prototype.microservices.organizationworkinglocationhours.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.daysmaster.dtob.DaysMaster;
import com.gigflex.prototype.microservices.daysmaster.repository.DaysMasterDao;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.organizationworkinglocationhours.dtob.DaysFromToResponse;
import com.gigflex.prototype.microservices.organizationworkinglocationhours.dtob.DaysLocationFromToResponse;
import com.gigflex.prototype.microservices.organizationworkinglocationhours.dtob.OrganizationWorkingLocationHours;
import com.gigflex.prototype.microservices.organizationworkinglocationhours.dtob.OrganizationWorkingLocationHoursRequest;
import com.gigflex.prototype.microservices.organizationworkinglocationhours.dtob.OrganizationWorkingLocationHoursResponse;
import com.gigflex.prototype.microservices.organizationworkinglocationhours.repository.OrganizationWorkingLocationHoursRepository;
import com.gigflex.prototype.microservices.organizationworkinglocationhours.search.OrganizationWorkingLocationHoursSpecificationsBuilder;
import com.gigflex.prototype.microservices.organizationworkinglocationhours.service.OrganizationWorkingLocationHoursService;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.util.GigflexDateUtil;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.workinglocation.dtob.WorkingLocation;
import com.gigflex.prototype.microservices.workinglocation.repository.WorkingLocationRepository;

@Service
public class OrganizationWorkingLocationHoursServiceImpl implements
		OrganizationWorkingLocationHoursService {

	@Autowired
	OrganizationWorkingLocationHoursRepository orgWorkLocHrsRepository;

	@Autowired
	DaysMasterDao daysMasterDao;

	@Autowired
	OrganizationRepository orgRep;

	@Autowired
	WorkingLocationRepository wrkingLocDao;

	@Autowired
	TimeZoneRepository timeZoneDao;

	@Override
	public String saveOrganizationWorkingLocationHours(
			List<OrganizationWorkingLocationHoursRequest> orgWrLocHrsReqlst,
			String ip) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();

			if (orgWrLocHrsReqlst != null && orgWrLocHrsReqlst.size() > 0) {
				for (OrganizationWorkingLocationHoursRequest owlhr : orgWrLocHrsReqlst) {
					JSONObject jsonobj = new JSONObject();
					if (owlhr != null
							&& owlhr.getDayCode() != null
							&& owlhr.getDayCode().trim().length() > 0
							&& owlhr.getOrganizationCode() != null
							&& owlhr.getOrganizationCode().trim().length() > 0
							&& owlhr.getWorkingLocationCode() != null
							&& owlhr.getWorkingLocationCode().trim().length() > 0) {

						Date frmDt = null;
						Date toDt = null;

						try {
							frmDt = new SimpleDateFormat(
									"yyyy-MM-dd HH:mm:ss").parse(owlhr
									.getFromDate().trim());
							toDt = new SimpleDateFormat(
									"yyyy-MM-dd HH:mm:ss").parse(owlhr
									.getToDate().trim());
							if (frmDt == null || toDt == null) {
								GigflexResponse derr = new GigflexResponse(400,
										new Date(),
										"Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
								return derr.toString();
							}
						} catch (Exception ex) {
							ex.printStackTrace();
							GigflexResponse derr = new GigflexResponse(400,
									new Date(),
									"Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
							return derr.toString();
						}

						DaysMaster dm = daysMasterDao
								.getDaysMasterByDaysCode(owlhr.getDayCode());
						if (dm != null && dm.getId() > 0) {

							Organization org = orgRep
									.findByOrganizationCode(owlhr
											.getOrganizationCode());
							if (org != null && org.getId() > 0) {

								WorkingLocation wl = wrkingLocDao
										.findByWorkingLocationCode(owlhr
												.getWorkingLocationCode());
								if (wl != null && wl.getId() > 0) {
									
									TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());
//									if (org != null && org.getId() > 0) {
                                                                        if(tzd!=null && tzd.getTimeZoneName()!=null && tzd.getTimeZoneName().length()>0)
                                                                        {
									frmDt = GigflexDateUtil
											.convertStringDateToGMT(owlhr
													.getFromDate().trim(), tzd.getTimeZoneName(),
													"yyyy-MM-dd HH:mm:ss");
									toDt = GigflexDateUtil
											.convertStringDateToGMT(owlhr
													.getToDate().trim(), tzd.getTimeZoneName(),
													"yyyy-MM-dd HH:mm:ss");
                                                                        }

									OrganizationWorkingLocationHours owlh = orgWorkLocHrsRepository
											.getOrgWorkingLovHrsByDayCodeOrgCodeAndWorkLocCode(
													owlhr.getDayCode(),
													owlhr.getOrganizationCode(),
													owlhr.getWorkingLocationCode());
									if (owlh != null && owlh.getId() > 0) {
										jsonobj.put("responsecode", 409);
										jsonobj.put("timestamp", new Date());
										jsonobj.put("message",
												"Record already exist.");
									} else {

										OrganizationWorkingLocationHours map = new OrganizationWorkingLocationHours();

										map.setDayCode(owlhr.getDayCode());
										map.setFromDate(frmDt);
										map.setToDate(toDt);
										map.setOrganizationCode(owlhr
												.getOrganizationCode());
										map.setWorkingLocationCode(owlhr
												.getWorkingLocationCode());
										map.setIpAddress(ip);

										OrganizationWorkingLocationHours mapRes = orgWorkLocHrsRepository
												.save(map);

										if (mapRes != null
												&& mapRes.getId() > 0) {
											// kafkaService
											// .sendOrganizationWorkerSkill(mapRes);
											jsonobj.put("responsecode", 200);
											jsonobj.put("timestamp", new Date());
											jsonobj.put("message",
													"Organization Working Location Hours added successfully");
											ObjectMapper mapperObj = new ObjectMapper();
											String Detail = mapperObj
													.writeValueAsString(mapRes);
											jsonobj.put("data", new JSONObject(
													Detail));
										} else {
											jsonobj.put("responsecode", 400);
											jsonobj.put("timestamp", new Date());
											jsonobj.put("Days Code",
													owlhr.getDayCode());
											jsonobj.put("Organization Code",
													owlhr.getOrganizationCode());
											jsonobj.put(
													"Working Location Code",
													owlhr.getWorkingLocationCode());
											jsonobj.put("message", "Failed");
										}
									}

								} else {
									jsonobj.put("message",
											"Working Location Code Not Found.");
									jsonobj.put("responsecode", 400);
									jsonobj.put("timestamp", new Date());
								}
							} else {
								jsonobj.put("message",
										"Organization Code Not Found.");
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
							}
						} else {
							jsonobj.put("message", "Days Code Not Found.");
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
						}
					}

					else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						// jsonobj.put("Days Code", owlhr.getDayCode());
						// jsonobj.put("Organization Code",
						// owlhr.getOrganizationCode());
						// jsonobj.put("Working Location Code",
						// owlhr.getWorkingLocationCode());
						jsonobj.put("message",
								"Organization Code, Working Location Code And Day Code should not be blank");
					}

					jarr.add(jsonobj);
				}
				if (jarr.size() > 0) {
					res = jarr.toString();
				} else {
					GigflexResponse derr = new GigflexResponse(400, new Date(),
							"Multiple add failed.");
					res = derr.toString();
				}

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Input data is not valid");
				res = derr.toString();
			}

		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;

	}

	@Override
	public String getOrganizationWorkingLocationHoursByWorkingLocationCode(
			String workingLocationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<OrganizationWorkingLocationHours> orgWrLcHrsLst = new ArrayList<OrganizationWorkingLocationHours>();

			List<OrganizationWorkingLocationHours> orgWrLcHrs = new ArrayList<OrganizationWorkingLocationHours>();

			orgWrLcHrs = orgWorkLocHrsRepository
					.getOrgWorkingLocHrsByWorkingLocationCode(workingLocationCode);

			for (OrganizationWorkingLocationHours owlh : orgWrLcHrs) {

				Date frmDt = null;
				Date toDt = null;
				WorkingLocation wl = wrkingLocDao
						.findByWorkingLocationCode(workingLocationCode.trim());
				if (wl != null && wl.getId() > 0 && wl.getTimeZone() != null
						&& wl.getTimeZone().trim().length() > 0) {
                                    TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());
					String timezone = tzd.getTimeZoneName();
                                        if(timezone!=null && timezone.length()>0)
                                        {
					Date frmDate = owlh.getFromDate();
					frmDt = GigflexDateUtil.getGMTtoLocationDate(frmDate,
							timezone, "yyyy-MM-dd HH:mm:ss");
					Date toDate = owlh.getToDate();
					toDt = GigflexDateUtil.getGMTtoLocationDate(toDate,
							timezone, "yyyy-MM-dd HH:mm:ss");
                                        }
				}

				owlh.setFromDate(frmDt);
				owlh.setToDate(toDt);

				orgWrLcHrsLst.add(owlh);
				if (orgWrLcHrsLst != null && orgWrLcHrsLst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(orgWrLcHrsLst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Success");
					jsonobj.put("data", new JSONArray(Detail));

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");
				}
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getOrganizationWorkingLocationHoursByOrganizationCode(
			String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (organizationCode != null
					&& organizationCode.trim().length() > 0) {

				List<Object> objlst = orgWorkLocHrsRepository
						.getOrgWorkingLocHrsByOrganizationCode(organizationCode);

				List<DaysLocationFromToResponse> daysLocResLst = new ArrayList<DaysLocationFromToResponse>();

				DaysLocationFromToResponse daysLocRes = new DaysLocationFromToResponse();

				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 3) {
							OrganizationWorkingLocationHours orgWrLc = (OrganizationWorkingLocationHours) arr[0];

							Date frmDt = null;
							Date toDt = null;

							WorkingLocation wl = wrkingLocDao
									.findByWorkingLocationCode(orgWrLc
											.getWorkingLocationCode().trim());

							if (wl != null && wl.getId() > 0
									&& wl.getTimeZone() != null
									&& wl.getTimeZone().trim().length() > 0) {
							TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());	
                                                            String timezone = tzd.getTimeZoneName();
                                                            if(timezone!=null && timezone.length()>0 )
                                                            {
								Date fromDate = orgWrLc.getFromDate();
								frmDt = GigflexDateUtil.getGMTtoLocationDate(
										fromDate, timezone,
										"yyyy-MM-dd HH:mm:ss");
								Date toDate = orgWrLc.getToDate();
								toDt = GigflexDateUtil
										.getGMTtoLocationDate(toDate, timezone,
												"yyyy-MM-dd HH:mm:ss");
                                                            }
							}

							String location = (String) arr[1];
							String daysName = (String) arr[2];

							DaysFromToResponse daysRes = new DaysFromToResponse();
							daysRes.setDaysName(daysName);
							daysRes.setFromDate(frmDt);
							daysRes.setToDate(toDt);
							if (i == 0) {
								List<DaysFromToResponse> dftr = new ArrayList<DaysFromToResponse>();
								dftr.add(daysRes);
								daysLocRes.setLocation(location);
								daysLocRes.setDaysFromToResponse(dftr);
							} else {
								if (daysLocRes.getLocation() != null
										&& !(daysLocRes.getLocation()
												.equalsIgnoreCase(location))) {
									daysLocResLst.add(daysLocRes);
									daysLocRes = new DaysLocationFromToResponse();
									List<DaysFromToResponse> dftr = new ArrayList<DaysFromToResponse>();
									dftr.add(daysRes);
									daysLocRes.setLocation(location);
									daysLocRes.setDaysFromToResponse(dftr);
								} else {
									List<DaysFromToResponse> dftrlst = daysLocRes
											.getDaysFromToResponse();
									dftrlst.add(daysRes);
									daysLocRes.setDaysFromToResponse(dftrlst);
								}
							}
						}
					}
					if (daysLocRes != null && daysLocRes.getLocation() != null
							&& daysLocRes.getLocation().length() > 0) {
						daysLocResLst.add(daysLocRes);
					}
					if (daysLocResLst.size() > 0) {

						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj
								.writeValueAsString(daysLocResLst);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllOrganizationWorkingLocationHoursWithNames() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<Object> objlst = orgWorkLocHrsRepository
					.getAllOrganizationWorkingLocationHoursWithNames();
			List<OrganizationWorkingLocationHoursResponse> owhrst = new ArrayList<OrganizationWorkingLocationHoursResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 4) {
						Date frmDt = null;
						Date toDt = null;
						OrganizationWorkingLocationHours owlh = (OrganizationWorkingLocationHours) arr[0];

						WorkingLocation wl = wrkingLocDao
								.findByWorkingLocationCode(owlh
										.getWorkingLocationCode().trim());

						OrganizationWorkingLocationHoursResponse owl = new OrganizationWorkingLocationHoursResponse();

						if (wl != null && wl.getId() > 0
								&& wl.getTimeZone() != null
								&& wl.getTimeZone().trim().length() > 0) {
							TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());	
                                                            String timezone = tzd.getTimeZoneName();
                                                            if(timezone!=null && timezone.length()>0 )
                                                            {
							Date fromDate = owlh.getFromDate();
							frmDt = GigflexDateUtil.getGMTtoLocationDate(
									fromDate, timezone, "yyyy-MM-dd HH:mm:ss");
							Date toDate = owlh.getToDate();
							toDt = GigflexDateUtil.getGMTtoLocationDate(toDate,
									timezone, "yyyy-MM-dd HH:mm:ss");
                                                            }
						}

						owl.setId(owlh.getId());
						owl.setDayCode(owlh.getDayCode());
						owl.setFromDate(frmDt);
						owl.setToDate(toDt);
						owl.setOrganizationCode(owlh.getOrganizationCode());
						owl.setWorkingLocationCode(owlh
								.getWorkingLocationHoursCode());
						owl.setLocation((String) arr[1]);
						owl.setDaysName((String) arr[2]);
						owl.setOrganizationName((String) arr[3]);

						owhrst.add(owl);
					}

				}

				if (owhrst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(owhrst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getOrganizationWorkingLocationHoursWithNamesByPage(int page,
			int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        if(limit>0){
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<Object> objlst = orgWorkLocHrsRepository
					.getAllOrganizationWorkingLocationHoursWithNames(pageableRequest);
			List<OrganizationWorkingLocationHoursResponse> owhrst = new ArrayList<OrganizationWorkingLocationHoursResponse>();
			if (objlst != null && objlst.size() > 0) {
                            int count=0;
                            List<Object> objlstcnt = orgWorkLocHrsRepository.getAllOrganizationWorkingLocationHoursWithNames();
                            if(objlstcnt!=null && objlstcnt.size()>0)
                            {
                                count=objlstcnt.size();
                            }
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 4) {
						Date frmDt = null;
						Date toDt = null;
						OrganizationWorkingLocationHours owlh = (OrganizationWorkingLocationHours) arr[0];

						WorkingLocation wl = wrkingLocDao
								.findByWorkingLocationCode(owlh
										.getWorkingLocationCode().trim());

						OrganizationWorkingLocationHoursResponse owl = new OrganizationWorkingLocationHoursResponse();

						if (wl != null && wl.getId() > 0
								&& wl.getTimeZone() != null
								&& wl.getTimeZone().trim().length() > 0) {
							TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());	
                                                            String timezone = tzd.getTimeZoneName();
                                                            if(timezone!=null && timezone.length()>0 )
                                                            {
							Date fromDate = owlh.getFromDate();
							frmDt = GigflexDateUtil.getGMTtoLocationDate(
									fromDate, timezone, "yyyy-MM-dd HH:mm:ss");
							Date toDate = owlh.getToDate();
							toDt = GigflexDateUtil.getGMTtoLocationDate(toDate,
									timezone, "yyyy-MM-dd HH:mm:ss");
                                                            }
						}

						owl.setId(owlh.getId());
						owl.setDayCode(owlh.getDayCode());
						owl.setFromDate(frmDt);
						owl.setToDate(toDt);
						owl.setOrganizationCode(owlh.getOrganizationCode());
						owl.setWorkingLocationCode(owlh
								.getWorkingLocationHoursCode());
						owl.setLocation((String) arr[1]);
						owl.setDaysName((String) arr[2]);
						owl.setOrganizationName((String) arr[3]);

						owhrst.add(owl);
					}

				}

				if (owhrst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(owhrst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
                                        jsonobj.put("count", count);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
                        } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			if (search != null && search.trim().length() > 0) {
				JSONObject jsonobj = new JSONObject();

				OrganizationWorkingLocationHoursSpecificationsBuilder builder = new OrganizationWorkingLocationHoursSpecificationsBuilder();
				Pattern pattern = Pattern
						.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
				java.util.regex.Matcher matcher = pattern.matcher(search + ",");
				while (matcher.find()) {
					builder.with(matcher.group(1), matcher.group(2),
							matcher.group(3));
				}

				Specification<OrganizationWorkingLocationHours> spec = builder
						.build();
				if (spec != null) {
					List<OrganizationWorkingLocationHours> orgWrLcHrs = orgWorkLocHrsRepository
							.findAll(spec);
					if (orgWrLcHrs != null && orgWrLcHrs.size() > 0) {
						for (OrganizationWorkingLocationHours owl : orgWrLcHrs) {

							Date frmDt = null;
							Date toDt = null;
							WorkingLocation wl = null;
							if (owl != null) {
								if (owl.getWorkingLocationCode() != null
										&& owl.getWorkingLocationCode().trim()
												.length() > 0) {
									wl = wrkingLocDao
											.findByWorkingLocationCode(owl
													.getWorkingLocationCode());
								}
								if (wl != null && wl.getId() > 0
										&& wl.getTimeZone() != null
										&& wl.getTimeZone().trim().length() > 0) {
									try {
										TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(wl.getTimeZone());	
                                                            String timezone = tzd.getTimeZoneName();
                                                            if(timezone!=null && timezone.length()>0 )
                                                            {
										Date fromDate = owl.getFromDate();
										frmDt = GigflexDateUtil
												.getGMTtoLocationDate(fromDate,
														timezone,
														"yyyy-MM-dd HH:mm:ss");
										Date toDate = owl.getToDate();
										toDt = GigflexDateUtil
												.getGMTtoLocationDate(toDate,
														timezone,
														"yyyy-MM-dd HH:mm:ss");
                                                            }
										owl.setFromDate(frmDt);
										owl.setToDate(toDt);

									} catch (Exception e) {
										e.printStackTrace();
									}
								}
								if (owl.getIsDeleted() != null
										&& owl.getIsDeleted() != true) {

									ObjectMapper mapperObj = new ObjectMapper();
									String Detail = mapperObj
											.writeValueAsString(owl);
									JSONObject jsonobjNew = new JSONObject();
									jsonobjNew.put(
											"OrganizationWorkingLocationHours",
											new JSONObject(Detail));
									jarr.add(jsonobjNew);

								}

							}
							if (jarr.size() > 0) {

								jsonobj.put("responsecode", 200);
								jsonobj.put("message", "Success");
								jsonobj.put("timestamp", new Date());
								jsonobj.put("data", jarr);
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("message", "Record Not Found!");
								jsonobj.put("timestamp", new Date());
							}
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Record Not Found!");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Record Not Found!");
					jsonobj.put("timestamp", new Date());
				}
				res = jsonobj.toString();

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Input data is not valid.");
				res = derr.toString();

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	// @Override
	// public String getOrganizationWorkingLocationHoursByOrganizationCode(
	// String organizationCode, int page, int limit) {
	// String res = "";
	// try {
	// JSONObject jsonobj = new JSONObject();
	// Pageable pageableRequest = PageRequest.of(page, limit);
	// if (organizationCode != null
	// && organizationCode.trim().length() > 0) {
	//
	// List<String> pageLoc = orgWorkLocHrsRepository
	// .getWorkingLocationByOrganizationCode(organizationCode,
	// pageableRequest);
	// if (pageLoc != null && pageLoc.size()>0) {
	//
	// List<Object> objlst = orgWorkLocHrsRepository
	// .getOrgWorkingLocHrsByOrganizationCodeWithLocation(
	// organizationCode, pageLoc);
	//
	// List<DaysLocationFromToResponse> daysLocResLst = new
	// ArrayList<DaysLocationFromToResponse>();
	//
	// DaysLocationFromToResponse daysLocRes = new DaysLocationFromToResponse();
	//
	// if (objlst != null && objlst.size() > 0) {
	// for (int i = 0; i < objlst.size(); i++) {
	// Object[] arr = (Object[]) objlst.get(i);
	// if (arr.length >= 3) {
	//
	// OrganizationWorkingLocationHours orgWrLc =
	// (OrganizationWorkingLocationHours) arr[0];
	//
	// String location = (String) arr[1];
	// String daysName = (String) arr[2];
	//
	// DaysFromToResponse daysRes = new DaysFromToResponse();
	// daysRes.setDaysName(daysName);
	// daysRes.setFromDate(orgWrLc.getFromDate());
	// daysRes.setToDate(orgWrLc.getToDate());
	// if (i == 0) {
	// List<DaysFromToResponse> dftr = new ArrayList<DaysFromToResponse>();
	// dftr.add(daysRes);
	// daysLocRes.setLocation(location);
	// daysLocRes.setDaysFromToResponse(dftr);
	// } else {
	// if (daysLocRes.getLocation() != null
	// && !(daysLocRes.getLocation()
	// .equalsIgnoreCase(location))) {
	// daysLocResLst.add(daysLocRes);
	// daysLocRes = new DaysLocationFromToResponse();
	// List<DaysFromToResponse> dftr = new ArrayList<DaysFromToResponse>();
	// dftr.add(daysRes);
	// daysLocRes.setLocation(location);
	// daysLocRes.setDaysFromToResponse(dftr);
	// } else {
	// List<DaysFromToResponse> dftrlst = daysLocRes
	// .getDaysFromToResponse();
	// dftrlst.add(daysRes);
	// daysLocRes
	// .setDaysFromToResponse(dftrlst);
	// }
	// }
	// }
	// }
	// if (daysLocRes != null
	// && daysLocRes.getLocation() != null
	// && daysLocRes.getLocation().length() > 0) {
	// daysLocResLst.add(daysLocRes);
	// }
	// if (daysLocResLst.size() > 0) {
	//
	// ObjectMapper mapperObj = new ObjectMapper();
	// String Detail = mapperObj
	// .writeValueAsString(daysLocResLst);
	// jsonobj.put("responsecode", 200);
	// jsonobj.put("message", "Success");
	// jsonobj.put("timestamp", new Date());
	// jsonobj.put("data", new JSONArray(Detail));
	// } else {
	// jsonobj.put("responsecode", 404);
	// jsonobj.put("message", "Record Not Found");
	// jsonobj.put("timestamp", new Date());
	// }
	// } else {
	// jsonobj.put("responsecode", 404);
	// jsonobj.put("message", "Record Not Found");
	// jsonobj.put("timestamp", new Date());
	// }
	// } else {
	// jsonobj.put("responsecode", 404);
	// jsonobj.put("message", "Record Not Found");
	// jsonobj.put("timestamp", new Date());
	// }
	// } else {
	// jsonobj.put("responsecode", 404);
	// jsonobj.put("message", "Organization Code should not be blank");
	// jsonobj.put("timestamp", new Date());
	// }
	// res = jsonobj.toString();
	// } catch (JSONException ex) {
	// GigflexResponse derr = new GigflexResponse(500, new Date(),
	// "JSON parsing exception is occurred.");
	// res = derr.toString();
	// ex.printStackTrace();
	// } catch (Exception ex) {
	// GigflexResponse derr = new GigflexResponse(500, new Date(),
	// "Exception is occurred.");
	// res = derr.toString();
	// ex.printStackTrace();
	// }
	// return res;
	// }

	@Override
	public String getOrganizationWorkingLocationHoursByOrganizationCode(
			String organizationCode, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        if(limit>0){
			Pageable pageableRequest = PageRequest.of(page, limit);
			if (organizationCode != null
					&& organizationCode.trim().length() > 0) {

				List<WorkingLocation> pageLoc = orgWorkLocHrsRepository.getWorkingLocationByOrganizationCode(organizationCode,
								pageableRequest);

				List<DaysLocationFromToResponse> daysLocResLst = new ArrayList<DaysLocationFromToResponse>();

				if (pageLoc != null && pageLoc.size() > 0) {
                                    int count=0;
                                    List<WorkingLocation> pageLoccnt = orgWorkLocHrsRepository.getWorkingLocationByOrganizationCode(organizationCode);
                                    if(pageLoccnt!=null && pageLoccnt.size()>0)
                                    {
                                        count=pageLoccnt.size();
                                    }
					for (WorkingLocation wl : pageLoc) {

						DaysLocationFromToResponse daysLocRes = new DaysLocationFromToResponse();
						daysLocRes.setLocation(wl.getLocation());

						List<Object> objlst = orgWorkLocHrsRepository
								.getOrgWorkingLocHrsByOrganizationCodeWithLocation(
										organizationCode,
										wl.getWorkingLocationCode());

						List<DaysFromToResponse> dftr = new ArrayList<DaysFromToResponse>();

						if (objlst != null && objlst.size() > 0) {
							for (int i = 0; i < objlst.size(); i++) {
								Object[] arr = (Object[]) objlst.get(i);
								if (arr.length >= 2) {

									DaysFromToResponse dftrl = new DaysFromToResponse();

									OrganizationWorkingLocationHours orgWrLc = (OrganizationWorkingLocationHours) arr[0];

									Date frmDt = null;
									Date toDt = null;

									WorkingLocation worLoc = wrkingLocDao
											.findByWorkingLocationCode(orgWrLc
													.getWorkingLocationCode()
													.trim());

									if (worLoc != null
											&& worLoc.getId() > 0
											&& worLoc.getTimeZone() != null
											&& worLoc.getTimeZone().trim()
													.length() > 0) {
										TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(worLoc.getTimeZone());	
                                                            String timezone = tzd.getTimeZoneName();
                                                            if(timezone!=null && timezone.length()>0 )
                                                            {
										Date fromDate = orgWrLc.getFromDate();
										frmDt = GigflexDateUtil
												.getGMTtoLocationDate(fromDate,
														timezone,
														"yyyy-MM-dd HH:mm:ss");
										Date toDate = orgWrLc.getToDate();
										toDt = GigflexDateUtil
												.getGMTtoLocationDate(toDate,
														timezone,
														"yyyy-MM-dd HH:mm:ss");
                                                            }
									}

									String daysName = (String) arr[1];

									dftrl.setDaysName(daysName);
									dftrl.setFromDate(frmDt);
									dftrl.setToDate(toDt);
									dftr.add(dftrl);
								}
							}
						}

						daysLocRes.setDaysFromToResponse(dftr);

						daysLocResLst.add(daysLocRes);

					}
					if (daysLocResLst.size() > 0) {

						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj
								.writeValueAsString(daysLocResLst);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
                                                jsonobj.put("count", count);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
                        } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

}
