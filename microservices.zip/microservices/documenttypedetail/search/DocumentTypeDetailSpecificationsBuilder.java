package com.gigflex.prototype.microservices.documenttypedetail.search;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.gigflex.prototype.microservices.documenttypedetail.dtob.DocumentTypeDetail;
import com.gigflex.prototype.microservices.util.SearchCriteria;




public class DocumentTypeDetailSpecificationsBuilder {
	private final List<SearchCriteria> params;
	 
    public DocumentTypeDetailSpecificationsBuilder() {
        params = new ArrayList<SearchCriteria>();
    }
 
    public DocumentTypeDetailSpecificationsBuilder with(String key, String operation, Object value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }
 
    public Specification<DocumentTypeDetail> build() {
        if (params.size() == 0) {
            return null;
        }
 
        List<Specification<DocumentTypeDetail>> specs = new ArrayList<Specification<DocumentTypeDetail>>();
        for (SearchCriteria param : params) {
            specs.add(new DocumentTypeDetailSpecification(param));
        }
 
        Specification<DocumentTypeDetail> result = specs.get(0);
        for (int i = 1; i < specs.size(); i++) {
            result = Specification.where(result).and(specs.get(i));
        }
        return result;
    }
}
