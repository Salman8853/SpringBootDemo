package com.gigflex.prototype.microservices.documenttypedetail.service.impl;

import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


import com.gigflex.prototype.microservices.documenttypedetail.dtob.DocumentTypeDetail;
import com.gigflex.prototype.microservices.documenttypedetail.dtob.DocumentTypeDetailRequest;
import com.gigflex.prototype.microservices.documenttypedetail.repository.DocumentTypeDetailRepository;
import com.gigflex.prototype.microservices.documenttypedetail.search.DocumentTypeDetailSpecificationsBuilder;
import com.gigflex.prototype.microservices.documenttypedetail.service.DocumentTypeDetailService;

import com.gigflex.prototype.microservices.util.GigflexResponse;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

@Service
public class DocumentTypeDetailServiceImpl implements DocumentTypeDetailService {

	@Autowired
	DocumentTypeDetailRepository docTypeDetDao;

	
	
	@Override
	public String getAllDocumentTypeDetail() {
		 String res = "";
		 try {
		 JSONObject jsonobj = new JSONObject();
		 List<DocumentTypeDetail> docTypeLst = docTypeDetDao.getAllDocumentTypeDetail();
		
		 if (docTypeLst != null && docTypeLst.size() > 0) {
		 jsonobj.put("responsecode", 200);
		 jsonobj.put("message", "Success");
		 jsonobj.put("timestamp", new Date());
		 ObjectMapper mapperObj = new ObjectMapper();
		 String Detail = mapperObj.writeValueAsString(docTypeLst);
		 jsonobj.put("data", new JSONArray(Detail));
		 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("message", "Record Not Found.");
		 jsonobj.put("timestamp", new Date());
		 }
		 res = jsonobj.toString();
		 } catch (JSONException | JsonProcessingException ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "JSON parsing exception occurred.");
		 res = derr.toString();
		 } catch (Exception ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "Exception occurred.");
		 res = derr.toString();
		 }
		 return res;

		
	}

	@Override
	public String getDocumentTypeDetailById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			DocumentTypeDetail docTypeLst = docTypeDetDao
					.getDocumentTypeDetailById(id);
			if (docTypeLst != null && docTypeLst.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(docTypeLst);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getDocumentTypeDetailByDocumentCode(String documentCode) {
		 String res = "";
		 try {
		 JSONObject jsonobj = new JSONObject();
                 if(documentCode!=null && documentCode.trim().length()>0)
                        {
		 DocumentTypeDetail docTypeLst = docTypeDetDao
		 .getDocumentTypeDetailByDocumentCode(documentCode);
		 if (docTypeLst != null && docTypeLst.getId() > 0) {
		 ObjectMapper mapperObj = new ObjectMapper();
		 String Detail = mapperObj.writeValueAsString(docTypeLst);
		 jsonobj.put("responsecode", 200);
		 jsonobj.put("timestamp", new Date());
		 jsonobj.put("message", "Success");
		 jsonobj.put("data", new JSONObject(Detail));
		
		 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("timestamp", new Date());
		 jsonobj.put("message", "Record Not Found");
		 }
                 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("timestamp", new Date());
		 jsonobj.put("message", "Document code should not be blank.");
		 }
		 res = jsonobj.toString();
		 } catch (JSONException | JsonProcessingException ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "JSON parsing exception occurred.");
		 res = derr.toString();
		 ex.printStackTrace();
		 } catch (Exception ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "Exception is occurred.");
		 res = derr.toString();
		 ex.printStackTrace();
		 }
		 return res;

		
	}

	@Override
	public String saveNewDocumentTypeDetail(
			DocumentTypeDetailRequest docTypeDetReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (docTypeDetReq != null) {

				if (docTypeDetReq.getDocumentName() != null
						&& docTypeDetReq.getDocumentName().trim().length() > 0
						) {

					
						

						DocumentTypeDetail docType = docTypeDetDao
								.getDocumentTypeDetailByDocumentName(
										docTypeDetReq.getDocumentName().trim());

						if (docType != null && docType.getId() > 0) {
							jsonobj.put("responsecode", 409);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Record already exist.");
						} else {

							DocumentTypeDetail docTypeLst = new DocumentTypeDetail();
							
							docTypeLst.setDocumentName(docTypeDetReq
									.getDocumentName());

							docTypeLst.setIpAddress(ip);

							DocumentTypeDetail docTypeRes = docTypeDetDao
									.save(docTypeLst);

							

							if (docTypeRes != null && docTypeRes.getId() > 0) {
								
								
								jsonobj.put("responsecode", 200);
                                                                jsonobj.put("timestamp", new Date());
								jsonobj.put("message",
										"Document Type Detail has been added successfully.");
								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj
										.writeValueAsString(docTypeRes);
								jsonobj.put("data", new JSONObject(Detail));
							} else {
                                                            jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Failed");
							}
						}
					
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Document Name should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String updateDocumentTypeDetailById(Long id,
			DocumentTypeDetailRequest docTypeDetReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (id > 0 && docTypeDetReq != null) {

				if (docTypeDetReq.getDocumentName() != null
						&& docTypeDetReq.getDocumentName().trim().length() > 0) {

					

						DocumentTypeDetail docTypeLst = docTypeDetDao.getDocumentTypeDetailById(id);
						if (docTypeLst != null && docTypeLst.getId() > 0) {

							DocumentTypeDetail docTypeL = docTypeDetDao.getDocumentTypeDetailByNotIdDocumentName(id,docTypeDetReq.getDocumentName());

							if (docTypeL != null && docTypeL.getId() > 0) {
								jsonobj.put("responsecode", 409);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Record already exist.");
							} else {

								DocumentTypeDetail docType = docTypeLst;
								
								docTypeLst.setDocumentName(docTypeDetReq
										.getDocumentName());
								docType.setIpAddress(ip);

								DocumentTypeDetail docTypeRes = docTypeDetDao
										.save(docType);
								if (docTypeRes != null
										&& docTypeRes.getId() > 0) {
									
									
									jsonobj.put("responsecode", 200);
									jsonobj.put("message",
											"Document Type Detail updation has been done");
									jsonobj.put("timestamp", new Date());
									ObjectMapper mapperObj = new ObjectMapper();
									String Detail = mapperObj
											.writeValueAsString(docTypeRes);
									jsonobj.put("data", new JSONObject(Detail));
								} else {
									jsonobj.put("responsecode", 400);
									jsonobj.put("message",
											"Document Type Detail updation has been failed.");
									jsonobj.put("timestamp", new Date());
								}
							}
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message",
									"Document Type Detail ID is not valid.");
							jsonobj.put("timestamp", new Date());
						}
					
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Document Name should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String softDeleteByDocumentCode(String documentCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        if(documentCode!=null && documentCode.trim().length()>0)
                        {
			DocumentTypeDetail docTypeLst = docTypeDetDao
					.getDocumentTypeDetailByDocumentCode(documentCode.trim());

			if (docTypeLst != null && docTypeLst.getId() > 0) {
				docTypeLst.setIsDeleted(true);
				DocumentTypeDetail docTypeRes = docTypeDetDao.save(docTypeLst);
				if (docTypeRes != null && docTypeRes.getId() > 0) {
					
					
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message",
							"Document Type Detail deleted successfully.");
					// kafkaService.sendRoleMasterUpdate(roleRes);
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
                        } else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Document code should not be blank.");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteByDocumentCode(List<String> documentCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String documentCode : documentCodeList) {
				if (documentCode != null && documentCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					documentCode = documentCode.trim();

					DocumentTypeDetail docTypeLst = docTypeDetDao
							.getDocumentTypeDetailByDocumentCode(documentCode);

					if (docTypeLst != null && docTypeLst.getId() > 0) {

						docTypeLst.setIsDeleted(true);
						DocumentTypeDetail docTypeRes = docTypeDetDao
								.save(docTypeLst);
						if (docTypeRes != null && docTypeRes.getId() > 0) {
							
							
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", documentCode);
							jsonobj.put("message",
									"Document Type Detail deleted successfully.");
							// kafkaService.se
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", documentCode);
							jsonobj.put("message", "Failed");
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", documentCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getAllDocumentTypeDetailByPgae(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                         if (limit > 0) {
			Pageable pageableRequest = PageRequest.of(page, limit);

			List<DocumentTypeDetail> objlst = docTypeDetDao.getAllDocumentTypeDetail(pageableRequest);
                        int count=0;
                        List<DocumentTypeDetail> listCnt = docTypeDetDao.getAllDocumentTypeDetail();
                        if(listCnt!=null)
                        {
                        count=listCnt.size();
                        }
			
				if (objlst!=null && objlst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(objlst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
                                        jsonobj.put("count", count);
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			
                        } else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("message", "Limit should not be Zero or Negative.");
                jsonobj.put("timestamp", new Date());
            }

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			if (search != null && search.trim().length() > 0) {
				JSONObject jsonobj = new JSONObject();

				DocumentTypeDetailSpecificationsBuilder builder = new DocumentTypeDetailSpecificationsBuilder();
				Pattern pattern = Pattern
						.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
				java.util.regex.Matcher matcher = pattern.matcher(search + ",");
				while (matcher.find()) {
					builder.with(matcher.group(1), matcher.group(2),
							matcher.group(3));
				}

				Specification<DocumentTypeDetail> spec = builder.build();
				if (spec != null) {
					List<DocumentTypeDetail> DocumentTypeDetailLst = docTypeDetDao
							.findAll(spec);
					if (DocumentTypeDetailLst != null
							&& DocumentTypeDetailLst.size() > 0) {
						for (DocumentTypeDetail dept : DocumentTypeDetailLst) {
							if (dept.getIsDeleted() != null
									&& dept.getIsDeleted() != true) {

								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj
										.writeValueAsString(dept);
								JSONObject jsonobjNew = new JSONObject();
								jsonobjNew.put("DocumentTypeDetail",
										new JSONObject(Detail));
								jarr.add(jsonobjNew);

							}

						}
						if (jarr.size() > 0) {

							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "Success");
							jsonobj.put("timestamp", new Date());
							jsonobj.put("data", jarr);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "Record Not Found!");
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Record Not Found!");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Record Not Found!");
					jsonobj.put("timestamp", new Date());
				}
				res = jsonobj.toString();

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Input data is not valid.");
				res = derr.toString();

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
		}
		return res;
	}

    @Override
    public String getDocumentTypeDetailByDocumentName(String documentName) {
        
		 String res = "";
		 try {
		 JSONObject jsonobj = new JSONObject();
                 if(documentName!=null && documentName.trim().length()>0)
                        {
		 DocumentTypeDetail docTypeLst = docTypeDetDao
		 .getDocumentTypeDetailByDocumentName(documentName);
		 if (docTypeLst != null && docTypeLst.getId() > 0) {
		 ObjectMapper mapperObj = new ObjectMapper();
		 String Detail = mapperObj.writeValueAsString(docTypeLst);
		 jsonobj.put("responsecode", 200);
		 jsonobj.put("timestamp", new Date());
		 jsonobj.put("message", "Success");
		 jsonobj.put("data", new JSONObject(Detail));
		
		 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("timestamp", new Date());
		 jsonobj.put("message", "Record Not Found");
		 }
                 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("timestamp", new Date());
		 jsonobj.put("message", "Document name should not be blank.");
		 }
		 res = jsonobj.toString();
		 } catch (JSONException | JsonProcessingException ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "JSON parsing exception occurred.");
		 res = derr.toString();
		 ex.printStackTrace();
		 } catch (Exception ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "Exception is occurred.");
		 res = derr.toString();
		 ex.printStackTrace();
		 }
		 return res;

		
	
    }

	

}
