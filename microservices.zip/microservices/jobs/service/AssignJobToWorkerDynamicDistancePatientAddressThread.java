/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.jobs.service;

import com.gigflex.prototype.microservices.jobs.dtob.Jobs;
import com.gigflex.prototype.microservices.jobs.dtob.JobsAssignToWorker;
import com.gigflex.prototype.microservices.jobs.dtob.JobsDuration;
import com.gigflex.prototype.microservices.jobs.repository.JobsAssignToWorkerRepository;
import com.gigflex.prototype.microservices.patient.dtob.PatientDetails;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexDateUtil;
import com.gigflex.prototype.microservices.util.GoogleDistanceDuration;
import com.gigflex.prototype.microservices.util.GoogleDistanceDurationResponse;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AssignJobToWorkerDynamicDistancePatientAddressThread implements Runnable {

    private static final Logger LOG = LoggerFactory.getLogger(AssignJobToWorkerDynamicDistancePatientAddressThread.class);
    private PatientDetails pdetails;
    private JobsAssignToWorkerRepository jobsAssignToWorkerRepository;
    private Date startDate;
    private String timeZone;
    private String googleAPIKEY;

    public AssignJobToWorkerDynamicDistancePatientAddressThread(PatientDetails pdetails, JobsAssignToWorkerRepository jobsAssignToWorkerRepository, Date startDate, String timeZone, String googleAPIKEY) {
        super();
        this.pdetails = pdetails;
        this.jobsAssignToWorkerRepository = jobsAssignToWorkerRepository;
        this.startDate = startDate;
        this.googleAPIKEY = googleAPIKEY;
        this.timeZone = timeZone;
    }

    @Override
    public void run() {
        LOG.info("================Start AssignJobToWorkerDynamicDistancePatientAddressThread===============");
        try {
            if (pdetails != null && startDate != null && timeZone != null) {
                Date localStartDate = GigflexDateUtil.getGMTtoLocationDate(startDate, timeZone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                if (localStartDate != null) {
                    String sDate = GigflexDateUtil.convertDateToString(localStartDate, GigflexConstants.YYYY_MM_DD);
                    if (sDate != null && sDate.length() > 0) {
                        List<String> stlst = new ArrayList<String>();
                        stlst.add(GigflexConstants.JOBSTATUS_ASSIGNED);
                        stlst.add(GigflexConstants.JOBSTATUS_INPROGRESS);
                        stlst.add(GigflexConstants.JOBSTATUS_ACCEPTED);
                        stlst.add(GigflexConstants.JOBSTATUS_COMPLETED);
                        String sdtStr = sDate + " 00:00:00";

                        Date sDT = GigflexDateUtil.convertStringDateToGMT(sdtStr, timeZone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                        Date sDTPeriod = GigflexDateUtil.convertStringToDate(sdtStr, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                        if (sDT != null && sDTPeriod != null) {
                            //  HashMap <String,Worker> workerMap=new HashMap<>();
                            HashMap<String, PatientDetails> patientMap = new HashMap<>();
                            // HashMap <String,Double> jobDurationDistanceMap=new HashMap<>();
                            HashMap<String, String> startDatePatientCodeMap = new HashMap<>();
                            List<Object> objlst = jobsAssignToWorkerRepository.getAllJobsByWorkerCodeWithFilterForChangePatientAddressThread(pdetails.getOrganizationCode(), stlst, sDT);
                            if (objlst != null && objlst.size() > 0) {
                                for (int i = 0; i < objlst.size(); i++) {
                                    Object[] arr = (Object[]) objlst.get(i);
                                    if (arr.length >= 4) {
                                        Jobs j = (Jobs) arr[0];
                                        JobsDuration jd = (JobsDuration) arr[1];
                                        JobsAssignToWorker aws = (JobsAssignToWorker) arr[2];
                                        PatientDetails pDetail = (PatientDetails) arr[3];
                                        Worker worker = (Worker) arr[4];
                                        if (j != null && jd != null && aws != null && pDetail != null && worker != null) {

//                                    if(!workerMap.containsKey(aws.getWorkerCode()))
//                                {
//                                   
//                                        workerMap.put(aws.getWorkerCode(), wkr);
//                                    
//                                }
                                            if (!patientMap.containsKey(j.getPatientCode())) {

                                                patientMap.put(j.getPatientCode(), pDetail);

                                            }

                                            if (timeZone != null && timeZone.length() > 0) {
                                                Date startDate = jd.getStartTime();
                                                startDate = GigflexDateUtil.getGMTtoLocationDate(startDate, timeZone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                                                String startDt = GigflexDateUtil.convertDateToString(startDate, GigflexConstants.YYYY_MM_DD);
                                                startDt += "$" + aws.getWorkerCode();
                                                if (!startDatePatientCodeMap.containsKey(startDt)) {
                                                    if (worker != null && worker.getId() > 0) {
                                                        PatientDetails pdSource = patientMap.get(j.getPatientCode());
                                                        if (pdSource != null && pdSource.getId() > 0) {
                                                            GoogleDistanceDurationResponse gddres = getGoogleDistanceDurationResponse(worker.getLatitude(), worker.getLongitude(), pdSource.getPatientLatitude(), pdSource.getPatientLongitude());
                                                            if (gddres != null && gddres.getDistanceValue() != null && gddres.getDurationValue() != null) {
                                                                try {
                                                                    if (aws.getStatus().equalsIgnoreCase(GigflexConstants.JOBSTATUS_ASSIGNED) || aws.getStatus().equalsIgnoreCase(GigflexConstants.JOBSTATUS_ACCEPTED)) {
                                                                        double mileCon = 1609.344;
                                                                        Double distance = gddres.getDistanceValue() / mileCon;
                                                                        aws.setDistance(distance);
                                                                        aws.setDrivingTimeInSec(gddres.getDurationValue());
                                                                        jobsAssignToWorkerRepository.save(aws);
                                                                    }
                                                                } catch (Exception ee) {
                                                                    LOG.error("Error in AssignJobToWorkerDynamicDistancePatientAddressThread save dynamic distance>>>>>>", ee);
                                                                }
                                                            }
                                                        }
                                                    }
                                                    startDatePatientCodeMap.put(startDt, j.getPatientCode());
                                                } else {
                                                    String pcode = startDatePatientCodeMap.get(startDt);
                                                    if (pcode != null) {
                                                        PatientDetails pd = patientMap.get(pcode);
                                                        if (pd != null && pd.getId() > 0) {
                                                            PatientDetails pdSource = patientMap.get(j.getPatientCode());
                                                            if (pdSource != null && pdSource.getId() > 0) {
                                                                GoogleDistanceDurationResponse gddres = getGoogleDistanceDurationResponse(pd.getPatientLatitude(), pd.getPatientLongitude(), pdSource.getPatientLatitude(), pdSource.getPatientLongitude());
                                                                if (gddres != null && gddres.getDistanceValue() != null && gddres.getDurationValue() != null) {
                                                                    try {
                                                                        if (aws.getStatus().equalsIgnoreCase(GigflexConstants.JOBSTATUS_ASSIGNED) || aws.getStatus().equalsIgnoreCase(GigflexConstants.JOBSTATUS_ACCEPTED)) {
                                                                            double mileCon = 1609.344;
                                                                            Double distance = gddres.getDistanceValue() / mileCon;
                                                                            aws.setDistance(distance);
                                                                            aws.setDrivingTimeInSec(gddres.getDurationValue());
                                                                            jobsAssignToWorkerRepository.save(aws);
                                                                        }
                                                                    } catch (Exception ee) {
                                                                        LOG.error("Error in AssignJobToWorkerDynamicDistancePatientAddressThread save dynamic distance>>>>>>", ee);
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                    startDatePatientCodeMap.put(startDt, j.getPatientCode());
                                                }
                                            }

                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                LOG.info("AssignJobToWorkerDynamicDistancePatientAddressThread >>>>>> in ELSE");
            }
        } catch (Exception e) {
            LOG.error("Error in AssignJobToWorkerDynamicDistancePatientAddressThread >>>>>>", e);
        }
        LOG.info("================End AssignJobToWorkerDynamicDistancePatientAddressThread===============");
    }

    private GoogleDistanceDurationResponse getGoogleDistanceDurationResponse(String lat1, String lon1, String lat2, String lon2) {
        try {
            if (lat1 != null && lat1.trim().length() > 0 && lon1 != null && lon1.trim().length() > 0 && lat2 != null && lat2.trim().length() > 0 && lon2 != null && lon2.trim().length() > 0) {
                GoogleDistanceDurationResponse res = GoogleDistanceDuration.getGoogleDistanceDuration(googleAPIKEY, lat1.trim(), lon1.trim(), lat2.trim(), lon2.trim());
                if (res != null && res.getStatus()) {

                    return res;

                }
            }
        } catch (Exception e) {
            LOG.error("Error in getGoogleDistanceDurationResponse>>>", e);
        }
        return null;
    }
}
