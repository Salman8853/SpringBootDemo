/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.jobs.service;

import com.gigflex.prototype.microservices.jobs.dtob.AssignToWorkerReq;
import com.gigflex.prototype.microservices.jobs.dtob.AssignToWorkerReqNew;
import com.gigflex.prototype.microservices.jobs.dtob.AssignToWorkerStatusReq;
import com.gigflex.prototype.microservices.jobs.dtob.AssignWorkerInProgerssStatusReq;
import com.gigflex.prototype.microservices.jobs.dtob.CancelToworkerReq;
import com.gigflex.prototype.microservices.jobs.dtob.JobDurationUpdate;
import com.gigflex.prototype.microservices.jobs.dtob.JobsRequest;
import com.gigflex.prototype.microservices.jobs.dtob.JobsUpdateRequest;
import com.gigflex.prototype.microservices.jobs.dtob.RejectToworkerreq;
import java.util.List;

/**
 *
 * @author nirbhay.p
 */
public interface JobsService {

    /**
     *
     * @param jobr
     * @param ip
     * @return
     */
    public String createWorkerJob(JobsRequest jobr, String ip);
    public String getWorkerJobById(Long id);
    public String getWorkerJobByJobCode(String jobCode);
    public String getBasicWorkerJobByJobCode(String jobCode);
    public String getWorkerJobDurationByJobDurationCode(String jobDurationCode);
    public String getJobsAssignToWorkerByJobsCode(String jobCode);
    public String getJobsAssignToWorkerByJobsCodeSpecialRes(String jobCode);
    public String getJobsAssignToWorkerByJobAssignToWorkerCode(String jobAssignToWorkerCode);
    public String getJobsAssignToWorkerByJobsCodeAndJobDurationCode(String jobCode,String jobDurationCode);
    public String assignToWorkerByJobCodeAndJobDurationCode(AssignToWorkerReq req,String jobCode,String jobDurationCode,String ip);
    public String assignToWorkerByJobAssignToWorkerCode(AssignToWorkerReq req,String jobAssignToWorkerCode,String ip);
    public String assignToWorkerAccepted(AssignToWorkerStatusReq req,String jobAssignToWorkerCode,String ip);
    public String assignToWorkerRejected(AssignToWorkerStatusReq req,String jobAssignToWorkerCode,String ip);
    public String getAllJobsByWorkerCodeWithFilterByPage(String workerCode, List<String> status, String stratDT, String endDT, int page, int limit);
    
    public String gettodaysAppoinmentsforMobileByworkerCode( String workerCode);

    public String assignToWorkerByJobDurationCode(AssignToWorkerReqNew wsr, String jobDurationCode, String remoteHost);

    public String getEligibleWorkerForJobsByJobDurationCode(String jobDurationCode);
    
    public String assignToWorkerAcceptedByJobDurationCode(AssignToWorkerReqNew wsr, String jobDurationCode, String remoteHost);
    
     public String assignToWorkerrejectedByJobDurationCode(RejectToworkerreq Req,String jobdurationCode,String remoteHost);
     
     public String assignToWorkercancelByJobDurationCode( CancelToworkerReq Req, String jobDurationCode, String remoteHost);
     
     public String assignToWorkerInProgressByJobDurationCode(AssignWorkerInProgerssStatusReq Req, String jobDurationCode, String remoteHost);
     
     public String assignToWorkercompleteByJobDurationCode(AssignWorkerInProgerssStatusReq Req,String jobDurationCode, String remoteHost);
     
     public String assignToWorkerPendingByJobDurationCode(RejectToworkerreq Req,String jobDurationCode,String remoteHost);
     
     public String assignToWorkerexpiredByJobDurationCode(CancelToworkerReq Req,String jobDurationCode,String remoteHost);

    public String updateJobDurationByJobDurationCode(String jobDurationCode,JobDurationUpdate jobDurationUpdate, String ip);

    public String getJobForDashboardByOrganizationCode(String organizationCode,String startDT,String endDT);

    public String getAllJobsByOrganizationCodeWithFilterByPage(String organizationCode, List<String> status, String startDT, String endDT, int page, int limit);

    public String updateWorkerJobSeriesByJobsCode(String jobCode, JobsUpdateRequest wsr, String ip);

    public String getAllJobsByOrganizationCodeWithFilter(String organizationCode, List<String> status, String startDT, String endDT);

    public String getAllJobsByOrganizationCodeWithFilter(String organizationCode, List<String> status, String startDT, String endDT, String patientCode);

    public String getAppointmentDetailOfTechnicianByOrganizationCode(String organizationCode, List<String> status, String startDT, String endDT);

    public String getAllJobsByOrganizationCodeWithFilterDateTime(String organizationCode, List<String> status, String startDT, String endDT);

    public String getDistanceCoveredByTechnician(String workerCode, String startDT, String endDT);
      
    public String getAllJobsByOrganizationCodeWithFilterForTest(String organizationCode, List<String> status, String startDT, String endDT);
    
    public String getAppointmentDetailOfTechnicianByOrganizationCodeForTest(String organizationCode, List<String> status, String startDT, String endDT);

    public String getAppointmentDetailOfTechnicianByOrganizationCodeByPage(String organizationCode, List<String> status, String startDT, String endDT, int page, int limit);

    public String getFullJobDetailsByJobDurationCode(String jobDurationCode);
}
