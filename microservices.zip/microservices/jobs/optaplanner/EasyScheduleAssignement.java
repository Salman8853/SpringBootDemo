/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.jobs.optaplanner;


import com.gigflex.prototype.microservices.jobs.dtob.JobsAssignToWorker;
import com.gigflex.prototype.microservices.jobs.repository.JobsAssignToWorkerRepository;
import com.gigflex.prototype.microservices.patient.dtob.PatientDetails;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexDateUtil;
import com.gigflex.prototype.microservices.util.GoogleDistanceDuration;
import com.gigflex.prototype.microservices.util.GoogleDistanceDurationResponse;
import com.gigflex.prototype.microservices.workerhoursofoperation.dtob.WorkerHoursOfOperation;
import com.gigflex.prototype.microservices.workertimeoff.dtob.WorkerTimeOff;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import org.optaplanner.core.api.score.buildin.hardsoft.HardSoftScore;
import org.optaplanner.core.impl.score.director.easy.EasyScoreCalculator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author nirbhay.p
 */
public class EasyScheduleAssignement implements EasyScoreCalculator<ScheduleAssignement>{
    private static final Logger LOG = LoggerFactory.getLogger(EasyScheduleAssignement.class);
      @Override
      public HardSoftScore calculateScore(ScheduleAssignement schedulesassignement,int i)
      {
            int hardScore = 0;
            int softScore = 0; 
           List<Schedule> sslst =schedulesassignement.getScheduleList();

            for(Schedule ss:sslst)
            {

             boolean ismatch=false;
             String googleApiKey=ss.getGoogleAPIKEY();
       
             for(Worker worker:schedulesassignement.getWorkerList()) 
             {  

             if(worker.getWorkertimeof()!=null && worker.getWorkertimeof().size()>0 )
                {    Boolean timeofmatch=false;
                   for(WorkerTimeOff wt:worker.getWorkertimeof())
                   {
                       if( (( (ss.getFromdate().equals(wt.getFromDateTime())) ||  (ss.getFromdate().before(wt.getFromDateTime()))   ) &&  ( (ss.getTodate().equals(wt.getToDateTime()))  ||  (ss.getTodate().after(wt.getToDateTime())) )) ||  
                               ( (wt.getFromDateTime().before(ss.getFromdate()))  && ((wt.getToDateTime().before(ss.getTodate())) || wt.getToDateTime().equals(ss.getTodate()) ) && (wt.getToDateTime().after(ss.getFromdate())) ) || 
                               ( (wt.getToDateTime().after(ss.getTodate()))  && ((wt.getFromDateTime().after(ss.getFromdate())) || wt.getFromDateTime().equals(ss.getFromdate()) ) && (wt.getFromDateTime().before(ss.getTodate())) ) ||
                                ((wt.getFromDateTime().before(ss.getFromdate())) && (wt.getToDateTime().after(ss.getTodate()))  ) )
                       {
                          timeofmatch=true;
                            break;
                       }
                   }
                     if(timeofmatch)
                     {
                        // hardScore+=-1;
                       continue;
                     }
                     
                }
                
               if(ss.getSkillCodeList()!=null && ss.getSkillCodeList().size()>0)
               { 
                  if(worker.getSkillList()!=null && worker.getSkillList().size()>0 )
                {    
                    Boolean skillmatch=true;
                    List<String>skillList=worker.getSkillList();
                    for(String skill:ss.getSkillCodeList())
                    {
                        if(!(skillList.contains(skill)))
                        {
                            skillmatch=false;
                            break;
                        }
                    }
                   if(skillmatch!=true)
                    {
                       // hardScore+=-1;
                       continue;
                    }  
                }
                  else
                  {
                       continue;
                  }
               }
               Boolean hopNot=false;
                Date timestampStartTime =null;
               try{
               Date startDate = ss.getFromdate();
               timestampStartTime = GigflexDateUtil.getGMTtoLocationDate(startDate, ss.getOrgTimeZone(), GigflexConstants.DD_MM_YYYY_HH_MM_SS);
               
                   if (timestampStartTime != null) {
                       String stDate=GigflexDateUtil.convertDateToString(timestampStartTime, GigflexConstants.YYYY_MM_DD);
                       if(stDate!=null)
                       {
                       Calendar cal = Calendar.getInstance();
                       cal.setTime(timestampStartTime);
                       int day = cal.get(Calendar.DAY_OF_WEEK);
                      HashMap <Integer,WorkerHoursOfOperation> workerHOPMap=worker.getWorkerHOPMap();
                      if(!workerHOPMap.isEmpty())
                      {
                          if(workerHOPMap.containsKey(day))
                          {
                             WorkerHoursOfOperation whop= workerHOPMap.get(day);
                              if(whop!=null && whop.getFromTime()!=null && whop.getFromTime().length()>0 && whop.getToTime()!=null && whop.getToTime().length()>0)
                              {
                              String startDT = stDate + " "+whop.getFromTime();
                              String endDT = stDate + " "+whop.getToTime();
                            
                              Date  sDT = GigflexDateUtil.convertStringDateToGMT(startDT, worker.getWorkerTimeZone(), GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                              Date  eDT = GigflexDateUtil.convertStringDateToGMT(endDT, worker.getWorkerTimeZone(), GigflexConstants.DD_MM_YYYY_HH_MM_SS); 
                              if(sDT!=null && eDT!=null)
                              {
                                  if(sDT.after(ss.getFromdate()))
                                  {
                                      hopNot=true;
                                  }
                                  if(eDT.before(ss.getTodate()))
                                  {
                                     hopNot=true; 
                                  }
                              }
                              }
                          }
                      }
                       }
                   }
               }catch(Exception e)
               {
                   e.printStackTrace();
                   LOG.error("Error in opta date conversion>>>", e);
               }
               
               if(hopNot)
               {
                   continue;
               }
               if(!(canBusy(worker,ss))        )
               {
                   continue;

                }
               Double distc=null;
               PatientDetails pdetail=findLastPatientDeatil( worker, ss);
               if(pdetail!=null)
               {
                   distc=  distance(pdetail.getPatientLatitude(),pdetail.getPatientLongitude(), ss.getLat(),ss.getLang());
               }
               else
               {
                    distc=  distance(worker.getLat(), worker.getLang(),ss.getLat(),ss.getLang());
               }
               System.out.println("-----------worker="+worker.getWorkerCode());
                 System.out.println(">>>>>>>>>>>>distc"+distc);
               if(distc==null)
               {
                  continue;  
               }
               if(distc>ss.getWorkingDistance())
               {
                   continue; 
               }
               
               Worker oldWorker=ss.getWorker();
               ismatch=true;
               ss.setWorker(worker);
               if(ss.getDistance()==null)
               {
                ss.setDistance(distc);   
//               
//               if(ss.getLat()!=null && ss.getLang()!=null && worker.getLat()!=null && worker.getLang()!=null)
//               {
//                 Double dis=  distance(ss.getLat(),ss.getLang(), worker.getLat(), worker.getLang(),googleApiKey);
//                 ss.setDistance(dis);
//               }
               }else
               {
                  Double olddis=ss.getDistance();
//                  Double dis= null;
//                  if(ss.getLat()!=null && ss.getLang()!=null && worker.getLat()!=null && worker.getLang()!=null)
//               {
//                  dis=  distance(ss.getLat(),ss.getLang(), worker.getLat(), worker.getLang(),googleApiKey);
//                 
//               }
                  if(distc!=null )
                  {
                     if(distc<=olddis)
                     {
                     ss.setDistance(distc);
                     }
                     else
                     {
                        ss.setWorker(oldWorker); 
                     }
                  }
                  
               }
    
             }

             
              if(ismatch==false)
            {
                hardScore+=-1;
            } 
              else
              {
                  softScore--;
              }
              
              
             
            }
            
            if(softScore==0 && hardScore==0)
            {
              hardScore=-1*schedulesassignement.getScheduleList().size();
            }
      
         return HardSoftScore.valueOfInitialized(hardScore, softScore); 
      }
    
     public PatientDetails findLastPatientDeatil(Worker worker,Schedule ss)
      {
          PatientDetails pdetails=null;
          try{
          JobsAssignToWorkerRepository assignToWorkerRepository=ss.getAssignToWorkerRepository();
              
              Date localStartDate = GigflexDateUtil.getGMTtoLocationDate(ss.getFromdate(), ss.getOrgTimeZone(), GigflexConstants.DD_MM_YYYY_HH_MM_SS);
            if(localStartDate!=null && assignToWorkerRepository!=null)
            {
                String sDate=GigflexDateUtil.convertDateToString(localStartDate, GigflexConstants.YYYY_MM_DD);
                if(sDate!=null && sDate.length()>0)
                {
                    List<String> stlst = new ArrayList<String>();
                        stlst.add(GigflexConstants.JOBSTATUS_ASSIGNED);
                        stlst.add(GigflexConstants.JOBSTATUS_INPROGRESS);
                        stlst.add(GigflexConstants.JOBSTATUS_ACCEPTED);
                        stlst.add(GigflexConstants.JOBSTATUS_COMPLETED);
                    String sdtStr=sDate+" 00:00:00";
                    Date sDT=GigflexDateUtil.convertStringDateToGMT(sdtStr, ss.getOrgTimeZone(), GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                    Date eDT=ss.getFromdate();
                    if(sDT!=null && eDT!=null )
                    {
                       List<PatientDetails> pdLsit= assignToWorkerRepository.getLastPatientDetailsWithFilterInJobAssign(worker.getWorkerCode(), stlst, sDT, eDT);
                       System.out.println(">>>>in findLastPatientDeatil pdLsit size="+pdLsit.size());
                       if(pdLsit!=null && pdLsit.size()>0)
                       {
                           pdetails=pdLsit.get(pdLsit.size()-1);
                       }
                    }
                }
            }
              
              
              
              
              }catch(Exception e)
          {
              e.printStackTrace();
          }
          return pdetails;
      }
      
      public boolean canBusy(Worker worker,Schedule ss)
      {
          boolean st=true;
          try{
              JobsAssignToWorkerRepository assignToWorkerRepository=ss.getAssignToWorkerRepository();
              
           Date fromDt=ss.getFromdate();// 1may 16:00
           Date toDate=ss.getTodate();//   1may 20:00
           Calendar cal = Calendar.getInstance();

            cal.setTime(fromDt);
            cal.add(Calendar.HOUR_OF_DAY, -1);
            Date decrementedjdStartime = cal.getTime();

            cal.setTime(toDate);
            cal.add(Calendar.HOUR_OF_DAY, 1);
            Date incrementedjdEndTime = cal.getTime();
         List<JobsAssignToWorker> sslst= assignToWorkerRepository.getBusyJobsAssignToWorkerListByWorkerCode(decrementedjdStartime, incrementedjdEndTime, worker.getWorkerCode(), GigflexConstants.JOBSTATUS_CANCELLED, GigflexConstants.JOBSTATUS_REJECTED) ; 
         if(sslst!=null && sslst.size()>0)
         {
              System.out.println(">>>>canBusy="+sslst.size()+" >>>>wroer-"+worker.getWorkerCode()+" >>>"+ss.getId());
             st=false;
         }
          }catch(Exception e)
          {
              e.printStackTrace();
          }
         return st;
      }
              
    
      
     private Double distance(String lat1, String lon1, String lat2, String lon2, String googleApiKey) {
        try {
            if(lat1!=null &&lat1.trim().length()>0 && lon1!=null && lon1.trim().length()>0 && lat2!=null && lat2.trim().length()>0 && lon2!=null && lon2.trim().length()>0 )
            {
                GoogleDistanceDurationResponse res=GoogleDistanceDuration.getGoogleDistanceDuration(googleApiKey, lat1.trim(), lon1.trim(), lat2.trim(), lat2.trim());
                if(res!=null && res.getStatus())
                {
                    if(res.getDistanceValue()!=null && res.getDistanceValue()>0)
                    {
                        double mileCon=1609.344;
                        Double dis=res.getDistanceValue()/mileCon;
                        return dis;
                    }
                }
            }
        } catch (Exception e) {
            LOG.error("Error in distance>>>", e);
        }
        return null;
    }
    
     private Double distance(String lat11, String lon11, String lat22, String lon22) {
         try {
             System.out.println("lat11="+lat11+"---lon11="+lon11+"---lat22="+lat22+"---lon22"+lon22);
             double lat1 = Double.parseDouble(lat11);
             double lon1 = Double.parseDouble(lon11);
             double lat2 = Double.parseDouble(lat22);
             double lon2 = Double.parseDouble(lon22);
             double theta = lon1 - lon2;
             Double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));
             dist = Math.acos(dist);
             dist = rad2deg(dist);
             dist = dist * 60 * 1.1515;
             return (dist);
         } catch (Exception e) {
             LOG.error("Error in distance>>>", e);
         }
         return null;
     }
    
     private double deg2rad(double deg) {
        return (deg * Math.PI / 180.0);
    }
     
    private double rad2deg(double rad) {
         return (rad * 180.0 / Math.PI);
    }
    
}