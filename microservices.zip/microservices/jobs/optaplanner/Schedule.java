/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.jobs.optaplanner;


import com.gigflex.prototype.microservices.jobs.repository.JobsAssignToWorkerRepository;
import java.util.Date;
import java.util.List;
import org.optaplanner.core.api.domain.entity.PlanningEntity;
import org.optaplanner.core.api.domain.variable.PlanningVariable;

/**
 *
 * @author nirbhay.p
 */
@PlanningEntity
public class Schedule {

    
   private Long id;
   private String jobCode;
   private String jobDurationCode;
   private List<String> skillCodeList;
   private String lat;
   private String lang;
   private String googleAPIKEY;
   private Double distance;
   private Date todate;
   private Date fromdate;
   private Worker worker;
   private JobsAssignToWorkerRepository assignToWorkerRepository;
   private String orgTimeZone;
   private Double workingDistance;

    public String getOrgTimeZone() {
        return orgTimeZone;
    }

    public void setOrgTimeZone(String orgTimeZone) {
        this.orgTimeZone = orgTimeZone;
    }
   

   @PlanningVariable(valueRangeProviderRefs = {"worker"},nullable = true)
   public Worker getWorker() {
        return worker;
    }

    public void setWorker(Worker worker) {
        this.worker = worker;
    }
   
    

    public Schedule() {
    }

    public Schedule(Long id, String jobCode, String jobDurationCode, List<String> skillCodeList,Date fromdate, Date todate, String lat, String lang, JobsAssignToWorkerRepository assignToWorkerRepository,String googleAPIKEY,String orgTimeZone,Double workingDistance) {
        this.id = id;
        this.jobCode = jobCode;
        this.jobDurationCode = jobDurationCode;
        this.skillCodeList = skillCodeList;
        this.lat = lat;
        this.lang = lang;
        this.assignToWorkerRepository = assignToWorkerRepository;
        this.fromdate=fromdate;
        this.todate=todate;
        this.googleAPIKEY=googleAPIKEY;
        this.orgTimeZone=orgTimeZone;
        this.workingDistance=workingDistance;
    }

    public Double getWorkingDistance() {
        return workingDistance;
    }

    public void setWorkingDistance(Double workingDistance) {
        this.workingDistance = workingDistance;
    }

    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    
    public Date getTodate() {
        return todate;
    }

    public void setTodate(Date todate) {
        this.todate = todate;
    }

    public Date getFromdate() {
        return fromdate;
    }

    public void setFromdate(Date fromdate) {
        this.fromdate = fromdate;
    }

    public JobsAssignToWorkerRepository getAssignToWorkerRepository() {
        return assignToWorkerRepository;
    }

    public void setAssignToWorkerRepository(JobsAssignToWorkerRepository assignToWorkerRepository) {
        this.assignToWorkerRepository = assignToWorkerRepository;
    }
    
  
    public String getJobCode() {
        return jobCode;
    }

    public void setJobCode(String jobCode) {
        this.jobCode = jobCode;
    }

    public String getJobDurationCode() {
        return jobDurationCode;
    }

    public void setJobDurationCode(String jobDurationCode) {
        this.jobDurationCode = jobDurationCode;
    }

    public List<String> getSkillCodeList() {
        return skillCodeList;
    }

    public void setSkillCodeList(List<String> skillCodeList) {
        this.skillCodeList = skillCodeList;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

   

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    public String getGoogleAPIKEY() {
        return googleAPIKEY;
    }

    public void setGoogleAPIKEY(String googleAPIKEY) {
        this.googleAPIKEY = googleAPIKEY;
    }    
}
