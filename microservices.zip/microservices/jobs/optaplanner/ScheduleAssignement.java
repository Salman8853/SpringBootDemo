/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.jobs.optaplanner;

import java.util.List;
import org.optaplanner.core.api.domain.solution.PlanningEntityCollectionProperty;
import org.optaplanner.core.api.domain.solution.PlanningScore;
import org.optaplanner.core.api.domain.solution.PlanningSolution;
import org.optaplanner.core.api.domain.solution.drools.ProblemFactCollectionProperty;
import org.optaplanner.core.api.domain.valuerange.ValueRangeProvider;
import org.optaplanner.core.api.score.buildin.hardsoft.HardSoftScore;

/**
 *
 * @author nirbhay.p
 */
@PlanningSolution
public class ScheduleAssignement {
    private List<Worker>workerList;
    private List<Schedule> scheduleList;
    private HardSoftScore score;

    public ScheduleAssignement() {
    }

    public ScheduleAssignement(List<Worker> workerList, List<Schedule> scheduleList) {
        this.workerList = workerList;
        this.scheduleList = scheduleList;
    }
    @ValueRangeProvider(id = "worker")
     @ProblemFactCollectionProperty
    public List<Worker> getWorkerList() {
        return workerList;
    }

    public void setWorkerList(List<Worker> workerList) {
        this.workerList = workerList;
    }

    
      @PlanningScore
    public HardSoftScore getScore() {
        return score;
    }

    
    public void setScore(HardSoftScore score) {
        this.score = score;
    }
@PlanningEntityCollectionProperty
    public List<Schedule> getScheduleList() {
        return scheduleList;
    }

    public void setScheduleList(List<Schedule> scheduleList) {
        this.scheduleList = scheduleList;
    }
    
    
}
