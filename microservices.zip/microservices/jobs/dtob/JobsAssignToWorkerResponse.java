package com.gigflex.prototype.microservices.jobs.dtob;

import com.gigflex.prototype.microservices.worker.dtob.Worker;



/**
 * 
 * @author nirbhay.p
 *
 */

public class JobsAssignToWorkerResponse  {


    private Long id;  
    
    private String jobsAassignWorkerCode;
    
    private String jobsDurationCode;
    
    private String jobsCode;  
    
    private Double distance;
    
    private String status; 
    
    private String comment;    
    
    private Worker worker;

    public Worker getWorker() {
        return worker;
    }

    public void setWorker(Worker worker) {
        this.worker = worker;
    }
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getJobsAassignWorkerCode() {
        return jobsAassignWorkerCode;
    }

    public void setJobsAassignWorkerCode(String jobsAassignWorkerCode) {
        this.jobsAassignWorkerCode = jobsAassignWorkerCode;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    
    
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getJobsDurationCode() {
        return jobsDurationCode;
    }

    public void setJobsDurationCode(String jobsDurationCode) {
        this.jobsDurationCode = jobsDurationCode;
    }

    public String getJobsCode() {
        return jobsCode;
    }

    public void setJobsCode(String jobsCode) {
        this.jobsCode = jobsCode;
    }

   
    
}