/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.jobs.dtob;

import com.gigflex.prototype.microservices.patient.dtob.PatientDetails;
import com.gigflex.prototype.microservices.proceduremaster.dtob.ProcedureMaster;
import java.util.Date;

/**
 *
 * @author nirbhay.p
 */
public class JobAssigntoWorkerWithFilterforWorkerResponse {
    
    
    private JobsAssignToWorker jobsAssignToWorker;
    
    private String jobsDurationCode;
    
    private String jobsCode; 
    
    private Date startTimeStamp ;
    
    private Date endTimeStamp ;
    
    private String startTime ;
    
    private String endTime ;
    
    private String procedureCode;
    
    private ProcedureMaster procedureMaster;
    
    private String jobName;
    
    private String organizationCode;
    
    private String notes;
    
    private String organizationName;
    
    private PatientDetails patientDetails;
    private String patientCode; 
    private String dateFormat;
    private String timeFormat;   
    private String distance;   

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }
    
    public String getDateFormat() {
        return dateFormat;
    }

    public void setDateFormat(String dateFormat) {
        this.dateFormat = dateFormat;
    }

    public String getTimeFormat() {
        return timeFormat;
    }

    public void setTimeFormat(String timeFormat) {
        this.timeFormat = timeFormat;
    }

    
    public ProcedureMaster getProcedureMaster() {
        return procedureMaster;
    }

    public void setProcedureMaster(ProcedureMaster procedureMaster) {
        this.procedureMaster = procedureMaster;
    }

    public String getPatientCode() {
        return patientCode;
    }

    public void setPatientCode(String patientCode) {
        this.patientCode = patientCode;
    }

    public JobsAssignToWorker getJobsAssignToWorker() {
        return jobsAssignToWorker;
    }

    public void setJobsAssignToWorker(JobsAssignToWorker jobsAssignToWorker) {
        this.jobsAssignToWorker = jobsAssignToWorker;
    }

    public String getJobsDurationCode() {
        return jobsDurationCode;
    }

    public void setJobsDurationCode(String jobsDurationCode) {
        this.jobsDurationCode = jobsDurationCode;
    }

    public String getJobsCode() {
        return jobsCode;
    }

    public void setJobsCode(String jobsCode) {
        this.jobsCode = jobsCode;
    }

    public Date getStartTimeStamp() {
        return startTimeStamp;
    }

    public void setStartTimeStamp(Date startTimeStamp) {
        this.startTimeStamp = startTimeStamp;
    }

    public Date getEndTimeStamp() {
        return endTimeStamp;
    }

    public void setEndTimeStamp(Date endTimeStamp) {
        this.endTimeStamp = endTimeStamp;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getProcedureCode() {
        return procedureCode;
    }

    public void setProcedureCode(String procedureCode) {
        this.procedureCode = procedureCode;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

    public PatientDetails getPatientDetails() {
        return patientDetails;
    }

    public void setPatientDetails(PatientDetails patientDetails) {
        this.patientDetails = patientDetails;
    }

    
    
}
