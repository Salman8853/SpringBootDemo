/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.jobs.dtob;

import java.util.List;

/**
 *
 * @author nirbhay.p
 */
public class JobsWithDurationRes {
    private JobsRes jobsRes;
    private List<JobsDurationRes> jobsDurationResLst;

    public JobsRes getJobsRes() {
        return jobsRes;
    }

    public void setJobsRes(JobsRes jobsRes) {
        this.jobsRes = jobsRes;
    }

    public List<JobsDurationRes> getJobsDurationResLst() {
        return jobsDurationResLst;
    }

    public void setJobsDurationResLst(List<JobsDurationRes> jobsDurationResLst) {
        this.jobsDurationResLst = jobsDurationResLst;
    }

  
    
}
