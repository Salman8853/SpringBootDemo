/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.jobs.dtob;

import java.util.List;

/**
 *
 * @author nirbhay.p
 */
public class JobManualResponse {
    JobsRes jobsRes;
    List<EligibleWorkerRes> eligibleWorkerResList;
    List<JobsDurationRes> jobsDurationResList;

    public JobsRes getJobsRes() {
        return jobsRes;
    }

    public void setJobsRes(JobsRes jobsRes) {
        this.jobsRes = jobsRes;
    }

    public List<EligibleWorkerRes> getEligibleWorkerResList() {
        return eligibleWorkerResList;
    }

    public void setEligibleWorkerResList(List<EligibleWorkerRes> eligibleWorkerResList) {
        this.eligibleWorkerResList = eligibleWorkerResList;
    }

    public List<JobsDurationRes> getJobsDurationResList() {
        return jobsDurationResList;
    }

    public void setJobsDurationResList(List<JobsDurationRes> jobsDurationResList) {
        this.jobsDurationResList = jobsDurationResList;
    }

   
    
}
