package com.gigflex.prototype.microservices.jobs.dtob;

import com.gigflex.prototype.microservices.patient.dtob.PatientDetails;
import com.gigflex.prototype.microservices.proceduremaster.dtob.ProcedureMaster;

/**
 * 
 * @author nirbhay.p
 *
 */

public class JobsDurationRes {


    private Long id;  
    
    private String jobsDurationCode;
    
    private String jobsCode;    
   
    private String startTime ;
     
    private String endTime ;
    
    private String jobstatus;
    
    private Double distance;
    
    private String durationHours;
    
    private String durationMinute;
    
    private String duration;
//    private String PatientLatitude;
//    
//    private String PatientLongitude;
    private PatientDetails patientDetails;
    
    private ProcedureMaster procedureMaster;
    
    private String jobName;
    
    private String dateFormat;
    
    private String timeFormat;
    
    private String notes;

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }    

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public String getDateFormat() {
        return dateFormat;
    }

    public void setDateFormat(String dateFormat) {
        this.dateFormat = dateFormat;
    }

    public String getTimeFormat() {
        return timeFormat;
    }

    public void setTimeFormat(String timeFormat) {
        this.timeFormat = timeFormat;
    }
    
    
    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getJobsDurationCode() {
        return jobsDurationCode;
    }

    public void setJobsDurationCode(String jobsDurationCode) {
        this.jobsDurationCode = jobsDurationCode;
    }

    public String getJobsCode() {
        return jobsCode;
    }

    public void setJobsCode(String jobsCode) {
        this.jobsCode = jobsCode;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

   
    public PatientDetails getPatientDetails() {
        return patientDetails;
    }

    public void setPatientDetails(PatientDetails patientDetails) {
        this.patientDetails = patientDetails;
    }

    public ProcedureMaster getProcedureMaster() {
        return procedureMaster;
    }

//    public String getPatientLatitude() {
//        return PatientLatitude;
//    }
//
//    public void setPatientLatitude(String PatientLatitude) {
//        this.PatientLatitude = PatientLatitude;
//    }
//
//    public String getPatientLongitude() {
//        return PatientLongitude;
//    }
//
//    public void setPatientLongitude(String PatientLongitude) {
//        this.PatientLongitude = PatientLongitude;
//    }
    public void setProcedureMaster(ProcedureMaster procedureMaster) {
        this.procedureMaster = procedureMaster;
    }

    public String getJobstatus() {
        return jobstatus;
    }

    public void setJobstatus(String jobstatus) {
        this.jobstatus = jobstatus;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getDurationHours() {
        return durationHours;
    }

    public void setDurationHours(String durationHours) {
        this.durationHours = durationHours;
    }

    public String getDurationMinute() {
        return durationMinute;
    }

    public void setDurationMinute(String durationMinute) {
        this.durationMinute = durationMinute;
    }

   
    
    
}