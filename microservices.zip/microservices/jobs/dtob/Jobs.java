package com.gigflex.prototype.microservices.jobs.dtob;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.util.Date;
import java.util.List;

import java.util.UUID;

import javax.persistence.PrePersist;
import org.hibernate.annotations.GenericGenerator;

/**
 * 
 * @author nirbhay.p
 *
 */
@Entity
@Table(name = "jobs")
public class Jobs extends CommonAttributes implements Serializable {


    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;  
    
    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "jobs_code", unique = true)
    private String jobsCode;
    
    @Column(name = "patient_code", nullable=false)
    private String patientCode; 
    
    @Column(name = "procedure_code", nullable=false)
    private String procedureCode;
    
    @Column(name = "jobname")
    private String jobName;
    
    @Column(name = "organization_code" ,  nullable=false)
    private String organizationCode;
    
    @Column(name = "start_date", columnDefinition="DATE",  nullable=false)
    private Date startDT ;
     
    @Column(name = "end_date", columnDefinition="DATE",  nullable=false)
    private Date endDT ;
       
    @Column(name = "notes")
    private String notes;
     
    @Column(name = "start_time")
    private String startTime ;
    
    @Column(name = "repeat_value")
    private Integer repeatValue;
    
    @Column(name = "repeat_type")
    private String repeatType;
    
    @Column(name = "isdateofmonth")
    private Boolean isDateOfMonth;
    
    @Column(name = "days_list")
    private String daysList;
    
    @Column(name = "duration_hours")
    private Integer durationHours;
    
    @Column(name = "duration_minute")
    private Integer durationMinute;
   
   @PrePersist
    private void assignUUID() {
        if(this.getJobsCode()==null || this.getJobsCode().length()==0)
        {
            this.setJobsCode(UUID.randomUUID().toString());
        }
    }

    public String getJobsCode() {
        return jobsCode;
    }

    public void setJobsCode(String jobsCode) {
        this.jobsCode = jobsCode;
    }

    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    
    public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }
    public Date getStartDT() {
        return startDT;
    }

    public void setStartDT(Date startDT) {
        this.startDT = startDT;
    }

    public Date getEndDT() {
        return endDT;
    }

    public void setEndDT(Date endDT) {
        this.endDT = endDT;
    }

    public String getPatientCode() {
        return patientCode;
    }

    public void setPatientCode(String patientCode) {
        this.patientCode = patientCode;
    }

    public String getProcedureCode() {
        return procedureCode;
    }

    public void setProcedureCode(String procedureCode) {
        this.procedureCode = procedureCode;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public Integer getRepeatValue() {
        return repeatValue;
    }

    public void setRepeatValue(Integer repeatValue) {
        this.repeatValue = repeatValue;
    }

    public String getRepeatType() {
        return repeatType;
    }

    public void setRepeatType(String repeatType) {
        this.repeatType = repeatType;
    }

    public Boolean getIsDateOfMonth() {
        return isDateOfMonth;
    }

    public void setIsDateOfMonth(Boolean isDateOfMonth) {
        this.isDateOfMonth = isDateOfMonth;
    }

    public String getDaysList() {
        return daysList;
    }

    public void setDaysList(String daysList) {
        this.daysList = daysList;
    }

    public Integer getDurationHours() {
        return durationHours;
    }

    public void setDurationHours(Integer durationHours) {
        this.durationHours = durationHours;
    }

    public Integer getDurationMinute() {
        return durationMinute;
    }

    public void setDurationMinute(Integer durationMinute) {
        this.durationMinute = durationMinute;
    }
    
    
}