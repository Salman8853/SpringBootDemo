/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.jobs.dtob;

import java.util.Date;

/**
 *
 * @author amit.kumar
 */
public class AppointmentDetail {
    
    private String jobStartDate;
    private String jobEndDate;
    private String jobsDurationCode;
    private String jobsCode;
    private String jobName;    
    private String status;
    private String dateFormat;
    private String timeFormat;   
    private Date timestampJobsStartTime;
    private Date timestampJobsEndTime;
    private String procedureIcon;
    private String drivingStartTime;
    private Boolean isPartial;
    private Integer drivingTimeInSecond;
    private String patientName;
    private String workerName;
    private String patientCode;
    private String workerCode;
    private Double distance;
    private String distanceText;
    private String durationText;
    private String patientAddress;
    private String phoneNumber;
    private String pCountryCode;

    public String getDistanceText() {
        return distanceText;
    }

    public void setDistanceText(String distanceText) {
        this.distanceText = distanceText;
    }

    public String getDurationText() {
        return durationText;
    }

    public void setDurationText(String durationText) {
        this.durationText = durationText;
    }

    
    public String getPatientCode() {
        return patientCode;
    }

    public void setPatientCode(String patientCode) {
        this.patientCode = patientCode;
    }

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getWorkerName() {
        return workerName;
    }

    public void setWorkerName(String workerName) {
        this.workerName = workerName;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }
    
    

    public Integer getDrivingTimeInSecond() {
        return drivingTimeInSecond;
    }

    public void setDrivingTimeInSecond(Integer drivingTimeInSecond) {
        this.drivingTimeInSecond = drivingTimeInSecond;
    }
    
    

    public Boolean getIsPartial() {
        return isPartial;
    }

    public void setIsPartial(Boolean isPartial) {
        this.isPartial = isPartial;
    }

    public String getDrivingStartTime() {
        return drivingStartTime;
    }

    public void setDrivingStartTime(String drivingStartTime) {
        this.drivingStartTime = drivingStartTime;
    }
    
    
    public String getProcedureIcon() {
        return procedureIcon;
    }

    public void setProcedureIcon(String procedureIcon) {
        this.procedureIcon = procedureIcon;
    }
    
    

    public String getJobStartDate() {
        return jobStartDate;
    }

    public void setJobStartDate(String jobStartDate) {
        this.jobStartDate = jobStartDate;
    }

    public String getJobEndDate() {
        return jobEndDate;
    }

    public void setJobEndDate(String jobEndDate) {
        this.jobEndDate = jobEndDate;
    }

    public String getJobsDurationCode() {
        return jobsDurationCode;
    }

    public void setJobsDurationCode(String jobsDurationCode) {
        this.jobsDurationCode = jobsDurationCode;
    }

    public String getJobsCode() {
        return jobsCode;
    }

    public void setJobsCode(String jobsCode) {
        this.jobsCode = jobsCode;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }


    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDateFormat() {
        return dateFormat;
    }

    public void setDateFormat(String dateFormat) {
        this.dateFormat = dateFormat;
    }

    public String getTimeFormat() {
        return timeFormat;
    }

    public void setTimeFormat(String timeFormat) {
        this.timeFormat = timeFormat;
    }

    public Date getTimestampJobsStartTime() {
        return timestampJobsStartTime;
    }

    public void setTimestampJobsStartTime(Date timestampJobsStartTime) {
        this.timestampJobsStartTime = timestampJobsStartTime;
    }

    public Date getTimestampJobsEndTime() {
        return timestampJobsEndTime;
    }

    public void setTimestampJobsEndTime(Date timestampJobsEndTime) {
        this.timestampJobsEndTime = timestampJobsEndTime;
    }        

    public String getPatientAddress() {
        return patientAddress;
    }

    public void setPatientAddress(String patientAddress) {
        this.patientAddress = patientAddress;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getpCountryCode() {
        return pCountryCode;
    }

    public void setpCountryCode(String pCountryCode) {
        this.pCountryCode = pCountryCode;
    }
    
    
    
}
