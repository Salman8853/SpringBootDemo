/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.jobs.dtob;

import java.util.Date;

/**
 *
 * @author amit.kumar
 */
public class StatusCount {
    
    private Date startDateTimestamp;
    private Date endDateTimestamp;
    private String startDate;
    private String endDate;
    private String dateFormat;
    private int statusCount;
    private Integer indexNumber;
    private Double fullfillmentRatio;

    public Date getStartDateTimestamp() {
        return startDateTimestamp;
    }

    public void setStartDateTimestamp(Date startDateTimestamp) {
        this.startDateTimestamp = startDateTimestamp;
    }

    public Date getEndDateTimestamp() {
        return endDateTimestamp;
    }

    public void setEndDateTimestamp(Date endDateTimestamp) {
        this.endDateTimestamp = endDateTimestamp;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getDateFormat() {
        return dateFormat;
    }

    public void setDateFormat(String dateFormat) {
        this.dateFormat = dateFormat;
    }

    public int getStatusCount() {
        return statusCount;
    }

    public void setStatusCount(int statusCount) {
        this.statusCount = statusCount;
    }

    public Integer getIndexNumber() {
        return indexNumber;
    }

    public void setIndexNumber(Integer indexNumber) {
        this.indexNumber = indexNumber;
    }

    public Double getFullfillmentRatio() {
        return fullfillmentRatio;
    }

    public void setFullfillmentRatio(Double fullfillmentRatio) {
        this.fullfillmentRatio = fullfillmentRatio;
    }
}
