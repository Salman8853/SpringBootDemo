/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.jobs.dtob;

import com.gigflex.prototype.microservices.patient.dtob.PatientDetails;
import java.util.Date;

/**
 *
 * @author amit.kumar
 */
public class JobsAllResponse {
    
    private String distance;
    private String workerName;
    private String workerCode;
    private String status;
    private String duration;
    private String startTime;
    private String endTime;
    private String patientCode;
    private String patientName;
    private String procedureCode;
    private String procedureIcon;
    private String dateFormat;
    private String timeFormat;   
    private Date timestampStartTime;
    private Date timestampEndTime;
    private PatientDetails patientDetails;
    
    private String jobsDurationCode;
    
    private String jobsCode;

    public String getJobsDurationCode() {
        return jobsDurationCode;
    }

    public void setJobsDurationCode(String jobsDurationCode) {
        this.jobsDurationCode = jobsDurationCode;
    }

    public String getJobsCode() {
        return jobsCode;
    }

    public void setJobsCode(String jobsCode) {
        this.jobsCode = jobsCode;
    }
    
    
    

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }  

    public String getWorkerName() {
        return workerName;
    }

    public void setWorkerName(String workerName) {
        this.workerName = workerName;
    }

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }
  

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getPatientCode() {
        return patientCode;
    }

    public void setPatientCode(String patientCode) {
        this.patientCode = patientCode;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getProcedureCode() {
        return procedureCode;
    }

    public void setProcedureCode(String procedureCode) {
        this.procedureCode = procedureCode;
    }

    public String getProcedureIcon() {
        return procedureIcon;
    }

    public void setProcedureIcon(String procedureIcon) {
        this.procedureIcon = procedureIcon;
    }

    public String getDateFormat() {
        return dateFormat;
    }

    public void setDateFormat(String dateFormat) {
        this.dateFormat = dateFormat;
    }

    public String getTimeFormat() {
        return timeFormat;
    }

    public void setTimeFormat(String timeFormat) {
        this.timeFormat = timeFormat;
    }

    public Date getTimestampStartTime() {
        return timestampStartTime;
    }

    public void setTimestampStartTime(Date timestampStartTime) {
        this.timestampStartTime = timestampStartTime;
    }

    public Date getTimestampEndTime() {
        return timestampEndTime;
    }

    public void setTimestampEndTime(Date timestampEndTime) {
        this.timestampEndTime = timestampEndTime;
    }

    public PatientDetails getPatientDetails() {
        return patientDetails;
    }

    public void setPatientDetails(PatientDetails patientDetails) {
        this.patientDetails = patientDetails;
    }

    
    
}
