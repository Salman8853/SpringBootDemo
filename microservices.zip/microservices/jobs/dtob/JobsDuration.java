package com.gigflex.prototype.microservices.jobs.dtob;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.util.Date;

import java.util.UUID;

import javax.persistence.PrePersist;
import org.hibernate.annotations.GenericGenerator;

/**
 * 
 * @author nirbhay.p
 *
 */
@Entity
@Table(name = "jobs_duration")
public class JobsDuration extends CommonAttributes implements Serializable {


    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;  
    
    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "jobs_duration_code", unique = true)
    private String jobsDurationCode;
    
    @Column(name = "jobs_code" , nullable=false)
    private String jobsCode;    
        
    @Column(name = "start_time", columnDefinition="DATETIME", nullable=false)
    private Date startTime ;
     
    @Column(name = "end_time", columnDefinition="DATETIME", nullable=false)
    private Date endTime ;
    @Column(name = "duration_hours")
    private Integer durationHours;
    @Column(name = "duration_minute")
    private Integer durationMinute;
    
    @Column(name = "notes")
    private String notes;
    
    @Column(name = "jobname")
    private String jobName;
         
   @PrePersist
    private void assignUUID() {
        if(this.getJobsDurationCode()==null || this.getJobsDurationCode().length()==0)
        {
            this.setJobsDurationCode(UUID.randomUUID().toString());
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getJobsDurationCode() {
        return jobsDurationCode;
    }

    public void setJobsDurationCode(String jobsDurationCode) {
        this.jobsDurationCode = jobsDurationCode;
    }

    public String getJobsCode() {
        return jobsCode;
    }

    public void setJobsCode(String jobsCode) {
        this.jobsCode = jobsCode;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Integer getDurationHours() {
        return durationHours;
    }

    public void setDurationHours(Integer durationHours) {
        this.durationHours = durationHours;
    }

    public Integer getDurationMinute() {
        return durationMinute;
    }

    public void setDurationMinute(Integer durationMinute) {
        this.durationMinute = durationMinute;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

   

   
    
}