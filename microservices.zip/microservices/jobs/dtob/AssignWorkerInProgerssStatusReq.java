/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.jobs.dtob;

/**
 *
 * @author m.salman
 */
public class AssignWorkerInProgerssStatusReq {
    private String comment;
    private String workerCode;
    private String curruntLatitude;
    private String curruntLongitude;

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getCurruntLatitude() {
        return curruntLatitude;
    }

    public void setCurruntLatitude(String curruntLatitude) {
        this.curruntLatitude = curruntLatitude;
    }

    public String getCurruntLongitude() {
        return curruntLongitude;
    }

    public void setCurruntLongitude(String curruntLongitude) {
        this.curruntLongitude = curruntLongitude;
    }
    
}
