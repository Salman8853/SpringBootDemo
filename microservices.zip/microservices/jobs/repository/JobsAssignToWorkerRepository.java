/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.jobs.repository;


import com.gigflex.prototype.microservices.jobs.dtob.JobsAssignToWorker;
import com.gigflex.prototype.microservices.patient.dtob.PatientDetails;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import java.util.Date;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author nirbhay.p
 */
public interface JobsAssignToWorkerRepository  extends JpaRepository<JobsAssignToWorker, Long>,JpaSpecificationExecutor<JobsAssignToWorker> {
    
//    @Query("SELECT w.workerCode FROM JobsAssignToWorker a,Worker w, JobsDuration b WHERE a.isDeleted != TRUE AND w.isDeleted != TRUE AND a.jobsDurationCode=b.jobsDurationCode AND (NOT ((b.startTime >= :endTime AND b.endTime > :endTime)\n" +
//        "OR (b.startTime < :startTime AND b.endTime <= :startTime))) AND a.driverCode IN (:workercodeList) AND a.driverCode=w.driverCode")
//        public List<String> getBusyWorkerList(@Param("startTime") Date startTime,@Param("endTime")  Date endTime,@Param("workercodeList") List<String> workercodeList);

    
@Query("SELECT DISTINCT a.workerCode FROM JobsAssignToWorker a, JobsDuration b WHERE a.isDeleted != TRUE AND b.isDeleted != TRUE AND a.jobsDurationCode=b.jobsDurationCode AND (NOT ((b.startTime >= :endTime AND b.endTime > :endTime) OR (b.startTime < :startTime AND b.endTime <= :startTime))) AND a.workerCode IN (:workercodeList) AND a.status!= :rejected  AND a.status!= :cancelled ")
public List<String> getBusyWorkerList(@Param("startTime") Date startTime,@Param("endTime")  Date endTime,@Param("workercodeList") List<String> workercodeList,@Param("cancelled")String  cancelled, @Param("rejected")String  rejected);
            
@Query("SELECT a FROM JobsAssignToWorker a WHERE a.isDeleted != TRUE AND a.jobsDurationCode =:jobsDurationCode AND (a.status =:assigned OR a.status =:accepted)")
public JobsAssignToWorker getAssignedWorkerList(@Param("assigned")String  assigned,@Param("accepted")String  accepted,@Param("jobsDurationCode") String  jobsDurationCode);   
        
@Query("SELECT j FROM JobsAssignToWorker j WHERE j.isDeleted != TRUE AND j.jobsCode = :jobsCode")
public List<JobsAssignToWorker> getJobsAssignToWorkerByJobsCode(@Param("jobsCode") String jobsCode);

@Query("SELECT j FROM JobsAssignToWorker j WHERE j.isDeleted != TRUE AND j.jobsCode = :jobsCode AND j.jobsDurationCode = :jobsDurationCode")
public JobsAssignToWorker getJobsAssignToWorkerByJobsCodeAndJobsDurationCode(@Param("jobsCode") String jobsCode,@Param("jobsDurationCode") String jobsDurationCode);

@Query("SELECT j FROM JobsAssignToWorker j WHERE j.isDeleted != TRUE AND j.jobsDurationCode = :jobsDurationCode")
public JobsAssignToWorker getJobsAssignToWorkerByJobsDurationCode(@Param("jobsDurationCode") String jobsDurationCode);


@Query("SELECT j FROM JobsAssignToWorker j WHERE j.isDeleted != TRUE AND j.jobsAassignWorkerCode = :jobsAassignWorkerCode")
public JobsAssignToWorker getJobsAssignToWorkerByJobsAassignWorkerCode(@Param("jobsAassignWorkerCode") String jobsAassignWorkerCode);

@Query("SELECT j,jd,jasw FROM Jobs j, JobsDuration jd, JobsAssignToWorker jasw WHERE j.isDeleted != TRUE AND jd.isDeleted != TRUE AND jasw.isDeleted != TRUE AND jasw.jobsDurationCode=jd.jobsDurationCode AND jasw.jobsCode=j.jobsCode AND jasw.workerCode= :workerCode AND jasw.status IN (:status)")
public List<Object> getAllJobsByWorkerCodeWithFilter(@Param("workerCode") String workerCode,@Param("status")List<String> status);

@Query("SELECT j,jd,jasw FROM Jobs j, JobsDuration jd, JobsAssignToWorker jasw WHERE j.isDeleted != TRUE AND jd.isDeleted != TRUE AND jasw.isDeleted != TRUE AND jasw.jobsDurationCode=jd.jobsDurationCode AND jasw.jobsCode=j.jobsCode AND jasw.workerCode= :workerCode AND jasw.status IN (:status)  ORDER BY jd.startTime")
public List<Object> getAllJobsByWorkerCodeWithFilterForDist(@Param("workerCode") String workerCode,@Param("status")List<String> status,Pageable pageableRequest);

@Query("SELECT j,jd,jasw FROM Jobs j, JobsDuration jd, JobsAssignToWorker jasw WHERE j.isDeleted != TRUE AND jd.isDeleted != TRUE AND jasw.isDeleted != TRUE AND jasw.jobsDurationCode=jd.jobsDurationCode AND jasw.jobsCode=j.jobsCode AND jasw.workerCode= :workerCode AND jasw.status IN (:status)   ORDER BY FIELD(jasw.status,  :orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(jd.startTime)) ")
public List<Object> getAllJobsByWorkerCodeWithFilter(@Param("workerCode") String workerCode,@Param("status")List<String> status,@Param("orderLst")List<String>  orderLst,Pageable pageableRequest);

@Query("SELECT j,jd,jasw FROM Jobs j, JobsDuration jd, JobsAssignToWorker jasw WHERE j.isDeleted != TRUE AND jd.isDeleted != TRUE AND jasw.isDeleted != TRUE AND jasw.jobsDurationCode=jd.jobsDurationCode AND jasw.jobsCode=j.jobsCode AND jasw.workerCode= :workerCode AND jasw.status IN (:status) AND jd.endTime>= :sDT AND jd.startTime< :eDT ")
public List<Object> getAllJobsByWorkerCodeWithFilter(@Param("workerCode") String workerCode,@Param("status")List<String> status, @Param("sDT") Date sDT,@Param("eDT")  Date eDT);

@Query("SELECT j,jd,jasw FROM Jobs j, JobsDuration jd, JobsAssignToWorker jasw WHERE j.isDeleted != TRUE AND jd.isDeleted != TRUE AND jasw.isDeleted != TRUE AND jasw.jobsDurationCode=jd.jobsDurationCode AND jasw.jobsCode=j.jobsCode AND jasw.workerCode= :workerCode AND jasw.status IN (:status) AND jd.endTime>= :sDT AND jd.startTime< :eDT  ORDER BY jd.startTime")
public List<Object> getAllJobsByWorkerCodeWithFilterForDist(@Param("workerCode") String workerCode,@Param("status")List<String> status, @Param("sDT") Date sDT,@Param("eDT")  Date eDT,Pageable pageableRequest);

@Query("SELECT j,jd,jasw FROM Jobs j, JobsDuration jd, JobsAssignToWorker jasw WHERE j.isDeleted != TRUE AND jd.isDeleted != TRUE AND jasw.isDeleted != TRUE AND jasw.jobsDurationCode=jd.jobsDurationCode AND jasw.jobsCode=j.jobsCode AND jasw.workerCode= :workerCode AND jasw.status IN (:status) AND jd.endTime>= :sDT AND jd.startTime< :eDT  ORDER BY jd.startTime")
public List<Object> getAllJobsByWorkerCodeWithFilterForDist(@Param("workerCode") String workerCode,@Param("status")List<String> status, @Param("sDT") Date sDT,@Param("eDT")  Date eDT);


@Query("SELECT j,jd,jasw FROM Jobs j, JobsDuration jd, JobsAssignToWorker jasw WHERE j.isDeleted != TRUE AND jd.isDeleted != TRUE AND jasw.isDeleted != TRUE AND jasw.jobsDurationCode=jd.jobsDurationCode AND jasw.jobsCode=j.jobsCode AND jasw.workerCode= :workerCode AND jasw.status IN (:status) AND jd.endTime>= :sDT AND jd.startTime< :eDT  ORDER BY FIELD(jasw.status,  :orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(jd.startTime)) ")
public List<Object> getAllJobsByWorkerCodeWithFilter(@Param("workerCode") String workerCode,@Param("status")List<String> status, @Param("sDT") Date sDT,@Param("eDT")  Date eDT,@Param("orderLst")List<String>  orderLst,Pageable pageableRequest);

@Query("SELECT a FROM JobsAssignToWorker a, JobsDuration b WHERE a.isDeleted != TRUE AND b.isDeleted != TRUE AND a.jobsDurationCode=b.jobsDurationCode AND (NOT ((b.startTime >= :endTime AND b.endTime > :endTime) OR (b.startTime < :startTime AND b.endTime <= :startTime))) AND a.workerCode= :workerCode AND a.status!= :rejected  AND a.status!= :cancelled ")
public List<JobsAssignToWorker> getBusyJobsAssignToWorkerListByWorkerCode(@Param("startTime") Date startTime,@Param("endTime")  Date endTime,@Param("workerCode") String workerCode,@Param("cancelled")String  cancelled, @Param("rejected")String  rejected);

@Query("SELECT js,jd,j FROM JobsAssignToWorker js,JobsDuration jd,Jobs j WHERE js.isDeleted != TRUE AND jd.isDeleted != TRUE AND j.isDeleted != TRUE AND js.workerCode=:workerCode AND  js.jobsDurationCode = jd.jobsDurationCode AND js.jobsCode=j.jobsCode AND ((jd.startTime>=:startTime AND jd.endTime<=:endTime) OR (jd.startTime<:startTime AND jd.endTime<:endTime AND jd.endTime>:startTime)OR(jd.startTime>:startTime AND jd.startTime<:endTime  AND jd.endTime>:endTime)) AND ( js.status=:statusAcc OR js.status=:statusInpro )  ORDER BY FIELD(js.status,  :orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(jd.startTime))")
public   List<Object>   getTodaysCurruntAppointmentByworkerCode(@Param("workerCode")String workerCode,@Param("statusAcc")String statusAcc,@Param("statusInpro")String statusInpro,@Param("startTime")Date startTime,@Param("endTime")Date endTime,@Param("orderLst")List<String>  orderLst);

@Query("SELECT js,jd,j FROM JobsAssignToWorker js,JobsDuration jd,Jobs j WHERE js.isDeleted != TRUE AND jd.isDeleted != TRUE AND j.isDeleted != TRUE AND js.workerCode=:workerCode AND  js.jobsDurationCode = jd.jobsDurationCode AND js.jobsCode=j.jobsCode AND ((jd.startTime>=:startTime AND jd.endTime<=:endTime) OR (jd.startTime<:startTime AND jd.endTime<:endTime AND jd.endTime>:startTime)OR(jd.startTime>:startTime AND jd.startTime<:endTime  AND jd.endTime>:endTime)) AND js.status=:status")
public   List<Object>   getCurruntAppointmentByworkerCode(@Param("workerCode")String workerCode,@Param("status")String status,@Param("startTime")Date startTime,@Param("endTime")Date endTime);

@Query("SELECT js,jd,j FROM JobsAssignToWorker js,JobsDuration jd,Jobs j WHERE js.isDeleted != TRUE AND jd.isDeleted != TRUE AND j.isDeleted != TRUE AND js.workerCode=:workerCode AND  js.jobsDurationCode = jd.jobsDurationCode AND js.jobsCode=j.jobsCode AND js.status=:status ORDER BY jd.startTime")
public   List<Object>   getCurruntAppointmentByworkerCode(@Param("workerCode")String workerCode,@Param("status")String status);

@Query("SELECT a FROM JobsAssignToWorker a WHERE a.isDeleted != TRUE AND a.appointmentId= :appointmentId ")
public JobsAssignToWorker getJobsAssignToWorkerByAppointmentid(@Param("appointmentId")String appointmentId);

@Query("SELECT j FROM JobsAssignToWorker j WHERE j.isDeleted != TRUE AND j.jobsCode = :jobsCode AND j.status IN (:statusList)")
public List<JobsAssignToWorker> getJobsAssignToWorkerListByJobCodeWithFilterForUpdate(@Param("jobsCode") String jobsCode,@Param("statusList")  List<String> statusList);
  
@Query("SELECT job,jd,jaw, pd FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw,PatientDetails pd WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND pd.isDeleted != TRUE AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode AND pd.patientCode =job.patientCode AND job.organizationCode = :organizationCode AND jaw.workerCode = :workerCode AND jaw.status IN (:status) AND ( (jd.startTime >= :sDT AND jd.endTime <=:eDT ) OR (jd.startTime <:sDT AND jd.endTime > :eDT  ) OR (jd.startTime <:sDT AND jd.endTime > :sDT  ) OR (jd.startTime < :eDT AND jd.endTime > :eDT ) ) ORDER BY jd.startTime")
public List<Object> getAllJobsByWorkerCodeWithFilterForThread(@Param("organizationCode") String organizationCode,@Param("workerCode") String workerCode,@Param("status") List<String> status,@Param("sDT") Date sDT,@Param("eDT") Date eDT);

@Query("SELECT job,jd,jaw, pd FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw,PatientDetails pd WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND pd.isDeleted != TRUE AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode AND pd.patientCode =job.patientCode AND jaw.workerCode = :workerCode AND jaw.status IN (:status) AND jd.startTime >= :sDT ORDER BY jd.startTime")
public List<Object> getAllJobsByWorkerCodeWithFilterForChangeAddressThread(@Param("workerCode") String workerCode,@Param("status") List<String> status,@Param("sDT") Date sDT);

@Query("SELECT job,jd,jaw, pd,w FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw,PatientDetails pd,Worker w WHERE w.isDeleted != TRUE AND  job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND pd.isDeleted != TRUE AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode AND pd.patientCode =job.patientCode AND job.organizationCode = :organizationCode AND jaw.workerCode = w.workerCode AND jaw.status IN (:status) AND jd.startTime >= :sDT ORDER BY jd.startTime")
public List<Object> getAllJobsByWorkerCodeWithFilterForChangePatientAddressThread(@Param("organizationCode") String organizationCode,@Param("status") List<String> status,@Param("sDT") Date sDT);

@Query("SELECT pd FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw,PatientDetails pd WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND pd.isDeleted != TRUE AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode AND pd.patientCode =job.patientCode AND jaw.workerCode = :workerCode AND jaw.status IN (:status) AND jd.startTime >= :sDT AND jd.startTime < :eDT AND jd.endTime <=:eDT ORDER BY jd.startTime")
public List<PatientDetails> getLastPatientDetailsWithFilterInJobAssign(@Param("workerCode") String workerCode,@Param("status") List<String> status,@Param("sDT") Date sDT,@Param("eDT") Date eDT);

}
