package com.gigflex.prototype.microservices.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.gigflex.prototype.microservices.healthcarenotification.dtob.HealthcareNotification;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.users.dtob.Users;
import com.gigflex.prototype.microservices.worker.dtob.Worker;



@Service
public class KafkaService {
     
     @Autowired
     private KafkaTemplate<String, Worker> kafkaWorkerTemplate;
     
     @Autowired
     private KafkaTemplate<String, Organization> kafkaOrganizationTemplate; 
   
     
     @Autowired
     private KafkaTemplate<String, Users> kafkaDriverForUserTemplate;
     
     @Autowired
     private KafkaTemplate<String, HealthcareNotification> kafkaNotificationTemplate;
     
  
    String kafkaTopicForOrganizationupdate = "UpdateOrganizationFromHealthcare";
    String kafkaTopicForUsersUpdate = "UpdateUsersFromHealthcare";
    String kafkaTopicWorkerUpdate = "UpdateWorkerFromHealthcare";
    
    String kafkaTopicForSendNotifications = "AddNewHealthCareNotification";
    

   public void sendOrganizationForUpdate(Organization message){
       kafkaOrganizationTemplate.send(kafkaTopicForOrganizationupdate, message);
    } 
      
    public void sendWorkerForUpdate(Worker message){
       kafkaWorkerTemplate.send(kafkaTopicWorkerUpdate, message);
    }    
        
    public void sendUpdateUser(Users message){
       kafkaDriverForUserTemplate.send(kafkaTopicForUsersUpdate, message);
    }
    
    public void sendNotifications(HealthcareNotification message){
    	kafkaNotificationTemplate.send(kafkaTopicForSendNotifications, message);
     }
}
