/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.department.dtob;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Transient;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author nirbhay.p
 */
@Entity
@Table(name = "department_master")
public class DepartmentMaster extends CommonAttributes implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "department_code", unique = true)
    private String departmentCode;

    @Column(name = "departmentname")
    private String departmentName;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "parentid")
    private DepartmentMaster parent;
    
    @Transient
    private Long parentid;
    
    @Transient
    private String parentName;
    
    @Column(name = "organization_code")
    private String organizationCode;

    @JsonIgnore
    @OneToMany(mappedBy = "parent", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Set<DepartmentMaster> childDepartment = new HashSet();
    
    @PrePersist
    private void assignUUID() {
        if(this.getDepartmentCode()==null || this.getDepartmentCode().length()==0)
        {
            this.setDepartmentCode(UUID.randomUUID().toString());
        }
    }
    
    public void setParentid() {
        if(parent!=null && parent.getId()>0)
        {
             this.parentid =parent.getId();
        }
        
    }
    
  
//    public Long getParentidLong() {
//        if(parent!=null && parent.getId()>0)
//        {
//             this.parentid =parent.getId();
//        }
//        return this.parentid;
//    }
    
    

    
    public String getParentName() {
		return parentName;
	}

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}

	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	
	public void setParentName() {
        if(parent!=null && parent.getId()>0 && parent.getDepartmentName() != null)
        {
             this.parentName = parent.getDepartmentName();
        }
        
    }
	

	public Long getParentid() {
        return parentid;
    }

    
    public void setParentid(Long parentid) {
        this.parentid = parentid;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDepartmentCode() {
        return departmentCode;
    }

    public void setDepartmentCode(String departmentCode) {
        this.departmentCode = departmentCode;
    }

    
    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public DepartmentMaster getParent() {
        return parent;
    }

    public void setParent(DepartmentMaster parent) {
        this.parent = parent;
    }

    public Set<DepartmentMaster> getChildDepartment() {
        return childDepartment;
    }

    public void setChildDepartment(Set<DepartmentMaster> childDepartment) {
        this.childDepartment = childDepartment;
    }

}
