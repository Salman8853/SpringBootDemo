/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.workpreferedshift.dtob;


import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.Date;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;


@Entity
@Table(name = "worker_preferedshift")
public class WorkerPreferdShift extends CommonAttributes implements Serializable{
    
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "worker_preferdshift_code", unique = true)
    private String workerPreferdShiftCode;
    
    @Column(name = "shiftdate",columnDefinition = "DATE", nullable = false)
    private Date shiftdate;
     
    @Column(name = "worker_code", nullable = false)
    private String workerCode;
    
    @Column(name = "fromtime")
    private String fromTime;
            
    @Column(name = "totime")
    private String toTime;      
                
    @Column(name = "off_hours_from_time")
    private String offHoursFromTime;
            
    @Column(name = "off_hours_to_time")
    private String offHoursToTime;  
    
    @PrePersist
    private void assignUUID() {
        if (this.getWorkerPreferdShiftCode() == null || this.getWorkerPreferdShiftCode().length() == 0) {
           this.setWorkerPreferdShiftCode(UUID.randomUUID().toString());
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getWorkerPreferdShiftCode() {
        return workerPreferdShiftCode;
    }

    public void setWorkerPreferdShiftCode(String workerPreferdShiftCode) {
        this.workerPreferdShiftCode = workerPreferdShiftCode;
    }

    public Date getShiftdate() {
        return shiftdate;
    }

    public void setShiftdate(Date shiftdate) {
        this.shiftdate = shiftdate;
    }


  

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getFromTime() {
        return fromTime;
    }

    public void setFromTime(String fromTime) {
        this.fromTime = fromTime;
    }

    public String getToTime() {
        return toTime;
    }

    public void setToTime(String toTime) {
        this.toTime = toTime;
    }

    public String getOffHoursFromTime() {
        return offHoursFromTime;
    }

    public void setOffHoursFromTime(String offHoursFromTime) {
        this.offHoursFromTime = offHoursFromTime;
    }

    public String getOffHoursToTime() {
        return offHoursToTime;
    }

    public void setOffHoursToTime(String offHoursToTime) {
        this.offHoursToTime = offHoursToTime;
    }

    
    
}
