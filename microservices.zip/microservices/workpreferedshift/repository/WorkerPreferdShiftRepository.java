/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.workpreferedshift.repository;
import com.gigflex.prototype.microservices.workertimeoff.dtob.WorkerTimeOff;
import com.gigflex.prototype.microservices.workpreferedshift.dtob.WorkerPreferdShift;
import java.util.Date;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author nirbhay.p
 */
public interface WorkerPreferdShiftRepository extends JpaRepository<WorkerPreferdShift, Long>,JpaSpecificationExecutor<WorkerPreferdShift>{
    
    
    @Query("SELECT wt FROM WorkerPreferdShift wt WHERE wt.isDeleted != TRUE")
    public List<WorkerPreferdShift> getAllWorkerPreferdShift();
    
    @Query("SELECT wt FROM WorkerPreferdShift wt WHERE wt.isDeleted != TRUE")
    public List<WorkerPreferdShift> getAllWorkerPreferdShift(Pageable pageableRequest);
    
    @Query("Select wt From WorkerPreferdShift wt Where wt.isDeleted != TRUE AND wt.workerCode= :workerCode")
    public List<WorkerPreferdShift> getWorkerPreferdShift(@Param("workerCode") String workerCode);
    
    @Query("Select wt From WorkerPreferdShift wt Where wt.isDeleted != TRUE AND wt.workerCode= :workerCode AND wt.shiftdate >= :start AND wt.shiftdate <= :end ORDER BY wt.shiftdate")
    public List<WorkerPreferdShift> getWorkerPreferdShiftByWorkerCodeForCalendar(@Param("workerCode") String workerCode,@Param("start") Date start,@Param("end") Date end);
    
    @Query("Select wt From WorkerPreferdShift wt Where wt.isDeleted != TRUE AND wt.workerPreferdShiftCode= :workerPreferdShiftCode")
    public WorkerPreferdShift getWorkerPreferdShiftByWorkerPreferdShiftCode(@Param("workerPreferdShiftCode") String workerPreferdShiftCode);
    
    @Query("SELECT wt FROM WorkerPreferdShift wt WHERE wt.isDeleted != TRUE AND wt.workerCode= :workerCode AND wt.shiftdate=:shiftdate ")
    public WorkerPreferdShift getworkerPreferdShiftByworkerCode(@Param("workerCode") String workerCode,@Param("shiftdate") Date shiftdate);
    
    @Query("SELECT wt FROM WorkerPreferdShift wt WHERE wt.isDeleted != TRUE AND wt.workerCode= :workerCode AND wt.shiftdate=:shiftdate  AND wt.workerPreferdShiftCode!= :workerPreferdShiftCode")
    public WorkerPreferdShift getworkerPreferdShiftByworkerCodeAndDateAndNotCode(@Param("workerCode") String workerCode,@Param("shiftdate") Date shiftdate,@Param("workerPreferdShiftCode") String workerPreferdShiftCode);
    
    
}
