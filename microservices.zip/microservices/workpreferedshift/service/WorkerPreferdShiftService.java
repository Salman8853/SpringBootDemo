/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.workpreferedshift.service;

import com.gigflex.prototype.microservices.workpreferedshift.dtob.WorkerPreferdShiftRequest;

/**
 *
 * @author nirbhay.p
 */
public interface WorkerPreferdShiftService {
    public String getWorkerPreferdShift();
    public String getWorkerPreferdShiftByPage(int page, int limit);
    public String getWorkerPreferdShiftByWorkerCode(String workerCode);
    public String getWorkerPreferdShiftByworkerPreferdShiftCode(String workerPreferdShiftCode);
    public String repeatWorkerPreferdShift(String workercode,String type,String ip);
    public String saveWorkerPreferdShift(WorkerPreferdShiftRequest workerprsfReq, String ip);
    public String updatesaveWorkerPreferdShift(WorkerPreferdShiftRequest workerprsfReq,String workerPreferdShiftCode, String ip);
    public String deleteWorkerPreferdShift(String workerPreferdShiftCode);
    public String getWorkerPreferdShiftByWorkerCodeForCalendar(String workerCode,String start,String end);
}
