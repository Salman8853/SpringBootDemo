/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.workertimeoff.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.Date;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author amit.kumar
 */
@Entity
@Table(name = "worker_timeoff")
public class WorkerTimeOff extends CommonAttributes implements Serializable{
    
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "timeoff_code", unique = true)
    private String timeoffCode;
    
            
    @PrePersist
    private void assignUUID() {
        if (this.getTimeoffCode() == null || this.getTimeoffCode().length() == 0) {
           this.setTimeoffCode(UUID.randomUUID().toString());
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTimeoffCode() {
        return timeoffCode;
    }

    public void setTimeoffCode(String timeoffCode) {
        this.timeoffCode = timeoffCode;
    }
    
    @Column(name = "organization_code")
    private String organizationCode;
     
    @Column(name = "worker_code", nullable = false)
    private String workerCode;
    
    @Column(name = "created_by")
    private String createdBy;
            
    @Column(name = "fromdate", columnDefinition = "DATE")
    private Date fromDate;

    @Column(name = "todate", columnDefinition = "DATE")
    private Date toDate;    
    
    @Column(name = "fromdatetime", columnDefinition = "DATETIME")
    private Date fromDateTime;

    @Column(name = "todatetime", columnDefinition = "DATETIME")
    private Date toDateTime;    
    
    @Column(name = "fromtime")
    private String fromTime;
            
    @Column(name = "totime")
    private String toTime;      
    
    @Column(name = "isrepeat")
    private Boolean isRepeat; 
    
    @Column(name = "repeat_week")
    private Boolean repeatWeek; 
    
    @Column(name = "repeat_month")
    private Boolean repeatMonth;    
  
    
    @Column(name = "repeat_this_year")
    private Boolean repeatThisYear;
    
    @Column(name = "cancel_reason")
    private String cancelReason;
    
    
    @Column(name = "reason")
    private String reason;

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }    
    
    public WorkerTimeOff() {
            super();
    }

    public WorkerTimeOff(Long id) {
            super();
            this.id = id;
    }

    public WorkerTimeOff(Long id,String timeoffCode,String organizationCode, String workerCode,String createdBy,
            Date fromDate, Date toDate,String fromTime,String toTime,boolean isRepeat,boolean repeatWeek,boolean repeatMonth,boolean repeatThisYear,String cancelReason,String reason) {
            super();
            this.id = id;
            this.timeoffCode = timeoffCode;
            this.organizationCode = organizationCode;
            this.workerCode = workerCode;
            this.createdBy = createdBy;
            this.fromDate = fromDate;
            this.toDate = toDate;
            this.fromTime = fromTime;
            this.toTime = toTime;
            this.isRepeat = isRepeat;
            this.repeatWeek = repeatWeek;
            this.repeatMonth = repeatMonth;
            this.repeatThisYear = repeatThisYear;        
            this.cancelReason = cancelReason;
            this.reason = reason;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }
    
    
    
    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public Date getToDate() {
        return toDate;
    }

    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }

    public String getFromTime() {
        return fromTime;
    }

    public void setFromTime(String fromTime) {
        this.fromTime = fromTime;
    }

    public String getToTime() {
        return toTime;
    }

    public void setToTime(String toTime) {
        this.toTime = toTime;
    }

    public Boolean isIsRepeat() {
        return isRepeat;
    }

    public void setIsRepeat(Boolean isRepeat) {
        this.isRepeat = isRepeat;
    }

    

    public Boolean isRepeatWeek() {
        return repeatWeek;
    }

    public void setRepeatWeek(Boolean repeatWeek) {
        this.repeatWeek = repeatWeek;
    }

    public Boolean isRepeatMonth() {
        return repeatMonth;
    }

    public void setRepeatMonth(Boolean repeatMonth) {
        this.repeatMonth = repeatMonth;
    }

    public Boolean isRepeatThisYear() {
        return repeatThisYear;
    }

    public void setRepeatThisYear(Boolean repeatThisYear) {
        this.repeatThisYear = repeatThisYear;
    }

    public String getCancelReason() {
        return cancelReason;
    }

    public void setCancelReason(String cancelReason) {
        this.cancelReason = cancelReason;
    }

    public Date getFromDateTime() {
        return fromDateTime;
    }

    public void setFromDateTime(Date fromDateTime) {
        this.fromDateTime = fromDateTime;
    }

    public Date getToDateTime() {
        return toDateTime;
    }

    public void setToDateTime(Date toDateTime) {
        this.toDateTime = toDateTime;
    }
        
    @Override
    public String toString() {
            return "WorkerTimeOff [id=" + id + ", timeoffCode=" +timeoffCode+", organizationCode=" + organizationCode +", workerCode=" + workerCode + ", createdBy=" + organizationCode +", fromDate=" + fromDate
                            + ", toDate=" + toDate + ", fromTime=" + fromTime +", toTime=" + toTime +", isRepeat=" + isRepeat +", repeatWeek=" + repeatWeek +", repeatMonth=" + repeatMonth +", repeatThisYear=" + repeatThisYear +", cancelReason=" + cancelReason + ", reason=" + reason +"]";
    }
    
}
