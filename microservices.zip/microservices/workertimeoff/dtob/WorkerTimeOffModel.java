/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.workertimeoff.dtob;

import java.util.Date;

/**
 *
 * @author amit.kumar
 */
public class WorkerTimeOffModel {
    
     private Long id;
     private String timeoffCode;     
     private String organizationCode;
     private String organizationName;
     private String workerCode; 
     private String workerName; 
     private String createdBy;
     private String fromDate;
     private String toDate;  
     private Date fromDateTimestamp;
     private Date toDateTimestamp;
     private String fromTime;    
     private String toTime;    
     private Boolean isRepeat; 
     private Boolean repeatWeek;    
     private Boolean repeatMonth;   
     private Boolean repeatThisYear;
     private String cancelReason;
     private String reason;

    public Date getFromDateTimestamp() {
        return fromDateTimestamp;
    }

    public void setFromDateTimestamp(Date fromDateTimestamp) {
        this.fromDateTimestamp = fromDateTimestamp;
    }

    public Date getToDateTimestamp() {
        return toDateTimestamp;
    }

    public void setToDateTimestamp(Date toDateTimestamp) {
        this.toDateTimestamp = toDateTimestamp;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
   
     
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTimeoffCode() {
        return timeoffCode;
    }

    public void setTimeoffCode(String timeoffCode) {
        this.timeoffCode = timeoffCode;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getFromDate() {
        return fromDate;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getToDate() {
        return toDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    public String getFromTime() {
        return fromTime;
    }

    public void setFromTime(String fromTime) {
        this.fromTime = fromTime;
    }

    public String getToTime() {
        return toTime;
    }

    public void setToTime(String toTime) {
        this.toTime = toTime;
    }

    public Boolean isIsRepeat() {
        return isRepeat;
    }

    public void setIsRepeat(Boolean isRepeat) {
        this.isRepeat = isRepeat;
    }

    public Boolean isRepeatWeek() {
        return repeatWeek;
    }

    public void setRepeatWeek(Boolean repeatWeek) {
        this.repeatWeek = repeatWeek;
    }

    public Boolean isRepeatMonth() {
        return repeatMonth;
    }

    public void setRepeatMonth(Boolean repeatMonth) {
        this.repeatMonth = repeatMonth;
    }

    public Boolean isRepeatThisYear() {
        return repeatThisYear;
    }

    public void setRepeatThisYear(Boolean repeatThisYear) {
        this.repeatThisYear = repeatThisYear;
    }

    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

    public String getWorkerName() {
        return workerName;
    }

    public void setWorkerName(String workerName) {
        this.workerName = workerName;
    }

    public String getCancelReason() {
        return cancelReason;
    }

    public void setCancelReason(String cancelReason) {
        this.cancelReason = cancelReason;
    }
        
}
