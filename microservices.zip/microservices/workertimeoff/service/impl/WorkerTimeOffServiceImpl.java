/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.workertimeoff.service.impl;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.healthcarenotification.dtob.HealthcareNotification;
import com.gigflex.prototype.microservices.healthcarenotification.service.HealthcareNotificationService;
import com.gigflex.prototype.microservices.jobs.dtob.JobsAssignToWorker;
import com.gigflex.prototype.microservices.jobs.repository.JobsAssignToWorkerRepository;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.setting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.setting.repository.LocalSettingRepository;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.users.dtob.Users;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.util.GigUtil;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexDateFormatConstants;
import com.gigflex.prototype.microservices.util.GigflexDateUtil;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import com.gigflex.prototype.microservices.util.SendNotification;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.worker.repository.WorkerRepository;
import com.gigflex.prototype.microservices.workertimeoff.dtob.WorkerTimeOff;
import com.gigflex.prototype.microservices.workertimeoff.dtob.WorkerTimeOffModel;
import com.gigflex.prototype.microservices.workertimeoff.repository.WorkerTimeOffDao;
import com.gigflex.prototype.microservices.workertimeoff.service.WorkerTimeOffService;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 *
 * @author amit.kumar
 */ 
@Service
public class WorkerTimeOffServiceImpl implements WorkerTimeOffService{

    private static final Logger LOG = LoggerFactory.getLogger(WorkerTimeOffServiceImpl.class);
     
    @Autowired
    private WorkerTimeOffDao workerTimeOffDao;
    
    @Autowired
    OrganizationRepository organizationRepository;
    
    @Autowired
    WorkerRepository workerRepository;
    
    @Autowired
    GlobalSettingRepository globalSettingRepository;
    @Autowired
    LocalSettingRepository localSettingRepository;
    @Autowired
    UserTypeRepository utr;
    @Autowired
    TimeZoneRepository timeZoneDao;
    
    
    
    @Autowired
    JobsAssignToWorkerRepository jatwDao; 
    
     @Autowired
     private HealthcareNotificationService notificationService;
    
    @Value("${email.service.url}")
    private String mailServiceURL ;
    //"http://18.223.158.6:8091/superadminservice/sendEmail/to/{to}/subject/{subject}/body/{body}";
    
    @Value("${email.workertimeoffrequest.subject}")
    private String subject;
    
    @Override
    public String findAllWorkerTimeOff() {
       
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<WorkerTimeOff> workerTimeOffList = workerTimeOffDao.getAllWorkerTimeOff();
                        List<WorkerTimeOffModel> workerTimeOffModelList = new ArrayList<WorkerTimeOffModel>();
                        
                        
                        String dtFormat=GigflexConstants.YYYY_MM_DD;
                        String timeformat = GigflexConstants.HH_MM_SS;
                        
                        if(workerTimeOffList != null && workerTimeOffList.size() > 0)
                        {
                            for(int i =0;i<workerTimeOffList.size();i++)
                            {
                               WorkerTimeOff workerTimeOff = workerTimeOffList.get(i) ;
                               
                               
                               String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, workerTimeOff.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                               timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, workerTimeOff.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                               if(dateformat!=null && dateformat.trim().length()>0 )
                               {
                                    dtFormat=dateformat.trim();
                               }
                               else
                               {
                                   dtFormat=GigflexConstants.YYYY_MM_DD;
                                   
                               }
                               
                               if(timeformat!=null && timeformat.trim().length()>0)
                               {
                                    timeformat=timeformat.trim();
                               }
                               else
                               {
                                   timeformat = GigflexConstants.HH_MM_SS;
                                   
                               }
                               
                               
                               WorkerTimeOffModel workerTimeOffModel = new WorkerTimeOffModel();

                               workerTimeOffModel.setId(workerTimeOff.getId()); 
                               workerTimeOffModel.setTimeoffCode(workerTimeOff.getTimeoffCode()); 
                               workerTimeOffModel.setOrganizationCode(workerTimeOff.getOrganizationCode());                            
                               Organization oroganization = organizationRepository.findByOrganizationCode(workerTimeOff.getOrganizationCode().trim());
                               if(oroganization != null)
                               {
                                   workerTimeOffModel.setOrganizationName(oroganization.getOrganizationName()); 
                               }
                               workerTimeOffModel.setWorkerCode(workerTimeOff.getWorkerCode()); 
                               Worker worker = workerRepository.findByWorkerCode(workerTimeOff.getWorkerCode());
                               if(worker != null)
                               {
                                   workerTimeOffModel.setWorkerName(worker.getName()); 
                               }                           
                               workerTimeOffModel.setCreatedBy(workerTimeOff.getCreatedBy());                            
                               workerTimeOffModel.setFromDate(GigflexDateUtil.convertDateToString(workerTimeOff.getFromDate(), dtFormat));
                               workerTimeOffModel.setToDate(GigflexDateUtil.convertDateToString(workerTimeOff.getToDate(), dtFormat));
                               
                               Date fromTime = GigflexDateUtil.convertStringToDate(workerTimeOff.getFromTime(), GigflexConstants.HH_MM_SS); 
                               if(fromTime != null)
                               {
                                   workerTimeOffModel.setFromTime(GigflexDateUtil.convertDateToString(fromTime, timeformat));
                               }
                               else
                               {
                                   workerTimeOffModel.setFromTime("");
                               }
                                 
                               
                               Date toTime = GigflexDateUtil.convertStringToDate(workerTimeOff.getToTime(), GigflexConstants.HH_MM_SS); 
                               
                               if(toTime != null)
                               {
                                   workerTimeOffModel.setToTime(GigflexDateUtil.convertDateToString(toTime, timeformat));
                               }
                               else
                               {
                                   workerTimeOffModel.setToTime("");
                               }
                                                              
                               workerTimeOffModel.setIsRepeat(workerTimeOff.isIsRepeat()); 
                               workerTimeOffModel.setRepeatWeek(workerTimeOff.isRepeatWeek()); 
                               workerTimeOffModel.setRepeatMonth(workerTimeOff.isRepeatMonth()); 
                               workerTimeOffModel.setRepeatThisYear(workerTimeOff.isRepeatThisYear());
                               workerTimeOffModel.setReason(workerTimeOff.getReason()); 


                               workerTimeOffModelList.add(workerTimeOffModel);
                            }

                        }
                        else
                        {
                            jsonobj.put("responsecode", 404);
			    jsonobj.put("message", "Record Not Found.");
			    jsonobj.put("timestamp", new Date());
                        }
                        
                        
			if (workerTimeOffModelList != null && workerTimeOffModelList.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(workerTimeOffModelList);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   java.util.logging.Logger.getLogger(WorkerTimeOffServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
		   res = derr.toString();
        }
		return res;
    }

    @Override
    public String findTimeOffByWorkerCode(String workercode) {
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<WorkerTimeOff> workerTimeOffList = workerTimeOffDao.getTimeOffByWorkerCode(workercode);

                        List<WorkerTimeOffModel> workerTimeOffModelList = new ArrayList<WorkerTimeOffModel>();
                        
                        String dtFormat=GigflexConstants.YYYY_MM_DD;
                        String timeformat = GigflexConstants.HH_MM_SS;
                        
                        
                        if(workerTimeOffList != null && workerTimeOffList.size() > 0)
                        {
                             for(int i =0;i<workerTimeOffList.size();i++)
                            {
                               WorkerTimeOff workerTimeOff = workerTimeOffList.get(i) ;
                               
                               String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, workercode, GigflexConstants.DATEFORMAT);
                               timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, workercode, GigflexConstants.TIMEFORMAT);
                               if(dateformat!=null && dateformat.trim().length()>0 )
                               {
                                    dtFormat=dateformat.trim();
                               }
                               else
                               {
                                   dtFormat=GigflexConstants.YYYY_MM_DD;
                                   
                               }
                               
                               if(timeformat!=null && timeformat.trim().length()>0)
                               {
                                    timeformat=timeformat.trim();
                               }
                               else
                               {
                                   timeformat = GigflexConstants.HH_MM_SS;
                                   
                               }                              
                               
                               
                               WorkerTimeOffModel workerTimeOffModel = new WorkerTimeOffModel();

                               workerTimeOffModel.setId(workerTimeOff.getId()); 
                               workerTimeOffModel.setTimeoffCode(workerTimeOff.getTimeoffCode()); 
                               workerTimeOffModel.setOrganizationCode(workerTimeOff.getOrganizationCode());                            
                               Organization oroganization = organizationRepository.findByOrganizationCode(workerTimeOff.getOrganizationCode());
                               if(oroganization != null)
                               {
                                   workerTimeOffModel.setOrganizationName(oroganization.getOrganizationName()); 
                               }

                               workerTimeOffModel.setWorkerCode(workerTimeOff.getWorkerCode());                                                      
                               Worker worker = workerRepository.findByWorkerCode(workerTimeOff.getWorkerCode());
                                if(worker != null)
                               {
                                   workerTimeOffModel.setWorkerName(worker.getName()); 
                               }                    

                               workerTimeOffModel.setCreatedBy(workerTimeOff.getCreatedBy());                            
                               workerTimeOffModel.setFromDate(GigflexDateUtil.convertDateToString(workerTimeOff.getFromDate(), dtFormat));
                               workerTimeOffModel.setToDate(GigflexDateUtil.convertDateToString(workerTimeOff.getToDate(), dtFormat));
                             
                               Date fromTime = GigflexDateUtil.convertStringToDate(workerTimeOff.getFromTime(), GigflexConstants.HH_MM_SS); 
                               if(fromTime != null)
                               {
                                   workerTimeOffModel.setFromTime(GigflexDateUtil.convertDateToString(fromTime, timeformat));
                               }
                               else
                               {
                                   workerTimeOffModel.setFromTime("");
                               }
                                 
                               
                               Date toTime = GigflexDateUtil.convertStringToDate(workerTimeOff.getToTime(), GigflexConstants.HH_MM_SS); 
                               
                               if(toTime != null)
                               {
                                   workerTimeOffModel.setToTime(GigflexDateUtil.convertDateToString(toTime, timeformat));
                               }
                               else
                               {
                                   workerTimeOffModel.setToTime("");
                               }
                               
                               workerTimeOffModel.setIsRepeat(workerTimeOff.isIsRepeat()); 
                               workerTimeOffModel.setRepeatWeek(workerTimeOff.isRepeatWeek()); 
                               workerTimeOffModel.setRepeatMonth(workerTimeOff.isRepeatMonth()); 
                               workerTimeOffModel.setRepeatThisYear(workerTimeOff.isRepeatThisYear());  
                               workerTimeOffModel.setReason(workerTimeOff.getReason());

                               workerTimeOffModelList.add(workerTimeOffModel);
                            }
                        }
                        else
                        {
                            jsonobj.put("responsecode", 404);
			    jsonobj.put("message", "Record Not Found.");
			    jsonobj.put("timestamp", new Date());
                        }
                        

                        
                        
			if (workerTimeOffModelList != null && workerTimeOffModelList.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(workerTimeOffModelList);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   java.util.logging.Logger.getLogger(WorkerTimeOffServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
            }
		return res;
    }

    @Override
    public String findTimeOffByWorkerCodeAndBetweenDates(String workercode, String reqFromDate, String reqToDate) {
       String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        
                        String dtFormat=GigflexConstants.YYYY_MM_DD;
                        //String timeformat = GigflexConstants.HH_MM_SS;
                        
                        if(workercode != null && workercode.trim().length() > 0 
                                && reqFromDate != null && reqFromDate.trim().length() > 0 
                                && reqToDate != null && reqToDate.trim().length() > 0)
                        {
                              if(!GigflexDateUtil.isDate(reqFromDate.trim(), GigflexDateFormatConstants.YYYY_MM_DD))
                            {
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                             "Plz send From date in correct format("+GigflexDateFormatConstants.YYYY_MM_DD+") ");
                                             return derr.toString();
                            }

                            if(!GigflexDateUtil.isDate(reqToDate.trim(), GigflexDateFormatConstants.YYYY_MM_DD))
                            {
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                             "Plz send To date in correct format("+GigflexDateFormatConstants.YYYY_MM_DD+") ");
                                             return derr.toString();
                            }

                            Date fromdate = null;
                            Date toDate = null;

                            try {
                                fromdate = GigflexDateUtil.convertStringToDate(reqFromDate.trim(), GigflexDateFormatConstants.YYYY_MM_DD);
                                toDate =   GigflexDateUtil.convertStringToDate(reqToDate.trim(), GigflexDateFormatConstants.YYYY_MM_DD);
                            } catch (Exception ex) {
                                java.util.logging.Logger.getLogger(WorkerTimeOffServiceImpl.class.getName()).log(Level.SEVERE, null, ex);

                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                                "Plz send date in correct format("+GigflexDateFormatConstants.YYYY_MM_DD+") ");
                                                return derr.toString();
                            }

                            if(fromdate.after(toDate)) 
                            {
                                 GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                                "From date should be less than todate ");
                                                return derr.toString();
                            }
                            
                            
                            
                            List<WorkerTimeOff> workerTimeOffList = workerTimeOffDao.getTimeOffByWorkerCodeAndBetweenDate(workercode,fromdate,toDate);

                            List<WorkerTimeOffModel> workerTimeOffModelList = new ArrayList<WorkerTimeOffModel>();

                            if(workerTimeOffList != null && workerTimeOffList.size() > 0)
                            {
                                 for(int i =0;i<workerTimeOffList.size();i++)
                                {
                                   WorkerTimeOff workerTimeOff = workerTimeOffList.get(i) ;
                                   
                                    String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, workercode, GigflexConstants.DATEFORMAT);
                     //               timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, workerTimeOff.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                    if(dateformat!=null && dateformat.trim().length()>0 )
                                    {
                                         dtFormat=dateformat.trim();
                                    }
                                    else
                                    {
                                        dtFormat=GigflexConstants.YYYY_MM_DD;

                                    }

//                                    if(timeformat!=null && timeformat.trim().length()>0)
//                                    {
//                                         timeformat=timeformat.trim();
//                                    }
//                                    else
//                                    {
//                                        timeformat = GigflexConstants.HH_MM_SS;
//
//                                    }           
//                                    
                                   
                                   WorkerTimeOffModel workerTimeOffModel = new WorkerTimeOffModel();

                                   workerTimeOffModel.setId(workerTimeOff.getId()); 
                                   workerTimeOffModel.setTimeoffCode(workerTimeOff.getTimeoffCode()); 
                                   workerTimeOffModel.setOrganizationCode(workerTimeOff.getOrganizationCode());                            
                                   Organization oroganization = organizationRepository.findByOrganizationCode(workerTimeOff.getOrganizationCode());
                                   if(oroganization != null)
                                   {
                                       workerTimeOffModel.setOrganizationName(oroganization.getOrganizationName()); 
                                   }

                                   workerTimeOffModel.setWorkerCode(workerTimeOff.getWorkerCode());                                                      
                                   Worker worker = workerRepository.findByWorkerCode(workerTimeOff.getWorkerCode());
                                    if(worker != null)
                                   {
                                       workerTimeOffModel.setWorkerName(worker.getName()); 
                                   }                    

                                   workerTimeOffModel.setCreatedBy(workerTimeOff.getCreatedBy());                            
                                   workerTimeOffModel.setFromDate(GigflexDateUtil.convertDateToString(workerTimeOff.getFromDate(), dtFormat));
                                   workerTimeOffModel.setToDate(GigflexDateUtil.convertDateToString(workerTimeOff.getToDate(), dtFormat));
                                   workerTimeOffModel.setFromDateTimestamp(workerTimeOff.getFromDate());
                                   workerTimeOffModel.setToDateTimestamp(workerTimeOff.getToDate());
//                                  Date fromTime = GigflexDateUtil.convertStringToDate(workerTimeOff.getFromTime(), GigflexConstants.HH_MM_SS); 
//                                    if(fromTime != null)
//                                    {
//                                        workerTimeOffModel.setFromTime(GigflexDateUtil.convertDateToString(fromTime, timeformat));
//                                    }
//                                    else
//                                    {
//                                        workerTimeOffModel.setFromTime("");
//                                    }
                                    workerTimeOffModel.setFromTime(workerTimeOff.getFromTime());

//                                    Date toTime = GigflexDateUtil.convertStringToDate(workerTimeOff.getToTime(), GigflexConstants.HH_MM_SS); 
//
//                                    if(toTime != null)
//                                    {
//                                        workerTimeOffModel.setToTime(GigflexDateUtil.convertDateToString(toTime, timeformat));
//                                    }
//                                    else
//                                    {
//                                        workerTimeOffModel.setToTime("");
//                                    }
                                   workerTimeOffModel.setToTime(workerTimeOff.getToTime());
                                   
                                   workerTimeOffModel.setIsRepeat(workerTimeOff.isIsRepeat()); 
                                   workerTimeOffModel.setRepeatWeek(workerTimeOff.isRepeatWeek()); 
                                   workerTimeOffModel.setRepeatMonth(workerTimeOff.isRepeatMonth()); 
                                   workerTimeOffModel.setRepeatThisYear(workerTimeOff.isRepeatThisYear());  
                                   workerTimeOffModel.setReason(workerTimeOff.getReason());

                                   workerTimeOffModelList.add(workerTimeOffModel);
                                }
                            }
                            else
                            {
                                jsonobj.put("responsecode", 404);
                                jsonobj.put("message", "Record Not Found.");
                                jsonobj.put("timestamp", new Date());
                            }




                            if (workerTimeOffModelList != null && workerTimeOffModelList.size() > 0) {
                                    jsonobj.put("responsecode", 200);
                                    jsonobj.put("message", "Success");
                                    jsonobj.put("timestamp", new Date());
                                    ObjectMapper mapperObj = new ObjectMapper();
                                    String Detail = mapperObj.writeValueAsString(workerTimeOffModelList);
                                    jsonobj.put("data", new JSONArray(Detail));
                            } else {
                                    jsonobj.put("responsecode", 404);
                                    jsonobj.put("message", "Record Not Found.");
                                    jsonobj.put("timestamp", new Date());
                            }
                        }
                        else
                        {
                            
                            jsonobj.put("responsecode", 404);
                            jsonobj.put("message", "Record Not Found.");
                            jsonobj.put("timestamp", new Date());
                            
                        }
                        
                        
                       
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                   java.util.logging.Logger.getLogger(WorkerTimeOffServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
                   GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
            }
		return res;
    }
    
    
    @Override
    public String findTimeOffByOrganizationCode(String organizationcode) {
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        String dtFormat=GigflexConstants.YYYY_MM_DD;
                        String timeformat = GigflexConstants.HH_MM_SS;
			List<WorkerTimeOff> workerTimeOffList = workerTimeOffDao.getTimeOffByOrganizationCode(organizationcode);

                        List<WorkerTimeOffModel> workerTimeOffModelList = new ArrayList<WorkerTimeOffModel>();
                        
                        if(workerTimeOffList != null && workerTimeOffList.size() > 0)
                        {
                             for(int i =0;i<workerTimeOffList.size();i++)
                            {
                               WorkerTimeOff workerTimeOff = workerTimeOffList.get(i) ;
                               
                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, workerTimeOff.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, workerTimeOff.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                if(dateformat!=null && dateformat.trim().length()>0 )
                                {
                                     dtFormat=dateformat.trim();
                                }
                                else
                                {
                                    dtFormat=GigflexConstants.YYYY_MM_DD;

                                }

                                if(timeformat!=null && timeformat.trim().length()>0)
                                {
                                     timeformat=timeformat.trim();
                                }
                                else
                                {
                                    timeformat = GigflexConstants.HH_MM_SS;

                                }     
                               
                               WorkerTimeOffModel workerTimeOffModel = new WorkerTimeOffModel();

                               workerTimeOffModel.setId(workerTimeOff.getId()); 
                               workerTimeOffModel.setTimeoffCode(workerTimeOff.getTimeoffCode()); 
                               workerTimeOffModel.setOrganizationCode(workerTimeOff.getOrganizationCode());                            
                               Organization oroganization = organizationRepository.findByOrganizationCode(workerTimeOff.getOrganizationCode());
                                if(oroganization != null)
                               {
                                   workerTimeOffModel.setOrganizationName(oroganization.getOrganizationName()); 
                               }                         
                               workerTimeOffModel.setWorkerCode(workerTimeOff.getWorkerCode());                                                      
                               Worker worker = workerRepository.findByWorkerCode(workerTimeOff.getWorkerCode());
                               if(worker != null)
                               {
                                   workerTimeOffModel.setWorkerName(worker.getName()); 
                               }       
                               workerTimeOffModel.setCreatedBy(workerTimeOff.getCreatedBy());                            
                               workerTimeOffModel.setFromDate(GigflexDateUtil.convertDateToString(workerTimeOff.getFromDate(), dtFormat));
                               workerTimeOffModel.setToDate(GigflexDateUtil.convertDateToString(workerTimeOff.getToDate(), dtFormat));
                              
                              Date fromTime = GigflexDateUtil.convertStringToDate(workerTimeOff.getFromTime(), GigflexConstants.HH_MM_SS); 
                               if(fromTime != null)
                               {
                                   workerTimeOffModel.setFromTime(GigflexDateUtil.convertDateToString(fromTime, timeformat));
                               }
                               else
                               {
                                   workerTimeOffModel.setFromTime("");
                               }
                                 
                               
                               Date toTime = GigflexDateUtil.convertStringToDate(workerTimeOff.getToTime(), GigflexConstants.HH_MM_SS); 
                               
                               if(toTime != null)
                               {
                                   workerTimeOffModel.setToTime(GigflexDateUtil.convertDateToString(toTime, timeformat));
                               }
                               else
                               {
                                   workerTimeOffModel.setToTime("");
                               }
                               
                               workerTimeOffModel.setIsRepeat(workerTimeOff.isIsRepeat()); 
                               workerTimeOffModel.setRepeatWeek(workerTimeOff.isRepeatWeek()); 
                               workerTimeOffModel.setRepeatMonth(workerTimeOff.isRepeatMonth()); 
                               workerTimeOffModel.setRepeatThisYear(workerTimeOff.isRepeatThisYear());
                               workerTimeOffModel.setReason(workerTimeOff.getReason());
                               workerTimeOffModelList.add(workerTimeOffModel);
                            }
                        }
                        else
                        {
                            jsonobj.put("responsecode", 400);
			    jsonobj.put("message", "Record Not Found.");
			    jsonobj.put("timestamp", new Date());
                        }
                        
                        
                        
			if (workerTimeOffModelList != null && workerTimeOffModelList.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(workerTimeOffModelList);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                 java.util.logging.Logger.getLogger(WorkerTimeOffServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
                 GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
                 
        }
		return res;
    }
    
    
    @Override
    public String findTimeOffByTimeOffCode(String timeOffcode) {
        
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        String dtFormat=GigflexConstants.YYYY_MM_DD;
                        String timeformat = GigflexConstants.HH_MM_SS;
			WorkerTimeOff workerTimeOff = workerTimeOffDao.getTimeOffByTimeOffCode(timeOffcode);
                        WorkerTimeOffModel workerTimeOffModel = new WorkerTimeOffModel();
                        
                        if(workerTimeOff != null )
                        {                       

                                String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, workerTimeOff.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, workerTimeOff.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                if(dateformat!=null && dateformat.trim().length()>0 )
                                {
                                     dtFormat=dateformat.trim();
                                }
                                else
                                {
                                    dtFormat=GigflexConstants.YYYY_MM_DD;

                                }

                                if(timeformat!=null && timeformat.trim().length()>0)
                                {
                                     timeformat=timeformat.trim();
                                }
                                else
                                {
                                    timeformat = GigflexConstants.HH_MM_SS;

                                }     
                            
                               workerTimeOffModel.setId(workerTimeOff.getId()); 
                               workerTimeOffModel.setTimeoffCode(workerTimeOff.getTimeoffCode()); 
                               workerTimeOffModel.setOrganizationCode(workerTimeOff.getOrganizationCode());                            
                               Organization oroganization = organizationRepository.findByOrganizationCode(workerTimeOff.getOrganizationCode());
                                if(oroganization != null)
                               {
                                   workerTimeOffModel.setOrganizationName(oroganization.getOrganizationName()); 
                               }                         
                               workerTimeOffModel.setWorkerCode(workerTimeOff.getWorkerCode());                                                      
                               Worker worker = workerRepository.findByWorkerCode(workerTimeOff.getWorkerCode());
                               if(worker != null)
                               {
                                   workerTimeOffModel.setWorkerName(worker.getName()); 
                               }       
                               workerTimeOffModel.setCreatedBy(workerTimeOff.getCreatedBy());                            
                               workerTimeOffModel.setFromDate(GigflexDateUtil.convertDateToString(workerTimeOff.getFromDate(), dtFormat));
                               workerTimeOffModel.setToDate(GigflexDateUtil.convertDateToString(workerTimeOff.getToDate(), dtFormat));
                             
                               Date fromTime = GigflexDateUtil.convertStringToDate(workerTimeOff.getFromTime(), GigflexConstants.HH_MM_SS); 
                               if(fromTime != null)
                               {
                                   workerTimeOffModel.setFromTime(GigflexDateUtil.convertDateToString(fromTime, timeformat));
                               }
                               else
                               {
                                   workerTimeOffModel.setFromTime("");
                               }
                                 
                               
                               Date toTime = GigflexDateUtil.convertStringToDate(workerTimeOff.getToTime(), GigflexConstants.HH_MM_SS); 
                               
                               if(toTime != null)
                               {
                                   workerTimeOffModel.setToTime(GigflexDateUtil.convertDateToString(toTime, timeformat));
                               }
                               else
                               {
                                   workerTimeOffModel.setToTime("");
                               }
                               
                               workerTimeOffModel.setIsRepeat(workerTimeOff.isIsRepeat()); 
                               workerTimeOffModel.setRepeatWeek(workerTimeOff.isRepeatWeek()); 
                               workerTimeOffModel.setRepeatMonth(workerTimeOff.isRepeatMonth()); 
                               workerTimeOffModel.setRepeatThisYear(workerTimeOff.isRepeatThisYear());
                               workerTimeOffModel.setReason(workerTimeOff.getReason());                            
                        }
                        else
                        {
                            jsonobj.put("responsecode", 404);
			    jsonobj.put("message", "Record Not Found.");
			    jsonobj.put("timestamp", new Date());
                        }
                        
                        
                        
			if (workerTimeOffModel != null && workerTimeOffModel.toString().trim().length() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(workerTimeOffModel);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
                 java.util.logging.Logger.getLogger(WorkerTimeOffServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
                 GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
                 
        }
		return res;
    }
    

    @Override
    public String saveWorkerTimeOff(WorkerTimeOffModel workerTimeOffReq, String ip) {
        
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (workerTimeOffReq != null) {
                                                        
                            
			if (workerTimeOffReq.getWorkerCode()!=null && workerTimeOffReq.getWorkerCode().trim().length() > 0
                                && workerTimeOffReq.getFromDate() != null &&  workerTimeOffReq.getFromDate().trim().length() > 0 
                                && workerTimeOffReq.getToDate() != null && workerTimeOffReq.getToDate().trim().length() >0
                                &&workerTimeOffReq.getOrganizationCode()!=null && workerTimeOffReq.getOrganizationCode().trim().length()>0 ) {
                                       
                            
                            if(!GigflexDateUtil.isDate(workerTimeOffReq.getFromDate().trim(), GigflexDateFormatConstants.YYYY_MM_DD))
                               {
                                   GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send From date in correct format("+GigflexDateFormatConstants.YYYY_MM_DD+") ");
						return derr.toString();
                               }
                               
                               if(!GigflexDateUtil.isDate(workerTimeOffReq.getToDate().trim(), GigflexDateFormatConstants.YYYY_MM_DD))
                               {
                                   GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send To date in correct format("+GigflexDateFormatConstants.YYYY_MM_DD+") ");
						return derr.toString();
                               }
                            
                             Date fromdate = null;
                             Date toDate = null;
                                                             
                                fromdate = GigflexDateUtil.convertStringToDate(workerTimeOffReq.getFromDate().trim(), GigflexDateFormatConstants.YYYY_MM_DD);
                                toDate =   GigflexDateUtil.convertStringToDate(workerTimeOffReq.getToDate().trim(), GigflexDateFormatConstants.YYYY_MM_DD);
                                
                                if(fromdate == null  ||  toDate == null)
                                {
                                    //java.util.logging.Logger.getLogger(WorkerTimeOffServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
                                
                                    GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send date in correct format("+GigflexDateFormatConstants.YYYY_MM_DD+") ");
						return derr.toString();
                                }
                                
                               String gFromTime="00:00:00" ;
                               if(workerTimeOffReq.getFromTime()!=null && workerTimeOffReq.getFromTime().trim().length() > 0)
                               {
                                   String strFromTime = workerTimeOffReq.getFromTime().trim();
                                   
                                   if(!GigflexDateUtil.isDate(strFromTime, GigflexConstants.HH_MM_SS))
                                   {
                                        GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send from time in correct format("+GigflexConstants.HH_MM_SS+") ");
						return derr.toString();
                                   }
                                   gFromTime=strFromTime;
                               }
                                
                               String gToTime="23:59:59" ;
                               if(workerTimeOffReq.getToTime()!=null && workerTimeOffReq.getToTime().trim().length() > 0)
                               {
                                   String strToTime = workerTimeOffReq.getToTime().trim();
                                   
                                   if(!GigflexDateUtil.isDate(strToTime, GigflexConstants.HH_MM_SS))
                                   {
                                        GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send to time in correct format("+GigflexConstants.HH_MM_SS+") ");
						return derr.toString();
                                   }
                                   gToTime=strToTime;
                               }
                             Date fromTimeStamp=null;
                             Date toTimeStamp=null;
                             String from=workerTimeOffReq.getFromDate()+" "+gFromTime;
                             String to=workerTimeOffReq.getToDate()+" "+gToTime;
                             String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, workerTimeOffReq.getOrganizationCode(), GigflexConstants.TimeZone);  
                             if(timezoneCode!=null && timezoneCode.length()>0 )
                             {
                                TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                if(tzd!=null && tzd.getTimeZoneName()!=null && tzd.getTimeZoneName().length()>0 )
                                {
                                        String timezone=tzd.getTimeZoneName();
                                        fromTimeStamp = GigflexDateUtil.convertStringDateToGMT(from, timezone,GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                                        toTimeStamp = GigflexDateUtil.convertStringDateToGMT(to, timezone,GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                                }
                            }
                                                       
                            WorkerTimeOff workerTimeOff = new WorkerTimeOff();
                            workerTimeOff.setFromDateTime(fromTimeStamp);
                            workerTimeOff.setToDateTime(toTimeStamp);
                            workerTimeOff.setIpAddress(ip);
                            workerTimeOff.setOrganizationCode(workerTimeOffReq.getOrganizationCode());
                            workerTimeOff.setWorkerCode(workerTimeOffReq.getWorkerCode()); 
                            workerTimeOff.setCreatedBy(workerTimeOffReq.getCreatedBy());
                            workerTimeOff.setFromDate(fromdate);
                            workerTimeOff.setToDate(toDate);
                            workerTimeOff.setFromTime(workerTimeOffReq.getFromTime());
                            workerTimeOff.setToTime(workerTimeOffReq.getToTime()); 
                            workerTimeOff.setIsRepeat(workerTimeOffReq.isIsRepeat());
                            workerTimeOff.setRepeatWeek(workerTimeOffReq.isRepeatWeek());
                            workerTimeOff.setRepeatMonth(workerTimeOffReq.isRepeatMonth()); 
                            workerTimeOff.setRepeatThisYear(workerTimeOffReq.isRepeatThisYear());
                            workerTimeOff.setReason(workerTimeOffReq.getReason());
					
                            WorkerTimeOff workerTimeOffRes = workerTimeOffDao.save(workerTimeOff);

                            if (workerTimeOffRes != null && workerTimeOffRes.getId() > 0) {
                                                                       
                                List<JobsAssignToWorker>  jatwList = workerTimeOffDao.getJobAssignedWorkerByWorkerCodeOrganizationCodeAndBetweenDates(workerTimeOffRes.getWorkerCode(),workerTimeOffRes.getFromDateTime(),workerTimeOffRes.getToDateTime(),GigflexConstants.JOBSTATUS_ACCEPTED,GigflexConstants.JOBSTATUS_ASSIGNED,workerTimeOffRes.getOrganizationCode());
                                Users user  = workerTimeOffDao.getAdminByOrganizationCode(workerTimeOffRes.getOrganizationCode()); 
                                Worker worker = workerRepository.getWorkerdetailByworkerCode(workerTimeOffRes.getWorkerCode());
                                    String workerName = "";
                                    if(worker != null && worker.getId() > 0)
                                    {
                                        workerName = worker.getName();
                                    }
                                if(jatwList != null && jatwList.size() > 0)
                                {
                                    for(JobsAssignToWorker jatw :jatwList )
                                    {
                                        jatw.setStatus(GigflexConstants.JOBSTATUS_PENDING); 
                                        jatw.setWorkerCode(null);
                                        jatw.setDistance(null);
                                        jatw.setDrivingTimeInSec(null);
                                        JobsAssignToWorker jatwRes = jatwDao.save(jatw); 
                                        
                                        if(jatwRes != null && jatwRes.getId() > 0 )
                                        {
                                           String appointmentId = jatwRes.getAppointmentId();
                                            
                                        //code for email
                                        
                                        String email ="";        
                                        if(user != null)
                                        {
                                            email = user.getEmail();
                                        }
                                        String bodyContent = " For Appointment Id : "+appointmentId+" worker "+workerName+" is going for time off so job status for assigned/accepted  job is reset as pending. Please reassign this job.<br>";
                                        SendNotification sn = new SendNotification();
    
                                        if (email != null && email.length() > 0) {
                                           String response=  sn.sendMail(email, subject, bodyContent, mailServiceURL);
    
                                           LOG.info("Cron scheduler mail response in DriverTimeOffServiceImpl >>>>>>", response);
                                         } 
                                        
                                        
                                            HealthcareNotification notification = new HealthcareNotification();

                                            String bodyContentShortMessage = "Worker "+workerName+" is going for time off so job status for assigned/accepted  job is reset as pending. Please reassign this job.<br>. Details are given below-"
                                                            + "Appointment Id : " + appointmentId ;
                                            String shortMessage = "Worker has taken time off successfully.";

                                            notification.setUserCode(user.getUserCode());
                                            notification.setMessage(bodyContentShortMessage);
                                            notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_ADMIN);
                                            notification.setShortMessage(shortMessage);
                                            notification.setAppointmentCode(appointmentId);
                                            notification.setIsRead(Boolean.FALSE);
                                            notification.setIpAddress(ip);

                                            notificationService.saveHealthcareNotification(notification);
                                            
                                        }
                                        
                                    }
                                }
                                else
                                {
                                    
                                    HealthcareNotification notification = new HealthcareNotification();

                                    
                                    
                                    String bodyContentShortMessage = "Worker is going for time off.Details are given below-"
                                                    + "Worker Name : "+workerName+
                                                     ", Time off from date : " + workerTimeOffRes.getFromDate()+
                                                     ", Time off from time :" + workerTimeOffRes.getFromTime()+
                                                     ", Time off to date :" +workerTimeOffRes.getToDate() +
                                                     " , Time off to time :"+workerTimeOffRes.getToTime(); 
                                    
                                    String shortMessage = "Worker"+workerName+" has taken time off successfully.";

                                    notification.setUserCode(user.getUserCode());
                                    notification.setMessage(bodyContentShortMessage);
                                    notification.setUserType("All");
                                    notification.setShortMessage(shortMessage);
                                    notification.setAppointmentCode("");
                                    notification.setIsRead(Boolean.FALSE);
                                    notification.setIpAddress(ip);

                                    notificationService.saveHealthcareNotification(notification);
                                    
                                }
                                

                                
                                
                                
                                
                                
                                    jsonobj.put("responsecode", 200);
                                    jsonobj.put("timestamp", new Date());
                                    jsonobj.put("message",
                                                    "Worker Time Off has been added successfully.");
                                    ObjectMapper mapperObj = new ObjectMapper();
                                    String Detail = mapperObj.writeValueAsString(workerTimeOffRes);
                                    jsonobj.put("data", new JSONObject(Detail));
                            } else {
                                
                                    jsonobj.put("responsecode", 400);
                                    jsonobj.put("timestamp", new Date());                                
                                    jsonobj.put("message", "Failed");
                            }
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Organization Code, Worker Code,From Date and To Date should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
        
    }

    @Override
    public String updateWorkerTimeOffByTimeOffcode(String timeOffCode, WorkerTimeOffModel workerTimeOffReq, String ip) {
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if ( timeOffCode != null && timeOffCode.trim().length() > 0 && workerTimeOffReq != null) {
                            
				if (workerTimeOffReq.getWorkerCode()!=null && workerTimeOffReq.getWorkerCode().trim().length() > 0
                                && workerTimeOffReq.getFromDate() != null &&  workerTimeOffReq.getFromDate().trim().length() > 0 
                                && workerTimeOffReq.getToDate() != null && workerTimeOffReq.getToDate().trim().length() >0) {

                               if(!GigflexDateUtil.isDate(workerTimeOffReq.getFromDate().trim(), GigflexDateFormatConstants.YYYY_MM_DD))
                               {
                                   GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send From date in correct format("+GigflexDateFormatConstants.YYYY_MM_DD+") ");
						return derr.toString();
                               }
                               
                               if(!GigflexDateUtil.isDate(workerTimeOffReq.getToDate().trim(), GigflexDateFormatConstants.YYYY_MM_DD))
                               {
                                   GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send To date in correct format("+GigflexDateFormatConstants.YYYY_MM_DD+") ");
						return derr.toString();
                               }
                              
                                  Date fromdate = null;
                                  Date toDate = null;
                             
                                  fromdate = GigflexDateUtil.convertStringToDate(workerTimeOffReq.getFromDate().trim(), GigflexDateFormatConstants.YYYY_MM_DD);
                                  toDate =   GigflexDateUtil.convertStringToDate(workerTimeOffReq.getToDate().trim(), GigflexDateFormatConstants.YYYY_MM_DD);
                                
                                  if(fromdate == null  ||  toDate == null)
                                  {
                                        //java.util.logging.Logger.getLogger(WorkerTimeOffServiceImpl.class.getName()).log(Level.SEVERE, null, ex);

                                        GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                                    "Plz send date in correct format("+GigflexDateFormatConstants.YYYY_MM_DD+") ");
                                                    return derr.toString();
                                  }
                                    
                               String gFromTime="00:00:00" ;
                               if(workerTimeOffReq.getFromTime()!=null && workerTimeOffReq.getFromTime().trim().length() > 0)
                               {
                                   String strFromTime = workerTimeOffReq.getFromTime().trim();
                                   
                                   if(!GigflexDateUtil.isDate(strFromTime, GigflexConstants.HH_MM_SS))
                                   {
                                        GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send from time in correct format("+GigflexConstants.HH_MM_SS+") ");
						return derr.toString();
                                   }
                                   gFromTime=strFromTime;
                               }
                                
                               String gToTime="23:59:59" ;
                               if(workerTimeOffReq.getToTime()!=null && workerTimeOffReq.getToTime().trim().length() > 0)
                               {
                                   String strToTime = workerTimeOffReq.getToTime().trim();
                                   
                                   if(!GigflexDateUtil.isDate(strToTime, GigflexConstants.HH_MM_SS))
                                   {
                                        GigflexResponse derr = new GigflexResponse(400, new Date(),
								"Plz send to time in correct format("+GigflexConstants.HH_MM_SS+") ");
						return derr.toString();
                                   }
                                   gToTime=strToTime;
                               }
                               
                            WorkerTimeOff workerTimeOffInDb = workerTimeOffDao.getTimeOffByTimeOffCode(timeOffCode); 
                            if (workerTimeOffInDb != null && workerTimeOffInDb.getId() > 0) {

                                Date fromTimeStamp=null;
                                Date toTimeStamp=null;
                                String from=workerTimeOffReq.getFromDate()+" "+gFromTime;
                                String to=workerTimeOffReq.getToDate()+" "+gToTime;
                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, workerTimeOffInDb.getOrganizationCode(), GigflexConstants.TimeZone);  
                                if(timezoneCode!=null && timezoneCode.length()>0 )
                    {
                        TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                        if(tzd!=null && tzd.getTimeZoneName()!=null && tzd.getTimeZoneName().length()>0 )
                    {
                        String timezone=tzd.getTimeZoneName();
				fromTimeStamp = GigflexDateUtil.convertStringDateToGMT(from, timezone,GigflexConstants.DD_MM_YYYY_HH_MM_SS);
				toTimeStamp = GigflexDateUtil.convertStringDateToGMT(to, timezone,GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                    }
                    }
						workerTimeOffInDb.setFromDateTime(fromTimeStamp);
                                                workerTimeOffInDb.setToDateTime(toTimeStamp);
						workerTimeOffInDb.setFromDate(fromdate);
                                                workerTimeOffInDb.setToDate(toDate); 
                                                workerTimeOffInDb.setFromTime(workerTimeOffReq.getFromTime()); 
                                                workerTimeOffInDb.setToTime(workerTimeOffReq.getToTime()); 
                                                workerTimeOffInDb.setOrganizationCode(workerTimeOffReq.getOrganizationCode()); 
                                                workerTimeOffInDb.setIsRepeat(workerTimeOffReq.isIsRepeat()); 
                                                workerTimeOffInDb.setRepeatWeek(workerTimeOffReq.isRepeatWeek()); 
                                                workerTimeOffInDb.setRepeatMonth(workerTimeOffReq.isRepeatMonth()); 
                                                workerTimeOffInDb.setRepeatThisYear(workerTimeOffReq.isRepeatThisYear()); 
                                                workerTimeOffInDb.setReason(workerTimeOffReq.getReason());
                                                
	                                        workerTimeOffInDb.setIpAddress(ip);

						WorkerTimeOff workerTimeOffRes = workerTimeOffDao.save(workerTimeOffInDb);
						if (workerTimeOffRes != null && workerTimeOffRes.getId() > 0) {
                                                    
                                                    
                                                    List<JobsAssignToWorker>  jatwList = workerTimeOffDao.getJobAssignedWorkerByWorkerCodeOrganizationCodeAndBetweenDates(workerTimeOffRes.getWorkerCode(),workerTimeOffRes.getFromDateTime(),workerTimeOffRes.getToDateTime(),GigflexConstants.JOBSTATUS_ACCEPTED,GigflexConstants.JOBSTATUS_ASSIGNED,workerTimeOffRes.getOrganizationCode());

                                                    Users user  = workerTimeOffDao.getAdminByOrganizationCode(workerTimeOffRes.getOrganizationCode()); 
                                                    Worker worker = workerRepository.getWorkerdetailByworkerCode(workerTimeOffRes.getWorkerCode());
                                                    String workerName = "";
                                                    if(worker != null && worker.getId() > 0)
                                                    {
                                                        workerName = worker.getName();
                                                    }
                                                    if(jatwList != null && jatwList.size() > 0)
                                                    {
                                                        for(JobsAssignToWorker jatw :jatwList )
                                                        {

                                                            jatw.setStatus(GigflexConstants.JOBSTATUS_PENDING); 
                                                            jatw.setWorkerCode(null);
                                                            jatw.setDistance(null);
                                                            jatw.setDrivingTimeInSec(null);
                                                            JobsAssignToWorker jatwRes = jatwDao.save(jatw); 

                                                            if(jatwRes != null && jatwRes.getId() > 0 )
                                                            {
                                                                String appointmentId = jatwRes.getAppointmentId();

                                                            //code for email

                                                            String email ="";        
                                                            if(user != null)
                                                            {
                                                                email = user.getEmail();
                                                            }
                                                            String bodyContent = "For appointment id : "+appointmentId+" worker "+workerName+" is going for time off so job status for assigned/accepted  job is reset as pending. Please reassign this job.<br>";
                                                            SendNotification sn = new SendNotification();

                                                            if (email != null && email.length() > 0) {
                                                               String response=  sn.sendMail(email, subject, bodyContent, mailServiceURL);

                                                               LOG.info("Cron scheduler mail response in DriverTimeOffServiceImpl >>>>>>", response);
                                                             } 

                                                            HealthcareNotification notification = new HealthcareNotification();

                                                            String bodyContentShortMessage = "Worker "+workerName+" is going for time off so job status for assigned/accepted  job is reset as pending. Please reassign this job.<br>. Details are given below-"
                                                                            + "Appointment ID : " + appointmentId ;
                                                            String shortMessage = "Worker "+workerName+" has updated time off successfully.";

                                                            notification.setUserCode(user.getUserCode());
                                                            notification.setMessage(bodyContentShortMessage);
                                                            notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_ADMIN);
                                                            notification.setShortMessage(shortMessage);
                                                            notification.setAppointmentCode(appointmentId); 
                                                            notification.setIsRead(Boolean.FALSE);
                                                            notification.setIpAddress(ip);

                                                            notificationService.saveHealthcareNotification(notification);

                                                            }

                                                        }
                                                    }
                                                    else
                                                    {
                                                        HealthcareNotification notification = new HealthcareNotification();

                                                        String bodyContentShortMessage = "Worker has updated time off.Details are given below-"
                                                        + "Worker Name : "+workerName+
                                                         ", Time off from date : " + workerTimeOffRes.getFromDate()+
                                                         ", Time off from time :" + workerTimeOffRes.getFromTime()+
                                                         ", Time off to date :" +workerTimeOffRes.getToDate() +
                                                         " , Time off to time :"+workerTimeOffRes.getToTime(); 
                                    
                                                        String shortMessage = "Worker "+workerName+" has updated time off successfully.";

                                                        notification.setUserCode(user.getUserCode());
                                                        notification.setMessage(bodyContentShortMessage);
                                                        notification.setUserType("All");
                                                        notification.setShortMessage(shortMessage);
                                                        notification.setAppointmentCode("");
                                                        notification.setIsRead(Boolean.FALSE);
                                                        notification.setIpAddress(ip);

                                                        notificationService.saveHealthcareNotification(notification);
                                                    }
                                                    
                                                    
							jsonobj.put("responsecode", 200);
							jsonobj.put("message",
									"Worker Time Off updation has been done");
							jsonobj.put("timestamp", new Date());
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj
									.writeValueAsString(workerTimeOffRes); 
							jsonobj.put("data", new JSONObject(Detail));
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message",
									"Worker Time Off updation has been failed.");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Worker Time Off ID is not valid.");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Worker Code,From Date & To Date should not be blank");

				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
    }

    @Override
    public String cancelTimeOffBytimeOffCode(String timeOffCode, String reason) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			WorkerTimeOff workerTimeOffInDb = workerTimeOffDao.getTimeOffByTimeOffCode(timeOffCode); 
			if (workerTimeOffInDb != null && workerTimeOffInDb.getId() > 0) {

                                workerTimeOffInDb.setIsDeleted(true);
                                workerTimeOffInDb.setCancelReason(reason); 
                                WorkerTimeOff workerTimeOffRes = workerTimeOffDao.save(workerTimeOffInDb);
                                if (workerTimeOffRes != null && workerTimeOffRes.getId() > 0) {
                                        jsonobj.put("responsecode", 200);
                                        jsonobj.put("timestamp", new Date());
                                        jsonobj.put("message",
                                                        "Worker Time Off cancelled successfully.");
                                        // kafkaService.
                                } else {
                                        jsonobj.put("responsecode", 400);
                                        jsonobj.put("timestamp", new Date());
                                        jsonobj.put("message", "Failed");
                                }
                        }

			else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
                    GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
                    res = derr.toString();
                    ex.printStackTrace();
                 LOG.error("Error in cancelTimeOffBytimeOffCode>>>>>>", ex);
                }catch(org.springframework.orm.jpa.JpaSystemException ex)
                {
                    GigflexResponse derr = new GigflexResponse(401, new Date(), GigUtil.getRootException(ex));
                    res = derr.toString();
                    ex.printStackTrace();
		} catch (Exception ex) {
		 ex.printStackTrace();
                  LOG.error("Error in cancelTimeOffBytimeOffCode>>>>>>", ex);	
                    GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
    }

    @Override
    public String cancelMultipleTimeOffBytimeOffCode(List<String> timeOffCodeList, String reason) {
        String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String timeOffCode : timeOffCodeList) {
				if (timeOffCode != null && timeOffCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					timeOffCode = timeOffCode.trim();

					WorkerTimeOff workerTimeOffInDb = workerTimeOffDao.getTimeOffByTimeOffCode(timeOffCode); 

					if (workerTimeOffInDb != null && workerTimeOffInDb.getId() > 0) {
						
						try{
							workerTimeOffInDb.setIsDeleted(true);
                                                        workerTimeOffInDb.setCancelReason(reason); 
							WorkerTimeOff workerTimeOffRes = workerTimeOffDao.save(workerTimeOffInDb);
							if (workerTimeOffRes != null && workerTimeOffRes.getId() > 0) {
								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("code", timeOffCode);
								jsonobj.put("message",
										"Worker Time Off cancelled successfully.");
								// kafkaService.sendUseronUpdate(usersDataRes);
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("code", timeOffCode);
								jsonobj.put("message", "Failed");
							}
						}catch(org.springframework.orm.jpa.JpaSystemException ex){
							jsonobj.put("responsecode", 500);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", timeOffCode);
							jsonobj.put("message",  GigUtil.getRootException(ex));
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", timeOffCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple cancel failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
    }

    

    

    
    
}
