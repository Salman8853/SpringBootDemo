/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.workertimeoff.service;

import com.gigflex.prototype.microservices.workertimeoff.dtob.WorkerTimeOffModel;
import java.util.List;

/**
 *
 * @author amit.kumar
 */
public interface WorkerTimeOffService {
    
    public String findAllWorkerTimeOff();

    public String findTimeOffByWorkerCode(String workercode);

    public String findTimeOffByOrganizationCode(String organizationcode);

    public String saveWorkerTimeOff(WorkerTimeOffModel workerTimeOffReq, String ip);

    public String updateWorkerTimeOffByTimeOffcode(String timeOffCode, WorkerTimeOffModel workerTimeOffReq, String ip);

    public String cancelTimeOffBytimeOffCode(String timeOffCode, String reason);

    public String cancelMultipleTimeOffBytimeOffCode(List<String> timeOffCodeList, String reason);

    public String findTimeOffByTimeOffCode(String timeOffcode);

    public String findTimeOffByWorkerCodeAndBetweenDates(String workercode, String fromdate, String todate);

    
}
