/**
 * 
 */
package com.gigflex.prototype.microservices.departmentworker.api;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.departmentworker.dtob.DepartmentWorkerRequest;
import com.gigflex.prototype.microservices.departmentworker.service.DepartmentWorkerService;
import com.gigflex.prototype.microservices.util.GigflexResponse;

/**
 * @author ajit.p
 *
 */
@CrossOrigin(origins="*")
@RestController
@RequestMapping("/healthcareservice/")
public class DepartmentWorkerController {
	
	@Autowired
	DepartmentWorkerService depWorkerService;
	
	@GetMapping("/departmentWorker/{search}")
	public String search(@PathVariable("search") String search) {
		return depWorkerService.search(search);
	}
	
	@GetMapping("/getAllDepartmentWorkerByWorkerCode/{workerCode}")
	public String getAllDepartmentWorkerByWorkerCode(@PathVariable String workerCode) {
		return depWorkerService.getDepartmentWorkerByWorkerCode(workerCode);
	}
	
	@GetMapping("/getAllDepartmentWorkerByWorkerCodeAssigned/{workerCode}")
	public String getAllDepartmentWorkerByWorkerCodeAssigned(@PathVariable String workerCode) {
		return depWorkerService.getDepartmentWorkerByWorkerCodeAssigned(workerCode);
	}
	
	@GetMapping(path="/getAllDepartmentWorkerByWorkerCodeByPage/{workerCode}")
    public String getAllCertificationsMasterByPage(@PathVariable String workerCode,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String dw = depWorkerService.getDepartmentWorkerByWorkerCode(workerCode, page, limit);
      
        return dw;
       
    }

	
	@PostMapping("/saveWorkerToDepartment")
	public String saveWorkerToDepartment(
			 @RequestBody DepartmentWorkerRequest departmentWorkerReq,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return depWorkerService.saveWorkerInDepartment(departmentWorkerReq,ip);

	}
	
	@PutMapping("/updateWorkerDepartment/{id}")
	public String updateRolePermissionsById(@PathVariable Long id,
			@RequestBody DepartmentWorkerRequest departmentWorkerReq,
			HttpServletRequest request) {
		if (id != null && departmentWorkerReq!=null) {
			String ip = request.getRemoteAddr();

			return depWorkerService.updateWorkerById(id, departmentWorkerReq, ip);
		} else {
                GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
                return derr.toString();
            }
	}
}
