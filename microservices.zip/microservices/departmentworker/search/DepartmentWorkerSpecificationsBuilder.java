package com.gigflex.prototype.microservices.departmentworker.search;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.gigflex.prototype.microservices.departmentworker.dtob.DepartmentWorker;
import com.gigflex.prototype.microservices.util.SearchCriteria;


public class DepartmentWorkerSpecificationsBuilder {
	private final List<SearchCriteria> params;
	 
    public DepartmentWorkerSpecificationsBuilder() {
        params = new ArrayList<SearchCriteria>();
    }
 
    public DepartmentWorkerSpecificationsBuilder with(String key, String operation, Object value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }
 
    public Specification<DepartmentWorker> build() {
        if (params.size() == 0) {
            return null;
        }
 
        List<Specification<DepartmentWorker>> specs = new ArrayList<Specification<DepartmentWorker>>();
        for (SearchCriteria param : params) {
            specs.add(new DepartmentWorkerSpecification(param));
        }
 
        Specification<DepartmentWorker> result = specs.get(0);
        for (int i = 1; i < specs.size(); i++) {
            result = Specification.where(result).and(specs.get(i));
        }
        return result;
    }
}
