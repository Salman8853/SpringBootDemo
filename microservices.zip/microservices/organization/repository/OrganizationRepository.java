/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.organization.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.gigflex.prototype.microservices.organization.dtob.Organization;

/**
 *
 * @author nirbhay.p
 */
public interface OrganizationRepository extends JpaRepository<Organization, Long>,JpaSpecificationExecutor<Organization>{
	
	@Query("SELECT org FROM Organization org, WorkerApprovalStatus was WHERE was.isDeleted != TRUE AND was.organization_Code = :organization_Code")
    public Organization findOrgByWASOrganizationCode(@Param("organization_Code") String organization_Code);
	
//	@Query("SELECT w FROM Worker w ,Organization org, WorkerApprovalStatus was WHERE org.isDeleted != TRUE AND org.organization_Code = :organization_Code")
//    public Worker getWorkerByOrganizationCode(@Param("organization_Code") String organization_Code);
	
	@Query("SELECT org FROM Organization org WHERE org.isDeleted != TRUE AND org.organizationCode = :organizationCode")
    public Organization findByOrganizationCode(@Param("organizationCode") String organizationCode);
    
    @Transactional
	public Integer deleteOrganizationrByOrganizationCode(String organizationCode);
    
    @Query("SELECT org FROM Organization org WHERE org.isDeleted != TRUE")
	public List<Organization> getAllOrganization();

	@Query("SELECT org FROM Organization org WHERE org.isDeleted != TRUE AND org.id = :id")
	public Organization getOrganizationById(@Param("id") Long id);
	  @Query("SELECT org FROM Organization org WHERE org.isDeleted != TRUE")
		public List<Organization> getAllOrganization(Pageable pageableRequest);
   
}

