package com.gigflex.prototype.microservices.organization.dtob;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.ws.rs.DefaultValue;

import com.gigflex.prototype.microservices.util.CommonAttributes;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * @author ajit.p
 *
 */

@Entity
@Table(name = "organization")
public class Organization extends CommonAttributes implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
	
	@Column(name = "organizationname")
	private String organizationName;
	
	@Column(name = "organization_code")	
	private String organizationCode;
	
	@Column(name = "phonenumber")
	private String phoneNumber;
	
	@Column(name = "address")
	private String address;
	
	@Column(name = "address1")
	private String address1;
	@Column(name = "city")
	private String city;
	@Column(name = "state_province")
	private String stateProvince;
	@Column(name = "country")
	private String country;
	@Column(name = "zipcode")
	private String zipCode;
	@Column(name = "taxid")
	private String taxId;
	@Column(name = "reg_no")
	private String regNo;
	@Column(name = "workfrom")
	private String workFrom;
	@Column(name = "workto")
	private String workTo;
	
	@Column(name = "lat")
	private String lat;
	@Column(name = "lang")
	private String lang;
	
	@Column(name = "isactive")
	private Boolean isActive;
	@Column(name = "isapproved")
	private Boolean isApproved;
	@Column(name = "approveddate", columnDefinition="DATETIME")
    private Date approvedDate ;
	@Column(name = "approvedby")
	private String approvedBy;
	@Column(name = "isverified")
	private Boolean isVerified;
	  
    @Column(name = "industry_code")
    private String industryCode;
           
    @Column(name = "organization_logo")
    private String organizationLogo;
    
    @Column(name = "timezone")
    private String timezone;
    
    
     public String getTimezone() {
        return timezone;
    }

    public void setTimezone(String timezone) {
        this.timezone = timezone;
    }

    public String getOrganizationLogo() {
        return organizationLogo;
    }

    public void setOrganizationLogo(String organizationLogo) {
        this.organizationLogo = organizationLogo;
    }
    
    public String getIndustryCode() {
        return industryCode;
    }

    public void setIndustryCode(String industryCode) {
        this.industryCode = industryCode;
    }
	public Organization() {
		super();
	}
	public Organization(Long id) {
		super();
		this.id = id;
	}
	public Organization(Long id, String organizationName, String organizationCode, String phoneNumber, String address,
			String address1, String city, String stateProvince, String country, String zipCode, String taxId,
			String regNo, String workFrom, String workTo, String lat, String lang, Boolean isActive, Boolean isApproved,
			Date approvedDate, String approvedBy, Boolean isVerified, String industryCode,String timezone ) {
		super();
		this.id = id;
		this.organizationName = organizationName;
		this.organizationCode = organizationCode;
		this.phoneNumber = phoneNumber;
		this.address = address;
		this.address1 = address1;
		this.city = city;
		this.stateProvince = stateProvince;
		this.country = country;
		this.zipCode = zipCode;
		this.taxId = taxId;
		this.regNo = regNo;
		this.workFrom = workFrom;
		this.workTo = workTo;
		this.lat = lat;
		this.lang = lang;
		this.isActive = isActive;
		this.isApproved = isApproved;
		this.approvedDate = approvedDate;
		this.approvedBy = approvedBy;
		this.isVerified = isVerified;
                this.industryCode = industryCode;
                this.timezone=timezone;
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getOrganizationName() {
		return organizationName;
	}
	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}
	public String getOrganizationCode() {
		return organizationCode;
	}
	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getStateProvince() {
		return stateProvince;
	}
	public void setStateProvince(String stateProvince) {
		this.stateProvince = stateProvince;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getTaxId() {
		return taxId;
	}
	public void setTaxId(String taxId) {
		this.taxId = taxId;
	}
	public String getRegNo() {
		return regNo;
	}
	public void setRegNo(String regNo) {
		this.regNo = regNo;
	}
	public String getWorkFrom() {
		return workFrom;
	}
	public void setWorkFrom(String workFrom) {
		this.workFrom = workFrom;
	}
	public String getWorkTo() {
		return workTo;
	}
	public void setWorkTo(String workTo) {
		this.workTo = workTo;
	}
	public String getLat() {
		return lat;
	}
	public void setLat(String lat) {
		this.lat = lat;
	}
	public String getLang() {
		return lang;
	}
	public void setLang(String lang) {
		this.lang = lang;
	}

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public Boolean getIsApproved() {
        return isApproved;
    }

    public void setIsApproved(Boolean isApproved) {
        this.isApproved = isApproved;
    }
	
	public Date getApprovedDate() {
		return approvedDate;
	}
	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}
	public String getApprovedBy() {
		return approvedBy;
	}
	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

    public Boolean getIsVerified() {
        return isVerified;
    }

    public void setIsVerified(Boolean isVerified) {
        this.isVerified = isVerified;
    }
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Organization [id=" + id + ", organizationName=" + organizationName + ", organizationCode="
				+ organizationCode + ", phoneNumber=" + phoneNumber + ", address=" + address + ", address1=" + address1
				+ ", city=" + city + ", stateProvince=" + stateProvince + ", country=" + country + ", zipCode="
				+ zipCode + ", taxId=" + taxId + ", regNo=" + regNo + ", workFrom=" + workFrom + ", workTo=" + workTo
				+ ", lat=" + lat + ", lang=" + lang + ", isActive=" + isActive + ", isApproved=" + isApproved
				+ ", approvedDate=" + approvedDate + ", approvedBy=" + approvedBy + ", isVerified=" + isVerified+",timezone "+timezone + "]";
	}
	
	
}
