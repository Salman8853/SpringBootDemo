package com.gigflex.prototype.microservices.organization.service;
import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.dtob.OrganizationConsume;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;


@Service
public class OrgDeleteOfRegistrationConsumeKafkaService {

	@Autowired
	OrganizationRepository organizationRepository;
	
    private static final Logger LOG = LoggerFactory.getLogger(OrgDeleteOfRegistrationConsumeKafkaService.class);


	@KafkaListener(topics = "DeleteOrganization")
    public void listen(@Payload String message) {
		ObjectMapper objectMapper = new ObjectMapper();
		LOG.info("received message='{}'", message);
		try {
			OrganizationConsume org = objectMapper.readValue(message, OrganizationConsume.class);
			LOG.info("received message='{}'", org.getOrganizationName());
			LOG.info("received message='{}'", org.getOrganizationCode());
			LOG.info("received message='{}'", org.getIsActive());
			Organization orgRes=organizationRepository.findByOrganizationCode(org.getOrganizationCode());
                        if(orgRes!=null && orgRes.getId()>0)
                        {
                            organizationRepository.deleteById(orgRes.getId());
                        }
			
		} catch (JsonParseException e) {
			LOG.error("In OrgDeleteOfOrganizationConsumeKafkaService >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In OrgDeleteOfOrganizationConsumeKafkaService >>>>", e);
		} catch (IOException e) {
			LOG.error("In OrgDeleteOfOrganizationConsumeKafkaService >>>>", e);
		}catch (Exception e) {
			LOG.error("In OrgDeleteOfOrganizationConsumeKafkaService >>>>", e);
		}
    }
}