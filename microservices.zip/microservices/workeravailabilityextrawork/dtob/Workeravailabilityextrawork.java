/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.workeravailabilityextrawork.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;



@Entity
@Table(name = "worker_availability_extrawork")
public class Workeravailabilityextrawork  extends CommonAttributes{
    
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;
    
    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "worker_preferdshift_code", unique = true)
    private String workerPreferdShiftCode;
      
    @Column(name = "days", nullable = false)
    private String days;
     @Column(name = "worker_code", nullable = false)
    private String workerCode;
      @PrePersist
    private void assignUUID() {
        if (this.getWorkerPreferdShiftCode() == null || this.getWorkerPreferdShiftCode().length() == 0) {
           this.setWorkerPreferdShiftCode(UUID.randomUUID().toString());
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getWorkerPreferdShiftCode() {
        return workerPreferdShiftCode;
    }

    public void setWorkerPreferdShiftCode(String workerPreferdShiftCode) {
        this.workerPreferdShiftCode = workerPreferdShiftCode;
    }

    public String getDays() {
        return days;
    }

    public void setDays(String days) {
        this.days = days;
    }

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }
    
}
