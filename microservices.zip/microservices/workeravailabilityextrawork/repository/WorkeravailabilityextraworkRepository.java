/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.workeravailabilityextrawork.repository;

import com.gigflex.prototype.microservices.workeravailabilityextrawork.dtob.Workeravailabilityextrawork;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


public interface WorkeravailabilityextraworkRepository extends JpaRepository<Workeravailabilityextrawork, Long>{
     @Query("SELECT wt FROM Workeravailabilityextrawork wt WHERE wt.isDeleted != TRUE")
    public List<Workeravailabilityextrawork> getAllExtraWorkerAvailability();
     @Query("SELECT wt FROM Workeravailabilityextrawork wt WHERE wt.isDeleted != TRUE")
    public List<Workeravailabilityextrawork> getAllExtraWorkerWorkerAvailability(Pageable pageableRequest);
     @Query("SELECT wt FROM Workeravailabilityextrawork wt WHERE wt.isDeleted != TRUE AND wt.workerCode= :workerCode ")
    public Workeravailabilityextrawork getExtraWorkerAvailability(@Param("workerCode") String workerCode);
}
