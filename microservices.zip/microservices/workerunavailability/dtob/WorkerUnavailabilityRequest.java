/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.workerunavailability.dtob;

/**
 *
 * @author nirbhay.p
 */
public class WorkerUnavailabilityRequest {
    
    private String unavailabilityDate;
    private String workerCode;
    private String fromTime;
    private String toTime;      
    private String requestOption;
    private String requestType;

    public String getUnavailabilityDate() {
        return unavailabilityDate;
    }

    public void setUnavailabilityDate(String unavailabilityDate) {
        this.unavailabilityDate = unavailabilityDate;
    }

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getFromTime() {
        return fromTime;
    }

    public void setFromTime(String fromTime) {
        this.fromTime = fromTime;
    }

    public String getToTime() {
        return toTime;
    }

    public void setToTime(String toTime) {
        this.toTime = toTime;
    }

    public String getRequestOption() {
        return requestOption;
    }

    public void setRequestOption(String requestOption) {
        this.requestOption = requestOption;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    
}
