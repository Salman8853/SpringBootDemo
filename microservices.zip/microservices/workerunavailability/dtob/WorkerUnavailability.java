/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.workerunavailability.dtob;


import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.Date;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;


@Entity
@Table(name = "worker_unavailability")
public class WorkerUnavailability extends CommonAttributes implements Serializable{
    
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "worker_unavailability_code", unique = true)
    private String workerUnavailabilityCode;
    
    @Column(name = "unavailability_date", nullable = false,  columnDefinition = "DATE")
    private Date unavailabilityDate;
     
    @Column(name = "worker_code", nullable = false)
    private String workerCode;
    
    @Column(name = "fromtime")
    private String fromTime;
            
    @Column(name = "totime")
    private String toTime;      
                
    @Column(name = "request_option", nullable = false)
    private String requestOption;
    
    @Column(name = "request_type")
    private String requestType;
    
    @PrePersist
    private void assignUUID() {
        if (this.getWorkerUnavailabilityCode() == null || this.getWorkerUnavailabilityCode().length() == 0) {
           this.setWorkerUnavailabilityCode(UUID.randomUUID().toString());
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getWorkerUnavailabilityCode() {
        return workerUnavailabilityCode;
    }

    public void setWorkerUnavailabilityCode(String workerUnavailabilityCode) {
        this.workerUnavailabilityCode = workerUnavailabilityCode;
    }

    public Date getUnavailabilityDate() {
        return unavailabilityDate;
    }

    public void setUnavailabilityDate(Date unavailabilityDate) {
        this.unavailabilityDate = unavailabilityDate;
    }

    

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getFromTime() {
        return fromTime;
    }

    public void setFromTime(String fromTime) {
        this.fromTime = fromTime;
    }

    public String getToTime() {
        return toTime;
    }

    public void setToTime(String toTime) {
        this.toTime = toTime;
    }

    public String getRequestOption() {
        return requestOption;
    }

    public void setRequestOption(String requestOption) {
        this.requestOption = requestOption;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

   
}
