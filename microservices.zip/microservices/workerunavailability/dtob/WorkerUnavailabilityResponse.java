/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.workerunavailability.dtob;


import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.Date;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;


public class WorkerUnavailabilityResponse{
    
    
    
    private Long id;

    private String workerUnavailabilityCode;
    
   
    private String unavailabilityDate;
     
    private String workerCode;
    

    private String fromTime;
            

    private String toTime;      
                

    private String requestOption;

    private String requestType;
    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getWorkerUnavailabilityCode() {
        return workerUnavailabilityCode;
    }

    public void setWorkerUnavailabilityCode(String workerUnavailabilityCode) {
        this.workerUnavailabilityCode = workerUnavailabilityCode;
    }

    public String getUnavailabilityDate() {
        return unavailabilityDate;
    }

    public void setUnavailabilityDate(String unavailabilityDate) {
        this.unavailabilityDate = unavailabilityDate;
    }

  

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getFromTime() {
        return fromTime;
    }

    public void setFromTime(String fromTime) {
        this.fromTime = fromTime;
    }

    public String getToTime() {
        return toTime;
    }

    public void setToTime(String toTime) {
        this.toTime = toTime;
    }

    public String getRequestOption() {
        return requestOption;
    }

    public void setRequestOption(String requestOption) {
        this.requestOption = requestOption;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

   
}
