/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.workerunavailability.api;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.workerunavailability.dtob.WorkerUnavailabilityRequest;
import com.gigflex.prototype.microservices.workerunavailability.service.WorkerUnavailabilityService;
import com.gigflex.prototype.microservices.workpreferedshift.dtob.WorkerPreferdShiftRequest;
import com.gigflex.prototype.microservices.workpreferedshift.service.WorkerPreferdShiftService;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author nirbhay.p
 */
@CrossOrigin(origins="*")
@RestController
@RequestMapping("/healthcareservice/")
public class WorkerUnavailabilityController {
    
    @Autowired
    WorkerUnavailabilityService workerUnavailabilityService;
    
    @GetMapping("/getAllWorkerUnavailability")
    public String getAllWorkerUnavailability(){
            return workerUnavailabilityService.getAllWorkerUnavailability();
    }
    
    @GetMapping(path="/getAllWorkerUnavailabilityByPage")
    public String getAllWorkerUnavailabilityByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        return workerUnavailabilityService.getAllWorkerUnavailabilityByPage(page, limit);
      
    }
    
    @GetMapping("/getWorkerUnavailabilityByWorkerCode/{workercode}")
    public String getWorkerUnavailabilityByWorkerCode(@PathVariable("workercode") String workercode){
        if(workercode!=null && workercode.trim().length()>0)
        {
        return workerUnavailabilityService.getWorkerUnavailabilityByWorkerCode(workercode.trim());
        }
        else
        {
                     GigflexResponse derr = new GigflexResponse(400, new Date(), "Worker code should not be blank.");
               return derr.toString();
            
        }
    }
    
    
    @GetMapping("/getWorkerUnavailabilityByWorkerUnavailabilityCode/{workerUnavailabilityCode}")
    public String getWorkerUnavailabilityByWorkerUnavailabilityCode(@PathVariable("workerUnavailabilityCode") String workerUnavailabilityCode){
        if(workerUnavailabilityCode!=null && workerUnavailabilityCode.trim().length()>0)
        {
        return workerUnavailabilityService.getWorkerUnavailabilityByWorkerUnavailabilityCode(workerUnavailabilityCode.trim());
        }
        else
        {
                     GigflexResponse derr = new GigflexResponse(400, new Date(), "WorkerUnavailabilityCode should not be blank.");
               return derr.toString();
            
        }
    }
    
    
    
     @PostMapping("/saveWorkerUnavailability")
    public String saveWorkerUnavailability(@RequestBody WorkerUnavailabilityRequest workerprsfReq,HttpServletRequest request){
              
        if(workerprsfReq!=null && workerprsfReq.getRequestOption()!=null && workerprsfReq.getRequestOption().trim().length()>0
                && workerprsfReq.getUnavailabilityDate()!=null && workerprsfReq.getUnavailabilityDate().trim().length()>0
                && workerprsfReq.getWorkerCode()!=null && workerprsfReq.getWorkerCode().length()>0) 
        {
            
          String ip = request.getRemoteAddr();
          return workerUnavailabilityService.saveWorkerUnavailability(workerprsfReq,ip);
        }
        else
        {
                   GigflexResponse derr = new GigflexResponse(400, new Date(), "Worker Code, Unavailability Date and Request Option should not be blank.");
               return derr.toString();
        }

    }
    
    @PutMapping("/updateWorkerUnavailability/{workerUnavailabilityCode}")
    public String updateWorkerUnavailability(@PathVariable("workerUnavailabilityCode") String workerUnavailabilityCode, @RequestBody WorkerUnavailabilityRequest workerprsfReq,HttpServletRequest request) {

                 
        if(workerUnavailabilityCode!=null && workerUnavailabilityCode.trim().length()>0 && workerprsfReq!=null && workerprsfReq.getRequestOption()!=null && workerprsfReq.getRequestOption().trim().length()>0
                && workerprsfReq.getUnavailabilityDate()!=null && workerprsfReq.getUnavailabilityDate().trim().length()>0
                && workerprsfReq.getWorkerCode()!=null && workerprsfReq.getWorkerCode().length()>0 ) 
        {
          String ip = request.getRemoteAddr();
          return workerUnavailabilityService.updateWorkerUnavailability(workerprsfReq,workerUnavailabilityCode,ip);
        }
        else
        {
                   GigflexResponse derr = new GigflexResponse(400, new Date(), "WorkerUnavailabilityCode, Worker Code, Unavailability Date and Request Option should not be blank.");
               return derr.toString();
        }

    }
    
    @DeleteMapping("/deleteWorkerUnavailability/{workerUnavailabilityCode}")
    public String deleteWorkerUnavailability(@PathVariable String workerUnavailabilityCode){
        
        if(workerUnavailabilityCode != null && workerUnavailabilityCode.trim().length() > 0 )
        {
            return workerUnavailabilityService.deleteWorkerUnavailability(workerUnavailabilityCode.trim());
        }
        else
        {
               GigflexResponse derr = new GigflexResponse(400, new Date(), "workerUnavailabilityCode should not be blank.");
               return derr.toString(); 
        }
        
        
    }
    
    
    
}
