/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.workerunavailability.repository;
import com.gigflex.prototype.microservices.workerunavailability.dtob.WorkerUnavailability;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author nirbhay.p
 */
public interface WorkerUnavailabilityRepository extends JpaRepository<WorkerUnavailability, Long>,JpaSpecificationExecutor<WorkerUnavailability>{
    
    
    @Query("SELECT wt FROM WorkerUnavailability wt WHERE wt.isDeleted != TRUE")
    public List<WorkerUnavailability> getAllWorkerUnavailability();
    
    @Query("SELECT wt FROM WorkerUnavailability wt WHERE wt.isDeleted != TRUE")
    public List<WorkerUnavailability> getAllWorkerUnavailability(Pageable pageableRequest);
    
    @Query("SELECT wt FROM WorkerUnavailability wt WHERE wt.isDeleted != TRUE AND wt.workerCode= :workerCode ")
    public List<WorkerUnavailability> getWorkerUnavailabilityByWorkerCode(@Param("workerCode") String workerCode);
    
    @Query("SELECT wt FROM WorkerUnavailability wt WHERE wt.isDeleted != TRUE AND wt.workerUnavailabilityCode= :workerUnavailabilityCode ")
    public WorkerUnavailability getWorkerUnavailabilityByCode(@Param("workerUnavailabilityCode") String workerUnavailabilityCode);
    
    
}
