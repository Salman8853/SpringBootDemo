/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.uploadpatient.service;

import com.gigflex.prototype.microservices.patient.dtob.PatientDetails;
import com.gigflex.prototype.microservices.patient.repository.PatientDao;
import com.gigflex.prototype.microservices.patient.service.PatientService;
import com.gigflex.prototype.microservices.uploadqueue.dtob.UploadQueue;
import com.gigflex.prototype.microservices.uploadqueue.repository.UploadQueueDao;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

/**
 *
 * @author amit.kumar
 */
public class PatientUploadThread implements Runnable {

//        KafkaService kafkaService;
	private String fileName;
	private String uploadCode;	
	private String organizationCode;
	private UploadQueueDao uploadQueueDao;
	private PatientDao patientDao;
        private PatientService patientService;


	public PatientUploadThread(/*KafkaService kafkaService,*/ String fileName,
			String uploadCode, String organizationCode,
			UploadQueueDao uploadQueueDao, PatientDao patientDao,PatientService patientService) {
		super();
//		this.kafkaService = kafkaService;
		this.fileName = fileName;
		this.uploadCode = uploadCode;		
		this.organizationCode = organizationCode;
		this.uploadQueueDao = uploadQueueDao;
		this.patientDao = patientDao;
                this.patientService=patientService;
                
	}



	@Override
	public void run() {
		try {
			File myFile = new File(fileName);
			FileInputStream fis = new FileInputStream(myFile);

			Workbook myWorkBook;
			Sheet mySheet = null;

			int inx = fileName.lastIndexOf(".");
			String filenameEnd = fileName.substring(inx);

			if (filenameEnd.equalsIgnoreCase(".xls")) {
				myWorkBook = new HSSFWorkbook(fis);
				mySheet = myWorkBook.getSheetAt(0);
			} else if (filenameEnd.equalsIgnoreCase(".xlsx")) {
				myWorkBook = new XSSFWorkbook(fis);
				mySheet = myWorkBook.getSheetAt(0);
			}
			Iterator<Row> rowIterator = mySheet.iterator();
			int rowCount = -1;
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();
				Boolean status = false;
				try {

					if (row != null) {
						rowCount++;

						if (rowCount != 0) {
							int cellCount = 0;
							PatientDetails pDetails = new PatientDetails();
                                                            
                                                        for(int i = 0 ; i < 10 ; i++)
                                                        {
								cellCount++;
                                                                Cell cell = row.getCell(i);

								if (cell != null) {
									String res = "";
									switch (cell.getCellType()) {
									case Cell.CELL_TYPE_STRING:
										if(cell.getStringCellValue()!=null )
                                                                                { 
                                                                                    res = cell.getStringCellValue().trim();                                     
                                                                                }
										break;
									case Cell.CELL_TYPE_NUMERIC:
										double var = cell.getNumericCellValue();
										Long l = (long) var;
										res = l.toString();
										break;
									case Cell.CELL_TYPE_BOOLEAN:
										if (cell.getBooleanCellValue()) {
											res = "true";
										} else {
											res = "false";
										}

										break;
									default:

									}									
                                                                            
                                                                          if (cellCount == 10) {
											pDetails.setpCountryCode(res);
                                                                                        break;

										} 
                                                                                 else if (cellCount == 9) {

											pDetails.setMobileNumber(res);                                                                                      

										}
                                                                                else if (cellCount == 8) {

											pDetails.setPhoneNumber(res);                                                                                       

										}
                                                                                else if (cellCount == 7) {
											pDetails.setZipCode(res);                                                                                        

										}                                                                                
                                                                                else if (cellCount == 6) {
											pDetails.setPatientCountry(res);                                                                                       

										}
                                                                                else if (cellCount == 5) {
											pDetails.setPatientState(res);

										}
                                                                                else if (cellCount == 4) {
											pDetails.setPatientCity(res);                                                                                     

										}
                                                                                else if (cellCount == 3) {
											pDetails.setPatientAddress(res);                                                                                       

										}
                                                                                else if (cellCount == 2) {
											pDetails.setPatientEmail(res);                                                                                       

										}
                                                                                else if (cellCount == 1) {
											pDetails.setPatientName(res);                                                                                       

										}  

								}

							}
							if (pDetails != null ) {				
                                                                pDetails.setIsDeleted(false);			
								pDetails.setOrganizationCode(organizationCode);
                                                                pDetails.setIsActive(true);
                                                                StringBuffer addr = new StringBuffer();
                                                                String address = addr.append(pDetails.getPatientAddress()).append(",").append(pDetails.getPatientCity()).append(",").append(pDetails.getPatientState())
                                                                        .append(",").append(pDetails.getPatientCountry()).append(",").append(pDetails.getZipCode()).toString();
                                                                String[] latLong = getLatitudeAndLongitude(address);                                                                                                                         
                                                                String latitude = latLong[0];
                                                                String longitude =  latLong[1];
                                                                pDetails.setPatientLatitude(latitude);
                                                                pDetails.setPatientLongitude(longitude); 
                                                                
								PatientDetails patientRes = patientDao.save(pDetails);

								if (patientRes != null && patientRes.getId() > 0) {
									status = true;
								}

							}

						}
					}
				}

				catch (Exception ex) {
					ex.printStackTrace();
				}
				if (rowCount >= 1) {
					UploadQueue uploadRes = uploadQueueDao
							.getUploadQueueByUploadCode(uploadCode);

					if (uploadRes != null && uploadRes.getId() > 0) {
						if (status) {
							uploadRes.setProcessedRecords(uploadRes
									.getProcessedRecords() + 1);
						} else {
							uploadRes.setFaliedRecords(uploadRes
									.getFaliedRecords() + 1);
						}

						uploadQueueDao.save(uploadRes);
					}
				}

			}
		} catch (Exception e) {
			e.printStackTrace();

		}

	}

    
        public String[] getLatitudeAndLongitude(String  address)
        {
            
            String[] langLat = new String[2];
            try {
                int responseCode = 0;               
                String api = "https://maps.googleapis.com/maps/api/geocode/xml?address=" + URLEncoder.encode(address, "UTF-8") + "&sensor=true&key=AIzaSyCn4jxvf3gmMxb7sBUZBRozcRHo6gXycVk";
                URL url = new URL(api);
                HttpURLConnection httpConnection = (HttpURLConnection)url.openConnection();
                httpConnection.connect();
                responseCode = httpConnection.getResponseCode();
                if(responseCode == 200)
                {
                    DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();;
                    Document document = builder.parse(httpConnection.getInputStream());
                    XPathFactory xPathfactory = XPathFactory.newInstance();
                    XPath xpath = xPathfactory.newXPath();
                    XPathExpression expr = xpath.compile("/GeocodeResponse/status");
                    String status = (String)expr.evaluate(document, XPathConstants.STRING);
                    if(status.equals("OK"))
                    {
                        expr = xpath.compile("//geometry/location/lat");
                        String latitude = (String)expr.evaluate(document, XPathConstants.STRING);
                        expr = xpath.compile("//geometry/location/lng");
                        String longitude = (String)expr.evaluate(document, XPathConstants.STRING);
                        
                        langLat[0] =latitude;
                        langLat[1] =longitude;
                    }
                    else
                    {
                        //default value
                        langLat[0] ="0.0";
                        langLat[1] ="0.0";
//                        throw new Exception("Error from the API - response status: "+status);
                    }
                }
                else
                {
                    langLat[0] ="0.0";
                    langLat[1] ="0.0";
                }
                
            } catch (UnsupportedEncodingException ex) {
                Logger.getLogger(PatientUploadThread.class.getName()).log(Level.SEVERE, null, ex);
            } catch (MalformedURLException ex) {
                Logger.getLogger(PatientUploadThread.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(PatientUploadThread.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ParserConfigurationException ex) {
                Logger.getLogger(PatientUploadThread.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SAXException ex) {
                Logger.getLogger(PatientUploadThread.class.getName()).log(Level.SEVERE, null, ex);
            } catch (XPathExpressionException ex) {
                Logger.getLogger(PatientUploadThread.class.getName()).log(Level.SEVERE, null, ex);
            } catch (Exception ex) {
                Logger.getLogger(PatientUploadThread.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            return langLat;
    }
        
}
