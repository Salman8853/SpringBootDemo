/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.setting.repository;

import com.gigflex.prototype.microservices.setting.dtob.GlobalSetting;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author nirbhay.p
 */
public interface GlobalSettingRepository  extends JpaRepository<GlobalSetting, Long>{
    
        @Query("SELECT g FROM GlobalSetting g WHERE g.isDeleted != TRUE ")
	public List<GlobalSetting> getAllGlobalSetting();
	
	@Query("SELECT g FROM GlobalSetting g WHERE g.isDeleted != TRUE ")
	public List<GlobalSetting> getAllGlobalSetting(Pageable pageableRequest);
        
        @Query("SELECT g FROM GlobalSetting g WHERE g.isDeleted != TRUE AND g.userTypeCode= :userTypeCode")
	public List<GlobalSetting> getAllGlobalSettingByUserType(@Param("userTypeCode") String userTypeCode);
	
	@Query("SELECT g FROM GlobalSetting g WHERE g.isDeleted != TRUE AND g.userTypeCode= :userTypeCode")
	public List<GlobalSetting> getAllGlobalSettingByUserType(@Param("userTypeCode") String userTypeCode,Pageable pageableRequest);
        
        @Query("SELECT g FROM GlobalSetting g WHERE g.isDeleted != TRUE AND g.userTypeCode= :userTypeCode AND g.settingName= :settingName")
	public GlobalSetting getGlobalSettingByUserTypeSettingName(@Param("userTypeCode") String userTypeCode,@Param("settingName") String settingName);
        
        @Query("SELECT g FROM GlobalSetting g WHERE g.isDeleted != TRUE AND g.globalSettingCode= :settingCode ")
	public GlobalSetting getGlobalSettingBySettingCode(@Param("settingCode") String settingCode);
        
        @Query("SELECT g FROM GlobalSetting g WHERE g.isDeleted != TRUE AND g.userTypeCode= :userTypeCode AND g.settingName= :settingName AND g.id!= :id")
	public GlobalSetting getGlobalSettingByUserTypeSettingNameNotID(@Param("userTypeCode") String userTypeCode,@Param("settingName") String settingName,@Param("id") Long id);
        
	@Query("SELECT g FROM GlobalSetting g WHERE g.isDeleted != TRUE AND g.id= :id")
	public GlobalSetting getGlobalSettingByID(@Param("id") Long id);
        
        @Query("SELECT g FROM GlobalSetting g WHERE g.isDeleted != TRUE AND g.userTypeCode= :userTypeCode AND g.settingType= :settingType ")
	public List<GlobalSetting> getGlobalSettingByUserTypeSettingType(@Param("userTypeCode") String userTypeCode,@Param("settingType") String settingType);
        
        @Query("SELECT DISTINCT g.settingType FROM GlobalSetting g WHERE g.isDeleted != TRUE AND g.userTypeCode= :userTypeCode ")
	public List<String> getAllSettingTypeByUserType(@Param("userTypeCode") String userTypeCode);
        
}
