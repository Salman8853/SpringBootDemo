/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.setting.service;
import com.gigflex.prototype.microservices.setting.dtob.LocalSettingReq;
import com.gigflex.prototype.microservices.setting.dtob.LocalSettingResponse;
import java.util.List;
/**
 *
 * @author nirbhay.p
 */
public interface LocalSettingService {
    
	public String getAllLocalSettingByPage(int page, int limit);
	
        public String getLocalSettingByUserCodeByPage(String userCode,int page, int limit);

	public String saveLocalSetting(LocalSettingReq localSettingReq, String ip);
        
        public String updateLocalSettingById(LocalSettingReq localSettingReq, Long id, String ip);
	
	public String getLocalSettingByLocalSettingCode(String localSettingCode);
        
        public String softDeleteLocalSettingByLocalSettingCode(String localSettingCode);
        
        public String softMultipleDeleteLocalSettingByLocalSettingCode(List<String> localSettingCodeList);
        
        public String getLocalSettingByUserCodeSettingName(String userCode,String settingName);
        
        public String getLocalSettingByUserCodeGlobalSettingCode(String userCode,String globalSettingCode);
        public String getLocalSettingByUserTypeSettingType(String userTypeCode,String settingType);
        public String getAllLocalSettingWithDefaultGlobalSettingByUserCode(String userCode);
        public String checkOrganizationSetting(String userCode);
        public String checkWorkerSetting(String workerCode);
        public String updateSettingByUserCode(String userCode, List<LocalSettingResponse> localSettingReq, String ip);
        public String getTimeslotByorganisationCode(String orgCode);
}

