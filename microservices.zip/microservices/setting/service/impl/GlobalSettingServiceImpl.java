/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.setting.service.impl;
import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.setting.dtob.GlobalSetting;
import com.gigflex.prototype.microservices.setting.service.GlobalSettingService;
import org.springframework.stereotype.Service;
import com.gigflex.prototype.microservices.setting.dtob.GlobalSettingReq;
import com.gigflex.prototype.microservices.setting.dtob.LocalSetting;
import com.gigflex.prototype.microservices.setting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.setting.repository.LocalSettingRepository;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
/**
 *
 * @author nirbhay.p
 */
@Service
public class GlobalSettingServiceImpl implements GlobalSettingService{
    @Autowired
    GlobalSettingRepository globalSettingRepository;
    
    @Autowired
    LocalSettingRepository localSettingRepository;
    
    @Override
    public String getAllGlobalSettingByPage(int page, int limit) {
        
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                         if (limit > 0) {
			Pageable pageableRequest = PageRequest.of(page, limit);

			List<GlobalSetting> gslst = globalSettingRepository.getAllGlobalSetting(pageableRequest);
                        int count=0;
                        List<GlobalSetting> cntlst = globalSettingRepository.getAllGlobalSetting();
                        if(cntlst!=null)
                        {
                        count=cntlst.size();
                        }
			if (gslst != null && gslst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
                                jsonobj.put("count", count);
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(gslst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
                        } else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("message", "Limit should not be Zero or Negative.");
                jsonobj.put("timestamp", new Date());
            }
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
		}
		return res;
	
    }

    @Override
    public String getGlobalSettingByUserTypeByPage(String userTypeCode, int page, int limit) {
        
        
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                         if (limit > 0) {
			Pageable pageableRequest = PageRequest.of(page, limit);

			List<GlobalSetting> gslst = globalSettingRepository.getAllGlobalSettingByUserType(userTypeCode,pageableRequest);
                        int count=0;
                        List<GlobalSetting> cntlst = globalSettingRepository.getAllGlobalSettingByUserType(userTypeCode);
                        if(cntlst!=null)
                        {
                        count=cntlst.size();
                        }
			if (gslst != null && gslst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
                                jsonobj.put("count", count);
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(gslst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
                        } else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("message", "Limit should not be Zero or Negative.");
                jsonobj.put("timestamp", new Date());
            }
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
		}
		return res;
	
    
    }

    @Override
    public String saveGlobalSetting(GlobalSettingReq globalSettingReq, String ip) {
        
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

					GlobalSetting gs = globalSettingRepository.getGlobalSettingByUserTypeSettingName(globalSettingReq.getUserTypeCode(),globalSettingReq.getSettingName());

					if (gs != null && gs.getId() > 0) {
						jsonobj.put("responsecode", 409);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "This Global Setting already exists");
					} else {
						GlobalSetting gset = new GlobalSetting();

						gset.setUserTypeCode(globalSettingReq.getUserTypeCode());
                                                gset.setSettingName(globalSettingReq.getSettingName());
                                                gset.setSettingValue(globalSettingReq.getSettingValue());
						gset.setIpAddress(ip);
                                                gset.setSettingType(globalSettingReq.getSettingType());
						GlobalSetting gsetRes = globalSettingRepository.save(gset);

						

						if (gsetRes != null && gsetRes.getId() > 0) {
                                                    jsonobj.put("responsecode", 200);
						jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Global Setting has been added successfully.");
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj.writeValueAsString(gsetRes);
							jsonobj.put("data", new JSONObject(Detail));
						} else {
                                                    jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Failed");
						}
					}
				
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	
    }

    @Override
    public String updateGlobalSettingById(GlobalSettingReq globalSettingReq, Long id, String ip) {
        
        
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        GlobalSetting gsid = globalSettingRepository.getGlobalSettingByID(id);
                        if (gsid != null && gsid.getId() > 0) {

					GlobalSetting gs = globalSettingRepository.getGlobalSettingByUserTypeSettingNameNotID(globalSettingReq.getUserTypeCode(),globalSettingReq.getSettingName(),id);

					if (gs != null && gs.getId() > 0) {
						jsonobj.put("responsecode", 409);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "This Global Setting already exists");
					} else {
						
						gsid.setUserTypeCode(globalSettingReq.getUserTypeCode());
                                                gsid.setSettingName(globalSettingReq.getSettingName());
                                                gsid.setSettingValue(globalSettingReq.getSettingValue());
						gsid.setIpAddress(ip);
                                                gsid.setSettingType(globalSettingReq.getSettingType());
						GlobalSetting gsetRes = globalSettingRepository.save(gsid);

						

						if (gsetRes != null && gsetRes.getId() > 0) {
                                                    jsonobj.put("responsecode", 200);
						jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Global Setting has been updated successfully.");
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj.writeValueAsString(gsetRes);
							jsonobj.put("data", new JSONObject(Detail));
						} else {
                                                    jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Failed");
						}
					}
				} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	
    
    }

    @Override
    public String getGlobalSettingByGlobalSettingCode(String globalSettingCode) {
        
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        
                        GlobalSetting gs = globalSettingRepository.getGlobalSettingBySettingCode(globalSettingCode);
                        
			if (gs != null && gs.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
                                ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(gs);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
                        
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
		}
		return res;
	
    }

    @Override
    public String softDeleteGlobalSettingByGlobalSettingCode(String globalSettingCode) {
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			 GlobalSetting gs = globalSettingRepository.getGlobalSettingBySettingCode(globalSettingCode);
			

			if (gs != null && gs.getId() > 0) {
                          List<LocalSetting> lslst= localSettingRepository.getLocalSettingByGlobalSettingCode(globalSettingCode);
                          if(lslst!=null && lslst.size()>0)
                          {
                              jsonobj.put("responsecode", 400);
                              jsonobj.put("timestamp", new Date());
			      jsonobj.put("message", "Please delete references from Local Setting.");
                          }
                          else
                          {
                          gs.setIsDeleted(true);
				GlobalSetting gsRes = globalSettingRepository.save(gs);
				if (gsRes != null && gsRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());

					jsonobj.put("message",
							"Global Setting deleted successfully.");

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}
                          }
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
		}
		return res;
    }

    @Override
    public String softMultipleDeleteGlobalSettingByGlobalSettingCode(List<String> globalSettingCodeList) {
        
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String globalSettingCode : globalSettingCodeList) {
				if (globalSettingCode != null && globalSettingCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					 GlobalSetting gs = globalSettingRepository.getGlobalSettingBySettingCode(globalSettingCode);
					

					if (gs != null && gs.getId() > 0) {
                                            List<LocalSetting> lslst= localSettingRepository.getLocalSettingByGlobalSettingCode(globalSettingCode);
                          if(lslst!=null && lslst.size()>0)
                          {
                              jsonobj.put("responsecode", 400);
                              jsonobj.put("timestamp", new Date());
                              jsonobj.put("globalSettingCode", globalSettingCode);
			      jsonobj.put("message", "Please delete references from Local Setting.");
                          }
                          else
                          {
						gs.setIsDeleted(true);
						GlobalSetting gsRes = globalSettingRepository.save(gs);
						if (gsRes != null && gsRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
                                                        jsonobj.put("globalSettingCode", globalSettingCode);
							jsonobj.put("message","Global Setting deleted successfully.");

						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("globalSettingCode", globalSettingCode);
							jsonobj.put("message", "Failed");
						}
                                        }
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("globalSettingCode", globalSettingCode);
						jsonobj.put("message", "Record Not Found");
					}

					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
		}
		return res;
	
    }

    @Override
    public String getGlobalSettingByUserTypeSettingName(String userTypeCode, String settingName) {
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        
                        GlobalSetting gs = globalSettingRepository.getGlobalSettingByUserTypeSettingName(userTypeCode,settingName);
                        
			if (gs != null && gs.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
                                ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(gs);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
                        
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
		}
		return res;
	
    }

    @Override
    public String getGlobalSettingByUserTypeSettingType(String userTypeCode, String settingType) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        
                        List<GlobalSetting> gs = globalSettingRepository.getGlobalSettingByUserTypeSettingType(userTypeCode,settingType);
                        
			if (gs != null && gs.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
                                ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(gs);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
                        
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
			res = derr.toString();
		}
		return res;
	
    
    }

    
}
