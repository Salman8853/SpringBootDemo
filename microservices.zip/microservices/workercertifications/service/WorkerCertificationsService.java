package com.gigflex.prototype.microservices.workercertifications.service;

import java.util.List;

import com.gigflex.prototype.microservices.workercertifications.dtob.WorkerCertificationsRequest;

public interface WorkerCertificationsService {
	public String search(String search);
	public String findAllWorkerCertifications();

	public String getAllWorkerCertificationsByPage(int page, int limit);
	public String getAllWorkerCertificationsWithNames();
	public String geAllWorkerCertificationsWithNamesByPage(int page, int limit);
        public String getWorkerCertificationsByWorkerCode(String workerCode);
        public String getWorkerCertificationsByWorkerCodeByPage(String workerCode,int page, int limit);
	public String findWorkerCertificationsById(Long id);
	public String saveWorkerCertifications(WorkerCertificationsRequest workerCertiReq,String ip);
	public String updateWorkerCertificationsById(Long id,WorkerCertificationsRequest workerCertiReq,String ip);
    public String deleteWorkerCertificationsById(Long id);
    public String softDeleteWorkerCertificationsById(Long id);
    public String softMultipleDeleteById(List<Long> idList);
	

}
