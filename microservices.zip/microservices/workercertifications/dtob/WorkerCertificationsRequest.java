package com.gigflex.prototype.microservices.workercertifications.dtob;

public class WorkerCertificationsRequest {
	
	private String certificationCode;
	
	private String workerCode;

	public String getCertificationCode() {
		return certificationCode;
	}

	public void setCertificationCode(String certificationCode) {
		this.certificationCode = certificationCode;
	}

	public String getWorkerCode() {
		return workerCode;
	}

	public void setWorkerCode(String workerCode) {
		this.workerCode = workerCode;
	}
	
	

}
