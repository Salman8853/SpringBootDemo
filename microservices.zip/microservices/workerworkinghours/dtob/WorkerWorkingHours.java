/**
 * 
 */
package com.gigflex.prototype.microservices.workerworkinghours.dtob;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.util.CommonAttributes;
/**
 * @author ajit.p
 *
 */

@Entity
@Table(name = "worker_working_hours")
public class WorkerWorkingHours extends CommonAttributes implements Serializable {
	    
	private static final long serialVersionUID = 1L;

		@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "id")
	    private Long id;

	    @Column(name = "worker_code")
	    private String workerCode;
	   
	    @Column(name = "fromdate", columnDefinition = "DATETIME")
		private Date fromDate;

		@Column(name = "todate", columnDefinition = "DATETIME")
		private Date toDate;
	    
	    @Column(name = "worker_preferred_location_code", nullable = false)
	    private String workerPreferredLocationCode;
	    
	    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
		@GenericGenerator(name = "uuid", strategy = "uuid2")
	    @Column(name = "worker_working_hours_code", unique = true)
	    private String workerWorkingHoursCode;
	    
        @Column(name = "days_code")
	    private String daysCode;
        
        @PrePersist
    	private void assignUUID() {
    		if (this.getWorkerWorkingHoursCode() == null || this.getWorkerWorkingHoursCode().length() == 0) {
    			this.setWorkerWorkingHoursCode(UUID.randomUUID().toString());
    		}
    	}

	public String getWorkerPreferredLocationCode() {
			return workerPreferredLocationCode;
		}

		public void setWorkerPreferredLocationCode(String workerPreferredLocationCode) {
			this.workerPreferredLocationCode = workerPreferredLocationCode;
		}

	public String getDaysCode() {
        return daysCode;
    }

    public void setDaysCode(String daysCode) {
        this.daysCode = daysCode;
    }
		public WorkerWorkingHours() {
			super();
		}

		public WorkerWorkingHours(Long id) {
			super();
			this.id = id;
		}

		public WorkerWorkingHours(Long id, String workerCode, Date fromDate, Date toDate,
				String workerWorkingHoursCode, String daysCode) {
			super();
			this.id = id;
			this.workerCode = workerCode;
			this.fromDate = fromDate;
			this.toDate = toDate;
			this.workerWorkingHoursCode = workerWorkingHoursCode;
                        this.daysCode = daysCode;
		}

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getWorkerCode() {
			return workerCode;
		}

		public void setWorkerCode(String workerCode) {
			this.workerCode = workerCode;
		}

		public Date getFromDate() {
			return fromDate;
		}

		public void setFromDate(Date fromDate) {
			this.fromDate = fromDate;
		}

		public Date getToDate() {
			return toDate;
		}

		public void setToDate(Date toDate) {
			this.toDate = toDate;
		}

		public String getWorkerWorkingHoursCode() {
			return workerWorkingHoursCode;
		}

		public void setWorkerWorkingHoursCode(String workerWorkingHoursCode) {
			this.workerWorkingHoursCode = workerWorkingHoursCode;
		}

		public static long getSerialversionuid() {
			return serialVersionUID;
		}

		@Override
		public String toString() {
			return "WorkerWorkingHours [id=" + id + ", workerCode=" + workerCode + ", fromDate=" + fromDate
					+ ", toDate=" + toDate + ", workerWorkingHoursCode=" + workerWorkingHoursCode + "]";
		}

	    
}