package com.gigflex.prototype.microservices.workerworkinghours.api;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.workerworkinghours.dtob.WorkerWorkingHoursRequest;
import com.gigflex.prototype.microservices.workerworkinghours.service.WorkerWorkingHoursService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/healthcareservice/")
@ControllerAdvice
public class WorkerWorkingHoursController {
	@Autowired
	WorkerWorkingHoursService workerWorkingHoursService;

	@GetMapping("/workerWorkingHours/{search}")
	public String search(@PathVariable("search") String search) {
		return workerWorkingHoursService.search(search);
	}

	@GetMapping("/getAllWorkerWorkingHours")
	public String getAllWorkerWorkingHours() {
		return workerWorkingHoursService.getAllWorkerWorkingHours();
	}

	@GetMapping("/getAllWorkerWorkingHoursWithNames")
	public String getAllWorkerWorkingHoursWithNames() {
		return workerWorkingHoursService.getAllWorkerWorkingHoursWithName();
	}

	@GetMapping("/getAllWorkerWorkingHoursWithNamesByPage")
	public String getAllWorkerWorkingHoursWithNamesByPage(
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String wwh = workerWorkingHoursService
				.getAllWorkerWorkingHoursWithNamesByPage(page, limit);

		return wwh;

	}

	@GetMapping(path = "/getAllWorkerWorkingHoursByPage")
	public String getAllWorkerWorkingHoursByPage(
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String wwh = workerWorkingHoursService.getAllWorkerWorkingHoursByPage(
				page, limit);

		return wwh;

	}

	@GetMapping("/getWorkerWorkingHours/{id}")
	public String getWorkerWorkingHoursById(@PathVariable Long id) {
		return workerWorkingHoursService.getWorkerWorkingHoursById(id);
	}

	@GetMapping("/getWorkerWorkingHoursByWorkerWorkingHoursCode/{workerWorkingHoursCode}")
	public String getWorkerWorkingHoursByWorkerWorkingHoursCode(@PathVariable String workerWorkingHoursCode) {
		return workerWorkingHoursService.getByWorkerWorkingHoursCode(workerWorkingHoursCode);
	}
	
	@GetMapping("/getWorkerWorkingHoursByWorkerPreferredLocationCode/{workerPreferredLocationCode}")
	public String getWorkerWorkingHoursByWorkerPreferredLocationCode(@PathVariable String workerPreferredLocationCode) {
		return workerWorkingHoursService.getAllWorkerWorkingHoursByWorkerPreferredLocationCode(workerPreferredLocationCode);
	}
	
	@GetMapping("/getWorkerWorkingHoursByWorkerCode/{workerCode}")
	public String getWorkerWorkingHoursByWorkerCode(@PathVariable String workerCode) {
		return workerWorkingHoursService.getAllWorkerWorkingHoursByWorkerCode(workerCode);
	}
	
	@GetMapping(path="/getWorkerWorkingHoursByWorkerCodeByPage/{workerCode}")
    public String getWorkerWorkingHoursByWorkerCodeByPage(@PathVariable String workerCode,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String wwh = workerWorkingHoursService.getAllWorkerWorkingHoursByWorkerCode(workerCode, page, limit);
      
        return wwh;
       
    }
	
	@GetMapping(path="/getWorkerWorkingHoursByWorkerPreferredLocationCodeByPage/{workerPreferredLocationCode}")
    public String getWorkerWorkingHoursByWorkerPreferredLocationCodeByPage(@PathVariable String workerPreferredLocationCode,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String wwh = workerWorkingHoursService.getAllWorkerWorkingHoursByWorkerPreferredLocationCodeByPage(workerPreferredLocationCode, page, limit);
      
        return wwh;
       
    }
	
	@PostMapping("/saveWorkerWorkingHours")
	public String saveWorkerWorkingHours(
			@RequestBody WorkerWorkingHoursRequest workinghrsReq,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return workerWorkingHoursService.saveWorkerWorkingHours(workinghrsReq,
				ip);

	}

	@PutMapping("/updateWorkerWorkingHours/{id}")
	public String updateWorkerWorkingHours(@PathVariable Long id,
			@RequestBody WorkerWorkingHoursRequest workinghrsRqst,
			HttpServletRequest httpRequest) {

		if (workinghrsRqst != null) {
			String ip = httpRequest.getRemoteAddr();
			return workerWorkingHoursService.updateWorkerWorkingHours(id,
					workinghrsRqst, ip);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

		//
		// Object response = null;
		// if (errors.hasErrors()) {
		// response = errors.getAllErrors();
		// return ResponseEntity.badRequest().body(response);
		// }
		// WorkerWorkingHours org =
		// workerWorkingHoursService.getWorkerWorkingHoursById(id);
		// if (org == null) {
		// response = "WorkerWorkingHours with Id : (" + id + ") Not found.";
		// } else {
		// org =
		// workerWorkingHoursService.saveWorkerWorkingHours(workerWorkingHours);
		//
		// id =
		// workerWorkingHoursService.saveWorkerWorkingHours(workerWorkingHours).getId();
		// response = "WorkerWorkingHours with Id : (" + id + ") is Updated.";
		// }
		// return ResponseEntity.ok(response);
	}

	@DeleteMapping("/deleteWorkerWorkingHours/{id}")
	public String deleteWorkerWorkingHoursById(@PathVariable Long id) {
		return workerWorkingHoursService.deleteWorkerWorkingHoursById(id);
	}

	@DeleteMapping("/deleteByWorkerWorkingHoursCode/{workerWorkingHoursCode}")
	public String deleteByWorkerWorkingHoursCode(
			@PathVariable String workerWorkingHoursCode) {
		return workerWorkingHoursService
				.deleteByWorkerWorkingHoursCode(workerWorkingHoursCode);
	}

	@DeleteMapping("/softDeleteByWorkerWorkingHoursCode/{workerWorkingHoursCode}")
	public String softDeleteByWorkerWorkingHoursCode(
			@PathVariable String workerWorkingHoursCode) {
		return workerWorkingHoursService
				.softDeleteByWorkerWorkingHoursCode(workerWorkingHoursCode);
	}

	@DeleteMapping("/softMultipleDeleteByWorkerWorkingHoursCode/{workerWorkingHoursCodeList}")
	public String softMultipleDeleteByWorkerWorkingHoursCode(
			@PathVariable List<String> workerWorkingHoursCodeList) {
		if (workerWorkingHoursCodeList != null
				&& workerWorkingHoursCodeList.size() > 0) {
			return workerWorkingHoursService
					.softMultipleDeleteByWorkerWorkingHoursCode(workerWorkingHoursCodeList);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

	}
}
