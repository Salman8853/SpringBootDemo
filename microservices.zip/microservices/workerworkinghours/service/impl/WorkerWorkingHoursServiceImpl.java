/**
 * 
 */
package com.gigflex.prototype.microservices.workerworkinghours.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.daysmaster.dtob.DaysMaster;
import com.gigflex.prototype.microservices.daysmaster.repository.DaysMasterDao;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.workerworkinghours.dtob.DaysFromToResponse;
import com.gigflex.prototype.microservices.workerworkinghours.dtob.DaysLocationFromToResponse;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.workerworkinghours.dtob.WorkerWorkingHours;
import com.gigflex.prototype.microservices.workerworkinghours.dtob.WorkerWorkingHoursRequest;
import com.gigflex.prototype.microservices.workerworkinghours.dtob.WorkerWorkingHoursResponse;
import com.gigflex.prototype.microservices.worker.repository.WorkerRepository;
import com.gigflex.prototype.microservices.workerworkinghours.repository.WorkerWorkingHoursRepository;
import com.gigflex.prototype.microservices.workerworkinghours.service.WorkerWorkingHoursService;
import com.gigflex.prototype.microservices.workerpreferredlocation.dtob.WorkerPreferredLocation;
import com.gigflex.prototype.microservices.workerpreferredlocation.repository.WorkerPreferredLocationRepository;
import com.gigflex.prototype.microservices.workerworkinghours.search.WorkerWorkingHoursSpecificationsBuilder;

/**
 * @author ajit.p
 *
 */

@Service
public class WorkerWorkingHoursServiceImpl implements WorkerWorkingHoursService {
	@Autowired
	WorkerWorkingHoursRepository workerWorkingHoursRepository;

	@Autowired
	DaysMasterDao daysMasterDao;

	@Autowired
	WorkerRepository workerDao;
        
        @Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	WorkerPreferredLocationRepository workerPreferredLocationRepository;

	@Override
	public String getWorkerWorkingHoursById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			WorkerWorkingHours workinghrsData = workerWorkingHoursRepository
					.getWorkerWorkingHoursById(id);
			if (workinghrsData != null && workinghrsData.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(workinghrsData);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record not found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public WorkerWorkingHours saveWorkerWorkingHours(
			WorkerWorkingHours workerWorkingHours) {

		return workerWorkingHoursRepository.save(workerWorkingHours);
	}

	@Override
	public void updateWorkerWorkingHours(WorkerWorkingHours worker) {
		WorkerWorkingHours workerWorkingHoursInDb = workerWorkingHoursRepository
				.getOne(worker.getId());
		if (workerWorkingHoursInDb != null) {
			workerWorkingHoursInDb.setId(worker.getId());
			workerWorkingHoursRepository.save(workerWorkingHoursInDb);

		}
	}

	@Override
	public String updateWorkerWorkingHours(Long id,
			WorkerWorkingHoursRequest workinghrsRqst, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (id > 0 && workinghrsRqst != null) {
				if (workinghrsRqst.getDaysCode() != null
						&& workinghrsRqst.getDaysCode().trim().length() > 0
						&& workinghrsRqst.getWorkerCode() != null
						&& workinghrsRqst.getWorkerCode().trim().length() > 0
						&& workinghrsRqst.getWorkerPreferredLocationCode() != null
						&& workinghrsRqst.getWorkerPreferredLocationCode()
								.trim().length() > 0) {
					WorkerWorkingHours wwhlst = workerWorkingHoursRepository
							.getWorkerWorkingHoursById(id);
					if (wwhlst != null && wwhlst.getId() > 0) {

						Date frmdt = null;
						Date todt = null;
						try {
							frmdt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
									.parse(workinghrsRqst.getFromDate());
							todt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
									.parse(workinghrsRqst.getToDate());
						} catch (Exception ex) {
							ex.printStackTrace();
							GigflexResponse derr = new GigflexResponse(400,
									new Date(),
									"Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
							return derr.toString();
						}

						DaysMaster days = daysMasterDao
								.getDaysMasterByDaysCode(workinghrsRqst
										.getDaysCode());
						if (days != null && days.getId() > 0) {

							Worker wrkr = workerDao
									.findByWorkerCode(workinghrsRqst
											.getWorkerCode());
							if (wrkr != null && wrkr.getId() > 0) {

								WorkerPreferredLocation wpl = workerPreferredLocationRepository
										.getPreferredLocationByWorkerPreferredLocationCode(workinghrsRqst
												.getWorkerPreferredLocationCode());
								if (wpl != null && wpl.getId() > 0) {

									WorkerWorkingHours wwhrs = workerWorkingHoursRepository
											.getWrkrWrkngHrsByIdDayCodeWorkerCodeAndWorkerPreferredLocCode(
													id,
													workinghrsRqst
															.getDaysCode(),
													workinghrsRqst
															.getWorkerCode(),
													workinghrsRqst
															.getWorkerPreferredLocationCode());
									if (wwhrs != null && wwhrs.getId() > 0) {
										jsonobj.put("responsecode", 409);
										jsonobj.put("timestamp", new Date());
										jsonobj.put("message",
												"Record already exist.");
									} else {

										WorkerWorkingHours wo = wwhlst;
										wo.setFromDate(frmdt);
										wo.setToDate(todt);
										wo.setDaysCode(workinghrsRqst
												.getDaysCode());
										wo.setWorkerCode(workinghrsRqst
												.getWorkerCode());
										wo.setWorkerPreferredLocationCode(workinghrsRqst
												.getWorkerPreferredLocationCode());
										wo.setIpAddress(ip);
										WorkerWorkingHours woRes = workerWorkingHoursRepository
												.save(wo);
										if (woRes != null && woRes.getId() > 0) {
											jsonobj.put("responsecode", 200);
											jsonobj.put("message",
													"Worker Working Hours updation has been done");
											jsonobj.put("timestamp", new Date());
											ObjectMapper mapperObj = new ObjectMapper();
											String Detail = mapperObj
													.writeValueAsString(woRes);
											jsonobj.put("data", new JSONObject(
													Detail));
										} else {
											jsonobj.put("responsecode", 400);
											jsonobj.put("message",
													"Worker Working Hours updation has been failed.");
											jsonobj.put("timestamp", new Date());
										}
									}
								} else {
									jsonobj.put("responsecode", 400);
									jsonobj.put("message", "ID is not valid.");
									jsonobj.put("timestamp", new Date());
								}

							} else {
								jsonobj.put("message",
										"Worker Preferred Location Code Not Found.");
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
							}
						} else {
							jsonobj.put("message", "Worker Code Not Found.");
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("message", "Days Code Not Found.");
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message",
							"Days Code, Worker Code and Worker Preferred Location Code should not be blank");
				}
			}

			else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getByWorkerWorkingHoursCode(String workerWorkingHoursCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			WorkerWorkingHours wrkinghrslst = workerWorkingHoursRepository
					.getWorkerOffDaysByWorkerWorkingHoursCode(workerWorkingHoursCode);
			if (wrkinghrslst != null) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(wrkinghrslst);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Success");
				jsonobj.put("data", new JSONObject(Detail));

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllWorkerWorkingHours() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<WorkerWorkingHours> wrkinghrslst = workerWorkingHoursRepository
					.getAllWorkerWorkingHours();
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (wrkinghrslst != null && wrkinghrslst.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(wrkinghrslst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record not found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String saveWorkerWorkingHours(
			WorkerWorkingHoursRequest workinghrsRqst, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (workinghrsRqst != null) {
				if (workinghrsRqst.getDaysCode() != null
						&& workinghrsRqst.getDaysCode().trim().length() > 0
						&& workinghrsRqst.getWorkerCode() != null
						&& workinghrsRqst.getWorkerCode().trim().length() > 0
						&& workinghrsRqst.getWorkerPreferredLocationCode() != null
						&& workinghrsRqst.getWorkerPreferredLocationCode()
								.trim().length() > 0) {

					Date frmdt = null;
					Date todt = null;
					try {
						frmdt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
								.parse(workinghrsRqst.getFromDate());
						todt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
								.parse(workinghrsRqst.getToDate());
					} catch (Exception ex) {
						ex.printStackTrace();
						GigflexResponse derr = new GigflexResponse(400,
								new Date(),
								"Plz send date in correct format(yyyy-MM-dd HH:mm:ss) ");
						return derr.toString();
					}

					DaysMaster days = daysMasterDao
							.getDaysMasterByDaysCode(workinghrsRqst
									.getDaysCode());
					if (days != null && days.getId() > 0) {

						Worker wrkr = workerDao.findByWorkerCode(workinghrsRqst
								.getWorkerCode());
						if (wrkr != null && wrkr.getId() > 0) {

							WorkerPreferredLocation wpl = workerPreferredLocationRepository
									.getPreferredLocationByWorkerPreferredLocationCode(workinghrsRqst
											.getWorkerPreferredLocationCode());
							if (wpl != null && wpl.getId() > 0) {

								WorkerWorkingHours wwhrs = workerWorkingHoursRepository
										.getWrkrWrkngHrsByDayCodeWorkerCodeAndWorkerPreferredLocCode(
												workinghrsRqst.getDaysCode(),
												workinghrsRqst.getWorkerCode(),
												workinghrsRqst
														.getWorkerPreferredLocationCode());
								if (wwhrs != null && wwhrs.getId() > 0) {
									jsonobj.put("responsecode", 409);
									jsonobj.put("timestamp", new Date());
									jsonobj.put("message",
											"Record already exist.");
								} else {

									WorkerWorkingHours worker = new WorkerWorkingHours();
									worker.setDaysCode(workinghrsRqst
											.getDaysCode());
									worker.setFromDate(frmdt);
									worker.setToDate(todt);
									worker.setWorkerCode(workinghrsRqst
											.getWorkerCode());
									worker.setWorkerPreferredLocationCode(workinghrsRqst
											.getWorkerPreferredLocationCode());

									WorkerWorkingHours workingRes = workerWorkingHoursRepository
											.save(worker);

									jsonobj.put("responsecode", 200);
									jsonobj.put("timestamp", new Date());

									if (workingRes != null
											&& workingRes.getId() > 0) {
										// kafkaService.sendRoleMaster(roleRes);
										jsonobj.put("message",
												"Worker Working Hours has been added successfully.");
										ObjectMapper mapperObj = new ObjectMapper();
										String Detail = mapperObj
												.writeValueAsString(workingRes);
										jsonobj.put("data", new JSONObject(
												Detail));
									} else {
										jsonobj.put("message", "Failed");
									}
								}
							} else {
								jsonobj.put("message",
										"Worker Preferred Location Code Not Found.");
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
							}
						} else {
							jsonobj.put("message", "Worker Code Not Found.");
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("message", "Days Code Not Found.");
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message",
							"Days Code, Worker Code and Worker Preferred Location Code should not be blank");

				}
			}

			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String deleteWorkerWorkingHoursById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Optional<WorkerWorkingHours> workerData = workerWorkingHoursRepository
					.findById(id);
			if (workerData.isPresent() && workerData.get() != null) {
				workerWorkingHoursRepository.deleteById(id);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Worker Working Hours has been deleted.");
				jsonobj.put("timestamp", new Date());
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String deleteByWorkerWorkingHoursCode(String workerWorkingHoursCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Integer deleteByWorkerCode = workerWorkingHoursRepository
					.deleteByWorkerWorkingHoursCode(workerWorkingHoursCode);
			if (deleteByWorkerCode != 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Worker Working Hours has been deleted.");
				jsonobj.put("timestamp", new Date());
				res = jsonobj.toString();
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softDeleteByWorkerWorkingHoursCode(
			String workerWorkingHoursCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			WorkerWorkingHours wrkinghrslst = workerWorkingHoursRepository
					.getWorkerOffDaysByWorkerWorkingHoursCode(workerWorkingHoursCode);

			if (wrkinghrslst != null && wrkinghrslst.getId() > 0) {
				wrkinghrslst.setIsDeleted(true);
				WorkerWorkingHours wwhRes = workerWorkingHoursRepository
						.save(wrkinghrslst);
				if (wrkinghrslst != null && wrkinghrslst.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());

					jsonobj.put("message",
							"Worker Working Hours deleted successfully.");

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteByWorkerWorkingHoursCode(
			List<String> workerWorkingHoursCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String workerWorkingHoursCode : workerWorkingHoursCodeList) {
				if (workerWorkingHoursCode != null
						&& workerWorkingHoursCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					workerWorkingHoursCode = workerWorkingHoursCode.trim();

					WorkerWorkingHours wrkinghrslst = workerWorkingHoursRepository
							.getWorkerOffDaysByWorkerWorkingHoursCode(workerWorkingHoursCode);

					if (wrkinghrslst != null && wrkinghrslst.getId() > 0) {

						wrkinghrslst.setIsDeleted(true);
						WorkerWorkingHours wwhRes = workerWorkingHoursRepository
								.save(wrkinghrslst);
						if (wwhRes != null && wwhRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", workerWorkingHoursCode);
							jsonobj.put("message",
									"WorkerWorkingHours deleted successfully.");
							// kafkaService.sendUseronUpdate(usersDataRes);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", workerWorkingHoursCode);
							jsonobj.put("message", "Failed");
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", workerWorkingHoursCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getAllWorkerWorkingHoursByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<WorkerWorkingHours> wrkinghrslst = workerWorkingHoursRepository
					.getAllWorkerWorkingHours(pageableRequest);
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (wrkinghrslst != null && wrkinghrslst.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(wrkinghrslst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			if (search != null && search.trim().length() > 0) {
				JSONObject jsonobj = new JSONObject();

				WorkerWorkingHoursSpecificationsBuilder builder = new WorkerWorkingHoursSpecificationsBuilder();
				Pattern pattern = Pattern
						.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
				java.util.regex.Matcher matcher = pattern.matcher(search + ",");
				while (matcher.find()) {
					builder.with(matcher.group(1), matcher.group(2),
							matcher.group(3));
				}

				Specification<WorkerWorkingHours> spec = builder.build();
                                if(spec!=null){
				List<WorkerWorkingHours> wrkinghrslst = workerWorkingHoursRepository
						.findAll(spec);
				if (wrkinghrslst != null && wrkinghrslst.size() > 0) {
					for (WorkerWorkingHours wwh : wrkinghrslst) {
						if (wwh.getIsDeleted() != null
								&& wwh.getIsDeleted() != true) {

							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj.writeValueAsString(wwh);
							JSONObject jsonobjNew = new JSONObject();
							jsonobjNew.put("WorkerWorkingHours",
									new JSONObject(Detail));
							jarr.add(jsonobjNew);

						}

					}
					if (jarr.size() > 0) {

						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", jarr);
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Record Not Found!");
						jsonobj.put("timestamp", new Date());
					}

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Record Not Found!");
					jsonobj.put("timestamp", new Date());
				}}
                                else{
                                  jsonobj.put("responsecode", 400);
				  jsonobj.put("message", "Record Not Found!");
				  jsonobj.put("timestamp", new Date());  
                                }
				res = jsonobj.toString();

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Input data is not valid.");
				res = derr.toString();

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getAllWorkerWorkingHoursByWorkerPreferredLocationCode(
			String workerPreferredLocationCode) {

		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (workerPreferredLocationCode != null
					&& workerPreferredLocationCode.trim().length() > 0) {
				List<WorkerWorkingHours> wrkinghrslst = new ArrayList<WorkerWorkingHours>();
				wrkinghrslst = workerWorkingHoursRepository
						.getAllWorkerWorkingHoursByWorkerPreferredLocationCode(workerPreferredLocationCode);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());

				if (wrkinghrslst != null && wrkinghrslst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(wrkinghrslst);
					jsonobj.put("data", new JSONArray(Detail));

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");

				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Invalid Input");
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllWorkerWorkingHoursByWorkerPreferredLocationCodeByPage(
			String workerPreferredLocationCode, int page, int limit) {

		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);

			if (workerPreferredLocationCode != null
					&& workerPreferredLocationCode.trim().length() > 0) {
				List<WorkerWorkingHours> wrkinghrslst = new ArrayList<WorkerWorkingHours>();
				wrkinghrslst = workerWorkingHoursRepository
						.getAllWorkerWorkingHoursByWorkerPreferredLocationCode(
								workerPreferredLocationCode, pageableRequest);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());

				if (wrkinghrslst != null && wrkinghrslst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(wrkinghrslst);
					jsonobj.put("data", new JSONArray(Detail));

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");

				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Invalid Input");

			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllWorkerWorkingHoursWithName() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<Object> objlst = workerWorkingHoursRepository
					.getAllWorkerWorkingHoursWithName();

			List<WorkerWorkingHoursResponse> maplst = new ArrayList<WorkerWorkingHoursResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 4) {
						WorkerWorkingHoursResponse wwhr = new WorkerWorkingHoursResponse();

						WorkerWorkingHours wwh = (WorkerWorkingHours) arr[0];

						wwhr.setId(wwh.getId());
						wwhr.setWorkerWorkingHoursCode(wwh
								.getWorkerWorkingHoursCode());

						wwhr.setWorkerCode(wwh.getWorkerCode());
						wwhr.setName((String) arr[1]);

						wwhr.setDaysCode(wwh.getDaysCode());
						wwhr.setDaysName((String) arr[2]);

						wwhr.setWorkerPreferredLocationCode(wwh
								.getWorkerPreferredLocationCode());
						wwhr.setLocation((String) arr[3]);

						wwhr.setFromDate(wwh.getFromDate());
						wwhr.setToDate(wwh.getToDate());

						maplst.add(wwhr);
					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllWorkerWorkingHoursWithNamesByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<Object> objlst = workerWorkingHoursRepository
					.getAllWorkerWorkingHoursWithName(pageableRequest);

			List<WorkerWorkingHoursResponse> maplst = new ArrayList<WorkerWorkingHoursResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 4) {
						WorkerWorkingHoursResponse wwhr = new WorkerWorkingHoursResponse();

						WorkerWorkingHours wwh = (WorkerWorkingHours) arr[0];

						wwhr.setId(wwh.getId());
						wwhr.setWorkerWorkingHoursCode(wwh
								.getWorkerWorkingHoursCode());

						wwhr.setWorkerCode(wwh.getWorkerCode());
						wwhr.setName((String) arr[1]);

						wwhr.setDaysCode(wwh.getDaysCode());
						wwhr.setDaysName((String) arr[2]);

						wwhr.setWorkerPreferredLocationCode(wwh
								.getWorkerPreferredLocationCode());
						wwhr.setLocation((String) arr[3]);

						wwhr.setFromDate(wwh.getFromDate());
						wwhr.setToDate(wwh.getToDate());

						maplst.add(wwhr);
					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllWorkerWorkingHoursByWorkerCode(String workerCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (workerCode != null && workerCode.trim().length() > 0) {

				List<Object> objlst = workerWorkingHoursRepository
						.getAllWorkerWorkingHoursByWorkerCode(workerCode);

				List<DaysLocationFromToResponse> daysLocResLst = new ArrayList<DaysLocationFromToResponse>();

				DaysLocationFromToResponse daysLocRes = new DaysLocationFromToResponse();

				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 3) {

							WorkerWorkingHours wrkWrLc = (WorkerWorkingHours) arr[0];

							String location = (String) arr[1];
							String daysName = (String) arr[2];

							DaysFromToResponse daysRes = new DaysFromToResponse();
							daysRes.setDaysName(daysName);
							daysRes.setFromDate(wrkWrLc.getFromDate());
							daysRes.setToDate(wrkWrLc.getToDate());
							if (i == 0) {
								List<DaysFromToResponse> dftr = new ArrayList<DaysFromToResponse>();
								dftr.add(daysRes);
								daysLocRes.setLocation(location);
								daysLocRes.setDaysFromToResponse(dftr);
							} else {
								if (daysLocRes.getLocation() != null
										&& !(daysLocRes.getLocation()
												.equalsIgnoreCase(location))) {
									daysLocResLst.add(daysLocRes);
									daysLocRes = new DaysLocationFromToResponse();
									List<DaysFromToResponse> dftr = new ArrayList<DaysFromToResponse>();
									dftr.add(daysRes);
									daysLocRes.setLocation(location);
									daysLocRes.setDaysFromToResponse(dftr);
								} else {
									List<DaysFromToResponse> dftrlst = daysLocRes
											.getDaysFromToResponse();
									dftrlst.add(daysRes);
									daysLocRes.setDaysFromToResponse(dftrlst);
								}
							}
						}
					}
					if (daysLocRes != null && daysLocRes.getLocation() != null
							&& daysLocRes.getLocation().length() > 0) {
						daysLocResLst.add(daysLocRes);
					}
					if (daysLocResLst.size() > 0) {

						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj
								.writeValueAsString(daysLocResLst);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

//	@Override
//	public String getAllWorkerWorkingHoursByWorkerCode(String workerCode,
//			int page, int limit) {
//		String res = "";
//		try {
//			JSONObject jsonobj = new JSONObject();
//			Pageable pageableRequest = PageRequest.of(page, limit);
//			if (workerCode != null && workerCode.trim().length() > 0) {
//
//				List<String> pageLoc = workerWorkingHoursRepository
//						.getWorkerWorkingHoursByWorkerCode(workerCode,
//								pageableRequest);
//				if (pageLoc != null && pageLoc.size()>0) {
//
//					List<Object> objlst = workerWorkingHoursRepository
//							.getAllWorkerWorkingHoursByWorkerCodeWithLocation(
//									workerCode, pageLoc);
//
//				List<DaysLocationFromToResponse> daysLocResLst = new ArrayList<DaysLocationFromToResponse>();
//
//				DaysLocationFromToResponse daysLocRes = new DaysLocationFromToResponse();
//
//				if (objlst != null && objlst.size() > 0) {
//					for (int i = 0; i < objlst.size(); i++) {
//						Object[] arr = (Object[]) objlst.get(i);
//						if (arr.length >= 3) {
//
//							WorkerWorkingHours wrkWrLc = (WorkerWorkingHours) arr[0];
//
//							String location = (String) arr[1];
//							String daysName = (String) arr[2];
//
//							DaysFromToResponse daysRes = new DaysFromToResponse();
//							daysRes.setDaysName(daysName);
//							daysRes.setFromDate(wrkWrLc.getFromDate());
//							daysRes.setToDate(wrkWrLc.getToDate());
//							if (i == 0) {
//								List<DaysFromToResponse> dftr = new ArrayList<DaysFromToResponse>();
//								dftr.add(daysRes);
//								daysLocRes.setLocation(location);
//								daysLocRes.setDaysFromToResponse(dftr);
//							} else {
//								if (daysLocRes.getLocation() != null
//										&& !(daysLocRes.getLocation()
//												.equalsIgnoreCase(location))) {
//									daysLocResLst.add(daysLocRes);
//									daysLocRes = new DaysLocationFromToResponse();
//									List<DaysFromToResponse> dftr = new ArrayList<DaysFromToResponse>();
//									dftr.add(daysRes);
//									daysLocRes.setLocation(location);
//									daysLocRes.setDaysFromToResponse(dftr);
//								} else {
//									List<DaysFromToResponse> dftrlst = daysLocRes
//											.getDaysFromToResponse();
//									dftrlst.add(daysRes);
//									daysLocRes.setDaysFromToResponse(dftrlst);
//								}
//							}
//						}
//					}
//					if (daysLocRes != null && daysLocRes.getLocation() != null
//							&& daysLocRes.getLocation().length() > 0) {
//						daysLocResLst.add(daysLocRes);
//					}
//					if (daysLocResLst.size() > 0) {
//
//						ObjectMapper mapperObj = new ObjectMapper();
//						String Detail = mapperObj
//								.writeValueAsString(daysLocResLst);
//						jsonobj.put("responsecode", 200);
//						jsonobj.put("message", "Success");
//						jsonobj.put("timestamp", new Date());
//						jsonobj.put("data", new JSONArray(Detail));
//					} else {
//						jsonobj.put("responsecode", 404);
//						jsonobj.put("message", "Record Not Found");
//						jsonobj.put("timestamp", new Date());
//					}
//				} else {
//					jsonobj.put("responsecode", 404);
//					jsonobj.put("message", "Record Not Found");
//					jsonobj.put("timestamp", new Date());
//				}
//				}else{
//					jsonobj.put("responsecode", 404);
//					jsonobj.put("message", "Record Not Found");
//					jsonobj.put("timestamp", new Date());
//				}
//			} else {
//				jsonobj.put("responsecode", 404);
//				jsonobj.put("message", "Worker Code should not be blank");
//				jsonobj.put("timestamp", new Date());
//			}
//			res = jsonobj.toString();
//		} catch (JSONException ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(),
//					"JSON parsing exception is occurred.");
//			res = derr.toString();
//			ex.printStackTrace();
//		} catch (Exception ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(),
//					"Exception is occurred.");
//			res = derr.toString();
//			ex.printStackTrace();
//		}
//		return res;
//	}
	
	@Override
	public String getAllWorkerWorkingHoursByWorkerCode(String workerCode,
			int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			if (workerCode != null
					&& workerCode.trim().length() > 0) {

				List<WorkerPreferredLocation> pageLoc = workerWorkingHoursRepository
						.getWorkerPreferredLocationByWorkerCode(workerCode, pageableRequest);

				List<DaysLocationFromToResponse> daysLocResLst = new ArrayList<DaysLocationFromToResponse>();

				if (pageLoc != null && pageLoc.size() > 0) {

					for (WorkerPreferredLocation wl : pageLoc) {

						DaysLocationFromToResponse daysLocRes = new DaysLocationFromToResponse();
						daysLocRes.setLocation(wl.getLocation());
                                                Organization  org=organizationRepository.findByOrganizationCode(wl.getWorkerOrganizationCode());
                                                if(org!=null && org.getId()>0)
                                                {
                                                    daysLocRes.setOrganizationCode(org.getOrganizationCode());
                                                    daysLocRes.setOrganizationName(org.getOrganizationName());
                                                }
						List<Object> objlst = workerWorkingHoursRepository
								.getAllWorkerWorkingHoursByWorkerCodeWithLocation(
										workerCode,
										wl.getWorkerPreferredLocationCode());

						List<DaysFromToResponse> dftr = new ArrayList<DaysFromToResponse>();

						if (objlst != null && objlst.size() > 0) {
							for (int i = 0; i < objlst.size(); i++) {
								Object[] arr = (Object[]) objlst.get(i);
								if (arr.length >= 2) {

									DaysFromToResponse dftrl = new DaysFromToResponse();

									WorkerWorkingHours wrkWrLc = (WorkerWorkingHours) arr[0];

									String daysName = (String) arr[1];

									dftrl.setDaysName(daysName);
									dftrl.setFromDate(wrkWrLc.getFromDate());
									dftrl.setToDate(wrkWrLc.getToDate());
									dftr.add(dftrl);
								}
							}
						}

						daysLocRes.setDaysFromToResponse(dftr);

						daysLocResLst.add(daysLocRes);

					}
					if (daysLocResLst.size() > 0) {

						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj
								.writeValueAsString(daysLocResLst);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONArray(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

}
