package com.gigflex.prototype.microservices.organizationskill.dtob;

import java.util.List;

public class OrganizationSkillRequest {

	private List<SkillData> SkillList;

	private String organizationCode;       

        public List<SkillData> getSkillList() {
            return SkillList;
        }

        public void setSkillList(List<SkillData> SkillList) {
            this.SkillList = SkillList;
        }        

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}
       
        
}
