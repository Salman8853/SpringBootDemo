package com.gigflex.prototype.microservices.organizationworkerskill.dtob;


public class OrganizationWorkerSkillRequest {
	
	private String skillCode;

	private String organizationCode;

//	private Double ExperienceInYear;
	
	private Long experienceInDays;


	private String workerCode;
	
	private Boolean isAssigned = false;
	
	public Boolean getIsAssigned() {
		return isAssigned;
	}

	public void setIsAssigned(Boolean isAssigned) {
		this.isAssigned = isAssigned;
	}

	public String getSkillCode() {
		return skillCode;
	}

	public void setSkillCode(String skillCode) {
		this.skillCode = skillCode;
	}

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}

//	public Double getExperienceInYear() {
//		return ExperienceInYear;
//	}
//
//	public void setExperienceInYear(Double experienceInYear) {
//		ExperienceInYear = experienceInYear;
//	}
	
	

	public String getWorkerCode() {
		return workerCode;
	}

	public Long getExperienceInDays() {
		return experienceInDays;
	}

	public void setExperienceInDays(Long experienceInDays) {
		this.experienceInDays = experienceInDays;
	}

	public void setWorkerCode(String workerCode) {
		this.workerCode = workerCode;
	}
	
	
	

}
