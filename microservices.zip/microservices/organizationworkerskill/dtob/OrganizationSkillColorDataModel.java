/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.organizationworkerskill.dtob;

import java.util.List;

/**
 *
 * @author amit.kumar
 */
public class OrganizationSkillColorDataModel {
    
    private String organizationCode;
    
    private String organizationName;
    
    private List<OrganizationSkillsModel> skillColorList;

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

    public List<OrganizationSkillsModel> getSkillColorList() {
        return skillColorList;
    }

    public void setSkillColorList(List<OrganizationSkillsModel> skillColorList) {
        this.skillColorList = skillColorList;
    }
    
}
