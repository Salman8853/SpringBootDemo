/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.uploadqueue.service;

import java.io.File;
import java.io.FileInputStream;
import java.util.Date;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.gigflex.prototype.microservices.uploadqueue.dtob.UploadQueue;
import com.gigflex.prototype.microservices.uploadqueue.repository.UploadQueueDao;
import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkerApprovalStatus;
import com.gigflex.prototype.microservices.verifyemployee.repository.WorkerApprovalStatusRepository;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.worker.repository.WorkerRepository;

public class FileUploadThread implements Runnable {
	

    
    private String fileName;
    private String uploadCode;
    private String userCode;
    private String organizationCode;
	private UploadQueueDao uploadQueueDao;
	private WorkerRepository workerDao;
	private WorkerApprovalStatusRepository wasDao;
 	

	public FileUploadThread(String fileName, String uploadCode,
			String userCode, String organizationCode,
			UploadQueueDao uploadQueueDao, WorkerRepository workerDao,
			WorkerApprovalStatusRepository wasDao) {
		super();
		this.fileName = fileName;
		this.uploadCode = uploadCode;
		this.userCode = userCode;
		this.organizationCode = organizationCode;
		this.uploadQueueDao = uploadQueueDao;
		this.workerDao = workerDao;
		this.wasDao = wasDao;
              
	}


	@Override
    public void run() {
		try{
		File myFile = new File(fileName);
        FileInputStream fis = new FileInputStream(myFile);

        Workbook myWorkBook; 
        Sheet mySheet=null; 
        
        int inx = fileName.lastIndexOf(".");
        String filenameEnd = fileName.substring(inx);

        if(filenameEnd.equalsIgnoreCase(".xls")){
        myWorkBook = new HSSFWorkbook(fis);
        mySheet = myWorkBook.getSheetAt(0);
        }else if (filenameEnd.equalsIgnoreCase(".xlsx")){
        myWorkBook = new XSSFWorkbook(fis); 
        mySheet = myWorkBook.getSheetAt(0); 
        }
        Iterator<Row> rowIterator = mySheet.iterator();
        int rowCount = -1;
        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Boolean status = false;
            try{
            	
            if(row != null){
                rowCount++;

            if(rowCount != 0){
            Iterator<Cell> cellIterator = row.cellIterator();
            int cellCount = 0;
            Worker worker  = new Worker();
            
            while (cellIterator.hasNext()) {
            	cellCount++;

                Cell cell = cellIterator.next();
                
                if(cell != null){
                	String res = "";
                	switch (cell.getCellType()) {
                    case Cell.CELL_TYPE_STRING:
                        res = cell.getStringCellValue();
                        break;
                    case Cell.CELL_TYPE_NUMERIC:
                    	double var = cell.getNumericCellValue();
                        Long l = (long)var;
                        res = l.toString();
                        break;
                    case Cell.CELL_TYPE_BOOLEAN:
                    	if(cell.getBooleanCellValue()){
                    		res = "true";
                    	}else{
                    		res= "false";
                    	}
             
                        break;
                    default :
                 
                    }
                	
                	
                	if(cellCount==10){
                		
            			if(res.trim().equalsIgnoreCase("true")){
                    	worker.setIsActive(true);
            			}else{
                        	worker.setIsActive(false);

            			}
                    	break;
                    
                    }else if(cellCount==9){
                    	
                    	worker.setExternalEmpCode(res);
                    	
                    }else if(cellCount==8){
                    	worker.setQualification(res);
                    	
                    }else if(cellCount==7){
            			if( res.trim().length() > 0){
                    	worker.setExpDays(Integer.parseInt(res));
                    			}
                    	
                    }else if(cellCount==6){
            			if( res.trim().length() > 0){

                    	worker.setExpMonth(Integer.parseInt(res));
            			}
                    	
                    }else if(cellCount==5){
                    	if( res.trim().length() > 0){
                    	worker.setExpYear(Integer.parseInt(res));
            			}
                    	
                    }else if(cellCount==4){
                    
                    	worker.setPhone(res);
                    	
                    }else if(cellCount==3){
                		worker.setDepartmentCode(res);
                    	
                    }else if(cellCount==2){
                    	worker.setEmail(res);
                    	
                    }else if(cellCount==1){
                    	worker.setName(res);
                    }
                	
                }
                
            }
            if(worker != null && worker.getName() != null){
            	
            	Worker workerRes = workerDao.save(worker);
            	
            	if(workerRes!=null && workerRes.getId() > 0){
            		status = true;


            		WorkerApprovalStatus was = new WorkerApprovalStatus();
            		was.setIsApproved(true);
            		was.setApprovedDate(new Date());
            		was.setApprovedByCode(userCode);
            		was.setWorkerCode(workerRes.getWorkerCode());
            		was.setOrganization_Code(organizationCode);
            		WorkerApprovalStatus wasRes = wasDao.save(was);
            		
            		if(wasRes!=null && wasRes.getId() > 0){


            		}
            		
            	}
            	
            }

                
            }
            }
        }
          
        catch(Exception ex){
        	ex.printStackTrace();
        }
            if(rowCount >= 1){
            UploadQueue uploadRes = uploadQueueDao.getUploadQueueByUploadCode(uploadCode);
            
            if(uploadRes != null && uploadRes.getId() > 0){
            	if(status){
            		uploadRes.setProcessedRecords(uploadRes.getProcessedRecords() + 1);
            	}else{
            		uploadRes.setFaliedRecords(uploadRes.getFaliedRecords() + 1);
            	}
            	
            	uploadQueueDao.save(uploadRes);
            }
            }



		}
		}
		catch(Exception e){
        	e.printStackTrace();

		}

	}
        

}
