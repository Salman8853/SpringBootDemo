package com.gigflex.prototype.microservices.uploadqueue.search;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.gigflex.prototype.microservices.uploadqueue.dtob.UploadQueue;
import com.gigflex.prototype.microservices.util.SearchCriteria;

public class UploadQueueSpecificationsBuilder {
	private final List<SearchCriteria> params;
	 
    public UploadQueueSpecificationsBuilder() {
        params = new ArrayList<SearchCriteria>();
    }
 
    public UploadQueueSpecificationsBuilder with(String key, String operation, Object value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }
 
    public Specification<UploadQueue> build() {
        if (params.size() == 0) {
            return null;
        }
 
        List<Specification<UploadQueue>> specs = new ArrayList<Specification<UploadQueue>>();
        for (SearchCriteria param : params) {
            specs.add(new UploadQueueSpecification(param));
        }
 
        Specification<UploadQueue> result = specs.get(0);
        for (int i = 1; i < specs.size(); i++) {
            result = Specification.where(result).and(specs.get(i));
        }
        return result;
    }
}
