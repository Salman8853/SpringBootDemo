/**
 * 
 */
package com.gigflex.prototype.microservices.workinglocation.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.util.GigUtil;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.workinglocation.dtob.WorkingLocation;
import com.gigflex.prototype.microservices.workinglocation.dtob.WorkingLocationRequest;
import com.gigflex.prototype.microservices.workinglocation.repository.WorkingLocationRepository;
import com.gigflex.prototype.microservices.workinglocation.service.WorkingLocationService;
import com.gigflex.prototype.microservices.workinglocation.search.WorkingLocationSpecificationsBuilder;

/**
 * @author ajit.p
 *
 */
@Service
public class WorkingLocationServiceImpl implements WorkingLocationService {
	private static final Logger LOG = LoggerFactory
			.getLogger(WorkingLocationServiceImpl.class);

	@Autowired
	WorkingLocationRepository workingLocationRepo;

	@Autowired
	OrganizationRepository orgDao;



	@Autowired
	TimeZoneRepository timeZoneDao;

	@Override
	public String getAllWorkingLocations() {

		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<WorkingLocation> wklst = workingLocationRepo
					.getAllWorkingLocation();

			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (wklst != null && wklst.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(wklst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;

	}

	@Override
	public String getWorkingLocationsById(Long id) {

		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			WorkingLocation wklst = workingLocationRepo
					.getWorkingLocationById(id);
			if (wklst != null && wklst.getId() > 0) {
				WorkingLocation wk = wklst;
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				if (wk != null) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(wk);
					jsonobj.put("data", new JSONObject(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String saveWorkingLocations(WorkingLocationRequest workingLocation,
			String ip) {
		// return workingLocationRepo.save(workingLocation);
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (workingLocation != null) {
				if ((workingLocation.getOrganizationCode() != null && workingLocation
						.getOrganizationCode().trim().length() > 0)
						&& (workingLocation.getTimeZone() != null && workingLocation
								.getTimeZone().trim().length() > 0)
						&& (workingLocation.getLang() != null && workingLocation
								.getLang().trim().length() > 0)
						&& (workingLocation.getLat() != null && workingLocation
								.getLat().trim().length() > 0)
						&& (workingLocation.getLocation() != null && workingLocation
								.getLocation().trim().length() > 0)) {
					Organization org = orgDao
							.findByOrganizationCode(workingLocation
									.getOrganizationCode());
					if (org != null && org.getId() > 0) {

						TimeZoneDetail tzd = timeZoneDao
								.getTimeZoneDetailByTimeZoneCode(workingLocation
										.getTimeZone());
						if (tzd != null && tzd.getId() > 0) {

							WorkingLocation workLoc1 = workingLocationRepo
									.getWorkingLocationByLatLangAndOrgCode(
											workingLocation.getLat(),
											workingLocation.getLang(),
											workingLocation
													.getOrganizationCode());
							if (workLoc1 != null && workLoc1.getId() > 0) {
								jsonobj.put("responsecode", 409);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Record already exist.");
							} else {
								WorkingLocation wl = new WorkingLocation();
								wl.setIsactive(workingLocation.getIsactive());
								wl.setLat(workingLocation.getLat());
								wl.setLang(workingLocation.getLang());
								wl.setLocation(workingLocation.getLocation());
								wl.setOrganizationCode(workingLocation
										.getOrganizationCode());
								wl.setTimeZone(workingLocation.getTimeZone());

								wl.setIpAddress(ip);

								WorkingLocation wlRes = workingLocationRepo
										.save(wl);

								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());

								if (wlRes != null && wlRes.getId() > 0) {

									jsonobj.put("message",
											"Working Location has been added successfully.");
									ObjectMapper mapperObj = new ObjectMapper();
									String Detail = mapperObj
											.writeValueAsString(wlRes);
									jsonobj.put("data", new JSONObject(Detail));
//									kafkaService.sendWorkingLocation(wlRes);
								} else {
									jsonobj.put("message", "Failed");
								}

							}
						} else {
							jsonobj.put("responsecode", 404);
							jsonobj.put("message", "TimeZone Code Not Found");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Organization Code Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Data should not be blank.");
					jsonobj.put("timestamp", new Date());
				}
			}
			//
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;

	}

	@Override
	public String deleteWorkingLoccationsById(Long id) {

		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Optional<WorkingLocation> wlData = workingLocationRepo.findById(id);
			if (wlData.isPresent() && wlData.get() != null) {
				workingLocationRepo.deleteById(id);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Department has been deleted.");
				jsonobj.put("timestamp", new Date());

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String updateWorkingLocations(
			WorkingLocationRequest workingLocation, Long id, String ip) {

		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (id > 0 && workingLocation != null) {
				if ((workingLocation.getOrganizationCode() != null && workingLocation
						.getOrganizationCode().trim().length() > 0)
						&& (workingLocation.getTimeZone() != null && workingLocation
								.getTimeZone().trim().length() > 0)
						&& (workingLocation.getLang() != null && workingLocation
								.getLang().trim().length() > 0)
						&& (workingLocation.getLat() != null && workingLocation
								.getLat().trim().length() > 0)
						&& (workingLocation.getLocation() != null && workingLocation
								.getLocation().trim().length() > 0)) {
					Organization org = orgDao
							.findByOrganizationCode(workingLocation
									.getOrganizationCode());
					if (org != null && org.getId() > 0) {

						TimeZoneDetail tzd = timeZoneDao
								.getTimeZoneDetailByTimeZoneCode(workingLocation
										.getTimeZone());
						if (tzd != null && tzd.getId() > 0) {

							WorkingLocation wrkLoc = workingLocationRepo
									.getWorkingLocationByIdLatLangAndOrgCode(
											id, workingLocation.getLat(),
											workingLocation.getLang(),
											workingLocation
													.getOrganizationCode());
							if (wrkLoc != null && wrkLoc.getId() > 0) {
								jsonobj.put("responsecode", 409);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Record already exist.");
							} else {

								WorkingLocation wklst = workingLocationRepo
										.getWorkingLocationById(id);
								if (wklst != null && wklst.getId() > 0) {
									WorkingLocation workLoc = wklst;
									workLoc.setLocation(workingLocation
											.getLocation());
									workLoc.setIpAddress(ip);
									workLoc.setIsactive(workingLocation
											.getIsactive());
									workLoc.setLang(workingLocation.getLang());
									workLoc.setLat(workingLocation.getLat());
									workLoc.setOrganizationCode(workingLocation
											.getOrganizationCode());
									workLoc.setTimeZone(workingLocation
											.getTimeZone());

									WorkingLocation wl = workingLocationRepo
											.save(workLoc);
									if (wl != null && wl.getId() > 0) {
										jsonobj.put("responsecode", 200);
										jsonobj.put("message",
												"Working Location updation has been done");
										jsonobj.put("timestamp", new Date());
										ObjectMapper mapperObj = new ObjectMapper();
										String Detail = mapperObj
												.writeValueAsString(wl);
										jsonobj.put("data", new JSONObject(
												Detail));
//										kafkaService
//												.sendUpdateWorkingLocation(wl);

									} else {
										jsonobj.put("responsecode", 400);
										jsonobj.put("message",
												"Working Location updation has been failed.");
										jsonobj.put("timestamp", new Date());
									}
								} else {
									jsonobj.put("responsecode", 400);
									jsonobj.put("message", "ID is not valid.");
									jsonobj.put("timestamp", new Date());
								}
							}
						} else {
							jsonobj.put("responsecode", 404);
							jsonobj.put("message", "TimeZone Code Not Found");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Organization Code Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Data should not be blank.");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;

	}

	@Override
	public String deleteWorkingLoccationsByWorkingLocationCode(
			String workingLocationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			WorkingLocation wklst = workingLocationRepo
					.findByWorkingLocationCode(workingLocationCode);

			Integer deleteByWrkLocCode = workingLocationRepo
					.deleteWorkingLocationByOrganizationCode(workingLocationCode);
			if (deleteByWrkLocCode != 0 && wklst != null && wklst.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", " Working Locations has been deleted.");
				jsonobj.put("timestamp", new Date());
				res = jsonobj.toString();

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softDeleteWorkingLoccationsByWorkingLocationCode(
			String workingLocationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			WorkingLocation wklst = workingLocationRepo
					.findByWorkingLocationCode(workingLocationCode);

			if (wklst != null && wklst.getId() > 0) {

				wklst.setIsDeleted(true);
				WorkingLocation wkRes = workingLocationRepo.save(wklst);
				if (wkRes != null && wkRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message",
							" Working Locations deleted successfully.");
//					kafkaService.sendUpdateWorkingLocation(wkRes);

				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
			LOG.error("Error in softDeleteByWorkingLocationCode>>>>>>", ex);
		} catch (org.springframework.orm.jpa.JpaSystemException ex) {
			GigflexResponse derr = new GigflexResponse(401, new Date(),
					GigUtil.getRootException(ex));
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
			LOG.error("Error in softDeleteByWorkingLocationCode>>>>>>", ex);
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteByWorkingLocationCode(
			List<String> workingLocationCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String workingLocationCode : workingLocationCodeList) {
				if (workingLocationCode != null
						&& workingLocationCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					workingLocationCode = workingLocationCode.trim();

					WorkingLocation wklst = workingLocationRepo
							.findByWorkingLocationCode(workingLocationCode);

					if (wklst != null && wklst.getId() > 0) {
						try {
							wklst.setIsDeleted(true);
							WorkingLocation wkRes = workingLocationRepo
									.save(wklst);
							if (wkRes != null && wkRes.getId() > 0) {
								jsonobj.put("responsecode", 200);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("code", workingLocationCode);
								jsonobj.put("message",
										"Working Location deleted successfully.");
//								kafkaService.sendUpdateWorkingLocation(wkRes);
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("code", workingLocationCode);
								jsonobj.put("message", "Failed");
							}
						} catch (org.springframework.orm.jpa.JpaSystemException ex) {
							jsonobj.put("responsecode", 401);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", workingLocationCode);
							jsonobj.put("message", GigUtil.getRootException(ex));
						}
					}

					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getWorkingLocationsByOrgCode(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (organizationCode != null && organizationCode.length() > 0) {
				List<WorkingLocation> wklst = workingLocationRepo
						.getWorkingLocationByOrganizationCode(organizationCode);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());

				if (wklst != null && wklst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(wklst);
					jsonobj.put("data", new JSONArray(Detail));
				}

				else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Invalid Input");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllWorkingLocationsByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<WorkingLocation> wlLst = workingLocationRepo
					.getAllWorkingLocation(pageableRequest);
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (wlLst != null && wlLst.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(wlLst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			if (search != null && search.trim().length() > 0) {
				JSONObject jsonobj = new JSONObject();

				WorkingLocationSpecificationsBuilder builder = new WorkingLocationSpecificationsBuilder();
				Pattern pattern = Pattern
						.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
				java.util.regex.Matcher matcher = pattern.matcher(search + ",");
				while (matcher.find()) {
					builder.with(matcher.group(1), matcher.group(2),
							matcher.group(3));
				}

				Specification<WorkingLocation> spec = builder.build();
				if (spec != null) {
					List<WorkingLocation> wlLst = workingLocationRepo
							.findAll(spec);
					if (wlLst != null && wlLst.size() > 0) {
						for (WorkingLocation wl : wlLst) {
							if (wl.getIsDeleted() != null
									&& wl.getIsDeleted() != true) {

								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj
										.writeValueAsString(wl);
								JSONObject jsonobjNew = new JSONObject();
								jsonobjNew.put("WorkingLocation",
										new JSONObject(Detail));
								jarr.add(jsonobjNew);

							}

						}
						if (jarr.size() > 0) {

							jsonobj.put("responsecode", 200);
							jsonobj.put("message", "Success");
							jsonobj.put("timestamp", new Date());
							jsonobj.put("data", jarr);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message", "Record Not Found!");
							jsonobj.put("timestamp", new Date());
						}

					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Record Not Found!");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Record Not Found!");
					jsonobj.put("timestamp", new Date());
				}
				res = jsonobj.toString();

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Input data is not valid.");
				res = derr.toString();

			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

}
