/**
 * 
 */
package com.gigflex.prototype.microservices.workinglocation.service;

import java.util.List;


import com.gigflex.prototype.microservices.workinglocation.dtob.WorkingLocationRequest;



/**
 * @author ajit.p
 *
 */

public interface WorkingLocationService {

	public String search(String search);

	public String getAllWorkingLocations();

	public String getAllWorkingLocationsByPage(int page, int limit);

	public String getWorkingLocationsById(Long id);

	public String getWorkingLocationsByOrgCode(String organizationCode);

	public String saveWorkingLocations(WorkingLocationRequest workingLocation,
			String ip);

	public String deleteWorkingLoccationsById(Long id);

	public String deleteWorkingLoccationsByWorkingLocationCode(String workingLocationCode);

	public String softDeleteWorkingLoccationsByWorkingLocationCode(String workingLocationCode);

	public String softMultipleDeleteByWorkingLocationCode(List<String> workingLocationCodeList);

	public String updateWorkingLocations(
			WorkingLocationRequest workingLocation, Long id, String ip);

}
