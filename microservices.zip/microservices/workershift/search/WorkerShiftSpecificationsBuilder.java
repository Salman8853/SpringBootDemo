package com.gigflex.prototype.microservices.workershift.search;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.gigflex.prototype.microservices.util.SearchCriteria;
import com.gigflex.prototype.microservices.workershift.dtob.WorkerShift;


public class WorkerShiftSpecificationsBuilder {
	private final List<SearchCriteria> params;
	 
    public WorkerShiftSpecificationsBuilder() {
        params = new ArrayList<SearchCriteria>();
    }
 
    public WorkerShiftSpecificationsBuilder with(String key, String operation, Object value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }
 
    public Specification<WorkerShift> build() {
        if (params.size() == 0) {
            return null;
        }
 
        List<Specification<WorkerShift>> specs = new ArrayList<Specification<WorkerShift>>();
        for (SearchCriteria param : params) {
            specs.add(new WorkerShiftSpecification(param));
        }
 
        Specification<WorkerShift> result = specs.get(0);
        for (int i = 1; i < specs.size(); i++) {
            result = Specification.where(result).and(specs.get(i));
        }
        return result;
    }
}
