/**
 * 
 */
package com.gigflex.prototype.microservices.workershift.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.gigflex.prototype.microservices.workershift.dtob.WorkerShift;

/**
 * @author ajit.p
 */
@Repository
public interface WorkerShiftRepository extends JpaRepository<WorkerShift, Long>,JpaSpecificationExecutor<WorkerShift>{

    @Query("SELECT ws FROM WorkerShift ws WHERE ws.workerCode=:workerCode AND ws.organizationCode=:organizationCode")
    public WorkerShift getShiftWorkerByOrganizationCode(@Param("workerCode") String workerCode, @Param("organizationCode") String organizationCode);

}

