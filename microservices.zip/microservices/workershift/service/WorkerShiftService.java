package com.gigflex.prototype.microservices.workershift.service;

import com.gigflex.prototype.microservices.workershift.dtob.WorkerShiftRequest;

public interface WorkerShiftService {
	public String search(String search);
	
	public String saveWorkerShift(WorkerShiftRequest workerShiftReq, String ip);

	public String updateWorkerShift(Long id, WorkerShiftRequest workerShiftReq, String ip);
	
}
