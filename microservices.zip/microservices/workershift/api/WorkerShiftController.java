/**
 * 
 */
package com.gigflex.prototype.microservices.workershift.api;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.workershift.dtob.WorkerShiftRequest;
import com.gigflex.prototype.microservices.workershift.service.WorkerShiftService;

/**
 * @author ajit.p
 *
 */
@CrossOrigin(origins="*")
@RestController
@RequestMapping("/healthcareservice/")
public class WorkerShiftController {

	@Autowired
	WorkerShiftService workerShiftService;
	
	@GetMapping("/workerShift/{search}")
	public String search(@PathVariable("search") String search) {
		return workerShiftService.search(search);
	}
	
	
	@PostMapping("/saveWorkerShift")
	public String saveWorkerShift(
			 @RequestBody WorkerShiftRequest workerShiftReq,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return workerShiftService.saveWorkerShift(workerShiftReq, ip);

	}
	
	@PutMapping("/updateWorkerShiftById/{id}")
	public String updateWorkerShiftById(@PathVariable Long id,
			 @RequestBody  WorkerShiftRequest workerShiftReq,
			HttpServletRequest request) {
		if (id != null && workerShiftReq!=null) {
			
			String ip = request.getRemoteAddr();

			return workerShiftService.updateWorkerShift(id, workerShiftReq, ip);
		 } else {
                GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
                return derr.toString();
            }
	}
}

